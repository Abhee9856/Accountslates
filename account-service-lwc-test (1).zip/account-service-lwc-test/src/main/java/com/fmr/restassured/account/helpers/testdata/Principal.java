package com.fmr.restassured.account.helpers.testdata;

import static org.hamcrest.Matchers.equalTo;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.velocity.VelocityContext;

import com.fmr.pap.restassured.core.BaseServiceTest;
import com.fmr.pap.restassured.core.ServiceVersion;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.constants.EnvironmentConstants;

public class Principal extends BaseServiceTest
{
	/**  */
	private String ppid;
	
	/**  */
	private String mid;
	
	/**  */
	private Scenario scenario = null;
	
	VelocityContext context = new VelocityContext();
	
	/**  */
	private static final String IDENTITY_PRINCIPAL_CREATE_PATH = "/identity/principal/create";

	/**  */
	private static final String IDENTITY_HOUSEHOLD_INSERT_PATH = "/identity/household/insert";
	
	/**
	 * @param mid
	 */
	public Principal(final String mid)
	{
		this.mid = mid;
	}

	/**
	 * @return
	 */
	public String getPpid()
	{
		return ppid;
	}

	/**
	 * @param ppid
	 */
	public void setPpid(final String ppid)
	{
		this.ppid = ppid;
	}

	/**
	 * @return
	 */
	public Scenario getScenario()
	{
		return scenario;
	}
	
	/**
	 * @param mid
	 * @return
	 */
	public String createPrincipalHouseholdWithScenario(final String productCode, final String categoryCode)
	{
		this.scenario = new Scenario(productCode, categoryCode);
		
		context.put("productCode", this.scenario.productCode);
		context.put("categoryCode", this.scenario.categoryCode);
		context.put("mid", mid);
		
		//Build request body, set the host, and retrieve the resource path
		setServiceBaseURIConfig(Services.Identity, ServiceVersion._201410);

		setOAuthRequestHeader();
		
		//Build request body, set the host, and retrieve the resource path
		request.body(IOUtil.generateJsonRequest
				(context, AccountConstants.SCENARIO_INSERT_TEMPLATE));
		
		//Call Account service
		response = request.post(IDENTITY_PRINCIPAL_CREATE_PATH);
		
		//Assert on response
		response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true));
		
		//Save the ppid after creating principal
		this.ppid = response.path("principal.planningPartyId").toString();
		
		//Create a scenario and save the ID
		this.setScenarioId(createSingleScenario());
		
		//Create the household Identity with the scenario.
		createHouseholdIdentity();
		
		return this.ppid;
	}

	/**
	 * @param productCode
	 * @param categoryCode
	 * @return
	 */
	private String createSingleScenario()
	{				
		PropertiesConfiguration config = setServiceBaseURIConfig(Services.Scenario, ServiceVersion._201410);
		String scenarioPath = config.getString(EnvironmentConstants.SCENARIO_INSERT);
		setOAuthRequestHeader();
		
		//Build request body, set the host, and retrieve the resource path
		request.body(IOUtil.generateJsonRequest
				(context, AccountConstants.SCENARIO_INSERT_TEMPLATE));
		
		//Call Account service
		response = request.post(scenarioPath);
		
		//Assert on response
		response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true));
		
		return response.path("scenario.scenario[0].id").toString();
	}

	/**
	 * @return
	 */
	/**
	 * @return
	 */
	private boolean createHouseholdIdentity()
	{
		context.put("scenarioId", this.scenario.scenarioId);
		
		setServiceBaseURIConfig(Services.Identity, ServiceVersion._201410);
		setOAuthRequestHeader();
		
		//Build request body, set the host, and retrieve the resource path
		request.body(IOUtil.generateJsonRequest
				(context, AccountConstants.IDENTITY_SCENARIO_CREATE_TEMPLATE));
		
		//Call Account service
		response = request.post(IDENTITY_HOUSEHOLD_INSERT_PATH);
		
		//Assert on response
		response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true));
		
		return response.path("resultCode");
		
	}
	
	/**
	 * @return
	 */
	public String getProductCode()
	{
		return this.scenario.productCode;
	}

	/**
	 * @param productCode
	 */
	public void setProductCode(final String productCode)
	{
		this.scenario.productCode = productCode;
	}

	/**
	 * @return
	 */
	public String getCategoryCode()
	{
		return scenario.categoryCode;
	}

	/**
	 * @param categoryCode
	 */
	public void setCategoryCode(final String categoryCode)
	{
		this.scenario.categoryCode = categoryCode;
	}

	/**
	 * @return
	 */
	public String getScenarioId()
	{
		return this.scenario.scenarioId;
	}

	/**
	 * @param scenarioId
	 */
	public void setScenarioId(final String scenarioId)
	{
		this.scenario.scenarioId = scenarioId;
	}

	/**
	 * @author a601767
	 *
	 */
	private class Scenario
	{
		private String productCode;
		
		private String categoryCode;
		
		private String scenarioId;
		
		public Scenario(final String productCode, final String categoryCode)
		{
			this.productCode = productCode;
			this.categoryCode = categoryCode;
		}

		
		
	}
}
