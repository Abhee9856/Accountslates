package com.fmr.restassured.account.helpers.testdata.dto;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * Contains tax rates related test data. Instantiates with default data, but can be updated.
 *
 * @author a631781
 */
@Entity
public class AccountTaxRatesTestData
{
    
    @Column(name = "test_name")
    private String testName = "account_accountTaxRate_get";
    
    @Column(name = "test_desc")
    private String testDescription = "Testing Taxrates for Retail customer";
    
    @Column(name = "test_env")
    private String testEnvironment = "DEF";
    
    @Column(name = "ssn")
    private String ssn = "434313740";
    
    @Column(name = "realm")
    private String realm = "Retail";
    
    @Column(name = "account_number")
    private String accountNumber = "X31254053";
    
    @Column(name = "source_system")
    private String sourceSystem = "RETAIL";
    
    public AccountTaxRatesTestData()
    {
        super();
    }
    
    /**
     * @param testName
     * @param testDescription
     * @param testEnvironment
     * @param ssn
     * @param realm
     * @param accountNumber
     * @param sourceSystem
     */
    public AccountTaxRatesTestData(String testName, String testDescription, String testEnvironment, String ssn,
            String realm, String accountNumber, String sourceSystem)
    {
        this.testName = testName;
        this.testDescription = testDescription;
        this.testEnvironment = testEnvironment;
        this.ssn = ssn;
        this.realm = realm;
        this.accountNumber = accountNumber;
        this.sourceSystem = sourceSystem;
    }
    
    /**
     * @return the testName
     */
    public String getTestName()
    {
        return testName;
    }
    
    /**
     * @param testName the testName to set
     */
    public void setTestName()
    {
        this.testName = testName;
    }
    
    /**
     * @return the testDescription
     */
    public String getTestDescription()
    {
        return testDescription;
    }
    
    /**
     * @param testDescription the testDescription to set
     */
    public void setTestDescription()
    {
        this.testDescription = testDescription;
    }
    
    /**
     * @return the testEnvironment
     */
    public String getTestEnvironment()
    {
        return testEnvironment;
    }
    
    /**
     * @param testEnvironment the testEnvironment to set
     */
    public void setTestEnvironment()
    {
        this.testEnvironment = testEnvironment;
    }
    
    /**
     * @return the ssn
     */
    public String getSsn()
    {
        return ssn;
    }
    
    /**
     * @param ssn the ssn to set
     */
    public void setSsn()
    {
        this.ssn = ssn;
    }
    
    /**
     * @return the realm
     */
    public String getRealm()
    {
        return realm;
    }
    
    /**
     * @param realm the realm to set
     */
    public void setRealm()
    {
        this.realm = realm;
    }
    
    /**
     * @return the accountNumber
     */
    public String getAccountNumber()
    {
        return accountNumber;
    }
    
    /**
     * @param accountNumber the accountNumber to set
     */
    public void setAccountNumber()
    {
        this.accountNumber = accountNumber;
    }
    
    /**
     * @return the sourceSystem
     */
    public String getSourceSystem()
    {
        return sourceSystem;
    }
    
    /**
     * @param sourceSystem the sourceSystem to set
     */
    public void setSourceSystem()
    {
        this.sourceSystem = sourceSystem;
    }
    
}
