/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers;

/**
 * Constants used as test flow tags
 *
 * @author a601767
 */
public class Tags {

    // Account Types
    /**
     * The constant
     */
    public static final String RETAIL = "retail";

    /**
     * The constant
     */
    public static final String FULLVIEW = "fullview";

    /**
     * The constant
     */
    public static final String FILI = "fili";

    /**
     * The constant
     */
    public static final String WORKPLACE = "workplace";

    /**
     * The constant
     */
    public static final String MANUAL = "manual";

    /**
     * The constant
     */
    public static final String DIGITAL = "digital";

    //Functionality
    /**
     * The constant TARGET_ACCOUNT
     */
    public static final String TARGET_ACCOUNT = "targetAccount";

    /**
     * The constant MATCH_TIERS
     */
    public static final String MATCH_TIERS = "matchTiers";


    // Operations
    public static final String ACCOUNT = "account";

    public static final String COMPOSITE = "composite";

    public static final String DETAILS = "details";

    public static final String CONTRIBUTIONS = "contributions";

    public static final String POSITIONS = "positions";

    public static final String RELATIONS = "relations";

    public static final String NEGATIVE = "negative";

    public static final String WITHDRAWALS = "withdrawals";

    public static final String TAXRATES = "taxrates";

    public static final String GRANTS = "grants";

    public static final String GET = "get";

    public static final String CRUD = "crud";

    public static final String SUITABILITY = "suitability";

    public static final String HYPO_FUND_TRANSFER = "hypotheticalfundtransfer";

    public static final String REAL_TIME_DATA = "realtimedata";

    public static final String ACCNUM = "accnum";
    
    public static final String AssetAllocation = "assetAllocation";

    public static final String MAUI = "maui";
    public static final String PRDC_DATA = "prdcdata";
    
    /** The constant GROUP */
    public static final String GROUP = "group";

    // Versions
    /**
     * The constant
     */
    public static final String V2014_10 = "2014_10";

    /**
     * The constant
     */
    public static final String V1 = "v1";

    /**
     * The constant
     */
    public static final String V2 = "v2";


    // Flow constants
    /**
     * The constant
     */
    public static final String REGRESSION = "regression";

    /**
     * The constant
     */
    public static final String PIPELINE = "pipeline";

    /**
     * The constant
     */
    public static final String ASYNCHRONOUS = "asynchronous";

    /**
     * The constant
     */
    public static final String SYNCHRONOUS = "synchronous";

    public static final String ADVISOR_BALANCES = "advisorBalances";
    /**
     * The constant
     */
    public static final String CRITICAL = "critical";
    public static final String TAM = "targetAssetMix";

    private Tags() {
        throw new IllegalStateException("Constant Class");
    }
}