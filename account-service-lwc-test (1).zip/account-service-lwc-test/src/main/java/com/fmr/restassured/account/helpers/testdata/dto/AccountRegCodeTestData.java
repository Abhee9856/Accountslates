/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.dto;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * Test data object for AccountRegCodeTestData to be used in DataProvider
 *
 * @author a653510
 *
 */
@Entity
public class AccountRegCodeTestData
{

	@Column(name = "ssn")
	private String ssn;

	@Column(name = "account_type")
	private String accountType;

	@Column(name = "accountTypeCode")
	private String accountTypeCode;

	@Column(name = "legalConstructCode")
	private String legalConstructCode;

	@Column(name = "legalConstructModifierCode")
	private String legalConstructModifierCode;

	@Column(name = "midInRequest")
	private String midInRequest;

	@Column(name = "src_based_regfilter")
	private String srcFilter;

	@Column(name = "regCode1")
	private String regCode1;

	@Column(name = "regCode2")
	private String regCode2;

	@Column(name = "regCode3")
	private String regCode3;

	@Column(name = "filterType")
	private String filterType;

	@Column(name = "poe")
	private String poe;

    @Column(name = "transferType")
    private String transferType;

	@Column(name = "isFullviewDetailOverridden")
	private String isFullviewDetailOverridden;
	/**
	 * @return the ssn
	 */
	public String getSsn()
	{
		return ssn;
	}


	/**
	 * @param ssn the ssn to set
	 */
	public void setSsn(String ssn)
	{
		this.ssn = ssn;
	}


	/**
	 * @return the accountType
	 */
	public String getAccountType()
	{
		return accountType;
	}


	/**
	 * @param accountType the accountType to set
	 */
	public void setAccountType(String accountType)
	{
		this.accountType = accountType;
	}


	/**
	 * @return the accountTypeCode
	 */
	public String getAccountTypeCode()
	{
		return accountTypeCode;
	}


	/**
	 * @param accountTypeCode the accountTypeCode to set
	 */
	public void setAccountTypeCode(String accountTypeCode)
	{
		this.accountTypeCode = accountTypeCode;
	}

	/**
	 * @return the legalConstructCode
	 */
	public String getLegalConstructCode()
	{
		return legalConstructCode;
	}


	/**
	 * @param legalConstructCode the legalConstructCode to set
	 */
	public void setLegalConstructCode(String legalConstructCode)
	{
		this.legalConstructCode = legalConstructCode;
	}

	/**
	 * @return the legalConstructModifierCode
	 */
	public String getLegalConstructModifierCode()
	{
		return legalConstructModifierCode;
	}


	/**
	 * @param legalConstructModifierCode the legalConstructCode to set
	 */
	public void setLegalConstructModifierCode(String legalConstructModifierCode)
	{
		this.legalConstructModifierCode = legalConstructModifierCode;
	}


	/**
	 * @return the midInRequest
	 */
	public String getMidInRequest()
	{
		return midInRequest;
	}


	/**
	 * @param midInRequest the midInRequest to set
	 */
	public void setMidInRequest(String midInRequest)
	{
		this.midInRequest = midInRequest;
	}


	/**
	 * @return the srcFilter
	 */
	public String getSrcFilter()
	{
		return srcFilter;
	}


	/**
	 * @param srcFilter the srcFilter to set
	 */
	public void setSrcFilter(String srcFilter)
	{
		this.srcFilter = srcFilter;
	}


	/**
	 * @return the regCode1
	 */
	public String getRegCode1()
	{
		return regCode1;
	}


	/**
	 * @param regCode1 the regCode1 to set
	 */
	public void setRegCode1(String regCode1)
	{
		this.regCode1 = regCode1;
	}


	/**
	 * @return the regCode2
	 */
	public String getRegCode2()
	{
		return regCode2;
	}


	/**
	 * @param regCode2 the regCode2 to set
	 */
	public void setRegCode2(String regCode2)
	{
		this.regCode2 = regCode2;
	}


	/**
	 * @return the regCode3
	 */
	public String getRegCode3()
	{
		return regCode3;
	}


	/**
	 * @param regCode3 the regCode3 to set
	 */
	public void setRegCode3(String regCode3)
	{
		this.regCode3 = regCode3;
	}


	/**
	 * @return the filterType
	 */
	public String getFilterType()
	{
		return filterType;
	}


	/**
	 * @param filterType the filterType to set
	 */
	public void setFilterType(String filterType)
	{
		this.filterType = filterType;
	}


	/**
	 * @return the poe
	 */
	public String getPoe()
	{
		return poe;
	}


	/**
	 * @param poe the poe to set
	 */
	public void setPoe(String poe)
	{
		this.poe = poe;
	}

    /**
     * @return the transferType
     */
    public String getTransferType()
    {
        return transferType;
    }

    /**
     * @param transferType the transferType to set
     */
    public void setTransferType(String transferType)
    {
        this.transferType = transferType;
    }

	/**
	 * @return the getIsFullviewDetailOverridden
	 */
	public String getIsFullviewDetailOverridden() {
		return isFullviewDetailOverridden;
	}
	/**
	 * @param isFullviewDetailOverridden the isFullviewDetailOverridden to set
	 */
	public void setIsFullviewDetailOverridden(String isFullviewDetailOverridden) {
		this.isFullviewDetailOverridden = isFullviewDetailOverridden;
	}

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString()
    {
	return "AccountRegCodeTestData [ssn=" + ssn + ", account_type=" + accountType + ", regCode1=" + regCode1
			+ ", regCode2=" + regCode2 + ", regCode3=" + regCode3 + ", srcFilter=" + srcFilter
			+ ", midInRequest="
			+ midInRequest + ", poe=" + poe + ", fcpsid=" + accountTypeCode + ", filterType=" + filterType
			+ "]";
    }

}
