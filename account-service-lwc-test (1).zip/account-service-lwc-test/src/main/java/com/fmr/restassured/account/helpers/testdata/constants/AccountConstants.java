/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.constants;

public class AccountConstants {


    // V1
    public static final String ACCOUNT_GET_TEMPLATE = "/template/account/account_get.vm";
    public static final String ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE = "/template/account/account_get_with_scenario_id_v1.vm";
    public static final String ACCOUNT_CREATE_TEMPLATE = "/template/account/account_create.vm";
    public static final String ACCOUNT_CREATE_NULL_DISPLAY_NAME_TEMPLATE = "/template/account/account_create_null_displayName.vm";
    public static final String ACCOUNT_CREATE_TEMPLATE_NO_DISPLAYNAME = "/template/account/account_create_without_displayName.vm";
    public static final String ACCOUNT_CREATE_WITH_SCENARIO_ID_TEMPLATE = "/template/account/account_create_with_scenario_id_v1.vm";
    public static final String ACCOUNT_CREATE_PARTNER_DEPENDENT_TEMPLATE =
            "/template/account/account_create_partner_dependent.vm";
    public static final String ACCOUNT_UPDATE_TEMPLATE = "/template/account/account_update.vm";
    public static final String ACCOUNT_UPDATE_TEMPLATE_NO_DISPLAYNAME = "/template/account/account_update_without_displayName.vm";
    public static final String ACCOUNT_UPDATE_WITH_SCENARIO_ID_TEMPLATE = "/template/account/account_update_with_scenario_id_v1.vm";
    public static final String ACCOUNT_DELETE_TEMPLATE = "/template/account/account_delete.vm";
    public static final String ACCOUNT_DELETE_V1_TEMPLATE_FOR_GRANTS = "/template/account/grants/account_delete_v1_for_grants.vm";
    public static final String TARGET_ACCOUNT_CREATE_TEMPLATE = "/template/account/target_account.vm";
    public static final String ACCOUNT_COMPOSITE_GET_TEMPLATE = "/template/account/account_get.vm";
    public static final String ACCOUNT_COMPOSITE_CREATE_TEMPLATE = "/template/account/account_composite_create.vm";
    public static final String ACCOUNT_COMPOSITE_CREATE_2_ACCOUNT_TEMPLATE = "/template/account/account_composite_create_2_accounts.vm";
    public static final String ACCOUNT_COMPOSITE_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE
            = "/template/account/account_composite_suitability_only_preferences_create_v1.vm";
    public static final String ACCOUNT_COMPOSITE_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V2
            = "/template/account/account_composite_suitability_only_preferences_create_v2.vm";
    public static final String ACCOUNT_COMPOSITE_CREATE_UPDATE_TEMPLATE_V1 = "/template/account/account_composite_create_update_v1.vm";
    public static final String ACCOUNT_COMPOSITE_CREATE_UPDATE_TEMPLATE_V2 = "/template/account/account_composite_create_update_v2.vm";
    public static final String ACCOUNT_COMPOSITE_UPDATE_TEMPLATE = "/template/account/account_composite_update.vm";
    public static final String ACCOUNT_COMPOSITE_DELETE_TEMPLATE = "/template/account/account_composite_delete.vm";
    public static final String ACCOUNT_DETAILS_GET_TEMPLATE = "/template/account/account_details_get.vm";
    public static final String ACCOUNT_DETAILS_CREATE_TEMPLATE = "/template/account/account_details_create.vm";
    public static final String ACCOUNT_DETAILS_UPDATE_TEMPLATE = "/template/account/account_details_create.vm";
    public static final String ACCOUNT_DETAILS_UPDATE_NULL_TEMPLATE =
            "/template/account/account_details_create_null.vm";
    public static final String ACCOUNT_DETAILS_DELETE_TEMPLATE = "/template/account/account_details_create.vm";
    public static final String ACCOUNT_DETAILS_GET_TEMPLATE_V2 = "/template/account/account_details_get_v2.vm";
    public static final String ACCOUNT_DETAILS_CREATE_TEMPLATE_V2 = "/template/account/account_details_create_v2.vm";
    public static final String ACCOUNT_POSITIONS_SET_TEMPLATE = "/template/account/account_positions_set.vm";
    public static final String ACCOUNT_POSITIONS_GET_TEMPLATE = "/template/account/account_get.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_GET_TEMPLATE = "/template/account/account_get.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_CREATE_TEMPLATE =
            "/template/account/contributions/account_contributions_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_UPDATE_TEMPLATE =
            "/template/account/contributions/account_contributions_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_DELETE_TEMPLATE =
            "/template/account/contributions/account_contributions_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_GET_TEMPLATE = "/template/account/account_get.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_CREATE_TEMPLATE =
            "/template/account/contributions/account_contributions_matchtiers_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_UPDATE_TEMPLATE =
            "/template/account/contributions/account_contributions_matchtiers_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_DELETE_TEMPLATE =
            "/template/account/contributions/account_contributions_matchtiers_create.vm";
    public static final String ACCOUNT_GRANTS_GET_TEMPLATE = "/template/account/grants/account_grants_get.vm";
    public static final String ACCOUNT_GRANTS_CREATE_TEMPLATE = "/template/account/grants/account_grants_create.vm";
    public static final String ACCOUNT_GRANTS_UPDATE_TEMPLATE = "/template/account/grants/account_grants_create.vm";
    public static final String ACCOUNT_GRANTS_DELETE_TEMPLATE = "/template/account/grants/account_grants_create.vm";
    public static final String ACCOUNT_GRANTS_CREATE_201410_TEMPLATE =
            "/template/account/account_grants_create_201410.vm";
    public static final String ACCOUNT_GRANTS_UPDATE_201410_TEMPLATE =
            "/template/account/account_grants_create_201410.vm";
    public static final String ACCOUNT_GRANTS_DELETE_201410_TEMPLATE =
            "/template/account/account_grants_create_201410.vm";
    public static final String ACCOUNT_RELATIONS_GET_TEMPLATE = "/template/account/account_with_scenario_get.vm";
    public static final String ACCOUNT_RELATIONS_CREATE_TEMPLATE =
            "/template/account/relations/account_v1_relations_create.vm";
    public static final String ACCOUNT_RELATIONS_UPDATE_TEMPLATE =
            "/template/account/relations/account_v1_relations_create.vm";
    public static final String ACCOUNT_RELATIONS_DELETE_TEMPLATE =
            "/template/account/relations/account_v1_relations_create.vm";
    public static final String ACCOUNT_RELATIONS_GET_V1_TEMPLATE = "/template/account/account_with_scenario_get.vm";
    public static final String ACCOUNT_RELATIONS_CREATE_V1_TEMPLATE = "/template/account/relations/account_relations_create.vm";
    public static final String ACCOUNT_RELATIONS_UPDATE_V1_TEMPLATE =
            "/template/account/relations/account_relations_create.vm";
    public static final String ACCOUNT_RELATIONS_DELETE_V1_TEMPLATE =
            "/template/account/relations/account_relations_create.vm";
    public static final String ACCOUNT_RELATIONS_CREATE_HH_TEMPLATE =
            "/template/account/relations/account_relations_households.vm";
    public static final String ACCOUNT_RELATIONS_UPDATE_HH_TEMPLATE =
            "/template/account/relations/account_relations_households.vm";
    public static final String ACCOUNT_RELATIONS_DELETE_HH_TEMPLATE =
            "/template/account/relations/account_relations_households.vm";
    public static final String ACCOUNT_RELATIONS_CREATE_MULTIPLE_TEMPLATE =
            "/template/account/relations/account_relations_multiple_create.vm";
    public static final String ACCOUNT_RELATIONS_UPDATE_MULTIPLE_TEMPLATE =
            "/template/account/relations/account_relations_multiple_create.vm";
    public static final String ACCOUNT_RELATIONS_DELETE_MULTIPLE_TEMPLATE =
            "/template/account/relations/account_relations_multiple_create.vm";
    public static final String ACCOUNT_RELATIONS_CREATE_MULTI_ACCT_TEMPLATE =
            "/template/account/relations/account_v1_relations_create_multiple_accounts.vm";
    public static final String ACCOUNT_RELATIONS_UPDATE_MULTI_ACCT_TEMPLATE =
            "/template/account/relations/account_v1_relations_create_multiple_accounts.vm";
    public static final String ACCOUNT_RELATIONS_DELETE_MULTI_ACCT_TEMPLATE =
            "/template/account/relations/account_v1_relations_create_multiple_accounts.vm";
    public static final String ACCOUNT_SUITABILITY_GET_TEMPLATE = "/template/account/account_get.vm";
    public static final String ACCOUNT_SUITABILITY_GET_TEMPLATE_V2 = "/template/account/suitability/account_suitability_v2_get.vm";
    public static final String ACCOUNT_SUITABILITY_CREATE_TEMPLATE = "/template/account/suitability/account_suitability_create.vm";
    public static final String ACCOUNT_SUITABILITY_UPDATE_TEMPLATE = "/template/account/suitability/account_suitability_create.vm";
    public static final String ACCOUNT_SUITABILITY_CREATE_TEMPLATE_V1 = "/template/account/suitability/account_suitability_create_v1.vm";
    public static final String ACCOUNT_SUITABILITY_CREATE_TEMPLATE_V2 = "/template/account/suitability/account_suitability_create_v2.vm";
    public static final String ACCOUNT_SUITABILITY_UPDATE_TEMPLATE_V1 = "/template/account/suitability/account_suitability_create_v1.vm";
    public static final String ACCOUNT_SUITABILITY_UPDATE_TEMPLATE_V2 = "/template/account/suitability/account_suitability_create_v2.vm";
    public static final String ACCOUNT_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V1
            = "/template/account/suitability/account_suitability_only_preferences_create_v1.vm";
    public static final String ACCOUNT_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V2
            = "/template/account/suitability/account_suitability_only_preferences_create_v2.vm";
    public static final String ACCOUNT_WITHDRAWALS_CREATE_TEMPLATE =
            "/template/account/withdrawals/account_withdrawals_create.vm";
    public static final String ACCOUNT_WITHDRAWALS_DELETE_TEMPLATE =
            "/template/account/withdrawals/account_withdrawals_create.vm";
    public static final String ACCOUNT_WITHDRAWALS_UPDATE_TEMPLATE =
            "/template/account/withdrawals/account_withdrawals_create.vm";
    public static final String ACCOUNT_WITHDRAWALS_GET_TEMPLATE = "/template/account/account_get.vm";
    public static final String ACCOUNT_POSITION_GET_TEMPLATE_V1 = "/template/account/account_position_v1_get.vm";
    // V2
    public static final String ACCOUNT_GET_TEMPLATE_V2 = "/template/account/account_v2_get.vm";
    public static final String ACCOUNT_CREATE_TEMPLATE_V2 = "/template/account/account_v2_create.vm";
    public static final String ACCOUNT_CREATE_TEMPLATE_V2_NO_DISPLAYNAME = "/template/account/account_v2_create_no_displayname.vm";
    public static final String ACCOUNT_CREATE_PARTNER_DEPENDENT_TEMPLATE_V2 =
            "/template/account/account_create_partner_dependent_v2.vm";
    public static final String ACCOUNT_UPDATE_TEMPLATE_V2 = "/template/account/account_v2_create.vm";
    public static final String ACCOUNT_DELETE_TEMPLATE_V2 = "/template/account/account_v2_create.vm";
    public static final String TARGET_ACCOUNT_CREATE_V2_TEMPLATE = "/template/account/target_account_v2.vm";
    public static final String TARGET_ACCOUNT_GET_V2_TEMPLATE = "/template/account/target_account_v2.vm";
    public static final String TARGET_ACCOUNT_UPDATE_V2_TEMPLATE = "/template/account/target_account_v2.vm";
    public static final String TARGET_ACCOUNT_DELETE_V2_TEMPLATE = "/template/account/target_account_v2.vm";
    public static final String ACCOUNT_COMPOSITE_GET_TEMPLATE_V2 = "/template/account/account_v2_composite_get.vm";
    public static final String ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2 =
            "/template/account/account_v2_composite_create.vm";
    public static final String ACCOUNT_COMPOSITE_CREATE_ESOP_TEMPLATE_V2 =
            "/template/account/account_v2_composite_create_ESOP.vm";
    public static final String ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2 =
            "/template/account/account_v2_composite_create.vm";
    public static final String ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2 =
            "/template/account/account_v2_composite_delete.vm";
    public static final String ACCOUNT_DETAILS_GET_V2_TEMPLATE = "/template/account/account_v2_get.vm";
    public static final String ACCOUNT_DETAILS_CREATE_V2_TEMPLATE = "/template/account/account_v2_details_create.vm";
    public static final String ACCOUNT_DETAILS_UPDATE_V2_TEMPLATE = "/template/account/account_v2_details_create.vm";
    public static final String ACCOUNT_DETAILS_UPDATE_V2_NULL_TEMPLATE =
            "/template/account/account_details_create_null.vm";
    public static final String ACCOUNT_DETAILS_DELETE_V2_TEMPLATE = "/template/account/account_v2_details_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE = "/template/account/account_v2_get.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_CREATE_V2_TEMPLATE =
            "/template/account/contributions/account_v2_contributions_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_UPDATE_V2_TEMPLATE =
            "/template/account/contributions/account_v2_contributions_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_DELETE_V2_TEMPLATE =
            "/template/account/contributions/account_v2_contributions_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_GET_V2_TEMPLATE =
            "/template/account/account_v2_get.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_CREATE_V2_TEMPLATE =
            "/template/account/contributions/account_v2_contributions_matchtiers_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_UPDATE_V2_TEMPLATE =
            "/template/account/contributions/account_v2_contributions_matchtiers_create.vm";
    public static final String ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_DELETE_V2_TEMPLATE =
            "/template/account/contributions/account_v2_contributions_matchtiers_create.vm";
    public static final String ACCOUNT_WITHDRAWALS_CREATE_V2_TEMPLATE =
            "/template/account/withdrawals/account_withdrawals_create_v2.vm";
    public static final String ACCOUNT_WITHDRAWALS_DELETE_V2_TEMPLATE =
            "/template/account/withdrawals/account_withdrawals_create_v2.vm";
    public static final String ACCOUNT_WITHDRAWALS_UPDATE_V2_TEMPLATE =
            "/template/account/withdrawals/account_withdrawals_create_v2.vm";
    public static final String ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE = "/template/account/account_v2_get.vm";
    public static final String ACCOUNT_RELATIONS_GET_V2_TEMPLATE = "/template/account/account_v2_get.vm";
    public static final String ACCOUNT_RELATIONS_CREATE_V2_TEMPLATE =
            "/template/account/relations/account_v2_relations_create.vm";
    public static final String ACCOUNT_RELATIONS_UPDATE_V2_TEMPLATE =
            "/template/account/relations/account_v2_relations_create.vm";
    public static final String ACCOUNT_RELATIONS_DELETE_V2_TEMPLATE =
            "/template/account/relations/account_v2_relations_create.vm";
    /*Templates for Grants v2 */
    public static final String ACCOUNT_GRANTS_GET_TEMPLATE_V2 = "/template/account/grants/account_grants_get_v2.vm";
    public static final String ACCOUNT_GRANTS_CREATE_TEMPLATE_V2 = "/template/account/grants/account_grants_create_v2.vm";
    public static final String ACCOUNT_GRANTS_UPDATE_TEMPLATE_V2 = "/template/account/grants/account_grants_create_v2.vm";
    public static final String ACCOUNT_GRANTS_DELETE_TEMPLATE_V2 = "/template/account/grants/account_grants_create_v2.vm";
    public static final String IDENTITY_SCENARIO_CREATE_TEMPLATE = "/template/identity/create_identity_scenario.vm";
    public static final String SCENARIO_INSERT_TEMPLATE = "/template/scenario/scenario_insert.vm";
    public static final String DEFAULT_SSN = "account_default_ssn";
    public static final String DEFAULT_SSN_FV = "default_ssn_fullview";
    public static final String DEFAULT_SSN_WORKPLACE = "default_ssn_workplace";
    public static final String DEFAULT_SSN_FILI = "default_ssn_fili";
    public static final String DEFAULT_SID = "883f8ed8-c928-11d8-b67a-ac196951aa77";
    public static final String RETAIL_ACCOUNT_DETAILS_TYPE = "com.fmr.ast.platform.account.domain.RetailAccountDetails";
    public static final String RETAIL_ACCOUNT_DETAILS = "ManualAccountDetails";
    public static final String FILI_ACCOUNT_DETAILS_TYPE = "com.fmr.ast.platform.account.domain.AnnuityAccountDetails";
    public static final String FILI_ACCOUNT_DETAILS = "AnnuityAccountDetails";
    public static final String FULLVIEW_ACCOUNT_DETAILS_TYPE =
            "com.fmr.ast.platform.account.domain.FullviewAccountDetails";
    public static final String FULLVIEW_ACCOUNT_DETAILS = "FullviewAccountDetails";
    public static final String MANUAL_ACCOUNT_DETAILS_TYPE = "com.fmr.ast.platform.account.domain.ManualAccountDetails";
    public static final String MANUAL_ACCOUNT_DETAILS = "ManualAccountDetails";
    public static final String WORKPLACE_ACCOUNT_DETAILS_TYPE =
            "com.fmr.ast.platform.account.domain.WorkplaceAccountDetails";
    public static final String WORKPLACE_ACCOUNT_DETAILS = "WorkplaceAccountDetails";
    public static final int HTTP_200 = 200;
    public static final String RETAIL = "RETAIL";
    public static final String MANUAL = "MANUAL";
    public static final String FULLVIEW = "FULLVIEW";
    public static final String FILI = "FILI";
    public static final String WORKPLACE = "WORKPLACE";
    public static final String NETBENEFITS = "NETBENEFITS";
    public static final String MID = "mid";
    public static final String RETAIL_LID = "retailLid";
    public static final String FESCO_LID = "fescoLid";
    public static final String FILI_LID = "filiLid";
    public static final String CALLING_APP_ID = "AP136091";
    public static final String APP_ID = "AP136091";
    public static final String TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_VM =
            "/template/account/account_position_set_v2.vm";
    public static final String TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_NEGATIVE_VM =
            "/template/account/account_position_set_v2_negative.vm";
    public static final String ACCOUNT_RELATIONS_DELETE_NEGATIVE_TEMPLATE =
            "/template/account/relations/account_relations_delete_noAccount.vm";
    public static final String ACCOUNT_TAX_RATES_V1_TEMPLATE = "/template/account/taxrates/account_taxrates_get_v1.vm";
    public static final String ACCOUNT_TAX_RATES_V2_TEMPLATE = "/template/account/taxrates/account_taxrates_get_v2.vm";
    public static final String ACCOUNT_DSS_BALANCE_V2_TEMPLATE = "/template/dss/get_dss_balance_v2.vm";

    public static final String WDS_GET_TEMPLATE = "/template/prdc/get_wds.vm";
    public static final String WDS_GET_PATH = "/ws-cds-person/webapi/v1/persons/person-get/wid";
    public static final String ACCOUNT_MAUI_V2_TEMPLATE = "/template/maui/account_maui_v2.vm";
    public static final String TEMPLATE_DSS_POSITION_V2 = "/template/dss/get_dss_positions_v2.vm";
    public static final String DSS_ACCOUNT_BASE_URI = "https://dpservice-uat-aws.fmr.com";
    public static final String APIGEE_BASE_URI_QA = "https://api-pi-stage.fmr.com";
    public static final String VM_PLAN_BASE_URI = "https://dc-plan-acp.fmr.com";
    public static final String WDS_BASE_URI = "https://ws-cds-person-acp.fmr.com";
    public static final String PRDC_BASE_URI = "https://prdc-accounts-acp.fmr.com";
    public static final String PRDC_GET_PATH = "/RRK-Accounts/1.0.1/parties/{wid}/accounts";
    public static final String PAP_QA_BASE_URI = "https://ast-platformqa1.fmr.com";
    public static final String MAUI_ACCOUNT_BASE_URI = "http://alpha-mmk.fmr.com:8980";
    public static final String MAUI_ACCOUNT_V2_PATH = "/XML_WS_A";
    public static final String VM_PLAN_PATH = "/201602/PlanService.svc";
    public static final String EDS_EMONEY_ACCOUNT_GET = "/externaldata/v1/emoney/account";
    public static final String DSS_ACCOUNT_POSITIONS_V2_PATH = "/ftgw/dp/position/v2";
    public static final String DSS_ACCOUNT_V2_PATH = "/ftgw/dp/customer-am-acctnxt/v2/accounts";
    public static final String RETIREMENT_DISTRIBUTION_PATH_V1 = "/ftgw/dp/retail-am-retrdistr/v1/accounts/distributions/retirement";
    public static final String TEMPLATE_DSS_ACCOUNT_V2 = "/template/dss/get_dss_account_v2.vm";
    public static final String RETIREMENT_DISTRIBUTION_TEMPLATE = "/template/retirementDistributions/retirementDistribution.vm";
    public static final String TEMPLATE_DSS_DETAILS_V2 = "/template/dss/get_dss_details_v2.vm";
    public static final String DSS_ACCOUNT_DETAILS_V2_PATH = "/ftgw/dp/balance/detail/v2";
    //Contribution Paths
    public static final String SET_ACCOUNT_CONTRIBUTIONS_V1 = "/account/v1/account/contributions/set";
    public static final String SET_ACCOUNT_CONTRIBUTIONS_V2 = "/account/v2/contributions/set";
    public static final String PLANNING_ACCOUNT_GRANTS_CREATE_TEMPLATE = "/template/planningaccountgrants"
            + "/account_grants_create.vm";
    public static final String VM_PLAN_TEMPLATE = "template/account/VMPlan.vm";
    public static final String GET_FINANCIALINSTRUMENT_PATH =  "/financialinstrument/2014/10/financialinstrument/generic/id/get";
    private AccountConstants() {
        throw new IllegalStateException("Constant Class");
    }


}
