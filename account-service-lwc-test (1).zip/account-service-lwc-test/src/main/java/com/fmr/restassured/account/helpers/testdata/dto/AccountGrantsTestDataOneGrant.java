/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.dto;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * Contains grants related test data. Instantiates with default data, but can be updated.
 *
 * @author a608077
 */
@Entity
public class AccountGrantsTestDataOneGrant {

    @Column(name = "test_name")
    private String testName = "onegrant_onevest";

    @Column(name = "fmvPrice")
    private double fmvPrice = 400.0;

    @Column(name = "stockPlanType")
    private String stockPlanType = "STOCK_OPTION";

    @Column(name = "stockOptionId")
    private String stockOptionId = "NBSOP";

    @Column(name = "grantType")
    private String grantType = "ISO";

    @Column(name = "grantDate")
    private String grantDate = "2022-01-01";

    @Column(name = "vestedShares")
    private float vestedShares = 43.0f;

    @Column(name = "unvestedShares")
    private float unvestedShares = 423.0f;

    @Column(name = "vestedValue")
    private float vestedValue = 432.0f;

    @Column(name = "unvestedValue")
    private float unvestedValue = 0.0f;

    @Column(name = "expirationDate")
    private String expirationDate = "2019-04-05";

    @Column(name = "grantPrice")
    private float grantPrice = 23.0f;

    @Column(name = "vest_vestDate")
    private String vest_vestDate = "2010-02-03";

    @Column(name = "vest_vestShares")
    private float vest_vestShares = 432.0f;

    @Column(name = "vest_distributionDate")
    private String vest_distributionDate = "2017-04-05";

    @Column(name = "vest_perfPercentage")
    private float vest_perfPercentage = 5.0f;

    @Column(name = "updatedfmvPrice")
    private double updatedfmvPrice = 543.12;

    @Column(name = "updatedVestedShares")
    private float updatedVestedShares = 0.0f;

    @Column(name = "updatedUnvestedShares")
    private float updatedUnvestedShares = 0.0f;

    @Column(name = "updatedVestedValue")
    private float updatedVestedValue = 3797.0f;

    @Column(name = "updatedUnvestedValue")
    private float updatedUnvestedValue = 4312.0f;

    @Column(name = "updatedExpirationDate")
    private String updatedExpirationDate = "2017-04-05";

    @Column(name = "updatedGrantPrice")
    private float updatedGrantPrice = 40.0f;

    @Column(name = "updatedVest_vestDate")
    private String updatedVest_vestDate = "2010-02-03";

    @Column(name = "updatedVest_vestShares")
    private float updatedVest_vestShares = 76.0f;

    @Column(name = "updatedVest_distributionDate")
    private String updatedVest_distributionDate = "2019-04-05";

    @Column(name = "updatedVest_perfPercentage")
    private float updatedVest_perfPercentage = 2.0f;


    public AccountGrantsTestDataOneGrant() {
        super();
    }

    /**
     * @param testName
     * @param fmvPrice
     * @param stockPlanType
     * @param stockOptionId
     * @param grantType
     * @param grantDate
     * @param vestedShares
     * @param unvestedShares
     * @param vestedValue
     * @param unvestedValue
     * @param expirationDate
     * @param grantPrice
     * @param vest_vestDate
     * @param vest_vestShares
     * @param vest_distributionDate
     * @param vest_perfPercentage
     * @param updatedfmvPrice
     * @param updatedVestedShares
     * @param updatedUnvestedShares
     * @param updatedVestedValue
     * @param updatedUnvestedValue
     * @param updatedExpirationDate
     * @param updatedGrantPrice
     * @param updatedVest_vestDate
     * @param updatedVest_vestShares
     * @param updatedVest_distributionDate
     * @param updatedVest_perfPercentage
     */
    public AccountGrantsTestDataOneGrant(String testName, float fmvPrice, String stockPlanType, String stockOptionId,
                                         String grantType, String grantDate, float vestedShares, float unvestedShares, float vestedValue, float unvestedValue,
                                         String expirationDate, float grantPrice, String vest_vestDate, float vest_vestShares, String vest_distributionDate,
                                         float vest_perfPercentage, float updatedfmvPrice, float updatedVestedShares, float updatedUnvestedShares,
                                         float updatedVestedValue, float updatedUnvestedValue, String updatedExpirationDate, float updatedGrantPrice, String updatedVest_vestDate,
                                         float updatedVest_vestShares, String updatedVest_distributionDate, float updatedVest_perfPercentage) {
        this.testName = testName;
        this.fmvPrice = fmvPrice;
        this.stockPlanType = stockPlanType;
        this.stockOptionId = stockOptionId;
        this.grantType = grantType;
        this.grantDate = grantDate;
        this.vestedShares = vestedShares;
        this.unvestedShares = unvestedShares;
        this.vestedValue = vestedValue;
        this.unvestedValue = unvestedValue;
        this.expirationDate = expirationDate;
        this.grantPrice = grantPrice;
        this.vest_vestDate = vest_vestDate;
        this.vest_vestShares = vest_vestShares;
        this.vest_distributionDate = vest_distributionDate;
        this.vest_perfPercentage = vest_perfPercentage;
        this.updatedfmvPrice = updatedfmvPrice;
        this.updatedVestedShares = updatedVestedShares;
        this.updatedUnvestedShares = updatedUnvestedShares;
        this.updatedVestedValue = updatedVestedValue;
        this.updatedUnvestedValue = updatedUnvestedValue;
        this.updatedExpirationDate = updatedExpirationDate;
        this.updatedGrantPrice = updatedGrantPrice;
        this.updatedVest_vestDate = updatedVest_vestDate;
        this.updatedVest_vestShares = updatedVest_vestShares;
        this.updatedVest_distributionDate = updatedVest_distributionDate;
        this.updatedVest_perfPercentage = updatedVest_perfPercentage;
    }


    /**
     * @return the testName
     */
    public String getTestName() {
        return testName;
    }


    /**
     * @param testName the testName to set
     */
    public void setTestName(String testName) {
        this.testName = testName;
    }


    /**
     * @return the fmvPrice
     */
    public double getFmvPrice() {
        return fmvPrice;
    }


    /**
     * @param fmvPrice the fmvPrice to set
     */
    public void setFmvPrice(double fmvPrice) {
        this.fmvPrice = fmvPrice;
    }


    /**
     * @return the stockPlanType
     */
    public String getStockPlanType() {
        return stockPlanType;
    }


    /**
     * @param stockPlanType the investObj_Txt stockPlanType to set
     */
    public void setStockPlanType(String stockPlanType) {
        this.stockPlanType = stockPlanType;
    }


    /**
     * @return the stockOptionId
     */
    public String getStockOptionId() {
        return stockOptionId;
    }


    /**
     * @param stockOptionId the stockOptionId to set
     */
    public void setStockOptionId(String stockOptionId) {
        this.stockOptionId = stockOptionId;
    }


    /**
     * @return the grantType
     */
    public String getGrantType() {
        return grantType;
    }


    /**
     * @param grantType the grantType to set
     */
    public void setGrantType(String grantType) {
        this.grantType = grantType;
    }


    /**
     * @return the grantDate
     */
    public String getGrantDate() {
        return grantDate;
    }


    /**
     * @param grantDate the grantDate to set
     */
    public void setGrantDate(String grantDate) {
        this.grantDate = grantDate;
    }


    /**
     * @return the vestedShares
     */
    public float getVestedShares() {
        return vestedShares;
    }


    /**
     * @param vestedShares the vestedShares to set
     */
    public void setVestedShares(float vestedShares) {
        this.vestedShares = vestedShares;
    }


    /**
     * @return the unvestedShares
     */
    public float getUnvestedShares() {
        return unvestedShares;
    }


    /**
     * @param unvestedShares the unvestedShares to set
     */
    public void setUnvestedShares(float unvestedShares) {
        this.unvestedShares = unvestedShares;
    }

    /**
     * @return the vestedValue
     */
    public float getVestedValue() {
        return vestedValue;
    }


    /**
     * @param vestedValue the vestedValue to set
     */
    public void setVestedValue(float vestedValue) {
        this.vestedValue = vestedValue;
    }

    /**
     * @return the unvestedValue
     */
    public float getUnvestedValue() {
        return unvestedValue;
    }


    /**
     * @param unvestedValue to set
     */
    public void setUnvestedValue(float unvestedValue) {
        this.unvestedValue = unvestedValue;
    }

    /**
     * @return the expirationDate
     */
    public String getExpirationDate() {
        return expirationDate;
    }


    /**
     * @param expirationDate the expirationDate to set
     */
    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    /**
     * @return the grantPrice
     */
    public float getGrantPrice() {
        return grantPrice;
    }


    /**
     * @param grantPrice the grantPrice to set
     */
    public void setGrantPrice(float grantPrice) {
        this.grantPrice = grantPrice;
    }

    /**
     * @return the vest_vestDate
     */
    public String getVest_vestDate() {
        return vest_vestDate;
    }


    /**
     * @param vest_vestDate the vest_vestDate to set
     */
    public void setVest_vestDate(String vest_vestDate) {
        this.vest_vestDate = vest_vestDate;
    }

    /**
     * @return the vest_vestShares
     */
    public float getVest_vestShares() {
        return vest_vestShares;
    }


    /**
     * @param vest_vestShares the vest_vestShares to set
     */
    public void setVest_vestShares(float vest_vestShares) {
        this.vest_vestShares = vest_vestShares;
    }

    /**
     * @return the vest_distributionDate
     */
    public String getVest_distributionDate() {
        return vest_distributionDate;
    }


    /**
     * @param vest_distributionDate the vest_distributionDate to set
     */
    public void setVest_distributionDate(String vest_distributionDate) {
        this.vest_distributionDate = vest_distributionDate;
    }

    /**
     * @return the vest_perfPercentage
     */
    public float getVest_perfPercentage() {
        return vest_perfPercentage;
    }


    /**
     * @param vest_perfPercentage the vest_perfPercentage to set
     */
    public void setVest_perfPercentage(float vest_perfPercentage) {
        this.vest_perfPercentage = vest_perfPercentage;
    }

    /**
     * @return the updatedfmvPrice
     */
    public double getUpdatedfmvPrice() {
        return updatedfmvPrice;
    }


    /**
     * @param updatedfmvPrice the updatedfmvPrice to set
     */
    public void setUpdatedfmvPrice(double updatedfmvPrice) {
        this.updatedfmvPrice = updatedfmvPrice;
    }

    /**
     * @return the updatedVestedShares
     */
    public float getUpdatedVestedShares() {
        return updatedVestedShares;
    }


    /**
     * @param updatedVestedShares the updatedVestedShares to set
     */
    public void setUpdatedVestedShares(float updatedVestedShares) {
        this.updatedVestedShares = updatedVestedShares;
    }

    /**
     * @return the updatedUnvestedShares
     */
    public float getUpdatedUnvestedShares() {
        return updatedUnvestedShares;
    }


    /**
     * @param updatedUnvestedShares the updatedUnvestedShares to set
     */
    public void setUpdatedUnvestedShares(float updatedUnvestedShares) {
        this.updatedUnvestedShares = updatedUnvestedShares;
    }

    /**
     * @return the updatedVestedValue
     */
    public float getUpdatedVestedValue() {
        return updatedVestedValue;
    }


    /**
     * @param updatedVestedValue the updatedVestedValue to set
     */
    public void setUpdatedVestedValue(float updatedVestedValue) {
        this.updatedVestedValue = updatedVestedValue;
    }

    /**
     * @return the updatedUnvestedValue
     */
    public float getUpdatedUnvestedValue() {
        return updatedUnvestedValue;
    }


    /**
     * @param updatedUnvestedValue the updatedUnvestedValue to set
     */
    public void setUpdatedUnvestedValue(float updatedUnvestedValue) {
        this.updatedUnvestedValue = updatedUnvestedValue;
    }

    /**
     * @return the    updatedExpirationDate,
     */
    public String getUpdatedExpirationDate() {
        return updatedExpirationDate;
    }


    /**
     * @param updatedExpirationDate the updatedExpirationDate to set
     */
    public void setUpdatedExpirationDate(String updatedExpirationDate) {
        this.updatedExpirationDate = updatedExpirationDate;
    }

    /**
     * @return the updatedGrantPrice
     */
    public float getUpdatedGrantPrice() {
        return updatedGrantPrice;
    }


    /**
     * @param updatedGrantPrice the updatedGrantPrice to set
     */
    public void setUpdatedGrantPrice(float updatedGrantPrice) {
        this.updatedGrantPrice = updatedGrantPrice;
    }

    /**
     * @return the updatedVest_vestDate
     */
    public String getUpdatedVest_vestDate() {
        return updatedVest_vestDate;
    }


    /**
     * @param updatedVest_vestDate the updatedVest_vestDate to set
     */
    public void setUpdatedVest_vestDate(String updatedVest_vestDate) {
        this.updatedVest_vestDate = updatedVest_vestDate;
    }

    /**
     * @return the updatedVest_vestShares
     */
    public float getUpdatedVest_vestShares() {
        return updatedVest_vestShares;
    }


    /**
     * @param updatedVest_vestShares the updatedVest_vestShares to set
     */
    public void setUpdatedVest_vestShares(float updatedVest_vestShares) {
        this.updatedVest_vestShares = updatedVest_vestShares;
    }

    /**
     * @return the updatedVest_distributionDate
     */
    public String getUpdatedVest_distributionDate() {
        return updatedVest_distributionDate;
    }


    /**
     * @param updatedVest_distributionDate the updatedVest_distributionDate to set
     */
    public void setUpdatedVest_distributionDate(String updatedVest_distributionDate) {
        this.updatedVest_distributionDate = updatedVest_distributionDate;
    }

    /**
     * @return the updatedVest_perfPercentage
     */
    public float getUpdatedVest_perfPercentage() {
        return updatedVest_perfPercentage;
    }


    /**
     * @param updatedVest_perfPercentage the updatedVest_perfPercentage to set
     */
    public void setUpdatedVest_perfPercentage(float updatedVest_perfPercentage) {
        this.updatedVest_perfPercentage = updatedVest_perfPercentage;
    }


}
