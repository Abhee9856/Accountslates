package com.fmr.restassured.account.helpers.testdata.dto;


import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * Contains withdrawals related test data. Instantiates with default data, but can be updated.
 *
 * @author a560878
 *
 */
@Entity
public class AccountSuitabilityTestData
{

	@Column(name = "test_name")
	private String testName = "Regular";

	@Column(name = "source_system")
	private String sourceSystem = "MONTHLY";

	@Column(name = "investObj_Txt")
	private String investObj_Txt = "1228.62";

	@Column(name = "investObj_Id")
	private String investObj_Id = "1228.62";

	@Column(name = "investPurp_Txt")
	private String investPurp_Txt = "MONEY";
	
	@Column(name = "investPurp_Id")
	private String investPurp_Id = "Regular";

	@Column(name = "investKnow_Txt")
	private String investKnow_Txt = "0.01";

	@Column(name = "investKnow_Id")
	private String investKnow_Id = "0.01";

	@Column(name = "annualIncRng_Txt")
	private String annualIncRng_Txt = "PERCENT";

	@Column(name = "annualIncRng_Id")
	private String annualIncRng_Id = "PERCENT";

	@Column(name = "liqNWRng_Txt")
	private String liqNWRng_Txt = "PERCENT";

	@Column(name = "liqNWRng_Id")
	private String liqNWRng_Id = "PERCENT";

	@Column(name = "netWorthRng_Txt")
	private String netWorthRng_Txt = "PERCENT";

	@Column(name = "netWorthRng_Id")
	private String netWorthRng_Id = "PERCENT";

	@Column(name = "taxBrktRng_Txt")
	private String taxBrktRng_Txt = "PERCENT";

	@Column(name = "taxBrktRng_Id")
	private String taxBrktRng_Id = "PERCENT";

	@Column(name = "essExpRng_Txt")
	private String essExpRng_Txt = "PERCENT";

	@Column(name = "essExpRng_Id")
	private String essExpRng_Id = "PERCENT";

	@Column(name = "spendLikeRng_Txt")
	private String spendLikeRng_Txt = "PERCENT";

	@Column(name = "spendLikeRng_Id")
	private String spendLikeRng_Id = "PERCENT";

	@Column(name = "invesTimeHrzn_Txt")
	private String invesTimeHrzn_Txt = "PERCENT";

	@Column(name = "invesTimeHrzn_Id")
	private String invesTimeHrzn_Id = "PERCENT";

	@Column(name = "tam_TotalEqty")
	private String tam_TotalEqty = "PERCENT";

	@Column(name = "tam_DomEqty")
	private String tam_DomEqty = "PERCENT";

	@Column(name = "tam_ForeignEqty")
	private String tam_ForeignEqty = "PERCENT";

	@Column(name = "tam_Bond")
	private String tam_Bond = "PERCENT";

	@Column(name = "tam_Cash")
	private String tam_Cash = "PERCENT";

	@Column(name = "tam_lowEqtyPct")
	private String tam_lowEqtyPct = "PERCENT";

	@Column(name = "tam_upEqtyPct")
	private String tam_upEqtyPct = "PERCENT";

	@Column(name = "tam_assetAlloc_Id")
	private String tam_assetAlloc_Id = "PERCENT";

	@Column(name = "tam_context")
	private String tam_context = "PERCENT";

	@Column(name = "investObj_Txt_Updt")
	private String investObj_Txt_Updt = "PERCENT";

	@Column(name = "investObj_Id_Updt")
	private String investObj_Id_Updt = "PERCENT";

	@Column(name = "investPurp_Txt_Updt")
	private String investPurp_Txt_Updt = "PERCENT";

	@Column(name = "investPurp_Id_Updt")
	private String investPurp_Id_Updt = "PERCENT";

	@Column(name = "investKnow_Txt_Updt")
	private String investKnow_Txt_Updt = "PERCENT";

	@Column(name = "investKnow_Id_Updt")
	private String investKnow_Id_Updt = "PERCENT";

	@Column(name = "annualIncRng_Txt_Updt")
	private String annualIncRng_Txt_Updt = "PERCENT";

	@Column(name = "annualIncRng_Id_Updt")
	private String annualIncRng_Id_Updt = "PERCENT";

	@Column(name = "liqNWRng_Txt_Updt")
	private String liqNWRng_Txt_Updt = "PERCENT";

	@Column(name = "liqNWRng_Id_Updt")
	private String liqNWRng_Id_Updt = "PERCENT";

	@Column(name = "netWorthRng_Txt_Updt")
	private String netWorthRng_Txt_Updt = "PERCENT";

	@Column(name = "netWorthRng_Id_Updt")
	private String netWorthRng_Id_Updt = "PERCENT";

	@Column(name = "taxBrktRng_Txt_Updt")
	private String taxBrktRng_Txt_Updt = "PERCENT";

	@Column(name = "taxBrktRng_Id_Updt")
	private String taxBrktRng_Id_Updt = "PERCENT";

	@Column(name = "essExpRng_Txt_Updt")
	private String essExpRng_Txt_Updt = "PERCENT";

	@Column(name = "essExpRng_Id_Updt")
	private String essExpRng_Id_Updt = "PERCENT";

	@Column(name = "spendLikeRng_Txt_Updt")
	private String spendLikeRng_Txt_Updt = "PERCENT";

	@Column(name = "spendLikeRng_Id_Updt")
	private String spendLikeRng_Id_Updt = "PERCENT";

	@Column(name = "invesTimeHrzn_Txt_Updt")
	private String invesTimeHrzn_Txt_Updt = "PERCENT";

	@Column(name = "invesTimeHrzn_Id_Updt")
	private String invesTimeHrzn_Id_Updt = "PERCENT";

	@Column(name = "tam_TotalEqty_Updt")
	private String tam_TotalEqty_Updt = "PERCENT";

	@Column(name = "tam_DomEqty_Updt")
	private String tam_DomEqty_Updt = "PERCENT";

	@Column(name = "tam_ForeignEqty_Updt")
	private String tam_ForeignEqty_Updt = "PERCENT";

	@Column(name = "tam_Bond_Updt")
	private String tam_Bond_Updt = "PERCENT";

	@Column(name = "tam_Cash_Updt")
	private String tam_Cash_Updt = "PERCENT";

	@Column(name = "tam_lowEqtyPct_Updt")
	private String tam_lowEqtyPct_Updt = "PERCENT";

	@Column(name = "tam_upEqtyPct_Updt")
	private String tam_upEqtyPct_Updt = "PERCENT";

	@Column(name = "tam_assetAlloc_Id_Updt")
	private String tam_assetAlloc_Id_Updt = "PERCENT";

	@Column(name = "tam_context_Updt")
	private String tam_context_Updt = "PERCENT";


	
	

	public AccountSuitabilityTestData()
	{
		super();
	}

	/**
	 *
	 * @param testName
	 * @param sourceSystem
	 * @param investObj_Txt
	 * @param investObj_Id
	 * @param investPurp_Txt
	 * @param investPurp_Id
	 * @param investKnow_Txt
	 * @param investKnow_Id
	 * @param annualIncRng_Txt
	 * @param annualIncRng_Id
	 * @param liqNWRng_Txt
	 * @param liqNWRng_Id
	 * @param netWorthRng_Txt
	 * @param netWorthRng_Id
	 * @param taxBrktRng_Txt
	 * @param taxBrktRng_Id
	 * @param essExpRng_Txt
	 * @param essExpRng_Id
	 * @param spendLikeRng_Txt
	 * @param spendLikeRng_Id
	 * @param invesTimeHrzn_Txt
	 * @param invesTimeHrzn_Id
	 * @param tam_TotalEqty
	 * @param tam_DomEqty
	 * @param tam_ForeignEqty
	 * @param tam_Bond
	 * @param tam_Cash
	 * @param tam_lowEqtyPct
	 * @param tam_upEqtyPct
	 * @param tam_assetAlloc_Id
	 * @param tam_context
	 * @param investObj_Txt_Updt
	 * @param investObj_Id_Updt
	 * @param investPurp_Txt_Updt
	 * @param investPurp_Id_Updt
	 * @param investKnow_Txt_Updt
	 * @param investKnow_Id_Updt
	 * @param annualIncRng_Txt_Updt
	 * @param annualIncRng_Id_Updt
	 * @param liqNWRng_Txt_Updt
	 * @param liqNWRng_Id_Updt
	 * @param netWorthRng_Txt_Updt
	 * @param netWorthRng_Id_Updt
	 * @param taxBrktRng_Txt_Updt
	 * @param taxBrktRng_Id_Updt
	 * @param essExpRng_Txt_Updt
	 * @param essExpRng_Id_Updt
	 * @param spendLikeRng_Txt_Updt
	 * @param spendLikeRng_Id_Updt
	 * @param invesTimeHrzn_Txt_Updt
	 * @param invesTimeHrzn_Id_Updt
	 * @param tam_TotalEqty_Updt
	 * @param tam_DomEqty_Updt
	 * @param tam_ForeignEqty_Updt
	 * @param tam_Bond_Updt
	 * @param tam_Cash_Updt
	 * @param tam_lowEqtyPct_Updt
	 * @param tam_upEqtyPct_Updt
	 * @param tam_assetAlloc_Id_Updt
	 * @param tam_context_Updt
	 * 
	 */
	public AccountSuitabilityTestData(String testName, String sourceSystem, String investObj_Txt, String investObj_Id,
	        String investPurp_Txt, String investPurp_Id, String investKnow_Txt, String investKnow_Id, String annualIncRng_Txt, String annualIncRng_Id,
	        String liqNWRng_Txt, String liqNWRng_Id, String netWorthRng_Txt, String netWorthRng_Id, String taxBrktRng_Txt, 
	        String taxBrktRng_Id, String essExpRng_Txt, String essExpRng_Id, String spendLikeRng_Txt, String spendLikeRng_Id,
	        String invesTimeHrzn_Txt, String invesTimeHrzn_Id, String tam_TotalEqty, String tam_DomEqty, String tam_ForeignEqty,
	        String tam_Bond, String tam_Cash, String tam_lowEqtyPct, String tam_upEqtyPct, String tam_assetAlloc_Id,
	        String tam_context, String investObj_Txt_Updt, String investObj_Id_Updt, String investPurp_Txt_Updt,
	        String investPurp_Id_Updt, String investKnow_Txt_Updt, String investKnow_Id_Updt, String annualIncRng_Txt_Updt,
	        String annualIncRng_Id_Updt, String liqNWRng_Txt_Updt, String liqNWRng_Id_Updt, String netWorthRng_Txt_Updt,
	        String netWorthRng_Id_Updt, String taxBrktRng_Txt_Updt, String taxBrktRng_Id_Updt, String essExpRng_Txt_Updt,
	        String essExpRng_Id_Updt, String spendLikeRng_Txt_Updt, String spendLikeRng_Id_Updt, String invesTimeHrzn_Txt_Updt,
	        String invesTimeHrzn_Id_Updt, String tam_TotalEqty_Updt, String tam_DomEqty_Updt, String tam_ForeignEqty_Updt,
	        String tam_Bond_Updt, String tam_Cash_Updt, String tam_lowEqtyPct_Updt, String tam_upEqtyPct_Updt,
	        String tam_assetAlloc_Id_Updt, String tam_context_Updt)
	{
		this.testName = testName;
		this.sourceSystem = sourceSystem;
		this.investObj_Txt = investObj_Txt;
		this.investObj_Id = investObj_Id;
		this.investPurp_Txt = investPurp_Txt;
		this.investPurp_Id = investPurp_Id;
		this.investKnow_Txt = investKnow_Txt;
		this.investKnow_Id = investKnow_Id;
		this.annualIncRng_Txt = annualIncRng_Txt;
		this.annualIncRng_Id = annualIncRng_Id;
		this.liqNWRng_Txt = liqNWRng_Txt;
		this.liqNWRng_Id = liqNWRng_Id;
		this.netWorthRng_Txt = netWorthRng_Txt;
		this.netWorthRng_Id = netWorthRng_Id;
		this.taxBrktRng_Txt = taxBrktRng_Txt;
		this.taxBrktRng_Id = taxBrktRng_Id;
		this.essExpRng_Txt = essExpRng_Txt;
		this.essExpRng_Id = essExpRng_Id;
		this.spendLikeRng_Txt = spendLikeRng_Txt;
		this.spendLikeRng_Id = spendLikeRng_Id;
		this.invesTimeHrzn_Txt = invesTimeHrzn_Txt;
		this.invesTimeHrzn_Id = invesTimeHrzn_Id;
		this.tam_TotalEqty = tam_TotalEqty;
		this.tam_DomEqty = tam_DomEqty;
		this.tam_ForeignEqty = tam_ForeignEqty;
		this.tam_Bond = tam_Bond;
		this.tam_Cash = tam_Cash;
		this.tam_lowEqtyPct = tam_lowEqtyPct;
		this.tam_assetAlloc_Id = tam_assetAlloc_Id;
		this.tam_upEqtyPct = tam_upEqtyPct;
		this.tam_context = tam_context;
		this.investObj_Txt_Updt = investObj_Txt_Updt;
		this.investObj_Id_Updt = investObj_Id_Updt;
		this.investPurp_Txt_Updt = investPurp_Txt_Updt;
		this.investPurp_Id_Updt = investPurp_Id_Updt;
		this.investKnow_Txt_Updt = investKnow_Txt_Updt;
		this.investKnow_Id_Updt = investKnow_Id_Updt;
		this.annualIncRng_Txt_Updt = annualIncRng_Txt_Updt;
		this.annualIncRng_Id_Updt = annualIncRng_Id_Updt;
		this.liqNWRng_Txt_Updt = liqNWRng_Txt_Updt;
		this.liqNWRng_Id_Updt = liqNWRng_Id_Updt;
		this.netWorthRng_Txt_Updt = netWorthRng_Txt_Updt;
		this.netWorthRng_Id_Updt = netWorthRng_Id_Updt;
		this.taxBrktRng_Txt_Updt = taxBrktRng_Txt_Updt;
		this.taxBrktRng_Id_Updt = taxBrktRng_Id_Updt;
		this.essExpRng_Txt_Updt = essExpRng_Txt_Updt;
		this.essExpRng_Id_Updt = essExpRng_Id_Updt;
		this.spendLikeRng_Txt_Updt = spendLikeRng_Txt_Updt;
		this.spendLikeRng_Id_Updt = spendLikeRng_Id_Updt;
		this.invesTimeHrzn_Txt_Updt = invesTimeHrzn_Txt_Updt;
		this.invesTimeHrzn_Id_Updt = invesTimeHrzn_Id_Updt;
		this.tam_TotalEqty_Updt = tam_TotalEqty_Updt;
		this.tam_DomEqty_Updt = tam_DomEqty_Updt;
		this.tam_ForeignEqty_Updt = tam_ForeignEqty_Updt;
		this.tam_Bond_Updt = tam_Bond_Updt;
		this.tam_Cash_Updt = tam_Cash_Updt;
		this.tam_lowEqtyPct_Updt = tam_lowEqtyPct_Updt;
		this.tam_upEqtyPct_Updt = tam_upEqtyPct_Updt;
		this.tam_assetAlloc_Id_Updt = tam_assetAlloc_Id_Updt;
		this.tam_context_Updt = tam_context_Updt;
	}


	/**
	 * @return the testName
	 */
	public String getTestName()
	{
		return testName;
	}

	
	/**
	 * @param testName the testName to set
	 */
	public void setTestName(String testName)
	{
		this.testName = testName;
	}

	
	/**
	 * @return the sourceSystem
	 */
	public String getSourceSystem()
	{
		return sourceSystem;
	}

	
	/**
	 * @param sourceSystem the sourceSystem to set
	 */
	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}

	
	/**
	 * @return the investObj_Txt
	 */
	public String getInvestObjTxt()
	{
		return investObj_Txt;
	}

	
	/**
	 * @param investObj_Txt the investObj_Txt Value to set
	 */
	public void setInvestObjTxt(String investObj_Txt)
	{
		this.investObj_Txt = investObj_Txt;
	}

	
	/**
	 * @return the investObj_Id
	 */
	public String getInvestObjId()
	{
		return investObj_Id;
	}

	
	/**
	 * @param investObj_Id the investObj_Id to set
	 */
	public void setInvestObjId(String investObj_Id)
	{
		this.investObj_Id = investObj_Id;
	}

	
	/**
	 * @return the investPurp_Txt
	 */
	public String getInvestPurpTxt()
	{
		return investPurp_Txt;
	}

	
	/**
	 * @param investPurp_Txt the investPurp_Txt to set
	 */
	public void setInvestPurpTxt(String investPurp_Txt)
	{
		this.investPurp_Txt = investPurp_Txt;
	}

	
	/**
	 * @return the investPurp_Id
	 */
	public String getInvestPurpId()
	{
		return investPurp_Id;
	}

	
	/**
	 * @param investPurp_Id the investPurp_Id to set
	 */
	public void setInvestPurpId(String investPurp_Id)
	{
		this.investPurp_Id = investPurp_Id;
	}

	
	/**
	 * @return the investKnow_Txt
	 */
	public String getInvestKnowTxt()
	{
		return investKnow_Txt;
	}

	
	/**
	 * @param investKnow_Txt the investKnow_Txt to set
	 */
	public void setInvestKnowTxt(String investKnow_Txt)
	{
		this.investKnow_Txt = investKnow_Txt;
	}

	
	/**
	 * @return the investKnow_Id
	 */
	public String getInvestKnowId()
	{
		return investKnow_Id;
	}

	
	/**
	 * @param investKnow_Id the investKnow_Id to set
	 */
	public void setInvestKnowId(String investKnow_Id)
	{
		this.investKnow_Id = investKnow_Id;
	}

	/**
	 * @return the annualIncRng_Txt
	 */
	public String getAnnualIncRngTxt()
	{
		return annualIncRng_Txt;
	}

	
	/**
	 * @param annualIncRng_Txt the annualIncRng_Txt to set
	 */
	public void setAnnualIncRngTxt(String annualIncRng_Txt)
	{
		this.annualIncRng_Txt = annualIncRng_Txt;
	}

	/**
	 * @return the annualIncRng_Id
	 */
	public String getAnnualIncRngId()
	{
		return annualIncRng_Id;
	}

	
	/**
	 * @param annualIncRng_Id the annualIncRng_Id to set
	 */
	public void setAnnualIncRngId(String annualIncRng_Id)
	{
		this.annualIncRng_Id = annualIncRng_Id;
	}

	/**
	 * @return the liqNWRng_Txt
	 */
	public String getLiqNWRngTxt()
	{
		return liqNWRng_Txt;
	}

	
	/**
	 * @param liqNWRng_Txt the liqNWRng_Txt to set
	 */
	public void setLiqNWRngTxt(String liqNWRng_Txt)
	{
		this.liqNWRng_Txt = liqNWRng_Txt;
	}

	/**
	 * @return the liqNWRng_Id
	 */
	public String getLiqNWRngId()
	{
		return liqNWRng_Id;
	}

	
	/**
	 * @param liqNWRng_Id the liqNWRng_Id to set
	 */
	public void setLiqNWRngId(String liqNWRng_Id)
	{
		this.liqNWRng_Id = liqNWRng_Id;
	}

	/**
	 * @return the netWorthRng_Txt
	 */
	public String getNetWorthRngTxt()
	{
		return netWorthRng_Txt;
	}

	
	/**
	 * @param netWorthRng_Txt the netWorthRng_Txt to set
	 */
	public void setNetWorthRngTxt(String netWorthRng_Txt)
	{
		this.netWorthRng_Txt = netWorthRng_Txt;
	}

	/**
	 * @return the netWorthRng_Id
	 */
	public String getNetWorthRngId()
	{
		return netWorthRng_Id;
	}

	
	/**
	 * @param netWorthRng_Id the netWorthRng_Id to set
	 */
	public void setNetWorthRngId(String netWorthRng_Id)
	{
		this.netWorthRng_Id = netWorthRng_Id;
	}

	/**
	 * @return the taxBrktRng_Txt
	 */
	public String getTaxBrktRngTxt()
	{
		return taxBrktRng_Txt;
	}

	
	/**
	 * @param taxBrktRng_Txt the taxBrktRng_Txt to set
	 */
	public void setTaxBrktRngTxt(String taxBrktRng_Txt)
	{
		this.taxBrktRng_Txt = taxBrktRng_Txt;
	}

	/**
	 * @return the taxBrktRng_Id
	 */
	public String getTaxBrktRngId()
	{
		return taxBrktRng_Id;
	}

	
	/**
	 * @param taxBrktRng_Id the taxBrktRng_Id to set
	 */
	public void setTaxBrktRngId(String taxBrktRng_Id)
	{
		this.taxBrktRng_Id = taxBrktRng_Id;
	}

	/**
	 * @return the essExpRng_Txt
	 */
	public String getEssExpRngTxt()
	{
		return essExpRng_Txt;
	}

	
	/**
	 * @param essExpRng_Txt the essExpRng_Txt to set
	 */
	public void setEssExpRngTxt(String essExpRng_Txt)
	{
		this.essExpRng_Txt = essExpRng_Txt;
	}

	/**
	 * @return the essExpRng_Id
	 */
	public String getEssExpRngId()
	{
		return essExpRng_Id;
	}

	
	/**
	 * @param essExpRng_Id the essExpRng_Id to set
	 */
	public void setEssExpRngId(String essExpRng_Id)
	{
		this.essExpRng_Id = essExpRng_Id;
	}

	/**
	 * @return the spendLikeRng_Txt
	 */
	public String getSpendLikeRngTxt()
	{
		return spendLikeRng_Txt;
	}

	
	/**
	 * @param spendLikeRng_Txt the tspendLikeRng_Txtype to set
	 */
	public void setSpendLikeRngTxt(String spendLikeRng_Txt)
	{
		this.spendLikeRng_Txt = spendLikeRng_Txt;
	}

	/**
	 * @return the spendLikeRng_Id
	 */
	public String getSpendLikeRngId()
	{
		return spendLikeRng_Id;
	}

	
	/**
	 * @param spendLikeRng_Id the spendLikeRng_Id to set
	 */
	public void setSpendLikeRngId(String spendLikeRng_Id)
	{
		this.spendLikeRng_Id = spendLikeRng_Id;
	}

	/**
	 * @return the invesTimeHrzn_Txt
	 */
	public String getInvesTimeHrznTxt()
	{
		return invesTimeHrzn_Txt;
	}

	
	/**
	 * @param invesTimeHrzn_Txt the invesTimeHrzn_Txt to set
	 */
	public void setInvesTimeHrznTxt(String invesTimeHrzn_Txt)
	{
		this.invesTimeHrzn_Txt = invesTimeHrzn_Txt;
	}

	/**
	 * @return the 	"invesTimeHrzn_Id"	TEXT,

	 */
	public String getInvesTimeHrznId()
	{
		return 	invesTimeHrzn_Id;
	}

	
	/**
	 * @param invesTimeHrzn_Id the invesTimeHrzn_Id to set
	 */
	public void setInvesTimeHrznId(String invesTimeHrzn_Id)
	{
		this.invesTimeHrzn_Id = invesTimeHrzn_Id;
	}

	/**
	 * @return the tam_TotalEqty
	 */
	public String getTamTotalEqty()
	{
		return tam_TotalEqty;
	}

	
	/**
	 * @param tam_TotalEqty the tam_TotalEqty to set
	 */
	public void setTamTotalEqty(String tam_TotalEqty)
	{
		this.tam_TotalEqty = tam_TotalEqty;
	}

	/**
	 * @return the tam_DomEqty
	 */
	public String getTamDomEqty()
	{
		return tam_DomEqty;
	}

	
	/**
	 * @param tam_DomEqty the tam_DomEqty to set
	 */
	public void setTamDomEqty(String tam_DomEqty)
	{
		this.tam_DomEqty = tam_DomEqty;
	}

	/**
	 * @return the tam_ForeignEqty
	 */
	public String getTamForeignEqty()
	{
		return tam_ForeignEqty;
	}

	
	/**
	 * @param tam_ForeignEqty the tam_ForeignEqty to set
	 */
	public void setTamForeignEqty(String tam_ForeignEqty)
	{
		this.tam_ForeignEqty = tam_ForeignEqty;
	}

	/**
	 * @return the tam_Bond
	 */
	public String getTamBond()
	{
		return tam_Bond;
	}

	
	/**
	 * @param tam_Bond the tam_Bond to set
	 */
	public void setTamBond(String tam_Bond)
	{
		this.tam_Bond = tam_Bond;
	}

	/**
	 * @return the tam_Cash
	 */
	public String getTamCash()
	{
		return tam_Cash;
	}

	
	/**
	 * @param tam_Cash the tam_Cash to set
	 */
	public void setTamCash(String tam_Cash)
	{
		this.tam_Cash = tam_Cash;
	}


	/**
	 * @return the tam_lowEqtyPct
	 */
	public String getTamLowEqtyPct()
	{
		return tam_lowEqtyPct;
	}

	
	/**
	 * @param tam_lowEqtyPct the tam_lowEqtyPct to set
	 */
	public void setTamLowEqtyPct(String tam_lowEqtyPct)
	{
		this.tam_lowEqtyPct = tam_lowEqtyPct;
	}

	/**
	 * @return the tam_upEqtyPct
	 */
	public String getTamUpEqtyPct()
	{
		return tam_upEqtyPct;
	}

	
	/**
	 * @param tam_upEqtyPct the tam_upEqtyPct to set
	 */
	public void setTamUpEqtyPct(String tam_upEqtyPct)
	{
		this.tam_upEqtyPct = tam_upEqtyPct;
	}

	/**
	 * @return the tam_assetAlloc_Id
	 */
	public String getTamAssetAllocId()
	{
		return tam_assetAlloc_Id;
	}

	
	/**
	 * @param tam_assetAlloc_Id the tam_assetAlloc_Id to set
	 */
	public void setTamAssetAllocId(String tam_assetAlloc_Id)
	{
		this.tam_assetAlloc_Id = tam_assetAlloc_Id;
	}

	/**
	 * @return the tam_context
	 */
	public String getTamContext()
	{
		return tam_context;
	}

	
	/**
	 * @param tam_context the tam_context to set
	 */
	public void setTamContext(String tam_context)
	{
		this.tam_context = tam_context;
	}


	/**
	 * @return the investObj_Txt_Updt
	 */
	public String getInvestObjTxtUpdt()
	{
		return investObj_Txt_Updt;
	}

	
	/**
	 * @param investObj_Txt_Updt the investObj_Txt_Updt to set
	 */
	public void setInvestObjTxtUpdt(String investObj_Txt_Updt)
	{
		this.investObj_Txt_Updt = investObj_Txt_Updt;
	}

	/**
	 * @return the investObj_Id_Updt
	 */
	public String getInvestObjIdUpdt()
	{
		return investObj_Id_Updt;
	}

	
	/**
	 * @param investObj_Id_Updt the investObj_Id_Updt to set
	 */
	public void setInvestObjIdUpdt(String investObj_Id_Updt)
	{
		this.investObj_Id_Updt = investObj_Id_Updt;
	}

	/**
	 * @return the investPurp_Txt_Updt
	 */
	public String getInvestPurpTxtUpdt()
	{
		return investPurp_Txt_Updt;
	}

	
	/**
	 * @param investPurp_Txt_Updt the investPurp_Txt_Updt to set
	 */
	public void setInvestPurpTxtUpdt(String investPurp_Txt_Updt)
	{
		this.investPurp_Txt_Updt = investPurp_Txt_Updt;
	}

	/**
	 * @return the investPurp_Id_Updt
	 */
	public String getInvestPurpIdUpdt()
	{
		return investPurp_Id_Updt;
	}

	
	/**
	 * @param investPurp_Id_Updt the investPurp_Id_Updt to set
	 */
	public void setInvestPurpIdUpdt(String investPurp_Id_Updt)
	{
		this.investPurp_Id_Updt = investPurp_Id_Updt;
	}

	/**
	 * @return the investKnow_Txt_Updt
	 */
	public String getInvestKnowTxtUpdt()
	{
		return investKnow_Txt_Updt;
	}

	
	/**
	 * @param investKnow_Txt_Updt the investKnow_Txt_Updt to set
	 */
	public void setInvestKnowTxtUpdt(String investKnow_Txt_Updt)
	{
		this.investKnow_Txt_Updt = investKnow_Txt_Updt;
	}

	/**
	 * @return the investKnow_Id_Updt
	 */
	public String getInvestKnowIdUpdt()
	{
		return investKnow_Id_Updt;
	}

	
	/**
	 * @param investKnow_Id_Updt the investKnow_Id_Updt to set
	 */
	public void setInvestKnowIdUpdt(String investKnow_Id_Updt)
	{
		this.investKnow_Id_Updt = investKnow_Id_Updt;
	}

	/**
	 * @return the annualIncRng_Txt_Updt
	 */
	public String getAnnualIncRngTxtUpdt()
	{
		return annualIncRng_Txt_Updt;
	}

	
	/**
	 * @param annualIncRng_Txt_Updt the annualIncRng_Txt_Updt to set
	 */
	public void setAnnualIncRngTxtUpdt(String annualIncRng_Txt_Updt)
	{
		this.annualIncRng_Txt_Updt = annualIncRng_Txt_Updt;
	}

	/**
	 * @return the annualIncRng_Id_Updt
	 */
	public String getAnnualIncRngIdUpdt()
	{
		return annualIncRng_Id_Updt;
	}

	
	/**
	 * @param annualIncRng_Id_Updt the annualIncRng_Id_Updt to set
	 */
	public void setAnnualIncRngIdUpdt(String annualIncRng_Id_Updt)
	{
		this.annualIncRng_Id_Updt = annualIncRng_Id_Updt;
	}

	/**
	 * @return the liqNWRng_Txt_Updt
	 */
	public String getLiqNWRngTxtUpdt()
	{
		return liqNWRng_Txt_Updt;
	}

	
	/**
	 * @param liqNWRng_Txt_Updt the liqNWRng_Txt_Updt to set
	 */
	public void setLiqNWRngTxtUpdt(String liqNWRng_Txt_Updt)
	{
		this.liqNWRng_Txt_Updt = liqNWRng_Txt_Updt;
	}

	/**
	 * @return the liqNWRng_Id_Updt
	 */
	public String getLiqNWRngIdUpdt()
	{
		return liqNWRng_Id_Updt;
	}

	
	/**
	 * @param liqNWRng_Id_Updt the liqNWRng_Id_Updt to set
	 */
	public void setLiqNWRngIdUpdt(String liqNWRng_Id_Updt)
	{
		this.liqNWRng_Id_Updt = liqNWRng_Id_Updt;
	}

	/**
	 * @return the netWorthRng_Txt_Updt
	 */
	public String getNetWorthRngTxtUpdt()
	{
		return netWorthRng_Txt_Updt;
	}

	
	/**
	 * @param netWorthRng_Txt_Updt the netWorthRng_Txt_Updt to set
	 */
	public void setNetWorthRngTxtUpdt(String netWorthRng_Txt_Updt)
	{
		this.netWorthRng_Txt_Updt = netWorthRng_Txt_Updt;
	}

	/**
	 * @return the netWorthRng_Id_Updt
	 */
	public String getNetWorthRngIdUpdt()
	{
		return netWorthRng_Id_Updt;
	}

	
	/**
	 * @param netWorthRng_Id_Updt the netWorthRng_Id_Updt to set
	 */
	public void setNetWorthRngIdUpdt(String netWorthRng_Id_Updt)
	{
		this.netWorthRng_Id_Updt = netWorthRng_Id_Updt;
	}

	/**
	 * @return the taxBrktRng_Txt_Updt
	 */
	public String getTaxBrktRngTxtUpdt()
	{
		return taxBrktRng_Txt_Updt;
	}

	
	/**
	 * @param taxBrktRng_Txt_Updt the taxBrktRng_Txt_Updt to set
	 */
	public void setTaxBrktRngTxtUpdt(String taxBrktRng_Txt_Updt)
	{
		this.taxBrktRng_Txt_Updt = taxBrktRng_Txt_Updt;
	}

	/**
	 * @return the taxBrktRng_Id_Updt
	 */
	public String getTaxBrktRngIdUpdt()
	{
		return taxBrktRng_Id_Updt;
	}

	
	/**
	 * @param taxBrktRng_Id_Updt the taxBrktRng_Id_Updt to set
	 */
	public void setTaxBrktRngIdUpdt(String taxBrktRng_Id_Updt)
	{
		this.taxBrktRng_Id_Updt = taxBrktRng_Id_Updt;
	}

	/**
	 * @return the essExpRng_Txt_Updt
	 */
	public String getEssExpRngTxtUpdt()
	{
		return essExpRng_Txt_Updt;
	}

	
	/**
	 * @param essExpRng_Txt_Updt the essExpRng_Txt_Updt to set
	 */
	public void setEssExpRngTxtUpdt(String essExpRng_Txt_Updt)
	{
		this.essExpRng_Txt_Updt = essExpRng_Txt_Updt;
	}

	/**
	 * @return the essExpRng_Id_Updt
	 */
	public String getEssExpRngIdUpdt()
	{
		return essExpRng_Id_Updt;
	}

	
	/**
	 * @param essExpRng_Id_Updt the essExpRng_Id_Updt to set
	 */
	public void setEssExpRngIdUpdt(String essExpRng_Id_Updt)
	{
		this.essExpRng_Id_Updt = essExpRng_Id_Updt;
	}

	/**
	 * @return the spendLikeRng_Txt_Updt
	 */
	public String getSpendLikeRngTxtUpdt()
	{
		return spendLikeRng_Txt_Updt;
	}

	
	/**
	 * @param spendLikeRng_Txt_Updt the spendLikeRng_Txt_Updt to set
	 */
	public void setSpendLikeRngTxtUpdt(String spendLikeRng_Txt_Updt)
	{
		this.spendLikeRng_Txt_Updt = spendLikeRng_Txt_Updt;
	}

	/**
	 * @return the spendLikeRng_Id_Updt
	 */
	public String getSpendLikeRngIdUpdt()
	{
		return spendLikeRng_Id_Updt;
	}

	
	/**
	 * @param spendLikeRng_Id_Updt the spendLikeRng_Id_Updt to set
	 */
	public void setSpendLikeRngIdUpdt(String spendLikeRng_Id_Updt)
	{
		this.spendLikeRng_Id_Updt = spendLikeRng_Id_Updt;
	}

	/**
	 * @return the invesTimeHrzn_Txt_Updt
	 */
	public String getInvesTimeHrznTxtUpdt()
	{
		return invesTimeHrzn_Txt_Updt;
	}

	
	/**
	 * @param invesTimeHrzn_Txt_Updt the invesTimeHrzn_Txt_Updt to set
	 */
	public void setInvesTimeHrznTxtUpdt(String invesTimeHrzn_Txt_Updt)
	{
		this.invesTimeHrzn_Txt_Updt = invesTimeHrzn_Txt_Updt;
	}

	/**
	 * @return the invesTimeHrzn_Id_Updt
	 */
	public String getInvesTimeHrznIdUpdt()
	{
		return invesTimeHrzn_Id_Updt;
	}

	
	/**
	 * @param invesTimeHrzn_Id_Updt the invesTimeHrzn_Id_Updt to set
	 */
	public void setInvesTimeHrznIdUpdt(String invesTimeHrzn_Id_Updt)
	{
		this.invesTimeHrzn_Id_Updt = invesTimeHrzn_Id_Updt;
	}

	/**
	 * @return the tam_TotalEqty_Updt
	 */
	public String getTamTotalEqtyUpdt()
	{
		return tam_TotalEqty_Updt;
	}

	
	/**
	 * @param tam_TotalEqty_Updt the tam_TotalEqty_Updt to set
	 */
	public void setTamTotalEqtyUpdt(String tam_TotalEqty_Updt)
	{
		this.tam_TotalEqty_Updt = tam_TotalEqty_Updt;
	}

	/**
	 * @return the tam_DomEqty_Updt
	 */
	public String getTamDomEqtyUpdt()
	{
		return tam_DomEqty_Updt;
	}

	
	/**
	 * @param tam_DomEqty_Updt the tam_DomEqty_Updt to set
	 */
	public void setTamDomEqtyUpdt(String tam_DomEqty_Updt)
	{
		this.tam_DomEqty_Updt = tam_DomEqty_Updt;
	}

	/**
	 * @return the tam_ForeignEqty_Updt
	 */
	public String getTamForeignEqtyUpdt()
	{
		return tam_ForeignEqty_Updt;
	}

	
	/**
	 * @param tam_ForeignEqty_Updt the tam_ForeignEqty_Updt to set
	 */
	public void getTamForeignEqtyUpdt(String tam_ForeignEqty_Updt)
	{
		this.tam_ForeignEqty_Updt = tam_ForeignEqty_Updt;
	}

	/**
	 * @return the tam_Bond_Updt
	 */
	public String getTamBondUpdt()
	{
		return tam_Bond_Updt;
	}

	
	/**
	 * @param tam_Bond_Updt the tam_Bond_Updt to set
	 */
	public void setTamBondUpdt(String tam_Bond_Updt)
	{
		this.tam_Bond_Updt = tam_Bond_Updt;
	}

	/**
	 * @return the tam_Cash_Updt
	 */
	public String getTamCashUpdt()
	{
		return tam_Cash_Updt;
	}

	
	/**
	 * @param tam_Cash_Updt the tam_Cash_Updt to set
	 */
	public void setTamCashUpdt(String tam_Cash_Updt)
	{
		this.tam_Cash_Updt = tam_Cash_Updt;
	}

	/**
	 * @return the tam_lowEqtyPct_Updt
	 */
	public String getTamLowEqtyPctUpdt()
	{
		return tam_lowEqtyPct_Updt;
	}

	
	/**
	 * @param tam_lowEqtyPct_Updt the tam_lowEqtyPct_Updt to set
	 */
	public void setTamLowEqtyPctUpdt(String tam_lowEqtyPct_Updt)
	{
		this.tam_lowEqtyPct_Updt = tam_lowEqtyPct_Updt;
	}

	/**
	 * @return the tam_upEqtyPct_Updt
	 */
	public String getTamUpEqtyPctUpdt()
	{
		return tam_upEqtyPct_Updt;
	}

	
	/**
	 * @param tam_upEqtyPct_Updt the tam_upEqtyPct_Updt to set
	 */
	public void setTamUpEqtyPctUpdt(String tam_upEqtyPct_Updt)
	{
		this.tam_upEqtyPct_Updt = tam_upEqtyPct_Updt;
	}

	/**
	 * @return the tam_assetAlloc_Id_Updt
	 */
	public String getTamAssetAllocIdUpdt()
	{
		return tam_assetAlloc_Id_Updt;
	}

	
	/**
	 * @param tam_assetAlloc_Id_Updt the tam_assetAlloc_Id_Updt to set
	 */
	public void setTamAssetAllocIdUpdt(String tam_assetAlloc_Id_Updt)
	{
		this.tam_assetAlloc_Id_Updt = tam_assetAlloc_Id_Updt;
	}

	/**
	 * @return the tam_context_Updt
	 */
	public String getTamContextUpdt()
	{
		return tam_context_Updt;
	}

	
	/**
	 * @param tam_context_Updt the tam_context_Updt to set
	 */
	public void setTamContextUpdt(String tam_context_Updt)
	{
		this.tam_context_Updt = tam_context_Updt;
	}



	

}
