/*
 * Copyright 2020, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.constants;

import org.apache.commons.lang3.StringUtils;

/**
 * @author a653510
 *
 */
public class TestDataConstants
{

	public final static String TEST_DATA_LOCATION = "src/test/resources/data/account_test_data.db";
	public final static String GRANTS_TEST_DATA_LOCATION = "src/test/resources/data/account_grants_test_data.db";


	public final static String ACCT_TYPE_RETAIL = "Retail";
	public final static String ACCT_TYPE_MANUAL = "Manual";
	public final static String ACCT_TYPE_WP = "Workplace";
	public final static String ACCT_TYPE_FILI = "Fili";
	public final static String ACCT_TYPE_FV = "FullView";

	public final static int NO_OF_ROWS = 10;

	public static final String HOST = StringUtils.isNotEmpty(System.getProperty("testEnv"))

			? System.getProperty("testEnv")
			: "https://ast-platformqa1.fmr.com";

	public final static String ACCOUNT_REGCODE_TABLE_NAME = "account_regcodes";

	public static final String ACCT_TYPE_COLNAME = "account_type";

	public final static String ACCT_RETAIL_TESTNAME = "account_retail";
	public static final String ACCT_FILI_TESTNAME = "account_fili";
	public static final String ACCT_WP_TESTNAME = "account_workplace";
	public static final String ACCT_MANUAL_TESTNAME = "account_manual";
	public static final String ACCT_FV_TESTNAME = "account_fullview";
	public static final String ACCT_GRANTSONEGRANT_TESTNAME = "onegrant_onevest";
	public static final String ACCT_POSITIONS_GET_TESTNAME = "account_positions_get";
	public static final String ACCT_POSITIONS_SET_TESTNAME = "account_positions_set";

	public static final String ACCOUNT_RETAIL_TABLE_NAME = "account_regcodes_retail";
	public static final String ACCOUNT_FILI_TABLE_NAME = "account_regcodes_fili";
	public static final String ACCOUNT_MANUAL_TABLE_NAME = "account_regcodes_manual";
	public static final String ACCOUNT_WP_TABLE_NAME = "account_regcodes_workplace";
	public static final String ACCOUNT_FV_TABLE_NAME = "account_regcodes_fullview";
	public static final String ACCOUNT_REGCODES_TABLE_NAME = "account_regcodes";

	public static final String ACCOUNT_GRANTSONEGRANT_TABLE_NAME = "onegrant_onevest";
	public static final String ACCOUNT_POSITIONS_TABLE_NAME = "account_positions";

	public static final String ACCT_COLNAME_FILTER_TYPE = "filterType";

	public static final String ACCT_FILTER_INCLUDEE = "INCLUDE";
	public static final String ACCT_FILTER_EXCLUDEE = "EXCLUDE";
	public static final String POE_NB = "NETBENEFITS";

	public static final String HH_PRINCIPAL = "PRINCIPAL";
	public static final String HH_PARTNER = "PARTNER";
	public static final String HH_DEPENDENT = "DEPENDENT";

	public static final String ACCT_FILI_CRITICAL_TEST = "account_fili_critical";
	public static final String ACCT_MANUAL_CRITICAL_TEST = "account_manual_critical";
	public static final String ACCT_RETAIL_CRITICAL_TEST = "account_retail_critical";
	public static final String ACCT_RETAIL_NPDCDB_TEST = "account_retail_isNpDCDBComplied";
	public static final String ACCT_WORKPLACE_CRITICAL_TEST = "account_workplace_critical";
	public static final String ACCT_FULLVIEW_CRITICAL_TEST = "account_fullview_critical";
	public static final int TWO_CRITICAL_ROWS = 2;
	public static final int THREE_CRITICAL_ROWS = 3;
	public static final int FIVE_CRITICAL_ROWS = 5;
	public static final int ONE = 1;
}