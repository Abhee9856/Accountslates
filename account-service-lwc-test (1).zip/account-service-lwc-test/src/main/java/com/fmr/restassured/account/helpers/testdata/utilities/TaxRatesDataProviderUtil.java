package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.restassured.account.helpers.testdata.dto.AccountTaxRatesTestData;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.testng.annotations.DataProvider;

public class TaxRatesDataProviderUtil
{
    
    /**
     * The AccountTaxRatesTestData DTO
     */
    private static List<List<AccountTaxRatesTestData>> taxratesTestData = null;
    
    /**
     * Instance to the test data utility class
     */
    private static final TestDataUtil testDataUtil = new TestDataUtil();
    
    /**
     * Gets use cases based on the source system provided.
     * <p>
     * <p>
     * the source system
     *
     * @return the test data
     */
    
    @DataProvider(name = "getRetailTaxRatesData")
    private static Object[][] getData()
    {
        taxratesTestData = new ArrayList<>();
        testDataUtil.getTaxRatesTestData().stream().filter(Objects::nonNull)
                .forEach(data -> {
                    final List<AccountTaxRatesTestData> dataList = new ArrayList<>();
                    dataList.add(data);
                    taxratesTestData.add(dataList);
                });
        
        return taxratesTestData.stream().map(List::toArray).toArray(Object[][]::new);
    }
    
}
