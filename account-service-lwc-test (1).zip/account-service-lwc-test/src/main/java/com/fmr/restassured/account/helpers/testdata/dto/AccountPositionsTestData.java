/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.dto;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * Contains position related test data. Instantiates with default data, but can be updated.
 *
 * @author a560878
 *
 */
@Entity
public class AccountPositionsTestData
{
	@Column(name = "test_name")
	private String testName = "account_positions_set";

	@Column(name = "source_system")
	private String sourceSystem = "Retail";

	@Column(name = "ssn")
	private String ssn = "123456789";

	@Column(name = "lid")
	private String lid = "retailLid";
	
	@Column(name = "src_based_regfilter")
	private String srcBasedRegFilter = "RETAIL";

	@Column(name = "regCode1")
	private String regCode1 = "401K";

	@Column(name = "regCode2")
	private String regCode2 = "IRA";

	@Column(name = "regCode3")
	private String regCode3 = "IRRL";

	@Column(name = "filterType")
	private String filterType = "INCLUDE";

	@Column(name = "poe")
	private String pointOfEntry = "RETAIL";

	public AccountPositionsTestData()
	{
		super();
	}

	/**
	 *
	 * @param testName
	 * @param sourceSystem
	 * @param ssn
	 * @param lid
	 * @param srcBasedRegFilter
	 * @param regCode1
	 * @param regCode2
	 * @param regCode3
	 * @param filterType
	 * @param pointOfEntry
	 */
	public AccountPositionsTestData(String testName, String ssn, String lid,
	        String srcBasedRegFilter, String regCode1, String regCode2, String regCode3, String filterType, String pointOfEntry)
	{
		this.testName = testName;
		this.sourceSystem = sourceSystem;
		this.ssn = ssn;
		this.lid = lid;
		this.srcBasedRegFilter = srcBasedRegFilter;
		this.regCode1 = regCode1;
		this.regCode2 = regCode2;
		this.regCode3 = regCode3;
		this.filterType = filterType;
		this.pointOfEntry = pointOfEntry;
	}

	
	/**
	 * @return the test name
	 */
	public String getTestName()
	{
		return testName;
	}

	
	/**
	 * @param testName the testName to set
	 */
	public void setTestName(String testName)
	{
		this.testName = testName;
	}

	
	/**
	 * @return the sourceSystem
	 */
	public String getSourceSystem()
	{
		return sourceSystem;
	}

	
	/**
	 * @param sourceSystem the sourceSystem to set
	 */
	public void setSourceSystem(String sourceSystem)
	{
		this.sourceSystem = sourceSystem;
	}

	
	/**
	 * @return the ssn
	 */
	public String getSsn()
	{
		return ssn;
	}

	
	/**
	 * @param ssn the ssn to set
	 */
	public void setSsn(String ssn)
	{
		this.ssn = ssn;
	}

	
	/**
	 * @return the lid
	 */
	public String getLid()
	{
		return lid;
	}

	
	/**
	 * @param lid the lid to set
	 */
	public void setLid(String lid)
	{
		this.lid = lid;
	}

	
	/**
	 * @return the srcBasedRegFilter
	 */
	public String getSrcBasedRegFilter()
	{
		return srcBasedRegFilter;
	}

	
	/**
	 * @param srcBasedRegFilter the srcBasedRegFilter to set
	 */
	public void setSrcBasedRegFilter(String srcBasedRegFilter)
	{
		this.srcBasedRegFilter = srcBasedRegFilter;
	}

	
	/**
	 * @return the regCode1
	 */
	public String getRegCode1()
	{
		return regCode1;
	}

	
	/**
	 * @param regCode1 the regCode1 to set
	 */
	public void setRegCode1(String regCode1)
	{
		this.regCode1 = regCode1;
	}

	
	/**
	 * @return the regCode2
	 */
	public String getRegCode2()
	{
		return regCode2;
	}

	
	/**
	 * @param regCode2 the regCode2 to set
	 */
	public void setRegCode2(String regCode2)
	{
		this.regCode2 = regCode2;
	}

	
	/**
	 * @return the regCode3
	 */
	public String getRegCode3()
	{
		return regCode3;
	}

	
	/**
	 * @param regCode3 the regCode3 to set
	 */
	public void setRegCode3(String regCode3)
	{
		this.regCode3 = regCode3;
	}

	/**
	 * @return the filterType
	 */
	public String getFilterType()
	{
		return filterType;
	}

	
	/**
	 * @param filterType the filterType to set
	 */
	public void setFilterType(String filterType)
	{
		this.filterType = filterType;
	}

	/**
	 * @return the pointOfEntry
	 */
	public String getPointOfEntry()
	{
		return pointOfEntry;
	}

	
	/**
	 * @param pointOfEntry the pointOfEntry to set
	 */
	public void setPointOfEntry(String pointOfEntry)
	{
		this.pointOfEntry = pointOfEntry;
	}


}
