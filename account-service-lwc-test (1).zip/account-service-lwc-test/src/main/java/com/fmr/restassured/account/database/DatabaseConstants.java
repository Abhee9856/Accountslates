/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.database;


/**
 * This class holds all constants pertaining to database connectivity
 *
 * @author a623549
 */
public class DatabaseConstants {
    /**
     * The constant for SQLite driver class name
     */
    public static final String SQLITE_DRIVER_CLASS_NAME = "org.sqlite.JDBC";

    /**
     * The constant for the file separator system property
     */
    public static final String FILE_SEPARATOR = "file.separator";

    /**
     * The constant for the database name used to retrieve test data
     **/
    public static final String SQLITE_TEST_DATA_DATABASE_NAME = "account_test_data.db";

    /**
     * The constant for SQLite JDBC URL that includes the path to the test data
     */
    public static final String SQLITE_JDBC_URL_TEST_DATA = "jdbc:sqlite:" + "src" + System.getProperty(FILE_SEPARATOR)
            + "test" + System.getProperty(FILE_SEPARATOR) + "resources" + System.getProperty(FILE_SEPARATOR) + "data"
            + System.getProperty(FILE_SEPARATOR) + SQLITE_TEST_DATA_DATABASE_NAME;

    /**
     * The constant for Oracle driver class name
     */
    public static final String ORACLE_DRIVER_CLASS_NAME = "oracle.jdbc.driver.OracleDriver";

    /**
     * The Constant SQLITE_SQL_FILE.
     */
    public static final String SQLITE_SQL_FILE_PATH = "src" + System.getProperty(FILE_SEPARATOR) + "test"
            + System.getProperty(FILE_SEPARATOR) + "resources" + System.getProperty(FILE_SEPARATOR) + "sql"
            + System.getProperty(FILE_SEPARATOR) + "SQLiteSQL.properties";

    public static final String SQL_MULTIPLE_REGCODES = "generic.pap.framework.sql.select.query.regcode.multiple";

    public static final String SQL_MULTIPLE_REGCODES_BY_SOURCE = "account.regcode.get.test.data.by.source";

    public static final String SQL_MULTIPLE_REGCODES_FILTER = "generic.pap.framework.sql.select.query.regcode.multiple.with.colname";

    public static final String SQL_CONTRIBUTIONS_BY_SOURCE = "account.contributions.get.test.data.by.source";

    /**
     * The Constant for query used to retrieve test data for one_grant_one_vest.
     */
    public static final String ONE_GRANT_ONE_VEST = "account.grants.onegrant.get";

    /**
     * This inner class contains constants pertaining to the SQLite property key names (located in the SQLiteSQL.properties file)
     *
     * @author a623549
     */
    public class SQLitePropertyConstants {
        /**
         * The constant for a SQLite property pertaining to an enroll 2014/10 query (refer to SQLiteSQL.properties)
         */
        public static final String SQLITE_SQL_ACCOUNT_DATA_BY_TESTNAME = "account.get.test.data";

    }

    /**
     * This inner class contains constants pertaining to the column names of the SQLite test data (account_test_data.db)
     *
     * @author a623549
     */
    public class SQLiteColumnNameConstants {
        /**
         * The constant for the 'ssn' column located in the SQLite database
         */
        public static final String SSN = "ssn";
        public static final String FcpsId = "misc";

        /**
         * The constant for the 'account_number_1' column located in the SQLite database
         */
        public static final String ACCOUNT_NUMBER_1 = "account_number_1";

        /**
         * The constant for the 'mnemonic_1' column located in the SQLite database
         */
        public static final String MNEMONIC_1 = "mnemonic_1";

        /**
         * The constant for the 'model_code' column located in the SQLite database
         */
        public static final String MODEL_CODE = "model_code";
    }
}
