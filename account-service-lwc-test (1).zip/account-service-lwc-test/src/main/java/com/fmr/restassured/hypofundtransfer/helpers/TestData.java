/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.hypofundtransfer.helpers;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.util.HashMap;

/**
 * Class that encapsulates the test data retrieved from the SQLite database.
 *
 * @author a653510
 *
 */
@Entity
public class TestData
{

	/** The map used to hold custom data parameters */
	private HashMap<String, String> map = new HashMap<String, String>();

	/** The SSN for a participant; also the fescoLid, filiLid, and/or the retailLid */
	@Column(name = "ssn")
	private String ssn;

	/** The FcpsId for a participant */
	private String fcpsId;

	/** The SID for a participant */
	private String sid;

	/** The MID for a participant */
	private String mid;
	
	private String groupId;
	
	private String groupType;
	

	/** The PPID for a participant */
	private String ppid;

	/** The Planning Party ID for a Partner */
	private String partPid;

	/** The Planning Party ID for a Dependent */
	private String dependentPid;

	/** The sourceSystem */
	@Column(name = "source_system1")
	private String sourceSystem1;

	/** The sourceSystem */
	@Column(name = "source_system2")
	private String sourceSystem2;

	/** The sourceSystem */
	@Column(name = "source_system3")
	private String sourceSystem3;

	/** The sourceSystem */
	@Column(name = "source_system4")
	private String sourceSystem4;

	/** The displayName */
	private String displayName1;

	/** The value */
	private float value1;

	/** The institutionName */
	private String institutionName1;

	/** The asOfDate */
	private String asOfDate1;

	/** The mnemonic for account number 1 */
	@Column(name = "mnemonic1")
	private String mnemonic1;

	/** The mnemonic for account number 2 */
	@Column(name = "mnemonic2")
	private String mnemonic2;

	/** An additional account number and/or plan number */
	private String accountNumber1;

	/** An additional account number and/or plan number */
	private String accountNumber2;

	/** An additional account number and/or plan number */
	private String accountNumber3;

	/** The mnemonic for account number 3 */
	@Column(name = "mnemonic3")
	private String mnemonic3;

	/** An additional account number and/or plan number */
	private String accountNumber4;

	/** The mnemonic for account number 4 */
	@Column(name = "mnemonic4")
	private String mnemonic4;

	@Column(name = "funding_act_num1")
	private String fundAcctNumber1;

	@Column(name = "funding_act_num2")
	private String fundAcctNumber2;

	@Column(name = "destination_act_num1")
	private String destAcctNumber1;

	@Column(name = "destination_act_num2")
	private String destAcctNumber2;

	@Column(name = "destination_act_type")
	private String destAcctType;

	@Column(name = "transfer_type")
	private String transferType;

	@Column(name = "total_amt")
	private double totalAmount;

	@Column(name = "domestic_equity_amt")
	private double domesticEquityAmount;

	@Column(name = "foreign_equity_amt")
	private double foreignEquityAmount;

	@Column(name = "bond_amt")
	private double bondAmount;

	@Column(name = "cash_amt")
	private double cashAmount;

	@Column(name = "other_amt")
	private double otherAmount;

	public TestData()
	{
		super();
	}

	/**
	 * TODO Auto-generated JavaDoc
	 *
	 * @param ssn
	 * @param fcpsId
	 * @param sid
	 * @param mid
	 * @param sourceSystem1
	 * @param sourceSystem2
	 * @param sourceSystem3
	 * @param sourceSystem4
	 * @param mnemonic1
	 * @param mnemonic2
	 * @param mnemonic3
	 * @param mnemonic4
	 * @param fundAcctNumber1
	 * @param fundAcctNumber2
	 * @param destAcctNumber1
	 * @param destAcctNumber2
	 * @param destAcctType
	 * @param transferType
	 * @param totalAmount
	 * @param domesticEquityAmount
	 * @param foreignEquityAmount
	 * @param bondAmount
	 * @param cashAmount
	 * @param otherAmount
	 */
	public TestData(String ssn, String fcpsId, String sid, String mid, String sourceSystem1, String sourceSystem2,
	        String sourceSystem3, String sourceSystem4, String mnemonic1, String mnemonic2, String mnemonic3,
	        String mnemonic4, String fundAcctNumber1, String fundAcctNumber2, String destAcctNumber1,
	        String destAcctNumber2, String destAcctType, String transferType, double totalAmount,
	        double domesticEquityAmount, double foreignEquityAmount, double bondAmount, double cashAmount,
	        double otherAmount)
	{
		super();
		this.ssn = ssn;
		this.fcpsId = fcpsId;
		this.sid = sid;
		this.mid = mid;
		this.sourceSystem1 = sourceSystem1;
		this.sourceSystem2 = sourceSystem2;
		this.sourceSystem3 = sourceSystem3;
		this.sourceSystem4 = sourceSystem4;
		this.mnemonic1 = mnemonic1;
		this.mnemonic2 = mnemonic2;
		this.mnemonic3 = mnemonic3;
		this.mnemonic4 = mnemonic4;
		this.fundAcctNumber1 = fundAcctNumber1;
		this.fundAcctNumber2 = fundAcctNumber2;
		this.destAcctNumber1 = destAcctNumber1;
		this.destAcctNumber2 = destAcctNumber2;
		this.destAcctType = destAcctType;
		this.transferType = transferType;
		this.totalAmount = totalAmount;
		this.domesticEquityAmount = domesticEquityAmount;
		this.foreignEquityAmount = foreignEquityAmount;
		this.bondAmount = bondAmount;
		this.cashAmount = cashAmount;
		this.otherAmount = otherAmount;
	}

	/**
	 * This method allows you to get a custom made parameter.
	 * 
	 * @param key
	 *            key used to retrieve the value
	 * @return the key or null if the key does not exist
	 */
	public String get(String key)
	{
		return map.get(key);
	}

	/**
	 * @return the map
	 */
	public HashMap<String, String> getMap()
	{
		return map;
	}

	/**
	 * This method will add a custom named parameter to a map for use in tests.
	 * 
	 * @param key
	 *            the key
	 * @param value
	 *            the value
	 */
	public void set(String key, String value)
	{
		map.put(key, value);
	}

	/**
	 * 
	 * Gets the SSN (customer identifier)
	 *
	 * @return the SSN (fescoLid, retailLid, filiLid)
	 */
	public String getSsn()
	{
		return ssn;
	}

	/**
	 * 
	 * Sets the SSN (customer identifier)
	 *
	 * @param ssn
	 *            (fescoLid, retailLid, filiLid)
	 */
	public void setSsn(String ssn)
	{
		this.ssn = ssn;
	}

	/**
	 *
	 * Gets the FcpsId (customer identifier)
	 *
	 * @return the fcpsId
	 */
	public String getFcpsId()
	{
		return fcpsId;
	}

	/**
	 *
	 * Sets the FcpsId (customer identifier)
	 *
	 * @param fcpsId
	 */
	public void setFcpsId(String fcpsId)
	{
		this.fcpsId = fcpsId;
	}

	/**
	 * 
	 * Gets the SID (identifier for FullView)
	 *
	 * @return
	 */
	public String getSid()
	{
		return sid;
	}

	/**
	 * 
	 * Sets the SID
	 *
	 * @param sid
	 */
	public void setSid(String sid)
	{
		this.sid = sid;
	}

	/**
	 * Gets the MID
	 * 
	 * @return mid
	 */
	public String getMid()
	{
		return mid;
	}

	/**
	 * Sets the MID
	 * 
	 * @param mid
	 */
	public void setMid(String mid)
	{
		this.mid = mid;
	}

	/**
	 * Gets the ppid
	 * 
	 * @return
	 *
	 */
	public String getPpid()
	{
		return ppid;
	}

	/**
	 * Sets the ppid
	 * 
	 * @param ppid
	 */
	public void setPpid(String ppid)
	{
		this.ppid = ppid;
	}

	/**
	 * Gets the Planning Party ID for the Partner
	 * 
	 * @return partPid
	 */
	public String getPartPid()
	{
		return partPid;
	}

	/**
	 * Sets the Planning Party ID for the Partner
	 * 
	 * @param partPid
	 */
	public void setPartPid(String partPid)
	{
		this.partPid = partPid;
	}

	/**
	 * Gets the Planning Party ID for the Dependent
	 * 
	 * @return dependentPid
	 */
	public String getDependentPid()
	{
		return dependentPid;
	}

	/**
	 * Sets the Planning Party ID for the Dependent
	 * 
	 * @param dependentPid
	 */
	public void setDependentPid(String dependentPid)
	{
		this.dependentPid = dependentPid;
	}

	/**
	 * 
	 * Gets the mnemonic for account number 1
	 *
	 * @return the mnemonic for account number 1
	 */
	public String getMnemonic1()
	{
		return mnemonic1;
	}

	/**
	 * 
	 * Sets the mnemonic for account number 1
	 *
	 * @param mnemonic1
	 */
	public void setMnemonic1(String mnemonic1)
	{
		this.mnemonic1 = mnemonic1;
	}

	public String getSourceSystem1()
	{
		return sourceSystem1;
	}

	public void setSourceSystem1(String sourceSystem)
	{
		this.sourceSystem1 = sourceSystem;
	}

	public String getDisplayName1()
	{
		return displayName1;
	}

	public void setDisplayName1(String displayName1)
	{
		this.displayName1 = displayName1;
	}

	public float getValue1()
	{
		return value1;
	}

	public void setValue1(float value1)
	{
		this.value1 = value1;
	}

	public String getInstitutionName1()
	{
		return institutionName1;
	}

	public void setInstitutionName1(String institutionName1)
	{
		this.institutionName1 = institutionName1;
	}

	public String getAsOfDate1()
	{
		return asOfDate1;
	}

	public void setAsOfDate1(String asOfDate1)
	{
		this.asOfDate1 = asOfDate1;
	}

	/**
	 * @return the accountNumber1
	 */
	public String getAccountNumber1()
	{
		return accountNumber1;
	}

	/**
	 * @param accountNumber1
	 *            the accountNumber1 to set
	 */
	public void setAccountNumber1(String accountNumber1)
	{
		this.accountNumber1 = accountNumber1;
	}

	/**
	 * 
	 * Gets account number 2
	 *
	 * @return account number 2
	 */
	public String getAccountNumber2()
	{
		return accountNumber2;
	}

	/**
	 * 
	 * Sets account number 2
	 *
	 * @param accountNumber2
	 */
	public void setAccountNumber2(String accountNumber2)
	{
		this.accountNumber2 = accountNumber2;
	}

	/**
	 * 
	 * Gets the mnemonic for account number 2
	 *
	 * @return
	 */
	public String getMnemonic2()
	{
		return mnemonic2;
	}

	/**
	 * 
	 * Sets the mnemonic for account number 2
	 *
	 * @param mnemonic2
	 */
	public void setMnemonic2(String mnemonic2)
	{
		this.mnemonic2 = mnemonic2;
	}

	/**
	 * 
	 * Gets account number 3
	 *
	 * @return account number 3
	 */
	public String getAccountNumber3()
	{
		return accountNumber3;
	}

	/**
	 * 
	 * Sets account number 3
	 *
	 * @param accountNumber3
	 */
	public void setAccountNumber3(String accountNumber3)
	{
		this.accountNumber3 = accountNumber3;
	}

	/**
	 * 
	 * Gets the mnemonic for account number 3
	 *
	 * @return the mnemonic for account number 3
	 */
	public String getMnemonic3()
	{
		return mnemonic3;
	}

	/**
	 * 
	 * Sets the mnemonic for account number 3
	 *
	 * @param mnemonic3
	 */
	public void setMnemonic3(String mnemonic3)
	{
		this.mnemonic3 = mnemonic3;
	}

	/**
	 * 
	 * Gets account number 4
	 *
	 * @return account number 4
	 */
	public String getAccountNumber4()
	{
		return accountNumber4;
	}

	/**
	 * 
	 * Sets account number 4
	 *
	 * @param accountNumber4
	 */
	public void setAccountNumber4(String accountNumber4)
	{
		this.accountNumber4 = accountNumber4;
	}

	/**
	 * 
	 * Gets the mnemonic for account number 4
	 *
	 * @return the mnemonic for account number 4
	 */
	public String getMnemonic4()
	{
		return mnemonic4;
	}

	/**
	 * 
	 * Sets the mnemonic for account number 4
	 *
	 * @param mnemonic4
	 */
	public void setMnemonic4(String mnemonic4)
	{
		this.mnemonic4 = mnemonic4;
	}

	/**
	 * @return the sourceSystem2
	 */
	public String getSourceSystem2()
	{
		return sourceSystem2;
	}

	/**
	 * @param sourceSystem2
	 *            the sourceSystem2 to set
	 */
	public void setSourceSystem2(String sourceSystem2)
	{
		this.sourceSystem2 = sourceSystem2;
	}

	/**
	 * @return the sourceSystem3
	 */
	public String getSourceSystem3()
	{
		return sourceSystem3;
	}

	/**
	 * @param sourceSystem3
	 *            the sourceSystem3 to set
	 */
	public void setSourceSystem3(String sourceSystem3)
	{
		this.sourceSystem3 = sourceSystem3;
	}

	/**
	 * @return the sourceSystem4
	 */
	public String getSourceSystem4()
	{
		return sourceSystem4;
	}

	/**
	 * @param sourceSystem4
	 *            the sourceSystem4 to set
	 */
	public void setSourceSystem4(String sourceSystem4)
	{
		this.sourceSystem4 = sourceSystem4;
	}

	/**
	 * @return the fundAcctNumber1
	 */
	public String getFundAcctNumber1()
	{
		return fundAcctNumber1;
	}

	/**
	 * @param fundAcctNumber1
	 *            the fundAcctNumber1 to set
	 */
	public void setFundAcctNumber1(String fundAcctNumber1)
	{
		this.fundAcctNumber1 = fundAcctNumber1;
	}

	/**
	 * @return the fundAcctNumber2
	 */
	public String getFundAcctNumber2()
	{
		return fundAcctNumber2;
	}

	/**
	 * @param fundAcctNumber2
	 *            the fundAcctNumber2 to set
	 */
	public void setFundAcctNumber2(String fundAcctNumber2)
	{
		this.fundAcctNumber2 = fundAcctNumber2;
	}

	/**
	 * @return the destAcctNumber1
	 */
	public String getDestAcctNumber1()
	{
		return destAcctNumber1;
	}

	/**
	 * @param destAcctNumber1
	 *            the destAcctNumber1 to set
	 */
	public void setDestAcctNumber1(String destAcctNumber1)
	{
		this.destAcctNumber1 = destAcctNumber1;
	}

	/**
	 * @return the destAcctNumber2
	 */
	public String getDestAcctNumber2()
	{
		return destAcctNumber2;
	}

	/**
	 * @param destAcctNumber2
	 *            the destAcctNumber2 to set
	 */
	public void setDestAcctNumber2(String destAcctNumber2)
	{
		this.destAcctNumber2 = destAcctNumber2;
	}

	/**
	 * @return the destAcctType
	 */
	public String getDestAcctType()
	{
		return destAcctType;
	}

	/**
	 * @param destAcctType
	 *            the destAcctType to set
	 */
	public void setDestAcctType(String destAcctType)
	{
		this.destAcctType = destAcctType;
	}

	/**
	 * @return the transferType
	 */
	public String getTransferType()
	{
		return transferType;
	}

	/**
	 * @param transferType
	 *            the transferType to set
	 */
	public void setTransferType(String transferType)
	{
		this.transferType = transferType;
	}

	/**
	 * @return the totalAmount
	 */
	public double getTotalAmount()
	{
		return totalAmount;
	}

	/**
	 * @param totalAmount
	 *            the totalAmount to set
	 */
	public void setTotalAmount(double totalAmount)
	{
		this.totalAmount = totalAmount;
	}

	/**
	 * @return the domesticEquityAmount
	 */
	public double getDomesticEquityAmount()
	{
		return domesticEquityAmount;
	}

	/**
	 * @param domesticEquityAmount
	 *            the domesticEquityAmount to set
	 */
	public void setDomesticEquityAmount(double domesticEquityAmount)
	{
		this.domesticEquityAmount = domesticEquityAmount;
	}

	/**
	 * @return the foreignEquityAmount
	 */
	public double getForeignEquityAmount()
	{
		return foreignEquityAmount;
	}

	/**
	 * @param foreignEquityAmount
	 *            the foreignEquityAmount to set
	 */
	public void setForeignEquityAmount(double foreignEquityAmount)
	{
		this.foreignEquityAmount = foreignEquityAmount;
	}

	/**
	 * @return the bondAmount
	 */
	public double getBondAmount()
	{
		return bondAmount;
	}

	/**
	 * @param bondAmount
	 *            the bondAmount to set
	 */
	public void setBondAmount(double bondAmount)
	{
		this.bondAmount = bondAmount;
	}

	/**
	 * @return the cashAmount
	 */
	public double getCashAmount()
	{
		return cashAmount;
	}

	/**
	 * @param cashAmount
	 *            the cashAmount to set
	 */
	public void setCashAmount(double cashAmount)
	{
		this.cashAmount = cashAmount;
	}

	/**
	 * @return the otherAmount
	 */
	public double getOtherAmount()
	{
		return otherAmount;
	}

	/**
	 * @param otherAmount
	 *            the otherAmount to set
	 */
	public void setOtherAmount(double otherAmount)
	{
		this.otherAmount = otherAmount;
	}

	
	/**
	 * @return the groupId
	 */
	public String getGroupId()
	{
		return groupId;
	}

	
	/**
	 * @param groupId the groupId to set
	 */
	public void setGroupId(String groupId)
	{
		this.groupId = groupId;
	}

	
	/**
	 * @return the groupType
	 */
	public String getGroupType()
	{
		return groupType;
	}

	
	/**
	 * @param groupType the groupType to set
	 */
	public void setGroupType(String groupType)
	{
		this.groupType = groupType;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		return "TestData [ssn=" + ssn + ", fcpsId=" + fcpsId + ", sid=" + sid + ", mid=" + mid + ", ppid=" + ppid
		        + ", partPid=" + partPid + ", dependentPid=" + dependentPid + ", sourceSystem1=" + sourceSystem1
		        + ", sourceSystem2=" + sourceSystem2 + ", sourceSystem3=" + sourceSystem3 + ", sourceSystem4="
		        + sourceSystem4 + ", displayName1=" + displayName1 + ", value1=" + value1 + ", institutionName1="
		        + institutionName1 + ", asOfDate1=" + asOfDate1 + ", mnemonic1=" + mnemonic1 + ", accountNumber1="
		        + accountNumber1 + ", accountNumber2=" + accountNumber2 + ", mnemonic2=" + mnemonic2
		        + ", accountNumber3=" + accountNumber3 + ", mnemonic3=" + mnemonic3 + ", accountNumber4="
		        + accountNumber4 + ", mnemonic4=" + mnemonic4 + ", fundAcctNumber1=" + fundAcctNumber1
		        + ", fundAcctNumber2=" + fundAcctNumber2 + ", destAcctNumber1=" + destAcctNumber1 + ", destAcctNumber2="
		        + destAcctNumber2 + ", destAcctType=" + destAcctType + ", transferType=" + transferType
		        + ", totalAmount=" + totalAmount + ", domesticEquityAmount=" + domesticEquityAmount
		        + ", foreignEquityAmount=" + foreignEquityAmount + ", bondAmount=" + bondAmount + ", cashAmount="
		        + cashAmount + ", otherAmount=" + otherAmount + "]";
	}

}
