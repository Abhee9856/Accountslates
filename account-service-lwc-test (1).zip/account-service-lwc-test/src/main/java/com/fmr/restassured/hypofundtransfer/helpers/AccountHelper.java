/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.hypofundtransfer.helpers;

import com.fmr.pap.restassured.core.TestEnv;

/**
 * Helper class for creating Account.
 *
 * @author a631781
 *
 */

public class AccountHelper
{

	public final static String ACCOUNT_CREATE_PATH = "account/v2/create";

	public static String getCurrentTestEnvHost()
	{
		String currentTestEnvHost = "";
		String testEnv = System.getProperty("testEnv");
		if (testEnv == null || testEnv == "")
		{
			// Test environment is set here and you can give the name of the env you wish to run your test against.
			testEnv = "QA1";
		}
		switch (TestEnv.valueOf(testEnv.toUpperCase()))
		{
			case LOCAL:
				currentTestEnvHost = "https://ast-platformqa1.fmr.com";
				break;
			case DEV1:
				currentTestEnvHost = "https://ast-platformqa1.fmr.com";
				break;
			case DIT1:
				currentTestEnvHost = "https://ast-platform-dit1.fmr.com";
				break;
			case QA1:
					
				break;
			case QA1_PASSIVE:
				currentTestEnvHost = "https://fc-pap-account-qa1-oma1-test.fmr.com";
				break;
			case PAC:
				currentTestEnvHost = "https://ast-platformqa1.fmr.com";
				break;
			default:
				currentTestEnvHost = "https://ast-platformqa1.fmr.com";
		}
		return currentTestEnvHost;
	}

	public static String getLocalTestEnvHost()
	{
		return "http://localhost:8080";
	}
	
	public static String getQATestEnvHost()
	{
		return "https://ast-platformqa1.fmr.com";
	}

}