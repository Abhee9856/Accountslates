package com.fmr.restassured.account.helpers.testdata.dto;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * Contains contribution related test data. Instantiates with default data, but can be updated.
 *
 * @author a601767
 */
@Entity
public class AccountContributionsTestData {

    @Column(name = "type")
    private String contributionType = "SIMPLE";

    @Column(name = "tax_type")
    private String contributionTaxType = "PRE_TAX";

    @Column(name = "level_type")
    private String contributionLevelType = "FAMILY";

    @Column(name = "contributor")
    private String contributor = "INDIVIDUAL";

    @Column(name = "frequency")
    private String frequency = "MONTHLY";

    @Column(name = "contribution_value")
    private String contributionValue = "818.89";

    @Column(name = "updated_contribution_value")
    private String updatedContributionValue = "426.85";

    @Column(name = "contribution_value_type")
    private String valueType = "MONEY";

    private Boolean isDetailed = true;

    private Boolean updatedIsDetailed = false;

    @Column(name = "contribution_basis_type")
    private String contribBasisTypeCd1 = "BASE";

    /**
     * The Contrib basis type cd.
     */
    private String contribBasisTypeCd = "BASECMMSN";

    /**
     * The Contribution name.
     */
    private String contributionName = "BEFORE-TAX";

    /**
     * The Election cd.
     */
    private String electionCd = "12";

    /**
     * The contribution id - primary key.
     */
    private String contributionId;

    /**
     * The Contribution Max Retail Value.
     */
    private String contributionMaxRateValue = "1.0";

    /**
     * The Contribution Max Retail Value Uom CD.
     */
    private String contributionMaxRateValueType = "PERCENT";

    /**
     * The Contribution Max Retail Value.
     */
    private String updatedContributionMaxRateValue = "0.5";

    /**
     * The Contrib basis type cd.
     */
    private String contribBasisTypeCd2 = "BONUS";

    /**
     * The Contribution name.
     */
    private String contributionName2 = "AFTER-TAX";

    /**
     * The Election cd.
     */
    private String electionCd2 = "13";

    public AccountContributionsTestData() {
        super();
    }

    public AccountContributionsTestData(final String contributionType, final String contributionTaxType,
                                        final String contributionLevelType, final String contributor,
                                        final String frequency, final String contributionValue,
                                        final String updatedContributionValue, final String valueType,
                                        final Boolean isDetailed, final String contribBasisTypeCd,
                                        final String contributionName, final String electionCd, final String contributionMaxRateValue,
                                        final String contributionMaxRateValueType, final String updatedContributionMaxRateValue,
                                        final String contribBasisTypeCd2, final String contribBasisTypeCd1,
                                        final String contributionName2, final String electionCd2) {
        this.contributionType = contributionType;
        this.contributionTaxType = contributionTaxType;
        this.contributionLevelType = contributionLevelType;
        this.contributor = contributor;
        this.frequency = frequency;
        this.contributionValue = contributionValue;
        this.updatedContributionValue = updatedContributionValue;
        this.valueType = valueType;
        this.isDetailed = isDetailed;
        this.contribBasisTypeCd = contribBasisTypeCd;
        this.contributionName = contributionName;
        this.electionCd = electionCd;
        this.contributionMaxRateValue = contributionMaxRateValue;
        this.contributionMaxRateValueType = contributionMaxRateValueType;
        this.updatedContributionMaxRateValue = updatedContributionMaxRateValue;
        this.contribBasisTypeCd2 = contribBasisTypeCd2;
        this.contribBasisTypeCd1 = contribBasisTypeCd1;
        this.contributionName2 = contributionName2;
        this.electionCd2 = electionCd2;
    }

    /**
     * @return the contributionType
     */
    public String getContributionType() {
        return contributionType;
    }

    /**
     * @param contributionType the contributionType to set
     */
    public void setContributionType(String contributionType) {
        this.contributionType = contributionType;
    }

    /**
     * @return the contributionTaxType
     */
    public String getContributionTaxType() {
        return contributionTaxType;
    }

    /**
     * @param contributionTaxType the contributionTaxType to set
     */
    public void setContributionTaxType(String contributionTaxType) {
        this.contributionTaxType = contributionTaxType;
    }

    /**
     * @return the contributionLevelType
     */
    public String getContributionLevelType() {
        return contributionLevelType;
    }

    /**
     * @param contributionLevelType the contributionLevelType to set
     */
    public void setContributionLevelType(String contributionLevelType) {
        this.contributionLevelType = contributionLevelType;
    }

    /**
     * @return the contributor
     */
    public String getContributor() {
        return contributor;
    }

    /**
     * @param contributor the contributor to set
     */
    public void setContributor(String contributor) {
        this.contributor = contributor;
    }

    /**
     * @return the frequency
     */
    public String getFrequency() {
        return frequency;
    }

    /**
     * @param frequency the frequency to set
     */
    public void setFrequency(String frequency) {
        this.frequency = frequency;
    }

    /**
     * @return the contributionValue
     */
    public String getContributionValue() {
        return contributionValue;
    }

    /**
     * @param contributionValue the contributionValue to set
     */
    public void setContributionValue(String contributionValue) {
        this.contributionValue = contributionValue;
    }

    /**
     * @return the updatedContributionValue
     */
    public String getUpdatedContributionValue() {
        return updatedContributionValue;
    }

    /**
     * @param updatedContributionValue the updatedContributionValue to set
     */
    public void setUpdatedContributionValue(String updatedContributionValue) {
        this.updatedContributionValue = updatedContributionValue;
    }

    /**
     * @return the valueType
     */
    public String getValueType() {
        return valueType;
    }

    /**
     * @param valueType the valueType to set
     */
    public void setValueType(String valueType) {
        this.valueType = valueType;
    }

    /**
     * @return the isDetailed
     */
    public Boolean getIsDetailed() {
        return isDetailed;
    }

    /**
     * @param isDetailed the isDetailed to set
     */
    public void setIsDetailed(Boolean isDetailed) {
        this.isDetailed = isDetailed;
    }

    /**
     * @return the updatedIsDetailed
     */
    public Boolean getUpdatedIsDetailed() {
        return updatedIsDetailed;
    }
    /**
     * @param updatedIsDetailed the updatedIsDetailed to set
     */
    public void setUpdatedIsDetailed(Boolean updatedIsDetailed) {
        this.updatedIsDetailed = updatedIsDetailed;
    }
    /**
     * Gets contrib basis type cd.
     *
     * @return the contrib basis type cd
     */
    public String getContribBasisTypeCd() {
        return contribBasisTypeCd;
    }

    /**
     * Sets contrib basis type cd.
     *
     * @param contribBasisTypeCd the contrib basis type cd
     */
    public void setContribBasisTypeCd(final String contribBasisTypeCd) {
        this.contribBasisTypeCd = contribBasisTypeCd;
    }

    /**
     * Gets contribution name.
     *
     * @return the contribution name
     */
    public String getContributionName() {
        return contributionName;
    }

    /**
     * Sets contribution name.
     *
     * @param contributionName the contribution name
     */
    public void setContributionName(final String contributionName) {
        this.contributionName = contributionName;
    }

    /**
     * Gets election cd.
     *
     * @return the election cd
     */
    public String getElectionCd() {
        return electionCd;
    }

    /**
     * Sets election cd.
     *
     * @param electionCd the election cd
     */
    public void setElectionCd(final String electionCd) {
        this.electionCd = electionCd;
    }

    /**
     * Gets contribution id.
     *
     * @return the contribution id
     */
    public String getContributionId() {
        return contributionId;
    }

    /**
     * Sets contribution id.
     *
     * @param contributionId the contribution id
     */
    public void setContributionId(final String contributionId) {
        this.contributionId = contributionId;
    }

    /**
     * Sets contributionMaxRateValue
     *
     * @param contributionMaxRateValue
     */
    public void setContributionMaxRateValuel(final String contributionMaxRateValue) {
        this.contributionMaxRateValue = contributionMaxRateValue;
    }

    /**
     * @return contributionMaxRateValue
     */
    public String getContributionMaxRateValue() {
        return contributionMaxRateValue;
    }

    /**
     * Sets contributionMaxRateValueType
     *
     * @param contributionMaxRateValueType
     */
    public void setContributionMaxRateValueType(String contributionMaxRateValueType) {
        this.contributionMaxRateValueType = contributionMaxRateValueType;
    }

    /**
     * @return contributionMaxRateValueType
     */
    public String getContributionMaxRateValueType() {
        return contributionMaxRateValueType;
    }

    /**
     * Sets updatedContributionMaxRateValue
     *
     * @param updatedContributionMaxRateValue
     */
    public void setUpdatedContributionMaxRateValue(final String updatedContributionMaxRateValue) {
        this.updatedContributionMaxRateValue = updatedContributionMaxRateValue;
    }

    /**
     * @return updatedContributionMaxRateValue
     */
    public String getUpdatedContributionMaxRateValue() {
        return updatedContributionMaxRateValue;
    }

    /**
     * Gets contribution name.
     *
     * @return the contribution name
     */
    public String getContributionName2() {
        return contributionName2;
    }

    /**
     * Sets contribution name.
     *
     * @param contributionName2 the contribution name
     */
    public void setContributionName2(final String contributionName2) {
        this.contributionName2 = contributionName2;
    }

    /**
     * Gets election cd.
     *
     * @return the second election cd
     */
    public String getElectionCd2() {
        return electionCd2;
    }

    /**
     * Sets election cd.
     *
     * @param electionCd2 the election cd
     */
    public void setElectionCd2(final String electionCd2) {
        this.electionCd2 = electionCd2;
    }

    /**
     * Gets contrib basis type cd.
     *
     * @return the contrib basis type cd
     */
    public String getContribBasisTypeCd2() {
        return contribBasisTypeCd2;
    }

    /**
     * Sets contrib basis type cd.
     *
     * @param contribBasisTypeCd2 the contrib basis type cd
     */
    public void setContribBasisTypeCd2(final String contribBasisTypeCd2) {
        this.contribBasisTypeCd2 = contribBasisTypeCd2;
    }


    /**
     * Gets contrib basis type cd.
     *
     * @return the contrib basis type cd
     */
    public String getContribBasisTypeCd1() {
        return contribBasisTypeCd1;
    }

    /**
     * Sets contrib basis type cd.
     *
     * @param contribBasisTypeCd1 the contrib basis type cd
     */
    public void setContribBasisTypeCd1(final String contribBasisTypeCd1) {
        this.contribBasisTypeCd1 = contribBasisTypeCd1;
    }

}
