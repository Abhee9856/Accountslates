/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.dto;

import java.util.HashMap;

/**
 * Class that encapsulates the test data retrieved from the SQLite database.
 *
 * @author a601767
 */
public class AccountsCommonTestData {
    /**
     * The map used to hold custom data parameters
     */
    private HashMap<String, String> map = new HashMap<>();

    /**
     * The SSN for a participant; also the fescoLid, filiLid, and/or the retailLid
     */
    private String ssn;

    /**
     * The FcpsId for a participant
     */
    private String fcpsId;

    /**
     * The SID for a participant
     */
    private String sid;

    /**
     * The MID for a participant
     */
    private String mid;

    /**
     * The PPID for a participant
     */
    private String ppid;

    /**
     * The Planning Party ID for a Partner
     */
    private String partPid;

    /**
     * The Planning Party ID for a Dependent
     */
    private String dependentPid;

    /**
     * The model code used in the model assignment subject area; typically 1055 but can be something else
     */
    private String modelCode;

    /**
     * The account number; also the plan number
     */
    private String accountNumber1;

    /**
     * The account ID in CFP
     */
    private String accountId1;

    /**
     * The account ID for account 2 in CFP
     */
    private String accountId2;

    /**
     * The sourceSystem
     */
    private String sourceSystem1;

    /**
     * The displayName
     */
    private String displayName1;

    /**
     * The value
     */
    private float value1;

    /**
     * The institutionName
     */
    private String institutionName1;

    /**
     * The asOfDate
     */
    private String asOfDate1;

    /**
     * The mnemonic for account number 1
     */
    private String mnemonic1;

    /**
     * An additional account number and/or plan number
     */
    private String accountNumber2;

    /**
     * The mnemonic for account number 2
     */
    private String mnemonic2;

    /**
     * An additional account number and/or plan number
     */
    private String accountNumber3;

    /**
     * The mnemonic for account number 3
     */
    private String mnemonic3;

    /**
     * An additional account number and/or plan number
     */
    private String accountNumber4;

    /**
     * The mnemonic for account number 4
     */
    private String mnemonic4;

    /**
     * This method allows you to get a custom-made parameter.
     *
     * @param key key used to retrieve the value
     * @return the key or null if the key does not exist
     */
    public String get(String key) {
        return map.get(key);
    }

    /**
     * @return the map
     */
    public HashMap<String, String> getMap() {
        return map;
    }

    /**
     * This method will add a custom named parameter to a map for use in tests.
     *
     * @param key   the key
     * @param value the value
     */
    public void set(String key, String value) {
        map.put(key, value);
    }

    /**
     * Gets the SSN (customer identifier)
     *
     * @return the SSN (fescoLid, retailLid, filiLid)
     */
    public String getSsn() {
        return ssn;
    }

    /**
     * Sets the SSN (customer identifier)
     *
     * @param ssn (fescoLid, retailLid, filiLid)
     */
    public void setSsn(String ssn) {
        this.ssn = ssn;
    }

    /**
     * Gets the FcpsId (customer identifier)
     *
     * @return the fcpsId
     */
    public String getFcpsId() {
        return fcpsId;
    }

    /**
     * Sets the FcpsId (customer identifier)
     *
     * @param fcpsId
     */
    public void setFcpsId(String fcpsId) {
        this.fcpsId = fcpsId;
    }


    /**
     * Gets the SID (identifier for FullView)
     *
     * @return
     */
    public String getSid() {
        return sid;
    }

    /**
     * Sets the SID
     *
     * @param sid
     */
    public void setSid(String sid) {
        this.sid = sid;
    }

    /**
     * Gets the MID
     *
     * @return mid
     */
    public String getMid() {
        return mid;
    }

    /**
     * Sets the MID
     *
     * @param mid
     */
    public void setMid(String mid) {
        this.mid = mid;
    }

    /**
     * Gets the ppid
     *
     * @return
     */
    public String getPpid() {
        return ppid;
    }

    /**
     * Sets the ppid
     *
     * @param ppid
     */
    public void setPpid(String ppid) {
        this.ppid = ppid;
    }

    /**
     * Gets the Planning Party ID for the Partner
     *
     * @return partPid
     */
    public String getPartPid() {
        return partPid;
    }

    /**
     * Sets the Planning Party ID for the Partner
     *
     * @param partPid
     */
    public void setPartPid(String partPid) {
        this.partPid = partPid;
    }

    /**
     * Gets the Planning Party ID for the Dependent
     *
     * @return dependentPid
     */
    public String getDependentPid() {
        return dependentPid;
    }

    /**
     * Sets the Planning Party ID for the Dependent
     *
     * @param dependentPid
     */
    public void setDependentPid(String dependentPid) {
        this.dependentPid = dependentPid;
    }

    /**
     * Gets the model code
     *
     * @return the model code
     */
    public String getModelCode() {
        return modelCode;
    }

    /**
     * Sets the model code
     *
     * @param modelCode
     */
    public void setModelCode(String modelCode) {
        this.modelCode = modelCode;
    }

    /**
     * Gets account number 1
     *
     * @return account number 1
     */
    public String getAccountNumber1() {
        return accountNumber1;
    }

    /**
     * Sets account number 1
     *
     * @param accountNumber1
     */
    public void setAccountNumber1(String accountNumber1) {
        this.accountNumber1 = accountNumber1;
    }

    /**
     * Gets account id 1
     *
     * @return account id 1
     */
    public String getAccountId1() {
        return accountId1;
    }

    /**
     * Sets account id 1
     *
     * @param accountId1
     */
    public void setAccountId1(String accountId1) {
        this.accountId1 = accountId1;
    }

    /**
     * Gets account id 2
     *
     * @return account id 2
     */
    public String getAccountId2() {
        return accountId2;
    }

    /**
     * Sets account id 2
     *
     * @param accountId2
     */
    public void setAccountId2(String accountId2) {
        this.accountId2 = accountId2;
    }

    /**
     * Gets the mnemonic for account number 1
     *
     * @return the mnemonic for account number 1
     */
    public String getMnemonic1() {
        return mnemonic1;
    }

    /**
     * Sets the mnemonic for account number 1
     *
     * @param mnemonic1
     */
    public void setMnemonic1(String mnemonic1) {
        this.mnemonic1 = mnemonic1;
    }

    public String getSourceSystem1() {
        return sourceSystem1;
    }

    public void setSourceSystem1(String sourceSystem) {
        this.sourceSystem1 = sourceSystem;
    }

    public String getDisplayName1() {
        return displayName1;
    }

    public void setDisplayName1(String displayName1) {
        this.displayName1 = displayName1;
    }

    public float getValue1() {
        return value1;
    }

    public void setValue1(float value1) {
        this.value1 = value1;
    }

    public String getInstitutionName1() {
        return institutionName1;
    }

    public void setInstitutionName1(String institutionName1) {
        this.institutionName1 = institutionName1;
    }

    public String getAsOfDate1() {
        return asOfDate1;
    }

    public void setAsOfDate1(String asOfDate1) {
        this.asOfDate1 = asOfDate1;
    }

    /**
     * Gets account number 2
     *
     * @return account number 2
     */
    public String getAccountNumber2() {
        return accountNumber2;
    }

    /**
     * Sets account number 2
     *
     * @param accountNumber2
     */
    public void setAccountNumber2(String accountNumber2) {
        this.accountNumber2 = accountNumber2;
    }

    /**
     * Gets the mnemonic for account number 2
     *
     * @return
     */
    public String getMnemonic2() {
        return mnemonic2;
    }

    /**
     * Sets the mnemonic for account number 2
     *
     * @param mnemonic2
     */
    public void setMnemonic2(String mnemonic2) {
        this.mnemonic2 = mnemonic2;
    }

    /**
     * Gets account number 3
     *
     * @return account number 3
     */
    public String getAccountNumber3() {
        return accountNumber3;
    }

    /**
     * Sets account number 3
     *
     * @param accountNumber3
     */
    public void setAccountNumber3(String accountNumber3) {
        this.accountNumber3 = accountNumber3;
    }

    /**
     * Gets the mnemonic for account number 3
     *
     * @return the mnemonic for account number 3
     */
    public String getMnemonic3() {
        return mnemonic3;
    }

    /**
     * Sets the mnemonic for account number 3
     *
     * @param mnemonic3
     */
    public void setMnemonic3(String mnemonic3) {
        this.mnemonic3 = mnemonic3;
    }

    /**
     * Gets account number 4
     *
     * @return account number 4
     */
    public String getAccountNumber4() {
        return accountNumber4;
    }

    /**
     * Sets account number 4
     *
     * @param accountNumber4
     */
    public void setAccountNumber4(String accountNumber4) {
        this.accountNumber4 = accountNumber4;
    }

    /**
     * Gets the mnemonic for account number 4
     *
     * @return the mnemonic for account number 4
     */
    public String getMnemonic4() {
        return mnemonic4;
    }

    /**
     * Sets the mnemonic for account number 4
     *
     * @param mnemonic4
     */
    public void setMnemonic4(String mnemonic4) {
        this.mnemonic4 = mnemonic4;
    }
}
