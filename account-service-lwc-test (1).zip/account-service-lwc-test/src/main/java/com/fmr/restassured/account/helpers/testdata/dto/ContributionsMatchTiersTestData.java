package com.fmr.restassured.account.helpers.testdata.dto;

import javax.persistence.Column;
import javax.persistence.Entity;


/**
 * Contribution tiers
 *
 * @author a601767
 *
 */
@Entity
public class ContributionsMatchTiersTestData
{

	@Column(name = "rate")
	private String rate;

	@Column(name = "rate_amount_limit")
	private String rateAmountLimit;

	@Column(name = "rate_percent_limit")
	private String ratePercentLimit;

	@Column(name = "tier")
	private Integer tier;

	@Column(name = "type")
	private String type;
	
	
	/**
	 * Default constructor
	 *
	 */
	public ContributionsMatchTiersTestData()
	{
		super();
	}


	/**
	 * Constructor
	 *
	 * @param rate the rate
	 * @param rateAmountLimit the rateAmountLimit
	 * @param ratePercentLimit the ratePercentLimit
	 * @param tier the tier
	 * @param type the type
	 */
	public ContributionsMatchTiersTestData(String rate, String rateAmountLimit, String ratePercentLimit,
	                Integer tier, String type)
	{
		this.rate = rate;
		this.rateAmountLimit = rateAmountLimit;
		this.ratePercentLimit = ratePercentLimit;
		this.tier = tier;
		this.type = type;
	}


	/**
	 * @return the rate
	 */
	public String getRate()
	{
		return rate;
	}

	
	/**
	 * @param rate the rate to set
	 */
	public void setRate(String rate)
	{
		this.rate = rate;
	}

	
	/**
	 * @return the rateAmountLimit
	 */
	public String getRateAmountLimit()
	{
		return rateAmountLimit;
	}

	
	/**
	 * @param rateAmountLimit the rateAmountLimit to set
	 */
	public void setRateAmountLimit(String rateAmountLimit)
	{
		this.rateAmountLimit = rateAmountLimit;
	}

	
	/**
	 * @return the ratePercentLimit
	 */
	public String getRatePercentLimit()
	{
		return ratePercentLimit;
	}

	
	/**
	 * @param ratePercentLimit the ratePercentLimit to set
	 */
	public void setRatePercentLimit(String ratePercentLimit)
	{
		this.ratePercentLimit = ratePercentLimit;
	}

	
	/**
	 * @return the tier
	 */
	public Integer getTier()
	{
		return tier;
	}

	
	/**
	 * @param tier the tier to set
	 */
	public void setTier(Integer tier)
	{
		this.tier = tier;
	}

	
	/**
	 * @return the type
	 */
	public String getType()
	{
		return type;
	}

	
	/**
	 * @param type the type to set
	 */
	public void setType(String type)
	{
		this.type = type;
	}


}
