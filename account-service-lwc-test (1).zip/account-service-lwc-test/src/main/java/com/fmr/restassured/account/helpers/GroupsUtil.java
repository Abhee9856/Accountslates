/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers;

import com.fmr.pap.restassured.utilities.IOUtil;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.apache.velocity.VelocityContext;

import java.util.List;

import java.util.Random;

/**
 * Class to create, Get and delete household groupId and Household Identity with GroupId
 *
 * @author a631781
 */
public class GroupsUtil {

    private static Response response;
    private static final String AST_HOST = "https://ast-platformqa1.fmr.com";
    //Get apo
    private static final String APO_V3_GROUPS_PATH = "/authorized-plan-owner/v3/groups";
    private static final String APO_V2_GROUPS_PATH = "/authorized-plan-owner/v2/groups";
    private static final String CREATE_IDENTITY_HOUSEHOLD_PATH = "/identity/v2/households";

    public static final String APO_GROUPS_CREATE_TEMPLATE = "/template/group/apo/apo_create_v2.vm";
    public static final String IDENTITY_HOUSEHOLD_CREATE_TEMPLATE = "/template/group/householdIdentity/household_identity_gid.vm";

    /**
     *
     * @param authToken
     * @param mid
     * @param poe
     * @param product
     * @return response
     */
    public static Response getGroupId
    (final String authToken, final String mid, final String poe, final String product) {

        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("AppId", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("fsreqid", "Target Account GroupID Testing"),
                        new Header("user-mid", mid),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json"),
                        new Header("user-poe", poe)))
                .queryParam("product", product)
                .request().log().ifValidationFails().baseUri(AST_HOST)
                .when().get(APO_V3_GROUPS_PATH);
        return response;
    }

    /**
     *
     * @param groupId
     * @param groupType
     * @param authToken
     * @param poe
     */
    public static void deleteGroup(final String groupId, final String groupType, final String authToken, final String poe) {
        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("AppId", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("fsreqid", "GroupAccounts Testing"),
                        new Header("user-poe", poe),
                        new Header("group-type", groupType),
                        new Header("group-id", groupId),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))

                .request().log().ifValidationFails().baseUri(AST_HOST).when().delete(APO_V3_GROUPS_PATH);

    }

    /**
     *
     * @param authToken
     * @param groupName
     * @param ssn1
     * @param ssn2
     * @param mid1
     * @param mid2
     * @param poe
     * @param product
     * @return response
     */
    public static Response createGroup
    (final String authToken, final String groupName, final String ssn1, final String ssn2, final String mid1, final String mid2, final String poe, final String product) {

        // Generate request body
        final VelocityContext context = new VelocityContext();
        context.put("groupName", groupName);
        context.put("SSN", ssn1);
        context.put("SSN2", ssn2);
        context.put("mid", mid1);
        context.put("mid2", mid2);

        final String body =
                IOUtil.generateJsonRequest(context, APO_GROUPS_CREATE_TEMPLATE);
        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("AppId", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("fsreqid", "GroupAccounts Testing"),
                        new Header("user-poe", poe),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))
                .queryParam("product", product)
                .request().log().ifValidationFails().baseUri(AST_HOST)
                .body(body).when().post(APO_V2_GROUPS_PATH);
        response.then().log().ifValidationFails()
                .statusCode(200);
        return response;
    }


    /**
     *
     * @param authToken
     * @param mid
     * @param groupId
     * @param groupType
     * @param mid2
     * @param poe
     * @param product
     * @return response
     */
    public static Response createHouseholdIdentityWithGroupId(final String authToken, final String mid, final String groupId, final String groupType, final String mid2, final String poe, final String product) {

        VelocityContext context = new VelocityContext();
        context.put("mid", mid);
        context.put("mid2", mid2);

        final String body =
                IOUtil.generateJsonRequest(context, IDENTITY_HOUSEHOLD_CREATE_TEMPLATE);

        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("calling-app-id", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("log-tracking-id", "GroupAccounts Testing"),
                        new Header("scenario-product-code", product),
                        new Header("scenario-category-code", "DEF"),
                        new Header("user-group-type", groupType),
                        new Header("user-group-id", groupId),
                        new Header("user-poe", poe),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))

                .request().log().ifValidationFails().baseUri(AST_HOST)
                .body(body).when().post(CREATE_IDENTITY_HOUSEHOLD_PATH);

        response.then().log().ifValidationFails()
                .statusCode(200);
        return response;
    }

    /**
     * @return random number
     */
    public static int generateRandomNumber() {
        // creating an object of Random class
        Random random = new Random();
        // Generates random integers 0 to 999
        return random.nextInt(1000);
    }

}
