package com.fmr.restassured.account.helpers.testdata;

public class UserIdentifiers
{

	private String ssn;

	private String mid;

	private String sid;

	private String ppid;

	/**
	 * Used to instantiate the object before/without having created a household ID. The ppid will only be set if testing
	 * requires creating household identity.
	 *
	 * @param ssn
	 *            the ssn or lid
	 * @param mid
	 *            the mid
	 * @param sid
	 *            the sid
	 */
	public UserIdentifiers(String ssn, String mid, String sid)
	{
		this.mid = mid;
		this.sid = sid;
		this.ssn = ssn;
	}

	/**
	 * Used to instantiate the object having previously created a household ID.
	 *
	 * @param ssn
	 *            the ssn or lid
	 * @param mid
	 *            the mid
	 * @param sid
	 *            the sid
	 * @param ppid
	 *            the planning party id
	 */
	public UserIdentifiers(String ssn, String mid, String sid, String ppid)
	{
		this.mid = mid;
		this.sid = sid;
		this.ssn = ssn;
		this.ppid = ppid;
	}

	/*
	 * The getters and setters for each field.
	 */
	public String getSsn()
	{
		return ssn;
	}

	public void setSsn(final String ssn)
	{
		this.ssn = ssn;
	}

	public void setMid(final String mid)
	{
		this.mid = mid;
	}

	public void setSid(final String sid)
	{
		this.sid = sid;
	}

	public void setPpid(final String ppid)
	{
		this.ppid = ppid;
	}

	public String getMid()
	{
		return mid;
	}

	public String getSid()
	{
		return sid;
	}

	public String getPpid()
	{
		return ppid;
	}

}
