/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers;

import java.util.ArrayList;
import java.util.List;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;

/**
 * The class GroupAccountsUtil.
 *
 * @author a651454
 */
public class GroupAccountsUtil
{
    /** The constant AST_HOST */
    private static final String AST_HOST = "https://ast-platformqa1.fmr.com";
    
    /** The constant GET_GROUP_ACCOUNT_NUMBERS_URI */
    private static final String GET_GROUP_ACCOUNT_NUMBERS_URI = "/ftgw/dp/pa-group-accounts/v1/financial-profiles"
            + "/accounts/groups/accountnumbers";
    
    /**
     * Checks if the provide account number is part of the group specified.
     *
     * @param authToken
     *            the authToken
     * @param groupId
     *            the groupId
     * @param groupType
     *            the groupType
     * @param accountNumber
     *            the accountNumber
     * @return true if part of the group, false otherwise
     */
    public static boolean accountExistsInGroup(final String authToken, final String groupId, final String groupType,
            final String accountNumber)
    {
        final List<String> accountNumbers = getGroupAccountNumbers(authToken, groupId, groupType);
        return accountNumbers.contains(accountNumber);
    }
    
    /**
     * Returns group account numbers from Group Accounts API.
     *
     * @param authToken
     *            the authToken
     * @param groupId
     *            the groupId
     * @param groupType
     *            the groupType
     * @return
     */
    private static List<String> getGroupAccountNumbers (final String authToken, final String groupId,
            final String groupType)
    {
        final Response response = RestAssured.given()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("AppId", "AP106532"),
                        new Header("fsreqid", "Group Accounts Testing"),
                        new Header("user-group-id", groupId),
                        new Header("user-group-type", groupType),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json"),
                        new Header("user-poe","RETAIL")))
                .request().log().ifValidationFails().baseUri(AST_HOST)
                .when().get(GET_GROUP_ACCOUNT_NUMBERS_URI);
        
        response.then().log().ifValidationFails();
    
        if(null != response && response.getStatusCode() == 200)
        {
           final List<String> accountNumbers = response.path("accounts.accountNumber");
           return null == accountNumbers ? new ArrayList<>() : accountNumbers;
        }
        else
        {
            return new ArrayList<>();
        }
    }
}
