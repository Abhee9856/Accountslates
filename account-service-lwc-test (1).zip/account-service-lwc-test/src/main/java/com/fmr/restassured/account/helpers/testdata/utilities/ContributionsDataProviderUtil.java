/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.ast.platform.account.domain.SourceSystem;
import com.fmr.restassured.account.helpers.testdata.dto.AccountContributionsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.ContributionsMatchTiersTestData;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.testng.annotations.DataProvider;

/**
 * This utility class contains methods pertaining to the implementation of DataProvider logic for handling multiple
 * datasets for Contributions testing.
 *
 * @author a601767
 */
public class ContributionsDataProviderUtil
{

	/** The contributionTestData DTO */
	private static List<List<AccountContributionsTestData>> contributionTestData = null;

	/** The matchTiersTestData DTO */
	private static List<List<ContributionsMatchTiersTestData>> matchTiersTestData = null;

	/** Instance to the test data utility class */
	private static final TestDataUtil testDataUtil = new TestDataUtil();


	/**
	 * Data Provider method for pulling multiple contributions for Fullview Accounts
	 *
	 * @return Object[][] the contribution data set for Fullview Accounts
	 */
	@DataProvider(name = "getFullviewContributionData")
	public static Object[][] getFullviewContributionData()
	{
		return getData(SourceSystem.FULLVIEW.name());
	}

	/**
	 * Data Provider method for pulling multiple contributions for Manual Accounts
	 *
	 * @return Object[][] the contribution data set for Manual Accounts
	 */
	@DataProvider(name = "getManualContributionData")
	public static Object[][] getManualContributionData()
	{
		return getData(SourceSystem.MANUAL.name());
	}

	/**
	 * Data Provider method for pulling multiple contributions for FILI Accounts
	 *
	 * @return Object[][] the contribution data set for FILI Accounts
	 */
	@DataProvider(name = "getFiliContributionData")
	public static Object[][] getFiliContributionData()
	{
		return getData(SourceSystem.FILI.name());
	}

	/**
	 * Data Provider method for pulling multiple contributions for Retail Accounts
	 *
	 * @return Object[][] the contribution data set for Retail Accounts
	 */
	@DataProvider(name = "getRetailContributionData")
	public static Object[][] getRetailContributionData()
	{
		return getData(SourceSystem.RETAIL.name());
	}

	/**
	 * Gets use cases based on the source system provided.
	 *
	 * @param sourceSystem
	 * 			the source system
	 * @return the test data
	 */
	private static Object[][] getData(final String sourceSystem)
	{
		contributionTestData = new ArrayList<>();
		testDataUtil.getContributionTestData(sourceSystem).stream().filter(Objects::nonNull)
			.forEach(data -> {
			        final List<AccountContributionsTestData> dataList = new ArrayList<>();
			        dataList.add(data);
			        contributionTestData.add(dataList);
		        });

		return contributionTestData.stream().map(List::toArray).toArray(Object[][]::new);
	}

	/**
	 * Data Provider method for pulling match tiers data.
	 *
	 * @return Object[][] the match tiers data
	 */
	@DataProvider(name = "getMatchTiers")
	public static Object[][] getMatchTiers()
	{
		matchTiersTestData = new ArrayList<>();
		testDataUtil.getMatchTiersTestData().stream().filter(Objects::nonNull)
			.forEach(data -> {
			        final List<ContributionsMatchTiersTestData> dataList = new ArrayList<>();
			        dataList.add(data);
			        matchTiersTestData.add(dataList);
		        });

		return matchTiersTestData.stream().map(List::toArray).toArray(Object[][]::new);
	}

	/**
	 * Data Provider method for pulling multiple contributions for workplace Accounts
	 *
	 * @return Object[][] the contribution data set for workplace Accounts
	 */
	@DataProvider(name = "getWorkplaceContributionData")
	public static Object[][] getWorkplaceContributionData()
	{
		return getData(SourceSystem.WORKPLACE.name());
	}
}
