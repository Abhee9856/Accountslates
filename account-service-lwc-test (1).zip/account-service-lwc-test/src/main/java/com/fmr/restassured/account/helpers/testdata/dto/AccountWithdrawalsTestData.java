package com.fmr.restassured.account.helpers.testdata.dto;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * Contains contribution related test data. Instantiates with default data, but can be updated.
 *
 * @author a601767
 *
 */
@Entity
public class AccountWithdrawalsTestData
{

	@Column(name = "type")
	private String type = "Regular";

	@Column(name = "frequency")
	private String frequency = "MONTHLY";

	@Column(name = "amount_value")
	private String amountValue = "1228.62";

	@Column(name = "amount_value_type")
	private String amountValueType = "MONEY";
	
	@Column(name = "updated_type")
	private String updatedType = "Regular";

	@Column(name = "updated_frequency")
	private String updatedFrequency = "YEARLY";

	@Column(name = "updated_amount_value")
	private String updatedAmountValue = "0.01";

	@Column(name = "updated_amount_value_type")
	private String updatedAmountValueType = "PERCENT";

	

	public AccountWithdrawalsTestData()
	{
		super();
	}

	/**
	 *
	 * @param type
	 * @param frequency
	 * @param amountValue
	 * @param amountValueType
	 * @param updatedType
	 * @param updatedfrequency
	 * @param updatedAmountValue
	 * @param updatedAmountValueType
	 */
	public AccountWithdrawalsTestData(String type, String frequency, String amountValue, String amountValueType,
	        String updatedType, String updatedfrequency, String updatedAmountValue, String updatedAmountValueType)
	{
		this.type = type;
		this.frequency = frequency;
		this.amountValue = amountValue;
		this.amountValueType = amountValueType;
		this.updatedType = updatedType;
		this.updatedFrequency = updatedfrequency;
		this.updatedAmountValue = updatedAmountValue;
		this.updatedAmountValueType = updatedAmountValueType;
	}

	
	/**
	 * @return the type
	 */
	public String getType()
	{
		return type;
	}

	
	/**
	 * @param type the type to set
	 */
	public void setType(String type)
	{
		this.type = type;
	}

	
	/**
	 * @return the frequency
	 */
	public String getFrequency()
	{
		return frequency;
	}

	
	/**
	 * @param frequency the frequency to set
	 */
	public void setFrequency(String frequency)
	{
		this.frequency = frequency;
	}

	
	/**
	 * @return the amountValue
	 */
	public String getAmountValue()
	{
		return amountValue;
	}

	
	/**
	 * @param amountValue the amountValue to set
	 */
	public void setAmountValue(String amountValue)
	{
		this.amountValue = amountValue;
	}

	
	/**
	 * @return the amountValueType
	 */
	public String getAmountValueType()
	{
		return amountValueType;
	}

	
	/**
	 * @param amountValueType the amountValueType to set
	 */
	public void setAmountValueType(String amountValueType)
	{
		this.amountValueType = amountValueType;
	}

	
	/**
	 * @return the updatedType
	 */
	public String getUpdatedType()
	{
		return updatedType;
	}

	
	/**
	 * @param updatettype the updatedType to set
	 */
	public void setUpdatedType(String updatedType)
	{
		this.updatedType = updatedType;
	}

	
	/**
	 * @return the updatedFrequency
	 */
	public String getUpdatedFrequency()
	{
		return updatedFrequency;
	}

	
	/**
	 * @param updatedfrequency the updatedFrequency to set
	 */
	public void setUpdatedFrequency(String updatedFrequency)
	{
		this.updatedFrequency = updatedFrequency;
	}

	
	/**
	 * @return the updatedAmountValue
	 */
	public String getUpdatedAmountValue()
	{
		return updatedAmountValue;
	}

	
	/**
	 * @param updatedAmountValue the updatedAmountValue to set
	 */
	public void setUpdatedAmountValue(String updatedAmountValue)
	{
		this.updatedAmountValue = updatedAmountValue;
	}

	
	/**
	 * @return the updatedAmountValueType
	 */
	public String getUpdatedAmountValueType()
	{
		return updatedAmountValueType;
	}

	
	/**
	 * @param updatedAmountValueType the updatedAmountValueType to set
	 */
	public void setUpdatedAmountValueType(String updatedAmountValueType)
	{
		this.updatedAmountValueType = updatedAmountValueType;
	}

	

}
