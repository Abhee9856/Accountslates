 /*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.helpers;


 import com.fmr.pap.restassured.common.soap.SOAPBackendUtil;
 import com.fmr.pap.restassured.common.soap.SOAPHelper;
 import com.fmr.pap.restassured.common.soap.SOAPSecureHeader;
 import com.fmr.pap.restassured.utilities.IOUtil;
 import com.fmr.pap.restassured.utilities.OAuthUtil;
 import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
 import org.apache.logging.log4j.LogManager;
 import org.apache.logging.log4j.Logger;
 import org.apache.velocity.VelocityContext;
 import org.testng.SkipException;
 import org.w3c.dom.Document;

 import static com.fmr.restassured.account.helpers.AccountUtil.oauthClientId;
 import static com.fmr.restassured.account.helpers.AccountUtil.oauthClientSecret;


 /**
  * The Class SOAPOauthUtil.
  *
  * @author a783909
  */
 public class SOAPOauthUtil
 {
     /** Logger to print appropriate error, warning, or info messages **/
     private static Logger LOGGER = LogManager.getLogger(SOAPOauthUtil.class);

     /* Action for VM plan */
     private static String VMPlanAction = "http://xmlns.fmr.com/WI/DC/2016/02/Plan/PlanService/GetRetirementPlanInfo";
     /* set contentType */
     private static String contentType = "application/soap+xml; charset=UTF-8";
     /** Authentication token to be used throughout test runs */
     private static SOAPSecureHeader secureHeader;

     /**
      * Gets secure header section with OAuth.
      *
      * @return secure header
      */
     public static SOAPSecureHeader getSecureHeader()
     {
         if(oauthClientId == null || oauthClientSecret == null) {

             LOGGER.info("Oauth credentials  missing");
             throw new SkipException(
                     "OAuth can not be generated due to missing credentials");

         }

         secureHeader = SOAPBackendUtil.getSecureHeader(oauthClientId, oauthClientSecret);
         return secureHeader;
     }

     /**
      * Gets the OAuth .
      *
      * @return the Oauth
      */
     public static String getOauthToken()
     {
         return OAuthUtil.getOAuthToken(oauthClientId, oauthClientSecret);
     }

     /**
      * call VM Plan Soap API
      *
      * @param secureHeader
      * @param ssn
      * @param planId
      * @return soap Response
      */
     public static Document callVMPlanSoapAPI(final SOAPSecureHeader secureHeader,
                                                                                  final String ssn, String planId)
     {
         final SOAPHelper soapHelper = new SOAPHelper();
         soapHelper.setSoapURL(AccountConstants.VM_PLAN_BASE_URI + AccountConstants.VM_PLAN_PATH);
         soapHelper.setSoapRequestMethod("POST");
         soapHelper.setSoapAction(VMPlanAction);
         soapHelper.setContentType(contentType);
         soapHelper.setSecHeader(secureHeader);

         soapHelper.setSoapRequest(buildVMPlanRequest(ssn, planId));

         return SOAPBackendUtil.convertSOAPMessageToDocument(SOAPBackendUtil.callSOAPService(soapHelper, true));
     }

     /**
      * build VM Plan Soap API Request
      * @param ssn
      * @param planId
      * @return Soap request
      */
     private static String buildVMPlanRequest(String ssn, String planId) {
         final VelocityContext context = new VelocityContext();
         context.put("SSN", IOUtil.formatSSN(ssn));
         context.put("PlanId", planId);

         return IOUtil.generateJsonRequest(context, AccountConstants.VM_PLAN_TEMPLATE);

     }

 }