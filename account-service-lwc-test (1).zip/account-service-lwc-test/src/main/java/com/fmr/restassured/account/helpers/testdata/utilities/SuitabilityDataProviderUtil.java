/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.ast.platform.account.domain.SourceSystem;
import com.fmr.restassured.account.helpers.testdata.dto.AccountSuitabilityTestData;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.testng.annotations.DataProvider;


/**
 * This utility class contains methods pertaining to the implementation of DataProvider logic for handling multiple
 * data sets for account suitability testing.
 *
 * @author a560878
 */

public class SuitabilityDataProviderUtil
{

	/** The AccountSuitabilityTestData DTO */
	private static List<List<AccountSuitabilityTestData>> suitabilityTestData = null;

	/** Instance to the test data utility class */
	private static final TestDataUtil testDataUtil = new TestDataUtil();

	
	/**
	 * Data Provider method for pulling suitability data for Fullview Accounts
	 *
	 * @return Object[][] the suitability data set for Fullview Accounts
	 */
	@DataProvider(name = "getFullviewSuitabilityData")
	public static Object[][] getFullviewSuitabilityData()
	{
		return getData(SourceSystem.FULLVIEW.name());
	}
	
	/**
	 * Data Provider method for pulling suitability data for Workplace Accounts
	 *
	 * @return Object[][] the suitability data set for Workplace Accounts
	 */
	@DataProvider(name = "getWorkplaceSuitabilityData")
	public static Object[][] getWorkplaceSuitabilityData()
	{
		return getData(SourceSystem.WORKPLACE.name());
	}

	
	/**
	 * Data Provider method for pulling suitability data for Retail Accounts
	 *
	 * @return Object[][] the suitability data set for Retail Accounts
	 */
	@DataProvider(name = "getRetailSuitabilityData")
	public static Object[][] getRetailSuitabilityData()
	{
		return getData(SourceSystem.RETAIL.name());
	}
	
	/**
	 * Data Provider method for pulling suitability data for FILI Accounts
	 *
	 * @return Object[][] the suitability data set for FILI Accounts
	 */
	@DataProvider(name = "getFiliSuitabilityData")
	public static Object[][] getFiliSuitabilityData()
	{
		return getData(SourceSystem.FILI.name());
	}
	
	/**
	 * Gets use cases based on the source system provided.
	 *
	 * @param sourceSystem
	 * 			the source system
	 * @return the test data
	 */
	private static Object[][] getData(final String sourceSystem)
	{
		suitabilityTestData = new ArrayList<>();
		testDataUtil.getSuitabilityTestData(sourceSystem).stream().filter(Objects::nonNull)
			.forEach(data -> {
			        final List<AccountSuitabilityTestData> dataList = new ArrayList<>();
			        dataList.add(data);
			        suitabilityTestData.add(dataList);
		        });

		return suitabilityTestData.stream().map(List::toArray).toArray(Object[][]::new);
	}
	/**
	 * Data Provider method for pulling suitability data for manual Accounts
	 *
	 * @return Object[][] the suitability data set for manual Accounts
	 */
	@DataProvider(name = "getManualSuitabilityData")
	public static Object[][] getManualSuitabilityData()
	{
		suitabilityTestData = new ArrayList<>();
		testDataUtil.getSuitabilityTestData(SourceSystem.RETAIL.name()).forEach(data -> {
			final List<AccountSuitabilityTestData> dataList = new ArrayList<>();
			dataList.add(data);
			suitabilityTestData.add(dataList);
		});

		return suitabilityTestData.stream().map(List::toArray).toArray(Object[][]::new);
	}
}
