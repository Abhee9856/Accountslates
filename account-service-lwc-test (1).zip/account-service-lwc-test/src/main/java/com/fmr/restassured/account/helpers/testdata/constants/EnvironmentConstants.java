/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.constants;


/**
 * This class holds all constants pertaining to the env.properties file (located under src/test/resources/environment)
 *
 * @author a601767
 *
 */
public class EnvironmentConstants
{	
	/** The constant for retrieving the path for account create V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_CREATE_PATH = "account.v2.create.path";
	
	/** The constant for retrieving the path for account create V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_GET_PATH = "account.v2.get.path";
	
	/** The constant for retrieving the path for account update V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_UPDATE_PATH = "account.v2.update.path";
	
	/** The constant for retrieving the path for account delete V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_DELETE_PATH = "account.v2.delete.path";
	
	/** The constant for retrieving the path for account gain/loss realized V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_GAINLOSS_REALIZED_PATH = "account.v2.gainloss.realized.path";
			
	/** The constant for retrieving the path for account gain/loss tax V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_GAINLOSS_TAX_GET_PATH = "account.v2.gainlosstax.get.path";
		
	/** The constant for retrieving the path for account advisor balances V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_ADVISORBALANCES_GET_PATH = "account.v2.advisorbalances.get.path";
	
	/** The constant for retrieving the path for account tax lots V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_TAXLOTS_GET_PATH = "account.v2.taxlots.get.path";
	
	/** The constant for retrieving the path for account tax rate V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_TAXRATE_GET_PATH = "account.v2.taxrate.get.path";
	
	/** The constant for retrieving the path for account loans V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_LOANS_GET_PATH = "account.v2.loans.get.path";
	
	/** The constant for retrieving the path for account composite create V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_COMPOSITE_CREATE_PATH = "account.v2.composite.create.path";
	
	/** The constant for retrieving the path for account composite get V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_COMPOSITE_GET_PATH = "account.v2.composite.get.path";
	
	/** The constant for retrieving the path for account composite update V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_COMPOSITE_UPDATE_PATH = "account.v2.composite.update.path";
	
	/** The constant for retrieving the path for account composite delete V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_COMPOSITE_DELETE_PATH = "account.v2.composite.delete.path";
	
	/** The constant for retrieving the path for account withdrawals create V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_WITHDRAWALS_CREATE_PATH = "account.v2.withdrawals.create.path";
	
	/** The constant for retrieving the path for account withdrawals get V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_WITHDRAWALS_GET_PATH = "account.v2.withdrawals.get.path";
	
	/** The constant for retrieving the path for account withdrawals update V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_WITHDRAWALS_UPDATE_PATH = "account.v2.withdrawals.update.path";
	
	/** The constant for retrieving the path for account withdrawals delete V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_WITHDRAWALS_DELETE_PATH = "account.v2.withdrawals.delete.path";
		
	/** The constant for retrieving the path for account contributions create V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_CONTRIBUTIONS_CREATE_PATH = "account.v2.contributions.create.path";
	
	/** The constant for retrieving the path for account contributions get V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_CONTRIBUTIONS_GET_PATH = "account.v2.contributions.get.path";
	
	/** The constant for retrieving the path for account contributions set V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_CONTRIBUTIONS_SET_PATH = "account.v2.contributions.set.path";
	
	/** The constant for retrieving the path for account contributions update V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_CONTRIBUTIONS_UPDATE_PATH = "account.v2.contributions.update.path";
	
	/** The constant for retrieving the path for account contributions delete V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_CONTRIBUTIONS_DELETE_PATH = "account.v2.contributions.delete.path";
		
	/** The constant for retrieving the path for account suitability get V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_SUITABILITY_GET_PATH = "account.v2.contributions.set.path";
	
	/** The constant for retrieving the path for account suitability update V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_SUITABILITY_UPDATE_PATH = "account.v2.contributions.update.path";
	
	/** The constant for retrieving the path for account suitability create V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_SUITABILITY_CREATE_PATH = "account.v2.suitability.create.path";
	
	/** The constant for retrieving the path for account details create V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_DETAILS_CREATE_PATH = "account.v2.details.create.path";
	
	/** The constant for retrieving the path for account contributions get V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_DETAILS_GET_PATH = "account.v2.details.get.path";
	
	/** The constant for retrieving the path for account contributions update V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_DETAILS_UPDATE_PATH = "account.v2.details.update.path";
	
	/** The constant for retrieving the path for account contributions delete V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_DETAILS_DELETE_PATH = "account.v2.details.delete.path";

	
	/** The constant for retrieving the path for account positions get V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_POSITIONS_GET_PATH = "account.v2.positions.get.path";
	
	/** The constant for retrieving the path for account positions set V2 operation (from the env.properties file) */
	public static final String ACCOUNT_V2_POSITIONS_SET_PATH = "account.v2.positions.set.path";
	
	/** The constant for retrieving the path for account create V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_CREATE_PATH = "account.create.path";
	
	/** The constant for retrieving the path for account get V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_GET_PATH = "account.get.path";
	
	/** The constant for retrieving the path for account update V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_UPDATE_PATH = "account.update.path";
	
	/** The constant for retrieving the path for account delete V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_DELETE_PATH = "account.delete.path";
	
	/** The constant for retrieving the path for account create V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_DETAILS_CREATE_PATH = "account.details.create.path";
	
	/** The constant for retrieving the path for account get V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_DETAILS_GET_PATH = "account.details.get.path";
	
	/** The constant for retrieving the path for account update V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_DETAILS_UPDATE_PATH = "account.details.update.path";
	
	/** The constant for retrieving the path for account delete V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_DETAILS_DELETE_PATH = "account.details.delete.path";
	
	/** The constant for retrieving the path for account positions get V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_POSITIONS_GET_PATH = "account.positions.get.path";
	
	/** The constant for retrieving the path for account positions set V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_POSITIONS_SET_PATH = "account.positions.set.path";
	
	/** The constant for retrieving the path for account contributions create V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_CONTRIBUTIONS_CREATE_PATH = "account.contributions.create.path";
	
	/** The constant for retrieving the path for account contributions get V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_CONTRIBUTIONS_GET_PATH = "account.contributions.get.path";
	
	/** The constant for retrieving the path for account contributions set V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_CONTRIBUTIONS_SET_PATH = "account.contributions.set.path";
	
	/** The constant for retrieving the path for account contributions update V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_CONTRIBUTIONS_UPDATE_PATH = "account.contributions.update.path";
	
	/** The constant for retrieving the path for account contributions delete V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_CONTRIBUTIONS_DELETE_PATH = "account.contributions.delete.path";
	
	/** The constant for retrieving the path for account composite get V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_COMPOSITE_GET_PATH = "account.composite.get.path";
	
	/** The constant for retrieving the path for account composite create V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_COMPOSITE_CREATE_PATH = "account.composite.create.path";
	
	/** The constant for retrieving the path for account composite update V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_COMPOSITE_UPDATE_PATH = "account.composite.update.path";
	
	/** The constant for retrieving the path for account withdrawals update V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_WITHDRAWALS_GET_PATH = "account.withdrawals.get.path";
	
	/** The constant for retrieving the path for account withdrawals create V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_WITHDRAWALS_CREATE_PATH = "account.withdrawals.create.path";
	
	/** The constant for retrieving the path for account withdrawals update V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_WITHDRAWALS_UPDATE_PATH = "account.withdrawals.update.path";
	
	/** The constant for retrieving the path for account withdrawals delete V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_WITHDRAWALS_DELETE_PATH = "account.withdrawals.delete.path";
	
	/** The constant for retrieving the path for account suitability update V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_SUITABILITY_GET_PATH = "account.suitability.get.path";
	
	/** The constant for retrieving the path for account suitability create V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_SUITABILITY_CREATE_PATH = "account.suitability.create.path";
	
	/** The constant for retrieving the path for account suitability update V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_SUITABILITY_UPDATE_PATH = "account.suitability.update.path";
	
	/** The constant for retrieving the path for account relations get V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_RELATIONS_GET_PATH = "account.relations.get.path";
	
	/** The constant for retrieving the path for account relations create V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_RELATIONS_CREATE_PATH = "account.relations.create.path";
	
	/** The constant for retrieving the path for account relations update V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_RELATIONS_UPDATE_PATH = "account.relations.update.path";
	
	/** The constant for retrieving the path for account relations delete V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_RELATIONS_DELETE_PATH = "account.relations.delete.path";
	
	/** The constant for retrieving the path for account grants create V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_GRANTS_CREATE_PATH = "account.grants.create.path";
	
	/** The constant for retrieving the path for account grants get V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_GRANTS_GET_PATH = "account.grants.get.path";
	
	/** The constant for retrieving the path for account grants update V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_GRANTS_UPDATE_PATH = "account.grants.update.path";
	
	/** The constant for retrieving the path for account grants delete V1 operation (from the env.properties file) */
	public static final String ACCOUNT_V1_GRANTS_DELETE_PATH = "account.grants.delete.path";
	
	/** The constant for retrieving the path for account get contributions operation (from the env.properties file) */
	public static final String ACCOUNT_GET_CONTRIBUTIONS_PATH = "account.resource.path.get.contributions";
	
	/** The constant for retrieving the path for account get positions operation (from the env.properties file) */
	public static final String ACCOUNT_GET_POSITIONS_PATH = "account.resource.path.get.positions";
	
	/** The constant for retrieving the path for account get details operation (from the env.properties file) */
	public static final String ACCOUNT_GET_DETAILS_PATH = "account.resource.path.get.details";
	
	/** The constant for retrieving the path for enroll 2014/10 operation (from the env.properties file) */
	public static final String ENROLL_201410_PATH = "enrollment.enroll.path.201410";
	
	/** The constant for retrieving the path for enrollPASW 2014/10 operation (from the env.properties file) */
	public static final String ENROLL_PASW_201410_PATH = "enrollment.enrollPASW.path.201410";
	
	/** The constant for retrieving the path for enrollPASW v1 operation (from the env.properties file) */
	public static final String ENROLL_PASW_V1_PATH = "enrollment.enrollPASW.path.v1";
	
	/** The constant for retrieving the path for enroll v2 operation (from the env.properties file) */
	public static final String ENROLL_V2_PATH = "enrollment.enroll.path.v2";
	
	/** The constant for retrieving the path for enroll v2 operation - virtual proxy (from the env.properties file) */
	public static final String ENROLL_V2_PATH_VIRTUAL_PROXY = "enrollment.enroll.path.v2.virtual.proxy";
	
	/** The constant for retrieving the base path for accessing the app service virtual assets (from the env.properties file) */
	public static final String APP_BASE_PATH_VIRTUAL = "base.app.virtual";
	
	/** The constant for retrieving the path for identity get principal operation (from the env.properties file) */
	public static final String IDENTITY_GET_PRINCIPAL_PATH = "identity.resource.path.get.principal";
	
	/** The constant for retrieving the path for identity insert household operation (from the env.properties file) */
	public static final String IDENTITY_INSERT_HOUSEHOLD_PATH = "identity.resource.path.insert.household";
	
	/** The constant for retrieving the path for scenario get operation (from the env.properties file) */
	public static final String SCENARIO_GET = "scenario.resource.path.get";
	
	/** The constant for retrieving the path for scenario get managed account operation (from the env.properties file) */
	public static final String SCENARIO_GET_MANAGED_ACCOUNT = "scenario.resource.path.get.managed.account";
	
	/** The constant for retrieving the path for scenario insert operation (from the env.properties file) */
	public static final String SCENARIO_INSERT = "scenario.resource.path.insert";
	
	/** The constant for retrieving the path for scenario update operation (from the env.properties file) */
	public static final String SCENARIO_UPDATE = "scenario.resource.path.update";
	
	/** The constant for retrieving the path for profile update retirement operation (from the env.properties file) */
	public static final String PROFILE_UPDATE_RETIREMENT = "profile.resource.path.update.retirement";
	
	/** The constant for retrieving the path for profile update planning operation (from the env.properties file) */
	public static final String PROFILE_UPDATE_PLANNING = "profile.resource.path.update.planning";
	
	/** The constant for retrieving the path for goal create retirement operation (from the env.properties file) */
	public static final String GOAL_CREATE_RETIREMENT = "goal.resource.path.create.retirement";
	
	/** The constant for retrieving the path for goal association create operation (from the env.properties file) */
	public static final String GOAL_ASSOCIATION_CREATE = "goal.association.resource.path.create";
	
	/** The constant for retrieving the path for model assignment create operation (from the env.properties file) */
	public static final String MODEL_ASSIGNMENT_CREATE = "model.assignment.resource.path.create";
	
	/** The constant for retrieving the path for income profile create manual incomes operation (from the env.properties file) */
	public static final String INCOME_PROFILE_CREATE_MANUAL_INCOMES = "income.profile.resource.path.create.manual.incomes";
}
