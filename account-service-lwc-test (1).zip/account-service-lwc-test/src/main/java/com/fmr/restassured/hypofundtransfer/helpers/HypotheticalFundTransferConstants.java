/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.hypofundtransfer.helpers;

/**
 * Constant class for HypoFund Transfer
 * @author a653510 and a631781
 */
public class HypotheticalFundTransferConstants
{
    
    private HypotheticalFundTransferConstants()
    {
        throw new IllegalStateException("Constant Class");
    }
    
    // V1
    public static final String HYPOFUNDTRANSFER_CREATE_V1_TEMPLATE = "/template/hypotheticalFundTransfer/hypofundtransfer_create.vm";
    
}
