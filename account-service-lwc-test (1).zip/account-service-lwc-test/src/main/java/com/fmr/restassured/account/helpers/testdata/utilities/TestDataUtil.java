/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.database.module.SQLiteTestData;
import com.fmr.restassured.account.database.DatabaseConstants;
import com.fmr.restassured.account.helpers.testdata.constants.TestDataConstants;
import com.fmr.restassured.account.helpers.testdata.dto.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class contains utility methods pertaining to test data contained in the SQLite database.
 *
 * @author a601767
 */
public class TestDataUtil extends SQLiteTestData {

    private static final Logger LOGGER = LogManager.getLogger(TestDataUtil.class);

    private static final String SQLITE_PROPERTIES_FILE = "/sql/SQLiteSQL.properties";

    public TestDataUtil() {
        super(TestDataConstants.TEST_DATA_LOCATION);
    }

    /**
     * Method that populates the TestData object with the contents of the SQLite record using the specified test name
     * and environment
     *
     * @param testName (the test_name column in the SQLite database)
     * @return TestData object (containing ssn/fescoLid, account numbers, mnemonics, etc.)
     */
@Deprecated
    public static AccountsCommonTestData populateRegressionTestData(final String testName) {
        return populateTestData(testName
        );
    }

    /**
     * @param testName name of the test
     * @param token    oauth token
     * @return TestData object
     */
    public static AccountsCommonTestData populateRegressionTestData(final String testName, final String token) {
        return populateTestData(testName,
                token);
    }

    /**
     * Method that populates the TestData object with the contents of the SQLite record using the specified test name,
     * environment, and SQLite property key name
     *
     * @param testName (the test_name column in the SQLite database)
     * @return TestData object
     */
    @SuppressWarnings("deprecation")
    private static AccountsCommonTestData populateTestData(final String testName) {
        ArrayList<HashMap<String, String>> rsList = DatabaseUtil.getRegressionTestData(testName, DatabaseConstants.SQLitePropertyConstants.SQLITE_SQL_ACCOUNT_DATA_BY_TESTNAME);

        final AccountsCommonTestData accountsCommonTestData = new AccountsCommonTestData();
        accountsCommonTestData.setSsn(rsList.get(0).get(DatabaseConstants.SQLiteColumnNameConstants.SSN));
        accountsCommonTestData.setFcpsId(rsList.get(0).get(DatabaseConstants.SQLiteColumnNameConstants.FcpsId));
        accountsCommonTestData.setMid(Identity.getUserIdentifier("lid", accountsCommonTestData.getSsn()).get("mid"));
        accountsCommonTestData.setSid(formatSid(Identity.getUserIdentifier("lid", accountsCommonTestData.getSsn()).get("sid")));

        return accountsCommonTestData;
    }

    /**
     * Method that populates the TestData object with the contents of the SQLite record using the specified test name,
     * environment, and SQLite property key name
     *
     * @param testName (the test_name column in the SQLite database)
     * @return TestData object
     */
    private static AccountsCommonTestData populateTestData(final String testName, final String token) {
        ArrayList<HashMap<String, String>> rsList = DatabaseUtil.getRegressionTestData(testName, DatabaseConstants.SQLitePropertyConstants.SQLITE_SQL_ACCOUNT_DATA_BY_TESTNAME);
        final AccountsCommonTestData accountsCommonTestData = new AccountsCommonTestData();
        if (CollectionUtils.isNotEmpty(rsList)) {
            accountsCommonTestData.setSsn(rsList.get(0).get(DatabaseConstants.SQLiteColumnNameConstants.SSN));

            Map<String, String> userIdentifier = Identity.getUserIdentifier("lid", accountsCommonTestData.getSsn(), token);
            accountsCommonTestData.setMid(userIdentifier.get("mid"));
            accountsCommonTestData.setSid(formatSid(userIdentifier.get("sid")));
        }
        return accountsCommonTestData;
    }

    /**
     * This method queries SQLite for the records that are in the account_regcodes table
     *
     * @param tableName table name
     * @param numOfRows number of rows
     * @param testName  the test_name column in the SQLite database
     * @param colName   diff columns in the table
     * @param colVal    value of the column
     * @return AccountRegCodeTestData records (as list)
     */
    public List<AccountRegCodeTestData> getAccountRegCodeTestDataRecordsWithFilter(final String tableName, final int numOfRows, final String testName,
                                                                                   final String colName, String colVal) {
        return this.getSQLiteTestData(tableName, numOfRows, AccountRegCodeTestData.class, testName,
                colName, colVal, DatabaseConstants.SQL_MULTIPLE_REGCODES_FILTER);
    }

    /**
     * This method modifies the existing account number as masked
     *
     * @param accNumber
     *          the account number
     * @return the account number with all but the last four digits masked
     */
    public static String getMaskedAccountNumber(final String accNumber)
    {
        final int exposedDigitsStart = accNumber.length() - 4;
        final StringBuilder accNum = new StringBuilder();
        for (int i = 0; i < accNumber.length(); i++)
        {
            if (i < exposedDigitsStart)
            {
                accNum.append("X");
            }
            else
            {
                accNum.append(accNumber.charAt(i));
            }
        }
        return accNum.toString();
    }

    /**
     * This method queries SQLite for the records that are in the account_contributions table
     *
     * @return AccountRegCodeTestData records (as list)
     */
    public List<AccountContributionsTestData> getContributionTestData(final String sourceSystem) {

        final Configurations configs = new Configurations();
        PropertiesConfiguration config;
        String query = "";
        try {
            config = configs.properties(SQLiteTestData.class.getResource(SQLITE_PROPERTIES_FILE));
            query = config.getString("account.contributions.get.test.data.by.source").replace("?", sourceSystem);
        } catch (final ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }

        return this.getSQLiteTestData(query, AccountContributionsTestData.class);
    }

    /**
     * This method queries SQLite for the records that are in the account_withdrawals table
     *
     * @return AccountRegCodeTestData records (as list)
     */
    public List<AccountWithdrawalsTestData> getWithdrawalsTestData(final String sourceSystem) {

        final Configurations configs = new Configurations();
        PropertiesConfiguration config;
        String query = "";
        try {
            config = configs.properties(SQLiteTestData.class.getResource(SQLITE_PROPERTIES_FILE));
            query = config.getString("account.withdrawals.get.test.data.by.source").replace("?", sourceSystem);
        } catch (final ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }

        return this.getSQLiteTestData(query, AccountWithdrawalsTestData.class);
    }

    /**
     * This method queries SQLite for the records that are in the account_regcodes table
     *
     * @param sourceSystem the sourceSystem
     * @return AccountRegCodeTestData records (as list)
     */
    public List<AccountRelationsTestData> getRelationsTestData(final String sourceSystem) {

        final Configurations configs = new Configurations();
        PropertiesConfiguration config;
        String query = "";
        try {
            config = configs.properties(SQLiteTestData.class.getResource(SQLITE_PROPERTIES_FILE));
            query = config.getString("account.relations.get.test.data.by.source").replace("?", sourceSystem);
        } catch (final ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }

        return this.getSQLiteTestData(query, AccountRelationsTestData.class);
    }


    /**
     * This method queries SQLite for the records that are in the account_positions table
     *
     * @return AccountPositionsTestData records (as list)
     */
    public List<AccountPositionsTestData> getPositionsTestData(final String sourceSystem) {

        final Configurations configs = new Configurations();
        PropertiesConfiguration config;
        String query = "";
        try {
            config = configs.properties(SQLiteTestData.class.getResource(SQLITE_PROPERTIES_FILE));
            query = config.getString("account.positions.get.test.data.by.source").replace("?", sourceSystem);
        } catch (final ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }

        return this.getSQLiteTestData(query, AccountPositionsTestData.class);
    }


    /**
     * This method queries SQLite for the records that are in the account_contributions_match_tiers table
     *
     * @return AccountRegCodeTestData records (as list)
     */
    public List<ContributionsMatchTiersTestData> getMatchTiersTestData() {

        final Configurations configs = new Configurations();
        PropertiesConfiguration config;
        try {
            config = configs.properties(SQLiteTestData.class.getResource(SQLITE_PROPERTIES_FILE));
        } catch (final ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }

        return this.getSQLiteTestData("select * from account_contributions_match_tiers",
                ContributionsMatchTiersTestData.class);
    }

    /**
     * This method queries SQLite for the records that are in the account_regcodes table
     *
     * @param tableName table name
     * @param numOfRows number of rows
     * @param testName  the test_name column in the SQLite database
     * @return AccountRegCodeTestData records (as list)
     */
    public List<AccountRegCodeTestData> getAccountRegCodeTestDataRecords(final String tableName, final int numOfRows, final String testName) {
        return this.getSQLiteTestData(tableName, numOfRows, AccountRegCodeTestData.class, testName,
                DatabaseConstants.SQL_MULTIPLE_REGCODES);
    }

    /**
     * This method queries SQLite for the records that are in the account_regcodes table
     *
     * @return AccountRegCodeTestData records (as list)
     */
    public List<AccountRegCodeTestData> getAccountRegCodeTestDataRecordsBySource(final String sourceSystem, final String tableName) {

        final Configurations configs = new Configurations();
        PropertiesConfiguration config;
        String query = "";
        try {
            config = configs.properties(SQLiteTestData.class.getResource(SQLITE_PROPERTIES_FILE));
            query = config.getString("account.regcode.get.test.data.by.source").replace("<tableName>", tableName)
                    .replace("?", sourceSystem);
        } catch (final ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }

        return this.getSQLiteTestData(query, AccountRegCodeTestData.class);
    }


    /**
     * This method queries SQLite for the records that are in the account_positions table
     *
     * @param tableName table name
     * @param numOfRows number of rows
     * @param testName  the test_name column in the SQLite database
     * @return PositionsAccountTestData records (as list)
     */
    public List<AccountPositionsTestData> getPositionsAccountTestDataRecords(final String tableName, final int numOfRows, final String testName) {
        return this.getSQLiteTestData(tableName, numOfRows, AccountPositionsTestData.class, testName,
                DatabaseConstants.SQL_MULTIPLE_REGCODES);
    }


    /**
     * Method that changes sid to UUID formatted.
     *
     * @param sid the unformatted sid
     * @return formatted sid
     */
    private static String formatSid(String sid) {
        return sid.substring(0, 8) + "-" + sid.substring(8, 12) + "-" + sid.substring(12, 16) + "-"
                + sid.substring(16, 20) + "-" + sid.substring(20);
    }

    /**
     * This method queries SQLite for the records that are in the account_accountTaxRates table
     *
     * @return AccountTaxRatesTestData records (as list)
     */
    public List<AccountTaxRatesTestData> getTaxRatesTestData() {
        final Configurations configs = new Configurations();
        PropertiesConfiguration config;
        String query = "";
        try {
            config = configs.properties(SQLiteTestData.class.getResource(SQLITE_PROPERTIES_FILE));
            query = config.getString("account.taxrates.get.test.data");
        } catch (final ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return this.getSQLiteTestData(query, AccountTaxRatesTestData.class);
    }
    
	/**
	 *
	 * This method queries SQLite for the records that are in the account_suitability table
	 *
	 * @param sourceSystem
     *              the source system
	 * @return AccountPositionsTestData records (as list)
	 */
	public List<AccountSuitabilityTestData> getSuitabilityTestData(final String sourceSystem)
	{
		
		final Configurations configs = new Configurations();
		PropertiesConfiguration config = null;
		String query = "";
		try
		{
			config = configs.properties(SQLiteTestData.class.getResource(SQLITE_PROPERTIES_FILE));
			query = config.getString("account.suitability.get.test.data.by.source").replace("?", sourceSystem);
		}
		catch (final ConfigurationException e)
		{
			LOGGER.error(e.getMessage(), e);
		}
		
		return this.getSQLiteTestData(query, AccountSuitabilityTestData.class);
	}

}
