/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers;

import com.fmr.pap.restassured.utilities.IOUtil;

import java.util.HashMap;
import java.util.List;

import org.apache.velocity.VelocityContext;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;

/**
 * Class to create, Get and delete household groupId and Household Identity with GroupId
 *
 * @author a631781
 */
public class HouseholdGroupUtil {
    /**
     * The response variable populated after each test run
     */
    private static Response response;

    private static final String HOUSEHOLD_GROUPS_HOST = "https://customerprofileqa1.fmr.com";
    private static final String CREATE_HOUSEHOLD_GROUPS_V1 = "/households/groups/v1";
    private static final String GET_HOUSEHOLD_GROUPS_V1 = "/households/groups/v1";
    private static final String GET_HOUSEHOLD_GROUP_ID = "/authorized-plan-owner/v2/groups";

    private static final String DELETE_HOUSEHOLD_GROUPS_V1 = "/households/groups/delete/v1";
    public static final String HOUSEHOLD_GROUPS_CREATE_TEMPLATE = "/template/householdgroup"
            + "/household_groups_create.vm";
    public static final String HOUSEHOLD_GROUPS_DELETE_TEMPLATE = "/template/householdgroup"
            + "/household_groups_delete.vm";
    private static final String AST_HOST = "https://ast-platformqa1.fmr.com";
    public static final String IDENTITY_GROUPID_CREATE_TEMPLATE = "/template/identity/create_identity_scenario.vm";
    private static final String CREATE_IDENTITY_GROUPID = "/identity/2014/10/identity/household/insert";

    public static final String SCENARIO_GROUPID_CREATE_TEMPLATE = "/template/scenario/scenario_insert.vm";
    private static final String CREATE_SCENARIO_GROUPID = "/scenario/2014/10/scenario/insert";
    private static final String GET_SCENARIO_GROUPID = "/scenario/2014/10/scenario/get";
    private static final String CREATE_PRINCIPAL_GROUPID = "/identity/2014/10/identity/principal/create";
    private static final String PRINCIPAL_GROUPID_CREATE_TEMPLATE = "/template/identity/create_principal.vm";

    public static Response createHouseholdGroup
            (final String authToken, final String ssn1, final String ssn2, final HashMap<String, String> accountInfo) {

        // Generate request body
        final VelocityContext context = new VelocityContext();
        context.put("SSN", ssn1);
        context.put("SSN2", ssn2);
        context.put("accountNumber", accountInfo.get("accountNumber"));
        context.put("accountNumber2", accountInfo.get("accountNumber2"));

        final String body =
                IOUtil.generateJsonRequest(context, HOUSEHOLD_GROUPS_CREATE_TEMPLATE);
        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("AppId", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("fsreqid", "GroupAccounts Testing"),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))

                .request().log().ifValidationFails().baseUri(HOUSEHOLD_GROUPS_HOST)
                .body(body).when().post(CREATE_HOUSEHOLD_GROUPS_V1);
        response.then().log().ifValidationFails()
                .statusCode(201);
        return response;
    }

    //Get household Group
    public static Response getHouseholdGroup
    (final String authToken, final String ssn, final String groupId) {

        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("AppId", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("fsreqid", "Target Account GroupID Testing"),
                        new Header("partyId", ssn),
                        new Header("partyIdType", "LID"),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))
                .queryParam("groupTypeCode", "APO_WM")
                .queryParam("groupId", groupId)
                .request().log().ifValidationFails().baseUri(HOUSEHOLD_GROUPS_HOST)
                .when().get(GET_HOUSEHOLD_GROUPS_V1);
        return response;
    }

    //Get household Group
    public static Response getHouseholdGroupId
    (final String authToken, final String mid) {

        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("AppId", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("fsreqid", "Target Account GroupID Testing"),
                        new Header("user-mid", mid),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json"),
                        new Header("user-poe","RETAIL")))
                .queryParam("product", "WM")
                .request().log().ifValidationFails().baseUri(AST_HOST)
                .when().get(GET_HOUSEHOLD_GROUP_ID);
        return response;
    }

    public static void deleteHouseholdGroup(final String groupId, final String authToken) {
        final VelocityContext context = new VelocityContext();
        context.put("groupId", groupId);

        final String body =
                IOUtil.generateJsonRequest(context, HOUSEHOLD_GROUPS_DELETE_TEMPLATE);

        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("AppId", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("fsreqid", "GroupAccounts Testing"),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))

                .request().log().ifValidationFails().baseUri(HOUSEHOLD_GROUPS_HOST)
                .body(body).when().post(DELETE_HOUSEHOLD_GROUPS_V1);

        response.then().log().ifValidationFails()
                .statusCode(200);
    }

    // Create HouseHold identity with groupID
    public static String createHouseholdIdentityWithGroupIdandType(String mid, String groupId, String groupType, String scenarioId, String authToken) {

        VelocityContext context = new VelocityContext();
        context.put("mid", mid);
        context.put("groupId", groupId);
        context.put("groupType", groupType);
        context.put("scenarioId", scenarioId);
        context.put("productCode", "IGE");
        context.put("categoryCode", "DEF");

        final String body =
                IOUtil.generateJsonRequest(context, IDENTITY_GROUPID_CREATE_TEMPLATE);

        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("calling-app-id", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("log-tracking-id", "GroupAccounts Testing"),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))

                .request().log().ifValidationFails().baseUri(AST_HOST)
                .body(body).when().post(CREATE_IDENTITY_GROUPID);

        response.then().log().ifValidationFails()
                .statusCode(200);
        return response.path("identityList.identity[0].planningPartyId", new String[0]).toString();
    }

    //Create Principal with groupID
    public static String createPrincipalWithGroupId(String mid, String groupId, String groupType, String productCode, String categoryCode, String authToken) {

        VelocityContext context = new VelocityContext();
        context.put("mid", mid);
        context.put("groupId", groupId);
        context.put("groupType", groupType);
        context.put("productCode", productCode);
        context.put("categoryCode", categoryCode);
        final String body =
                IOUtil.generateJsonRequest(context, PRINCIPAL_GROUPID_CREATE_TEMPLATE);

        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("calling-app-id", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("log-tracking-id", "GroupAccounts Testing"),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))

                .request().log().ifValidationFails().baseUri(AST_HOST)
                .body(body).when().post(CREATE_PRINCIPAL_GROUPID);

        response.then().log().ifValidationFails()
                .statusCode(200);
        return response.path("principal.planningPartyId").toString();
    }

    // Create Scenario with groupID
    public static String createScenarioWithGroupIdandType(String mid, String groupId, String groupType, String authToken) {

        VelocityContext context = new VelocityContext();
        context.put("mid", mid);
        context.put("groupId", groupId);
        context.put("groupType", groupType);
        context.put("productCode", "IGE");
        context.put("categoryCode", "DEF");

        final String body =
                IOUtil.generateJsonRequest(context, SCENARIO_GROUPID_CREATE_TEMPLATE);

        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("calling-app-id", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("log-tracking-id", "GroupAccounts Testing"),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))

                .request().log().ifValidationFails().baseUri(AST_HOST)
                .body(body).when().post(CREATE_SCENARIO_GROUPID);

        response.then().log().ifValidationFails()
                .statusCode(200);
        return response.path("scenario.scenario[0].id").toString();
    }

    //Get Scenario with groupID
    public static String getScenarioWithGroupIdandType(String mid, String groupId, String groupType, String authToken) {

        VelocityContext context = new VelocityContext();
        context.put("mid", mid);
        context.put("groupId", groupId);
        context.put("groupType", groupType);
        context.put("productCode", "IGE");
        context.put("categoryCode", "DEF");

        final String body =
                IOUtil.generateJsonRequest(context, SCENARIO_GROUPID_CREATE_TEMPLATE);

        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("calling-app-id", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("log-tracking-id", "GroupAccounts Testing"),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))

                .request().log().ifValidationFails().baseUri(AST_HOST)
                .body(body).when().post(GET_SCENARIO_GROUPID);

        response.then().log().ifValidationFails()
                .statusCode(200);
        return response.path("scenario.scenario[0].id").toString();
    }
    
    /**
     * Delete all existing groups for a user.
     *
     * @param authToken
     *            the authToken
     * @param ssn
     *            the ssn
     */
    public static void deleteExistingGroups(final String authToken, final String ssn) {
        response = getHouseholdGroup(authToken, ssn);
        int getGroupIdsStatusCode = response.getStatusCode();
        if (getGroupIdsStatusCode == 200) {
            {
                List<String> groupIdList = response.path("households.household.groupId");
                if (groupIdList != null) {
                    for (String groupId : groupIdList) {
                        deleteHouseholdGroup(groupId, authToken);
                    }
                }
            }
        }
    }
    
    /**
     * Returns groups for a user.
     *
     * @param authToken
     *            the authToken
     * @param ssn
     *            the ssn
     * @return user groups
     */
    public static Response getHouseholdGroup
            (final String authToken, final String ssn) {
        
        response = RestAssured.given().log().ifValidationFails()
                .headers(new Headers(
                        new Header("Authorization", authToken),
                        new Header("AppId", "AP106532"),
                        new Header("appName", "Advice and Planning Platform"),
                        new Header("fsreqid", "Target Account GroupID Testing"),
                        new Header("partyId", ssn),
                        new Header("partyIdType", "LID"),
                        new Header("Accept", "application/json;charset=UTF-8"),
                        new Header("Content-Type", "application/json")))
                .queryParam("groupTypeCode", "APO_WM")
                .request().log().ifValidationFails().baseUri(HOUSEHOLD_GROUPS_HOST)
                .when().get(GET_HOUSEHOLD_GROUPS_V1);
        return response;
    }
}