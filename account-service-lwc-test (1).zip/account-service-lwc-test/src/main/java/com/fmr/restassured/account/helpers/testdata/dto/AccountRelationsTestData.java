/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.dto;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * Contains contribution related test data. Instantiates with default data, but can be updated.
 *
 * @author a601767
 *
 */
@Entity
public class AccountRelationsTestData
{

	//Account 1
	@Column(name = "beneficiary_allocation_pct")
	private String beneficiaryAllocationPct = null;

	@Column(name = "role_type")
	private String roleType = "OWNER";

	@Column(name = "entity_type")
	private String entityType = null;

	@Column(name = "updated_beneficiary_allocation_pct")
	private String updatedBeneficiaryAllocationPct = null;


	//Account 2
	@Column(name = "beneficiary_allocation_pct_2")
	private String beneficiaryAllocationPct2 = null;

	@Column(name = "role_type_2")
	private String roleType2 = "OWNER";

	@Column(name = "entity_type_2")
	private String entityType2 = null;

	@Column(name = "updated_beneficiary_allocation_pct_2")
	private String updatedBeneficiaryAllocationPct2 = null;


	public AccountRelationsTestData()
	{
		super();
	}

	public AccountRelationsTestData(final String beneficiaryAllocationPct, final String roleType,
									final String entityType, String updatedBeneficiaryAllocationPct,
									final String beneficiaryAllocationPct2, final String roleType2,
									final String entityType2, final String updatedBeneficiaryAllocationPct2)
	{
		this.beneficiaryAllocationPct = beneficiaryAllocationPct;
		this.roleType = roleType;
		this.entityType = entityType;
		this.updatedBeneficiaryAllocationPct = updatedBeneficiaryAllocationPct;
		this.beneficiaryAllocationPct2 = beneficiaryAllocationPct2;
		this.roleType2 = roleType2;
		this.entityType2 = entityType2;
		this.updatedBeneficiaryAllocationPct2 = updatedBeneficiaryAllocationPct2;
	}

	/**
	 * @return beneficiaryAllocationPct
	 */
	public String getBeneficiaryAllocationPct()
	{
		return beneficiaryAllocationPct;
	}

	/**
	 * @param beneficiaryAllocationPct
	 * 			the beneficiaryAllocationPct
	 */
	public void setBeneficiaryAllocationPct(final String beneficiaryAllocationPct)
	{
		this.beneficiaryAllocationPct = beneficiaryAllocationPct;
	}

	/**
	 * @return roleType
	 */
	public String getRoleType()
	{
		return roleType;
	}

	/**
	 * @param roleType
	 * 			the roleType
	 */
	public void setRoleType(String roleType)
	{
		this.roleType = roleType;
	}

	/**
	 * @return entityType
	 */
	public String getEntityType()
	{
		return entityType;
	}

	/**
	 * @param entityType
	 * 			the entityType
	 */
	public void setEntityType(final String entityType)
	{
		this.entityType = entityType;
	}

	/**
	 * @return updatedBeneficiaryAllocationPct
	 */
	public String getUpdatedBeneficiaryAllocationPct()
	{
		return updatedBeneficiaryAllocationPct;
	}

	/**
	 * @param updatedBeneficiaryAllocationPct
	 * 			the updatedBeneficiaryAllocationPct
	 */
	public void setUpdatedBeneficiaryAllocationPct(final String updatedBeneficiaryAllocationPct)
	{
		this.updatedBeneficiaryAllocationPct = updatedBeneficiaryAllocationPct;
	}

	/**
	 * @return beneficiaryAllocationPct2
	 */
	public String getBeneficiaryAllocationPct2()
	{
		return beneficiaryAllocationPct2;
	}

	/**
	 * @param beneficiaryAllocationPct2
	 * 			the beneficiaryAllocationPct2
	 */
	public void setBeneficiaryAllocationPct2(final String beneficiaryAllocationPct2)
	{
		this.beneficiaryAllocationPct2 = beneficiaryAllocationPct2;
	}

	/**
	 * @return roleType2
	 */
	public String getRoleType2()
	{
		return roleType2;
	}

	/**
	 * @param roleType2
	 * 			the roleType2
	 */
	public void setRoleType2(final String roleType2)
	{
		this.roleType2 = roleType2;
	}

	/**
	 * @return entityType2
	 */
	public String getEntityType2()
	{
		return entityType2;
	}

	/**
	 * @param entityType2
	 * 			the entityType2
	 */
	public void setEntityType2(final String entityType2)
	{
		this.entityType2 = entityType2;
	}

	/**
	 * @return updatedBeneficiaryAllocationPct2
	 */
	public String getUpdatedBeneficiaryAllocationPct2()
	{
		return updatedBeneficiaryAllocationPct2;
	}

	/**
	 * @param updatedBeneficiaryAllocationPct2
	 * 			the updatedBeneficiaryAllocationPct2
	 */
	public void setUpdatedBeneficiaryAllocationPct2(final String updatedBeneficiaryAllocationPct2)
	{
		this.updatedBeneficiaryAllocationPct2 = updatedBeneficiaryAllocationPct2;
	}
}