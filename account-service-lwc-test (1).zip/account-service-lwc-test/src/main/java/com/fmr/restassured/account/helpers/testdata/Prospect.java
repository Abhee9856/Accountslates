/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata;

import com.fmr.pap.restassured.core.BaseServiceTest;
import com.fmr.pap.restassured.core.ServiceVersion;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.utilities.IOUtil;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.velocity.VelocityContext;

/**
 * This class is a POJO that creates and holds a household identity for a prospect.
 * Upon instantiation the class creates the household ID and sets the PPID.
 *
 * @author a601767
 *
 */
public class Prospect extends BaseServiceTest
{
	private String prospectId;
	
	private String sid;
	
	private String ppid;
	
	/**
	 * Creates the household identity for the prospect and sets the ppid
	 *
	 * @param prospectId
	 * @param sid
	 */
	public Prospect(String prospectId, String sid)
	{
		this.prospectId = prospectId;
		this.sid = sid;
		
		createHouseholdIdentity();
	}

	/**
	 * Get the ppid
	 * 
	 * @return the ppid
	 */
	public String getPpid()
	{
		return ppid;
	}
	
	/**
	 * Cleans the customer data before creating the household identity for this mid and returning the Planning Party ID.
	 *
	 */
	private void createHouseholdIdentity()
	{
		VelocityContext context = new VelocityContext();
		context.put("userIdentifierValue", sid);
		context.put("userIdentifierType", "sid");
		context.put("prospectId", prospectId);
		context.put("pointOfEntry", "RETAIL");
		context.put("principalPlanningPartyId", "0");
		context.put("planningPartyId", "0");
		context.put("relationship", "PRINCIPAL");
		context.put("firstName", "Prospect");
		context.put("middleName", "MName");
		context.put("lastName", "LName");
		context.put("gender", "MALE");
		context.put("preferredName", "Rick");
		context.put("dateOfBirth", "1977-11-11");

		
		PropertiesConfiguration config = setServiceBaseURIConfig(Services.Identity, ServiceVersion._201410);
		String householdInsertPath = config.getString("identity.household.insert.path");
		
		setOAuthRequestHeader();
				
		request.body(IOUtil.generateJsonRequest(context, "/template/identity/identity.household.insert.vm"));
		
		response = request.post(householdInsertPath);
		
		Integer ppid =  response.path("identityList.identity[0].planningPartyId");
		this.ppid = String.valueOf(ppid);
	}

}


