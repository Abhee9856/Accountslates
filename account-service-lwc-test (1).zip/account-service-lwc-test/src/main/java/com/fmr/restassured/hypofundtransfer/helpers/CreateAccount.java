/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.hypofundtransfer.helpers;

import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountConstants;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;

/**
 * Class to create Account
 *
 * @author a631781
 */

public class CreateAccount
{

	/**
	 * Logger to print appropriate error, warning, or info messages.
	 */
	private static Logger logger = LogManager.getLogger(CreateAccount.class);

	/**
	 * The response variable populated after each test run
	 */
	private static Response response;

	/**
	 * Create Accounts
	 * 
	 * @param ssn
	 * @param accountNumber
	 * @param source
	 * @param mnemonic
	 * @param accountNumber2
	 * @param source2
	 * @param mnemonic2
	 * @param accountNumber3
	 * @param source3
	 * @param mnemonic3
	 * @param accountNumber4
	 * @param source4
	 * @param mnemonic4
	 * @param ppid
	 * @param mid
	 * @param request
	 * @param authToken
	 * @return AccountIDs
	 */
	public static String createAccounts(final String ssn, final String accountNumber, final String source,
		final String mnemonic,final float value, final String accountNumber2, final String source2, final String mnemonic2, final float value2,
	        final String accountNumber3, final String source3, final String mnemonic3, final String accountNumber4,
	        final String source4, final String mnemonic4, final String ppid, final String mid,
	        final RequestSpecification request, final String authToken)
	{
		final String host = AccountHelper.getQATestEnvHost();
		final String path = AccountsPaths.CREATE_ACCOUNT_V2;

		final VelocityContext context = new VelocityContext();
		context.put("accountNumber", accountNumber);
		context.put("source", source);
		context.put("mnemonic", mnemonic);
		context.put("accountNumber2", accountNumber2);
		context.put("source2", source2);
		context.put("mnemonic2", mnemonic2);
		if (null != accountNumber3)
		{

			context.put("accountNumber3", accountNumber3);
			context.put("source3", source3);
			context.put("mnemonic3", mnemonic3);
			context.put("value3", "1055000");
		}

		if (null != accountNumber4)
		{

			context.put("accountNumber4", accountNumber4);
			context.put("source4", source4);
			context.put("mnemonic4", mnemonic4);
			context.put("value4", "175000");
		}
		context.put("value", value);
		context.put("asOfDate", "2021-01-14");
		context.put("value2", value2);

		context.put("ppid", ppid);
		final String body =
		        IOUtil.generateJsonRequest(context, AccountConstants.HFT_CREATE_ACCOUNTS_TEMPLATE);
		request.given().header(new Header("Authorization", authToken)).baseUri(host).body(body);
		response = request.log().ifValidationFails().post(path);
		String accId1 = null, accId2 = null, accId3 = null, accId4 = null;
		response.then().log().ifValidationFails().statusCode(200);

		if (null != response.path("accountList"))
		{
			if (null != response.path("accountList.accountId.find{it.accountNumber == '" + accountNumber + "'}"))
			{
				accId1 = response.path("accountList.accountId.find{it.accountNumber == '" + accountNumber + "'}.id");
			}
			if (null != response.path("accountList.accountId.find{it.accountNumber == '" + accountNumber2 + "'}"))
			{
				accId2 = response.path("accountList.accountId.find{it.accountNumber == '" + accountNumber2 + "'}.id");
			}
			if (null != response.path("accountList.accountId.find{it.accountNumber == '" + accountNumber3 + "'}"))
			{
				accId3 = response.path("accountList.accountId.find{it.accountNumber == '" + accountNumber3 + "'}.id");
			}
			if (null != response.path("accountList.accountId.find{it.accountNumber == '" + accountNumber4 + "'}"))
			{
				accId4 = response.path("accountList.accountId.find{it.accountNumber == '" + accountNumber4 + "'}.id");
			}
		}

		final StringBuilder builder = new StringBuilder(accId1).append(",").append(accId2);
		if (null != accId3)
		{
			builder.append(",").append(accId3);
		}

		if (null != accId4)
		{
			builder.append(",").append(accId4);
		}
		return builder.toString();

	}
}