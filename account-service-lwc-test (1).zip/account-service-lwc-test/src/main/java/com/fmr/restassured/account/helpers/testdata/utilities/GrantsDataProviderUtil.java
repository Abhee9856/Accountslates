/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.restassured.account.helpers.testdata.constants.TestDataConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountGrantsTestDataOneGrant;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.DataProvider;

/**
 * This utility class contains methods pertaining to the implementation of DataProvider logic for handling multiple
 * data sets for account grants testing.
 *
 * @author a608077
 */

public class GrantsDataProviderUtil {

    /**
     * The AccountGrantsTestData DTO
     */
    private static List<List<AccountGrantsTestDataOneGrant>> grantsTestData = null;

    /**
     * Instance to the test data utility class
     */
    private static final GrantsTestDataUtil grantsTestDataUtil = new GrantsTestDataUtil();


    /**
     * Data Provider method for pulling grants data for one_grant_one_vest
     *
     * @return Object[][] the grants data
     */
    @DataProvider(name = "getOneGrantOneVestData")
    public static Object[][] getOneGrantOneVestData() {
        grantsTestData = new ArrayList<>();
        grantsTestDataUtil.getGrantsOneGrantAccountData(TestDataConstants.ACCOUNT_GRANTSONEGRANT_TABLE_NAME,
                TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_GRANTSONEGRANT_TESTNAME).forEach(data -> {
            final List<AccountGrantsTestDataOneGrant> dataList = new ArrayList<>();
            dataList.add(data);
            grantsTestData.add(dataList);
        });

        return grantsTestData.stream().map(List::toArray).toArray(Object[][]::new);
    }
}
