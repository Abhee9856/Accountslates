/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.hypofundtransfer.helpers;


/**
 * This class holds all constants pertaining to the env.properties file (located under src/test/resources/environment)
 *
 * @author a653510
 *
 */
public class HypotheticalFundTransferPaths
{	
	public static final String HYPOFUNDTRNDFR_V1_PATH = "hypo-fund-transfer/v1/financial-profiles/accounts/transfers";
	
	public static final String HYPOFUNDTRNDFR_V1_PATH_APIGEE = "/pa-hypo-fund-transfer/v1/financial-profiles/accounts/transfers";

}
