/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.restassured.account.database.DatabaseConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountPositionsTestData;

import java.util.ArrayList;
import java.util.List;

import com.fmr.restassured.account.helpers.testdata.constants.TestDataConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import org.testng.annotations.DataProvider;

/**
 * This utility class contains methods pertaining to the implementation of DataProvider logic for handling multiple
 * datasets.
 *
 * @author a653510
 */
public class AccountsRegCodesDataProviderUtil {

    private static List<List<AccountRegCodeTestData>> regCdList = null;

    private static List<List<AccountRegCodeTestData>> filiRegCdList = null;

    private static List<List<AccountRegCodeTestData>> fullViewRegCdList = null;

    private static List<List<AccountPositionsTestData>> positionsList = null;


    /**
     * Instance to the test data utility class
     */
    private static final TestDataUtil testDataUtil = new TestDataUtil();

    /**
     * Data Provider method for pulling multiple Regcode data set for Retail Accounts
     *
     * @return Object[][] the regCode data set for Retail Accounts-get
     */
    @DataProvider(name = "getRetailAccountRegCodeGet")
    public static Object[][] getRetailAccountRegCodeGet() {
        regCdList = new ArrayList<>();
        testDataUtil.getAccountRegCodeTestDataRecordsBySource("Retail",TestDataConstants.ACCOUNT_REGCODES_TABLE_NAME)
                .forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            regCdList.add(dataList);
        });

        return regCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }
    /**
     * Data Provider method for pulling multiple Regcode data set for Retail Accounts
     *
     * @return Object[][] the regCode data set for Retail Accounts
     */
    @DataProvider(name = "getRetailAccountRegCode")
    public static Object[][] getRetailAccountRegCode() {
        regCdList = new ArrayList<>();
        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_REGCODES_TABLE_NAME,
                TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_RETAIL_TESTNAME).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            regCdList.add(dataList);
        });

        return regCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling multiple Regcode data set for FILI Accounts
     *
     * @return Object[][] the regCode data set for Fili Accounts
     */
    @DataProvider(name = "getFiliRegCodeData")
    public static Object[][] getFiliRegCodeData() {
        filiRegCdList = new ArrayList<>();
        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_FILI_TABLE_NAME,
                TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_FILI_TESTNAME).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            filiRegCdList.add(dataList);
        });

        return filiRegCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling multiple Regcode data set for Workplace Accounts
     *
     * @return Object[][] the regCode data set for Workplace Accounts
     */
    @DataProvider(name = "getWorkplaceAccountRegCode")
    public static Object[][] getWorkplaceAccountRegCode() {
        final List<List<AccountRegCodeTestData>> workplaceRegCdList = new ArrayList<>();

        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_WP_TABLE_NAME,
                TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_WP_TESTNAME).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            workplaceRegCdList.add(dataList);
        });

        return workplaceRegCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling multiple Regcode data set for FILI Accounts
     *
     * @return Object[][] the regCode data set for Fili Accounts
     */
    @DataProvider(name = "getFiliRegCodeDataWithFilterExclude")
    public static Object[][] getFiliRegCodeDataWithFilterExclude() {
        filiRegCdList = new ArrayList<>();
        testDataUtil
                .getAccountRegCodeTestDataRecordsWithFilter(TestDataConstants.ACCOUNT_FILI_TABLE_NAME,
                        TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_FILI_TESTNAME,
                        TestDataConstants.ACCT_COLNAME_FILTER_TYPE, TestDataConstants.ACCT_FILTER_EXCLUDEE)
                .forEach(data -> {
                    final List<AccountRegCodeTestData> dataList = new ArrayList<>();
                    dataList.add(data);
                    filiRegCdList.add(dataList);
                });

        return filiRegCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling multiple Regcode data set for FILI Accounts
     *
     * @return Object[][] the regCode data set for Fili Accounts
     */
    @DataProvider(name = "getFiliRegCodeDataWithFilterInclude")
    public static Object[][] getFiliRegCodeDataWithFilterInclude() {
        filiRegCdList = new ArrayList<>();
        testDataUtil
                .getAccountRegCodeTestDataRecordsWithFilter(TestDataConstants.ACCOUNT_FILI_TABLE_NAME,
                        TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_FILI_TESTNAME,
                        TestDataConstants.ACCT_COLNAME_FILTER_TYPE, TestDataConstants.ACCT_FILTER_INCLUDEE)
                .forEach(data -> {
                    final List<AccountRegCodeTestData> dataList = new ArrayList<>();
                    dataList.add(data);
                    filiRegCdList.add(dataList);
                });

        return filiRegCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling multiple Regcode data set for RETAIL Accounts
     *
     * @return Object[][] the regCode data set for Retail Accounts
     */
    @DataProvider(name = "getRetailRegCodeDataWithFilterExclude")
    public static Object[][] getRetailRegCodeDataWithFilterExclude() {
        regCdList = new ArrayList<>();
        testDataUtil
                .getAccountRegCodeTestDataRecordsWithFilter(TestDataConstants.ACCOUNT_RETAIL_TABLE_NAME,
                        TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_RETAIL_TESTNAME,
                        TestDataConstants.ACCT_COLNAME_FILTER_TYPE, TestDataConstants.ACCT_FILTER_EXCLUDEE)
                .forEach(data -> {
                    final List<AccountRegCodeTestData> dataList = new ArrayList<>();
                    dataList.add(data);
                    regCdList.add(dataList);
                });

        return regCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling multiple Regcode data set for RETAIL Accounts
     *
     * @return Object[][] the regCode data set for Retail Accounts
     */
    @DataProvider(name = "getRetailRegCodeDataWithFilterInclude")
    public static Object[][] getRetailRegCodeDataWithFilterInclude() {
        regCdList = new ArrayList<>();
        testDataUtil
                .getAccountRegCodeTestDataRecordsWithFilter(TestDataConstants.ACCOUNT_RETAIL_TABLE_NAME,
                        TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_RETAIL_TESTNAME,
                        TestDataConstants.ACCT_COLNAME_FILTER_TYPE, TestDataConstants.ACCT_FILTER_INCLUDEE)
                .forEach(data -> {
                    final List<AccountRegCodeTestData> dataList = new ArrayList<>();
                    dataList.add(data);
                    regCdList.add(dataList);
                });

        return regCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling multiple Regcode data set for FV Accounts
     *
     * @return Object[][] the regCode data set for FV Accounts
     */
    @DataProvider(name = "getFullViewRegCodeData")
    public static Object[][] getFullViewRegCodeData() {
        fullViewRegCdList = new ArrayList<>();
        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_FV_TABLE_NAME,
                TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_FV_TESTNAME).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            fullViewRegCdList.add(dataList);
        });

        return fullViewRegCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling multiple Regcode data set for Manual Accounts
     *
     * @return Object[][] the regCode data set for Manual Accounts
     */
    @DataProvider(name = "getManualRegCodeData")
    public static Object[][] getManualRegCodeData() {
        List<List<AccountRegCodeTestData>> manualRegCdList = new ArrayList<>();
        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_MANUAL_TABLE_NAME,
                TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_MANUAL_TESTNAME).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            manualRegCdList.add(dataList);
        });

        return manualRegCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling multiple positions data set for all Accounts
     *
     * @return Object[][] the position data set for all Accounts
     */
    @DataProvider(name = "getPositionsAccountData")
    public static Object[][] getPositionsAccountData() {
        positionsList = new ArrayList<>();
        testDataUtil.getPositionsAccountTestDataRecords(TestDataConstants.ACCOUNT_POSITIONS_TABLE_NAME,
                TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_POSITIONS_GET_TESTNAME).forEach(data -> {
            final List<AccountPositionsTestData> dataList = new ArrayList<>();
            dataList.add(data);
            positionsList.add(dataList);
        });

        return positionsList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling multiple positions data set for all Accounts
     *
     * @return Object[][] the position data set for all Accounts
     */
    @DataProvider(name = "setPositionsAccountData")
    public static Object[][] setPositionsAccountData() {
        positionsList = new ArrayList<>();
        testDataUtil.getPositionsAccountTestDataRecords(TestDataConstants.ACCOUNT_POSITIONS_TABLE_NAME,
                TestDataConstants.NO_OF_ROWS, TestDataConstants.ACCT_POSITIONS_SET_TESTNAME).forEach(data -> {
            final List<AccountPositionsTestData> dataList = new ArrayList<>();
            dataList.add(data);
            positionsList.add(dataList);
        });

        return positionsList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling Critical Regcode data set for FILI Accounts
     *
     * @return Object[][] the regCode data set for Fili Accounts
     */
    @DataProvider(name = "getFiliData")
    public static Object[][] getFiliData() {
        filiRegCdList = new ArrayList<>();
        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_FILI_TABLE_NAME,
                TestDataConstants.TWO_CRITICAL_ROWS, TestDataConstants.ACCT_FILI_CRITICAL_TEST).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            filiRegCdList.add(dataList);
        });

        return filiRegCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }


    /**
     * Data Provider method for pulling Critical Regcode data set for Manual Accounts
     *
     * @return Object[][] the regCode data set for Manual Accounts
     */
    @DataProvider(name = "getManualData")
    public static Object[][] getManualData() {
        List<List<AccountRegCodeTestData>> manualRegCdList = new ArrayList<>();
        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_MANUAL_TABLE_NAME,
                TestDataConstants.FIVE_CRITICAL_ROWS, TestDataConstants.ACCT_MANUAL_CRITICAL_TEST).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            manualRegCdList.add(dataList);
        });

        return manualRegCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling Critical Regcode data set for Retail Accounts
     *
     * @return Object[][] the regCode data set for Retail Accounts
     */
    @DataProvider(name = "getRetailAccountData")
    public static Object[][] getRetailAccountData() {
        regCdList = new ArrayList<>();
        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_RETAIL_TABLE_NAME,
                TestDataConstants.THREE_CRITICAL_ROWS, TestDataConstants.ACCT_RETAIL_CRITICAL_TEST).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            regCdList.add(dataList);
        });

        return regCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling Critical Regcode data set for Workplace Accounts
     *
     * @return Object[][] the regCode data set for Workplace Accounts
     */
    @DataProvider(name = "getWorkplaceAccountData")
    public static Object[][] getWorkplaceAccountData() {
        final List<List<AccountRegCodeTestData>> workplaceRegCdList = new ArrayList<>();

        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_WP_TABLE_NAME,
                TestDataConstants.TWO_CRITICAL_ROWS, TestDataConstants.ACCT_WORKPLACE_CRITICAL_TEST).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            workplaceRegCdList.add(dataList);
        });

        return workplaceRegCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling Critical Regcode data set for FV Accounts
     *
     * @return Object[][] the regCode data set for FV Accounts
     */
    @DataProvider(name = "getFullViewData")
    public static Object[][] getFullViewData() {
        fullViewRegCdList = new ArrayList<>();
        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_FV_TABLE_NAME,
                TestDataConstants.THREE_CRITICAL_ROWS, TestDataConstants.ACCT_FULLVIEW_CRITICAL_TEST).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            fullViewRegCdList.add(dataList);
        });

        return fullViewRegCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }

    /**
     * Data Provider method for pulling NPDCDB Regcode data set for Retail Accounts
     *
     * @return Object[][] the regCode data set for Retail Accounts
     */
    @DataProvider(name = "getNPDCDBRetailAccountData")
    public static Object[][] getNPDCDBRetailAccountData() {
        regCdList = new ArrayList<>();
        testDataUtil.getAccountRegCodeTestDataRecords(TestDataConstants.ACCOUNT_RETAIL_TABLE_NAME,
                TestDataConstants.TWO_CRITICAL_ROWS, TestDataConstants.ACCT_RETAIL_NPDCDB_TEST).forEach(data -> {
            final List<AccountRegCodeTestData> dataList = new ArrayList<>();
            dataList.add(data);
            regCdList.add(dataList);
        });

        return regCdList.stream().map(List::toArray).toArray(Object[][]::new);
    }
}