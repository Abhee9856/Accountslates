/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers;

import com.fmr.ast.platform.domain.common.assetclassification.AllocationPart;
import com.fmr.ast.platform.domain.common.assetclassification.AssetAllocation;
import com.fmr.pap.restassured.utilities.OAuthUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

/**
 * Account Utility
 *
 * @author a631781
 */

public class AccountUtil
{

    /**
     * The LOGGER.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(AccountUtil.class);

    /**
     * The Constant PAP_DATE_FORMAT.
     */
    public static final String PAP_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";

	public static final String oauthClientId = System.getProperty("oauthClientId");

	public static final String oauthClientSecret =System.getProperty("oauthClientSecret");

	public static final String JWTClientId = System.getProperty("JWTClientId");;

	public static final String JWTClientSecret = System.getProperty("JWTClientSecret");

	public static final String ApigeeBaseUri = "https://apigee.proxy.aws-nonprod.fmrcloud.com";

	public static final String ApigeeTokenPath = "/fidelity-np-perf-pperf/edgemicro-auth-pi-v2-1/token";

    /**
     * Instantiates a new account utils.
     */
    private AccountUtil()
    {
	super();
    }

    /**
     * Parse EPOCH date to Date Format.
     *
     * @param asOfDateTime the as of date time
     * @return the date
     */
    public static String parseDSSDate(final Long asOfDateTime)
    {
	String parsedDate = "";
	try
	{
	    TimeZone.setDefault(TimeZone.getTimeZone("GMT"));
	    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(PAP_DATE_FORMAT);
	    Date d = new Date(asOfDateTime * 1000);
	    parsedDate = simpleDateFormat.format(d);
	}
	catch (final Exception e)
	{
	    LOGGER.error("Date Conversion failed", e);
	}
	return parsedDate;
    }

    /**
     * Calculate equity pct.
     *
     * @param domesticEquity
     *                the domestic equity
     * @param foreignEquity
     *                the foreign equity
     * @param privateQqtAlt
     *                the private qqt alt
     * @param privateCreditAlt
     *                the private credit alt
     * @param privateRealAssetAlt
     *                the private real asset alt
     * @return EquityPercentage
     */
    public static float calculateEquityPct(final float domesticEquity, final float foreignEquity,
		    final float privateQqtAlt, final float privateCreditAlt, final float privateRealAssetAlt)
    {
	float EquityPercentage =
			domesticEquity + foreignEquity + (privateQqtAlt * 1.2f) + (privateCreditAlt * 0.35f) + (
					privateRealAssetAlt * 0.5f);
	return EquityPercentage;
    }
    
    /**
     * Post transfer ast allocation amount det act.
     *
     * @param smvDestAct
     *                the smv dest act
     * @param totalAmtTransferred
     *                the total amt transferred
     * @param assetAllocationPct
     *                the asset allocation pct
     * @param assetTypeAmtTransferred
     *                the asset type amt transferred
     * @return postTransferAssetAmount
     */
    public static float postTransferAstAllocationAmountDetAct(final float smvDestAct, final float totalAmtTransferred,
		    final float assetAllocationPct, final float assetTypeAmtTransferred)
    {
	float perTransferAmt = (smvDestAct - totalAmtTransferred) * assetAllocationPct;
	float postTransferAssetAmount = (perTransferAmt + assetTypeAmtTransferred);

	return postTransferAssetAmount;
    }

    /**
     * Post transfer ast allocation amount funding act.
     *
     * @param srcMktValFundingAccount
     *                the src mkt val funding account
     * @param totalAmtTransferred
     *                the total amt transferred
     * @param assetAllocationPct
     *                the asset allocation pct
     * @param assetTypeAmtTransferred
     *                the asset type amt transferred
     * @return postTransferAssetAmount
     */
    public static float postTransferAstAllocationAmountFundingAct(final float srcMktValFundingAccount,
		    final float totalAmtTransferred,
		    final float assetAllocationPct, final float assetTypeAmtTransferred)
    {
	float perTransferAmt = (srcMktValFundingAccount + totalAmtTransferred) * assetAllocationPct;
	float postTransferAssetAmount = (perTransferAmt - assetTypeAmtTransferred);

	return postTransferAssetAmount;
    }

    /**
     * Post transfer ast allocation amount target act.
     *
     * @param smvDestActTarget
     *                the smv dest act target
     * @param assetAllocationPct
     *                the asset allocation pct
     * @return postTransferAssetAmount
     */
    public static float postTransferAstAllocationAmountTargetAct(final float smvDestActTarget,
		    final float assetAllocationPct)
    {

	float postTransferAssetAmount = smvDestActTarget * assetAllocationPct;

	return postTransferAssetAmount;
    }

	/**
	 * Generates the oauthToken using clientId and clientSecret.
	 *
	 * @return oauthToken
	 */
	public static String getOauthToken()
	{
		return OAuthUtil.getOAuthToken(oauthClientId, oauthClientSecret);
	}

	public static String getoAuthTokenForRetirementDistribution() 
	{
		return OAuthUtil.getOAuthToken(ApigeeBaseUri + ApigeeTokenPath,
				JWTClientId, JWTClientSecret, "client_credentials", (String) null, (String) null, (String) null);
	}

	/**
	 * Validate the asset allocation.
	 * (Can be adapted for other tests by making the expected values dynamic. Currently the Target Account create
	 * template only allows for the BOND value to be set.)
	 *
	 * @param assetAllocation
	 * 				the assetAllocation object from the response.
	 */
	public static void validateV1AssetAllocation(final AssetAllocation assetAllocation, final Double bond)
	{
		assetAllocation.getAllocation().forEach(allocationPart ->
		{
			switch (allocationPart.getAssetClass())
			{
				case BOND:
					Assert.assertEquals(bond, allocationPart.getNetPercentage().getValue());
					break;
				case CASH:
					Assert.assertEquals(0.0607d, allocationPart.getNetPercentage().getValue());
					break;
				case OTHER:
					Assert.assertEquals(0.0d, allocationPart.getNetPercentage().getValue());
					break;
				case TOTAL_EQUITY:
					Assert.assertEquals(0.513d, allocationPart.getNetPercentage().getValue());
					validatedEquityAllocation(allocationPart.getAllocation());
					break;
			}
		});
	}

	/**
	 * Sub-method for validating the equity percents.
	 *
	 * @param allocation
	 * 				the allocation
	 */
	private static void validatedEquityAllocation(final List<AllocationPart> allocation)
	{
		allocation.forEach(allocationPart -> {
			switch (allocationPart.getAssetClass())
			{
				case DOMESTIC_EQUITY:
					Assert.assertEquals(0.5116d, allocationPart.getNetPercentage().getValue());
					break;
				case FOREIGN_EQUITY:
					Assert.assertEquals(0.0014d, allocationPart.getNetPercentage().getValue());
					break;
			}
		});
	}
}
