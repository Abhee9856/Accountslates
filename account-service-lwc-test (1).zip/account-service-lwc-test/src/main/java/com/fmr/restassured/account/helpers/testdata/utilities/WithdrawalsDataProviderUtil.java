/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.ast.platform.account.domain.SourceSystem;
import com.fmr.restassured.account.helpers.testdata.dto.AccountWithdrawalsTestData;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.testng.annotations.DataProvider;

/**
 * This utility class contains methods pertaining to the implementation of DataProvider logic for handling multiple
 * data sets for withdrawals testing.
 *
 * @author a601767
 */
public class WithdrawalsDataProviderUtil
{

	/** The AccountWithdrawalsTestData DTO */
	private static List<List<AccountWithdrawalsTestData>> withdrawalsTestData = null;

	/** Instance to the test data utility class */
	private static final TestDataUtil testDataUtil = new TestDataUtil();

	
	/**
	 * Data Provider method for pulling multiple withdrawals for Fullview Accounts
	 *
	 * @return Object[][] the withdrawal data set for Fullview Accounts
	 */
	@DataProvider(name = "getFullviewWithdrawalData")
	public static Object[][] getFullviewWithdrawalData()
	{
		return getData(SourceSystem.FULLVIEW.name());
	}
	
	/**
	 * Data Provider method for pulling multiple withdrawals for Retail Accounts
	 *
	 * @return Object[][] the withdrawal data set for Retail Accounts
	 */
	@DataProvider(name = "getRetailWithdrawalData")
	public static Object[][] getRetailWithdrawalData()
	{
		return getData(SourceSystem.RETAIL.name());
	}

	/**
	 * Data Provider method for pulling multiple withdrawals for Workplace Accounts
	 *
	 * @return Object[][] the withdrawal data set for Workplace Accounts
	 */
	@DataProvider(name = "getWorkplaceWithdrawalData")
	public static Object[][] getWorkplaceWithdrawalData()
	{
		return getData(SourceSystem.WORKPLACE.name());
	}

	/**
	 * Data Provider method for pulling multiple withdrawals for FILI Accounts
	 *
	 * @return Object[][] the withdrawal data set for FILI Accounts
	 */
	@DataProvider(name = "getFiliWithdrawalData")
	public static Object[][] getFiliWithdrawalData()
	{
		return getData(SourceSystem.FILI.name());
	}
	
	/**
	 * Gets use cases based on the source system provided.
	 *
	 * @param sourceSystem
	 * 			the source system
	 * @return the test data
	 */
	private static Object[][] getData(final String sourceSystem)
	{
		withdrawalsTestData = new ArrayList<>();
		testDataUtil.getWithdrawalsTestData(sourceSystem).stream().filter(Objects::nonNull)
			.forEach(data -> {
			        final List<AccountWithdrawalsTestData> dataList = new ArrayList<>();
			        dataList.add(data);
			        withdrawalsTestData.add(dataList);
		        });

		return withdrawalsTestData.stream().map(List::toArray).toArray(Object[][]::new);
	}
	/**
	 * Data Provider method for pulling multiple withdrawals for manual Accounts
	 *
	 * @return Object[][] the withdrawal data set for manual Accounts
	 */
	@DataProvider(name = "getManualWithdrawalData")
	public static Object[][] getManualWithdrawalData()
	{
		withdrawalsTestData = new ArrayList<>();
		testDataUtil.getWithdrawalsTestData(SourceSystem.RETAIL.name()).forEach(data -> {
			final List<AccountWithdrawalsTestData> dataList = new ArrayList<>();
			dataList.add(data);
			withdrawalsTestData.add(dataList);
		});

		return withdrawalsTestData.stream().map(List::toArray).toArray(Object[][]::new);
	}
}
