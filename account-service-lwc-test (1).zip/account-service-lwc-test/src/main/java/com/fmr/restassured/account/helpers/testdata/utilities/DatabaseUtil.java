/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.restassured.account.database.DatabaseConfigUtil;
import com.fmr.restassured.account.database.DatabaseConstants;
import com.fmr.restassured.account.database.SQLCommand;
import com.zaxxer.hikari.HikariDataSource;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class serves as a utility class for any database connection activities
 *
 * @author a601767
 *
 */
public class DatabaseUtil
{
	/** Logger to print appropriate error, warning, or info messages **/
	private static Logger logger = LogManager.getLogger(DatabaseUtil.class);
	
	/**
	 * 
	 * Retrieves test data from SQLite database
	 *
	 * @param testName
	 * @param sqlitePropertyKeyName
	 * @return test data pertaining to the specified environment and test name
	 */
	public static ArrayList<HashMap<String, String>> getRegressionTestData(final String testName, final String sqlitePropertyKeyName)
	{
		ArrayList<HashMap<String, String>> rsList = null;
		
		HikariDataSource ds = null;
		Connection conn = null;
		
		try
		{	
			ds = DatabaseConfigUtil.getSqliteDataSource();
			conn = ds.getConnection();
			
			final String sql = getSQLiteCommand(sqlitePropertyKeyName);
			final SQLCommand sqlCommand = new SQLCommand.SQLCommandBuilder(conn, sql)
					.setString(1, testName)
					.build();
			
			rsList = sqlCommand.getResults();
			
			logger.trace("SQL: " + sqlCommand.getSql());
			logger.trace("Results: " + rsList);
		}
		catch (SQLException | IOException e)
		{
			logger.error(e.getMessage());
		}
		finally
		{
			try
			{
				assert conn != null;
				conn.close();
				ds.close();
			}
			catch (SQLException ignore)
			{
				logger.error(ignore.getMessage(), ignore);
			}
		}
		
		return rsList;
	}
	
	/**
	 * 
	 * Method that will get the SQL command from the properties file
	 * 
	 * @param propertyName
	 * @return the value of the specified key name
	 */
	private static String getSQLiteCommand(final String propertyName)
	{
		final Properties prop = new Properties();
		InputStream input = null;
		
		try
		{
			input = new FileInputStream(DatabaseConstants.SQLITE_SQL_FILE_PATH);

			prop.load(input);
		}
		catch (IOException e)
		{
			logger.error(e.getMessage(), e);
		}

		return prop.getProperty(propertyName);
	}
}
