/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers;

/**
 * This class holds all constants for paths of Account service
 * @author a608077
 *
 */
public class AccountPaths
{
	public static final String RESOLVE_ACCOUNT_NUMBER_PATH = "/account/v2/resolve-account-number";
}
