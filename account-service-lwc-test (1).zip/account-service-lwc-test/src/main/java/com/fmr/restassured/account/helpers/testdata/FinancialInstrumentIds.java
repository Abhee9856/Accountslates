/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata;

import static org.hamcrest.Matchers.equalTo;

import com.fmr.pap.restassured.core.BaseServiceTest;
import com.fmr.pap.restassured.core.ServiceVersion;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.velocity.VelocityContext;

/**
 * This object contains a mapping of stock symbols to financial instrument IDs.
 *
 * @author a601767
 *
 */
public class FinancialInstrumentIds extends BaseServiceTest
{
	//Financial Instrument IDs and their symbols
	private Map<String, FinancialInstrumentDetails> finstIdDetailsList = new HashMap<>();

	private static final String CUSIP = "cusip";
	private static final String FUND_CODE = "fundCode";
	public static final String FINANCIAL_INSTRUMENTS_GET_ID_TEMPLATE = "/template/financialInstruments/financialInstruments.getId.vm";

	public static final String FINANCIAL_INSTRUMENTS_GET_ID_PATH = "/financialinstrument/2014/10/financialinstrument/id/get";
	public static final String FINANCIAL_INSTRUMENTS_QA_BASE_URI = "https://ast-platformqa1.fmr.com";

	/**
	 * Constructor takes a variable number of stock symbols and builds a mapping of
	 * symbols to the financial instrument IDs
	 *
	 */
	public FinancialInstrumentIds(final String ... symbols)
	{
		for (final String symbol : symbols)
		{
			finstIdDetailsList.put(symbol, null);
		}
		
		resolveFinancialInstrumentIds();
	}
	
	
	/**
	 * Get the finstId associated with the symbol
	 *
	 * @return the finstId
	 */
	public Integer getFinstId(String symbol)
	{
		return finstIdDetailsList.get(symbol).getFinstId();
	}
	
	/**
	 * Get the Morningstar ID
	 *
	 * @return the morningstar id
	 */
	public String getMorningstarId(String symbol)
	{
		return finstIdDetailsList.get(symbol).getMorningstarId();
	}
	
	/**
	 * Get the type associated with the symbol
	 *
	 * @return the type
	 */
	public String getType(String symbol)
	{
		return finstIdDetailsList.get(symbol).getType();
	}
	
	/**
	 * Get the Cusip associated with the symbol
	 *
	 * @return the cusip
	 */
	public String getCusip(String symbol)
	{
		return finstIdDetailsList.get(symbol).getCusip();
	}
	
	/**
	 * Get the Symbol associated with the symbol
	 *
	 * @return the symbol
	 */
	public String getSymbol(String symbol)
	{
		return finstIdDetailsList.get(symbol).getSymbol();
	}
	
	
	/**
	 * Get the name associated with the symbol
	 *
	 * @return the name
	 */
	public String getName(String symbol)
	{
		return finstIdDetailsList.get(symbol).getName();
	}

	/**
	 * Resolve stock symbols to the corresponding finstIds. This method will call
	 * Financial Instrument service for each symbol in the map and populate the value mappings to 
	 * the FinstId for the symbol.
	 *
	 * @param map contains stock symbols as keys and null values, which will be populated with corresponding finstIds.
	 * @return Updated map with FinstId values populated.
	 */
	public void resolveFinancialInstrumentIds()
	{
		ArrayList<String> symbols = new ArrayList<>(finstIdDetailsList.keySet());
		VelocityContext fiContext = new VelocityContext();
		fiContext.put(CUSIP, "null");
		fiContext.put(FUND_CODE, "null");
		setOAuthRequestHeader();

		for (int i = 0; i < symbols.size(); i++)
		{
			fiContext.put("symbol", symbols.get(i));
			//Build request body, set the host, and retrieve the resource path
			request.body(IOUtil.generateJsonRequest
					(fiContext, FINANCIAL_INSTRUMENTS_GET_ID_TEMPLATE));
			
			//Call Account service
			response = request.post(FINANCIAL_INSTRUMENTS_QA_BASE_URI+FINANCIAL_INSTRUMENTS_GET_ID_PATH);
			
			//Assert on response
			response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true));
			
			//Add the Financial Instrument to the map
			FinancialInstrumentDetails finstDetails = new FinancialInstrumentDetails();
			finstDetails.setFinstId(response.path("finstIdList[0].finstId"));
			finstDetails.setCusip(response.path("finstIdList[0].symbol"));
			try 
			{
				finstDetails.setSymbol(response.path("finstIdList[0].cusip"));
			} 
			catch (IllegalArgumentException e)
			{
				finstDetails.setSymbol(null);
			}
			try 
			{
				finstDetails.setMorningstarId(response.path("finstIdList[0].morningStarId"));
			} 
			catch (IllegalArgumentException e)
			{
				finstDetails.setMorningstarId(null);
			}
			finstDetails.setType(response.path("finstIdList[0].type"));
			finstDetails.setName(response.path("finstIdList[0].name"));
			
			finstIdDetailsList.put(symbols.get(i), finstDetails);
		}
		
	}
	
	private class FinancialInstrumentDetails
	{
		/** The  */
		private Integer finstId;
		
		/** The  */
		private String symbol;

		/** The  */
		private String morningstarId;

		/** The  */
		private String cusip;

		/** The  */
		private String type;

		/** The  */
		private String name;

		/** Default constructor */
		public FinancialInstrumentDetails()
		{
			super();
		}

		/**
		 * @return
		 */
		public Integer getFinstId()
		{
			return finstId;
		}

		/**
		 * @return
		 */
		public String getSymbol() 
		{
			return symbol;
		}

		/**
		 * @return
		 */
		public String getMorningstarId() 
		{
			return morningstarId;
		}

		/**
		 * @return
		 */
		public String getCusip() 
		{
			return cusip;
		}

		/**
		 * @return
		 */
		public String getType() 
		{
			return type;
		}

		/**
		 * @return
		 */
		public String getName() 
		{
			return name;
		}

		/**
		 * @param symbol
		 */
		public void setSymbol(String symbol) 
		{
			this.symbol = symbol;
		}

		/**
		 * @param finstId
		 */
		public void setFinstId(Integer finstId) {
			this.finstId = finstId;
		}

		/**
		 * @param morningstarId
		 */
		public void setMorningstarId(String morningstarId) 
		{
			this.morningstarId = morningstarId;
		}

		/**
		 * @param cusip
		 */
		public void setCusip(String cusip) 
		{
			this.cusip = cusip;
		}

		/**
		 * @param type
		 */
		public void setType(String type) 
		{
			this.type = type;
		}

		/**
		 * @param name
		 */
		public void setName(String name) 
		{
			this.name = name;
		}
	
	}
}
