/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/**
 * This is a utility class that creates and maintains database connectivity methods
 *
 * @author a623549
 *
 */
public class DatabaseConfigUtil
{
	/**
	 * 
	 * Creates a Hikari Data Source with a SQLite configuration
	 * This data source holds the connection to the SQLite database.
	 *
	 * @return HikariDataSource
	 */
	public static HikariDataSource getSqliteDataSource()
	{
		HikariConfig config = new HikariConfig();
		config.setDriverClassName(DatabaseConstants.SQLITE_DRIVER_CLASS_NAME);
		config.setJdbcUrl(DatabaseConstants.SQLITE_JDBC_URL_TEST_DATA);
		
		HikariDataSource ds = new HikariDataSource(config);
		
		return ds;
	}
	public static HikariDataSource getIsolatedDataSource(String dbFilePath) {
		HikariConfig config = new HikariConfig();
		config.setJdbcUrl("jdbc:sqlite:" + dbFilePath);
		config.setDriverClassName(DatabaseConstants.SQLITE_DRIVER_CLASS_NAME);

		HikariDataSource ds = new HikariDataSource(config);

		return ds;
	}
}
