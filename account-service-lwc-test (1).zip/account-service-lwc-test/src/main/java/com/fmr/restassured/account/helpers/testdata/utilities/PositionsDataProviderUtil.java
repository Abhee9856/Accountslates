/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.ast.platform.account.domain.SourceSystem;
import com.fmr.restassured.account.helpers.testdata.dto.AccountPositionsTestData;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.testng.annotations.DataProvider;

/**
 * This utility class contains methods pertaining to the implementation of DataProvider logic for handling multiple
 * data sets for positions testing.
 *
 * @author a560878
 */
public class PositionsDataProviderUtil
{

	/** The AccountPositionsTestData DTO */
	private static List<List<AccountPositionsTestData>> positionsTestData = null;

	/** Instance to the test data utility class */
	private static final TestDataUtil testDataUtil = new TestDataUtil();

	
	/**
	 * Data Provider method for pulling multiple positions for Fullview Accounts
	 *
	 * @return Object[][] the positions data set for Fullview Accounts
	 */
	@DataProvider(name = "getFullviewPositionsData")
	public static Object[][] getFullviewPositionsData()
	{
		return getData(SourceSystem.FULLVIEW.name());
	}
	
	/**
	 * Data Provider method for pulling multiple positions for Retail Accounts
	 *
	 * @return Object[][] the positions data set for Retail Accounts
	 */
	@DataProvider(name = "getRetailPositionsData")
	public static Object[][] getRetailPositionsData()
	{
		return getData(SourceSystem.RETAIL.name());
	}
	
	/**
	 * Data Provider method for pulling multiple positions for FILI Accounts
	 *
	 * @return Object[][] the positions data set for FILI Accounts
	 */
	@DataProvider(name = "getFiliPositionsData")
	public static Object[][] getFiliPositionsData()
	{
		return getData(SourceSystem.FILI.name());
	}
	
	/**
	 * Gets use cases based on the source system provided.
	 *
	 * @param sourceSystem
	 * 			the source system
	 * @return the test data
	 */
	private static Object[][] getData(final String sourceSystem)
	{
		positionsTestData = new ArrayList<>();
		testDataUtil.getPositionsTestData(sourceSystem).stream().filter(Objects::nonNull)
			.forEach(data -> {
			        final List<AccountPositionsTestData> dataList = new ArrayList<>();
			        dataList.add(data);
			        positionsTestData.add(dataList);
		        });

		return positionsTestData.stream().map(List::toArray).toArray(Object[][]::new);
	}
}
