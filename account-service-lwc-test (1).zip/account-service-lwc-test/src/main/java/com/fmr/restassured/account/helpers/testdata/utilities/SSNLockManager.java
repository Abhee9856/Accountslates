/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Manages thred-safe locking mechanisam for ssn-based operations. This class provides synchronization capabiluties to
 * prevent concurrent access to resources assosicated with specific SSNs.
 */
public class SSNLockManager
{

	//Thread-safe map to store locks for each ssn
	private static final ConcurrentHashMap<String, ReentrantLock> lockMap = new ConcurrentHashMap<>();

	//Maximum time to wait for acquiring a lock in seconds
	private static final long LOCK_TIMEOUT_SECONDS = 30;

	/**
	 * Attempts to acquire a lock for the specified SSN. If a lock doesn't exist for the SSN, creates a new fair
	 * ReentrantLock. waits up to LOCK_TIMEOUT_SECONDS to acquire the lock.
	 *
	 * @param ssn
	 * @return true if lock was acquired, false if timeout or interruption occured
	 */
	public static boolean lock(String ssn)
	{
		ReentrantLock lock = lockMap.computeIfAbsent(ssn, k -> new ReentrantLock(true));
		try
		{
			return lock.tryLock(LOCK_TIMEOUT_SECONDS, TimeUnit.SECONDS);

		}
		catch (InterruptedException e)
		{
			Thread.currentThread().interrupt();
			return false;
		}
	}

	/**
	 * Releases the lock for the specified SSN if it exists and is held by the current thread. Also removes the lock
	 * from the map after releasing.
	 *
	 * @param ssn
	 * 		The SSN whose lock should be released
	 */
	public static void unlock(String ssn)
	{
		ReentrantLock lock = lockMap.get(ssn);
		if (lock != null && lock.isHeldByCurrentThread())
		{
			lock.unlock();
			lockMap.remove(ssn);
		}
	}

	/**
	 * Removes all lccks from the lock map. Used for cleanup purposes
	 */
	public static void clearLocks()
	{
		lockMap.clear();
	}

}