/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.dto;

/**
 * @author a608077
 */
public class AccountGrantsTestData {


    private String entityId = null;
    private String entityTypeCode = null;
    private String workplaceClientId = null;
    private float fmvPrice;

    private String ppid;

    private String source = "MANUAL";

    private String prospectId;

    private String mid;

    private String sid;

    private String ssn;

    private String scenarioId;
    private String productCode;
    private String categoryCode;

    private String accId;
    private String accId2;

    private String accNumber;
    private String accNumber2;

    private String partPid;

    private String mnemonic;

    private String stockOptionId;
    private String stockOptionId2;

    private String grantType;
    private String grantType2;

    private int sequence;
    private int sequence2;

    private String grantDate;
    private String grantDate2;

    /**
     * @return the getGrantDate2
     */
    public String getGrantDate2() {
        return grantDate2;
    }

    /**
     * @param grantDate2 the grantDate2 to set
     */
    public void setGrantDate2(String grantDate2) {
        this.grantDate2 = grantDate2;
    }

    /**
     * @return the accId2
     */
    public String getAccId2() {
        return accId2;
    }

    /**
     * @param accId2 the accId2 to set
     */
    public void setAccId2(String accId2) {
        this.accId2 = accId2;
    }

    /**
     * @return the sequence
     */
    public final int getSequence() {
        return sequence;
    }


    /**
     * @param sequence the sequence to set
     */
    public final void setSequence(int sequence) {
        this.sequence = sequence;
    }

    /**
     * @return the sequence2
     */
    public int getSequence2() {
        return sequence2;
    }

    /**
     * @param sequence2 the sequence2 to set
     */
    public void setSequence2(int sequence2) {
        this.sequence2 = sequence2;
    }

    /**
     * @return the grantDate
     */
    public final String getGrantDate() {
        return grantDate;
    }

    /**
     * @param grantDate the grantDate to set
     */
    public final void setGrantDate(String grantDate) {
        this.grantDate = grantDate;
    }

    /**
     * @return the grantType2
     */
    public String getGrantType2() {
        return grantType2;
    }

    /**
     * @param grantType2 the grantType2 to set
     */
    public void setGrantType2(String grantType2) {
        this.grantType2 = grantType2;
    }

    /**
     * @return the partPid
     */
    public final String getPartPid() {
        return partPid;
    }

    /**
     * @param partPid the partPid to set
     */
    public final void setPartPid(String partPid) {
        this.partPid = partPid;
    }

    /**
     * @return the stockOptionId
     */
    public final String getStockOptionId() {
        return stockOptionId;
    }

    /**
     * @param stockOptionId the stockOptionId to set
     */
    public final void setStockOptionId(String stockOptionId) {
        this.stockOptionId = stockOptionId;
    }

    /**
     * @return the stockOptionId2
     */
    public String getStockOptionId2() {
        return stockOptionId2;
    }

    /**
     * @param stockOptionId2 the stockOptionId2 to set
     */
    public void setStockOptionId2(String stockOptionId2) {
        this.stockOptionId2 = stockOptionId2;
    }

    /**
     * @return the grantType
     */
    public final String getGrantType() {
        return grantType;
    }


    /**
     * @param grantType the grantType to set
     */
    public final void setGrantType(String grantType) {
        this.grantType = grantType;
    }

    /**
     * @return the accId
     */
    public String getAccId() {
        return accId;
    }

    /**
     * @param accId the accId to set
     */
    public void setAccId(String accId) {
        this.accId = accId;
    }

    /**
     * @return the ppid
     */
    public String getPpid() {
        return ppid;
    }

    /**
     * @param ppid the ppid to set
     */
    public void setPpid(String ppid) {
        this.ppid = ppid;
    }

    /**
     * @return the source
     */
    public String getSource() {
        return source;
    }

    /**
     * @param source the source to set
     */
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * @return the prospectId
     */
    public String getProspectId() {
        return prospectId;
    }

    /**
     * @param prospectId the prospectId to set
     */
    public void setProspectId(String prospectId) {
        this.prospectId = prospectId;
    }

    /**
     * @return the sid
     */
    public String getSid() {
        return sid;
    }

    /**
     * @param sid the sid to set
     */
    public void setSid(String sid) {
        this.sid = sid;
    }

    /**
     * @return the ssn
     */
    public String getSsn() {
        return ssn;
    }

    /**
     * @param ssn the ssn to set
     */
    public void setSsn(String ssn) {
        this.ssn = ssn;
    }


    /**
     * @return the productCode
     */
    public String getProductCode() {
        return productCode;
    }


    /**
     * @param productCode the productCode to set
     */
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }


    /**
     * @return the categoryCode
     */
    public String getCategoryCode() {
        return categoryCode;
    }


    /**
     * @param categoryCode the categoryCode to set
     */
    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode;
    }

    /**
     * @return the mid
     */
    public String getMid() {
        return mid;
    }

    /**
     * @param mid the mid to set
     */
    public void setMid(String mid) {
        this.mid = mid;
    }

    /**
     * @return the accNumber
     */
    public String getAccNumber() {
        return accNumber;
    }

    /**
     * @param accNumber the accNumber to set
     */
    public void setAccNumber(String accNumber) {
        this.accNumber = accNumber;
    }

    /**
     * @return the accNumber2
     */
    public String getAccNumber2() {
        return accNumber2;
    }

    /**
     * @param accNumber2 the accNumber2 to set
     */
    public void setAccNumber2(String accNumber2) {
        this.accNumber2 = accNumber2;
    }

    /**
     * @return the mnemonic
     */
    public String getMnemonic() {
        return mnemonic;
    }

    /**
     * @param mnemonic the mnemonic to set
     */
    public void setMnemonic(String mnemonic) {
        this.mnemonic = mnemonic;
    }


    /**
     * @return the workplaceClientId
     */
    public final String getWorkplaceClientId() {
        return workplaceClientId;
    }


    /**
     * @param workplaceClientId the workplaceClientId to set
     */
    public final void setWorkplaceClientId(String workplaceClientId) {
        this.workplaceClientId = workplaceClientId;
    }


    /**
     * @return the entityId
     */
    public final String getEntityId() {
        return entityId;
    }


    /**
     * @param entityId the entityId to set
     */
    public final void setEntityId(String entityId) {
        this.entityId = entityId;
    }


    /**
     * @return the entityTypeCode
     */
    public final String getEntityTypeCode() {
        return entityTypeCode;
    }


    /**
     * @param entityTypeCode the entityTypeCode to set
     */
    public final void setEntityTypeCode(String entityTypeCode) {
        this.entityTypeCode = entityTypeCode;
    }

    /**
     * @return the scenarioId
     */
    public final String getScenarioId() {
        return scenarioId;
    }


    /**
     * @param scenarioId the scenarioId to set
     */
    public final void setScenarioId(String scenarioId) {
        this.scenarioId = scenarioId;
    }

}
