/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.pap.restassured.database.module.SQLiteTestData;
import com.fmr.restassured.account.database.DatabaseConstants;

import java.util.List;

import com.fmr.restassured.account.helpers.testdata.constants.TestDataConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountGrantsTestDataOneGrant;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * This class contains utility methods pertaining to test data contained in the SQLite database for accounts_grants_test_data.db
 *
 * @author a608077
 */
public class GrantsTestDataUtil extends SQLiteTestData {

    private static final Logger LOGGER = LogManager.getLogger(TestDataUtil.class);

    private static final String SQLITE_PROPERTIES_FILE = "/sql/SQLiteSQL.properties";

    public GrantsTestDataUtil() {
        super(TestDataConstants.GRANTS_TEST_DATA_LOCATION);
    }


    /**
     * This method queries SQLite for the records that are in the onegrant_onevest table
     *
     * @param tableName name of the table in SQLite
     * @param numOfRows number of rows of data
     * @param testName name of the test in SQLite
     * @return AccountGrantsTestDataOneGrant records (as list)
     */
    public List<AccountGrantsTestDataOneGrant> getGrantsOneGrantAccountData(final String tableName, final int numOfRows, final String testName) {
        return this.getSQLiteTestData(tableName, numOfRows, AccountGrantsTestDataOneGrant.class, testName, DatabaseConstants.ONE_GRANT_ONE_VEST);
    }
}
