/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.ast.platform.account.domain.SourceSystem;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRelationsTestData;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.testng.annotations.DataProvider;

/**
 * This utility class contains methods pertaining to the implementation of DataProvider logic for handling multiple
 * data sets for relations testing.
 *
 * @author a601767
 */
public class RelationsDataProviderUtil
{

	/** The AccountRelationsTestData DTO */
	private static List<List<AccountRelationsTestData>> relationsTestData = null;

	/** Instance to the test data utility class */
	private static final TestDataUtil testDataUtil = new TestDataUtil();


	/**
	 * Data Provider method for pulling multiple Relations for Fullview Accounts
	 *
	 * @return Object[][] the Relations data set for Fullview Accounts
	 */
	@DataProvider(name = "getFullviewRelationsData")
	public static Object[][] getFullviewRelationsData()
	{
		return getData(SourceSystem.FULLVIEW.name());
	}

	/**
	 * Data Provider method for pulling multiple Relations for Retail Accounts
	 *
	 * @return Object[][] the Relations data set for Retail Accounts
	 */
	@DataProvider(name = "getRetailRelationsData")
	public static Object[][] getRetailRelationsData()
	{
		return getData(SourceSystem.RETAIL.name());
	}

	/**
	 * Data Provider method for pulling multiple Relations for FILI Accounts
	 *
	 * @return Object[][] the Relations data set for FILI Accounts
	 */
	@DataProvider(name = "getFiliRelationsData")
	public static Object[][] getFiliRelationsData()
	{
		return getData(SourceSystem.FILI.name());
	}

	/**
	 * Data Provider method for pulling multiple Relations for Manual Accounts
	 *
	 * @return Object[][] the Relations data set for Retail Accounts
	 */
	@DataProvider(name = "getManualRelationsData")
	public static Object[][] getManualRelationsData()
	{
		return getData(SourceSystem.MANUAL.name());
	}

	/**
	 * Data Provider method for pulling multiple Relations for Workplace Accounts
	 *
	 * @return Object[][] the Relations data set for Retail Accounts
	 */
	@DataProvider(name = "getWorkplaceRelationsData")
	public static Object[][] getWorkplaceRelationsData()
	{
		return getData(SourceSystem.WORKPLACE.name());
	}
	/**
	 * Gets use cases based on the source system provided.
	 *
	 * @param sourceSystem
	 * 			the source system
	 * @return the test data
	 */
	private static Object[][] getData(final String sourceSystem)
	{
		relationsTestData = new ArrayList<>();
		testDataUtil.getRelationsTestData(sourceSystem).stream().filter(Objects::nonNull)
				.forEach(data -> {
					final List<AccountRelationsTestData> dataList = new ArrayList<>();
					dataList.add(data);
					relationsTestData.add(dataList);
				});

		return relationsTestData.stream().map(List::toArray).toArray(Object[][]::new);
	}

}
