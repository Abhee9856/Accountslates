/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.v1.composite.crud.retail;


import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.Matchers.*;

/**
 * Tests for Preserving displayName when a Target Account converts to Real Account
 *
 * @author a631781
 * Updated by a608077 for testing deletion of a transfer once the target accunt is converted to real account(PFCP-14831)
 * Updated by a631781 to validate irrevocableTrust and trustType.
 * Updated by a608077 on 09/23/2024 to include managed flag(PFCP-17274)
 */
@Test(groups = {
        Tags.RETAIL,
        Tags.COMPOSITE,
        Tags.V1,
        Tags.TARGET_ACCOUNT})
public class Retail_Composite_TargetAccount_to_RealAccount extends PAPBaseServiceTest {

    protected Retail_Composite_TargetAccount_to_RealAccount() {
        super(Services.Account);
    }

    //Context
    private VelocityContext context;

    int startYear = ZonedDateTime.now().plusYears(1).getYear();

    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    private final float fundingAccountAmount = 5.55f;

    private static final String isProductSuitable = "true";

    private AccountsCommonTestData accountsCommonTestData;
    private TestDataUtil testDataUtil;
    private static final String LOG_TRACKING_ID = Retail_Composite_TargetAccount_to_RealAccount.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String displayNameTargetAct = "TargetAccount DisplayName for Composite V1";

    private static String targetAccountId;

    private static final String TRUA = "TRUA";

    //Financial Instrument IDs and their symbols
    private FinancialInstrumentIds finstIds;

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init() {
        String oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();

        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_contributions_CRUD_RK_Retail_Principal_104", oAuth);
        String mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(mid);

        //Data setup
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("contribFreq", "YEARLY");
        accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        accountsCommonTestData.set("contribAmount", "6000.0");
        accountsCommonTestData.set("updatedContribAmount", "500.0");
        accountsCommonTestData.set("withdrawAmount", "500.0");
        accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
        accountsCommonTestData.set("withdrawFreq", "YEARLY");
        accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        //Resolve finstIds
        finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("mid", accountsCommonTestData.getMid());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", "RETAIL");
    }

    /**
     * Get retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
                response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode) {
            Assert.assertEquals(dssResultCode, false);
        }

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
        accountsCommonTestData.setAccountNumber2(response.path("accountList[1].accountId.accountNumber"));
        accountsCommonTestData.setMnemonic2(response.path("accountList[1].regCode.mnemonic"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void getCompositeAccount() {
        // Exclude external data
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());

    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getCompositeAccount"})
    public void createCompositeAccount() {
        // Generate request body
        String accNum = accountsCommonTestData.getAccountNumber1();
        String acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
        context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", finstIds.getFinstId("GBOND"));
        context.put("GCASH", finstIds.getFinstId("GCASH"));
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accNum);
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("contribValue", accountsCommonTestData.get("contribAmount"));
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("_type", AccountConstants.RETAIL_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.RETAIL_ACCOUNT_DETAILS);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

        //Save account number and ID
        accountsCommonTestData.setAccountId1(response.path(acctRoot + "account.accountId.id"));
    }

    /**
     * Create target account
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void createTargetAccount() {
        // Generate request body
        context.put("targetAccountNumber", accountsCommonTestData.getAccountNumber2());
        context.put("targetAccountSourceSystem", accountsCommonTestData.getSourceSystem1());
        context.put("targetAccountPpid", accountsCommonTestData.getPpid());
        context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("fundingAccountValue", String.valueOf(fundingAccountAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("category", "INVESTOR_SELECTED_STRATEGY");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
        context.put("riskTolerance", "8");
        context.put("withdrawalNeeds", "TIME_TO_TIME_WITHDRAWAL_LESS_THAN_EQUAL_TO_6");
        context.put("isProductSuitable", isProductSuitable);
        float unknownAmount = 20.0f;
        context.put("unknownAmount", String.valueOf(unknownAmount));
        context.put("targetDisplayName", displayNameTargetAct);
        context.put("irrevocableTrust", "true");
        context.put("trustType", TRUA);
        context.put("assetAllocation", "0.05");
        context.put("managed", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value",
                        equalTo(fundingAccountAmount),
                        "targetAccounts[0].accountId.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()),
                        "targetAccounts[0].fundingAccounts[0].accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        "targetAccounts[0].accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber2()),
                        "targetAccounts[0].displayName", equalTo(displayNameTargetAct),
                        "targetAccounts[0].irrevocableTrust", equalTo(true),
                        "targetAccounts[0].trustType", equalTo(TRUA),
                        "targetAccounts[0].equityPercent", equalTo(0.5f),
                        "targetAccounts[0].complementaryAdjustmentOption",
                        equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"),
                        "targetAccounts[0].isProductSuitable", equalTo(Boolean.valueOf(isProductSuitable)),
                        "targetAccounts[0].managed", equalTo(true),
                        "targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount),
                        "targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
                        equalTo("TIME_TO_TIME_WITHDRAWAL_LESS_THAN_EQUAL_TO_6"),
                        "targetAccounts[0].targetAssetMixes[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"),
                        "targetAccounts[0].assetAllocation.allocation[0].netPercentage.value", equalTo(0.05f),
                        "targetAccounts[0].assetAllocation.allocation[0]", notNullValue());
        targetAccountId = response.path("targetAccounts[0].accountId.id");

    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void getCompositeAccountAfterCreate() {
        // Exclude external data sources
        context.put("externalDataSources", "true");
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId
                                + "'}.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber2()),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.accountId.id",
                        equalTo(targetAccountId),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.displayName",
                        equalTo(displayNameTargetAct),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId
                                + "'}.sourceMarketValue.amount.value",
                        equalTo(fundingAccountAmount),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId
                                + "'}.accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId
                                + "'}.fundingAccounts[0].accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId
                                + "'}.fundingAccounts[0].amount.value",
                        equalTo(fundingAccountAmount),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.irrevocableTrust",
                        equalTo(true),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.trustType", equalTo(TRUA),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.managed", equalTo(true));
    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterCreate")
    public void verifyCompositeAccountWithEDSasFalse() {
        context.put("includeFundTransferDetails", true);
        // Exclude external data sources
        context.put("externalDataSources", "false");
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts.find{it.account.accountId.id=='" + targetAccountId
                                + "'}.account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber2()),
                        "accounts.find{it.account.accountId.id=='" + targetAccountId
                                + "'}.account.displayName", equalTo(displayNameTargetAct))
                .body("transfers", Matchers.empty());
    }

    /**
     * Validate irrevocableTrust and trustType when Target Account is converted to Real account and EEDS is true.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "verifyCompositeAccountWithEDSasFalse")
    public void getCompositeAccountAfterTAtoRWithEDSTrue() {
        context.put("includeFundTransferDetails", true);
        // Exclude external data sources
        context.put("externalDataSources", true);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts.find{it.account.accountId.id=='" + targetAccountId
                                + "'}.account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber2()),
                        "accounts.find{it.account.accountId.id=='" + targetAccountId
                                + "'}.account.displayName", equalTo(displayNameTargetAct),
                        "accounts.find{it.account.accountId.id=='" + targetAccountId + "'}.details.irrevocableTrust",
                        equalTo(true),
                        "accounts.find{it.account.accountId.id=='" + targetAccountId + "'}.details.trustType", equalTo(TRUA),
                        "accounts.find{it.account.accountId.id=='" + targetAccountId + "'}.details.isManaged", equalTo(true));
    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterTAtoRWithEDSTrue")
    public void deleteCompositeAccount() {
        // Exclude external data sources
        context.put("externalDataSources", "true");
        // Generate request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber2());
        context.put("accId", targetAccountId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void deleteSecondCompositeAccount() {
        // Exclude external data sources
        context.put("externalDataSources", "true");
        // Generate request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("accId", accountsCommonTestData.getAccountId1());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

    }

    /**
     * Call delete and confirm that no accounts come back in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void getCompositeAccountAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}