/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.suitability.crud.manual;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.MatcherAssert.assertThat;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsSuitabilityPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.SuitabilityDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountSuitabilityTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

/**
 * Tests CRUD operations for Account Suitability V1 for Manual accounts owned by the Principal.
 *
 * @author a560878
 * Test flow:
 * 1. Create Principal
 * 2. Create then get Manual account
 * 3. Create then get account suitability for the account created
 * 4. Update then get account suitability created in step 4
 * 5. Delete the account then get accountsuitability to validate manual accounts and suitabililty were deleted
 * 6. SQLite data includes all data  and partial data scenarios
 * <p>
 * Updated by a608077 on 12/06/2021 to include: Changes for account level preferences(PFCP-6920)
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.SUITABILITY,
        Tags.V1,
        Tags.CRITICAL,
        "PFCP-3081"})
public class Manual_Suitability_CRUD_v1 extends PAPBaseServiceTest {

    protected Manual_Suitability_CRUD_v1() {
        super(Services.Account);
    }


    private String mid;

    private String ppid;

    private String mnemonic = "IRA";

    private String accountNumber;

    private String accountId;

    private String sourceSystem = "MANUAL";

    private String displayName = "Rest Assured Test Manual Account";

    private float value = 500;

    private String asOfDate = "2020-10-31";

    private VelocityContext context;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Manual_Suitability_CRUD_v1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;
    private static AccountsCommonTestData accountsCommonTestData;

    //Start and End years for accountPreferencesIA - both should be greater than the current year.
    int startYear = ZonedDateTime.now().plusYears(1).getYear();
    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {

        final String oAuth = AccountUtil.getOauthToken();
        // Data setup
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_suitability_CRUD_Manual", oAuth);

        mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate request context with user IDs
        context = new VelocityContext();

        context.put("mid", mid);
        context.put("ppid", ppid);
        context.put("source", "MANUAL");


    }

    /**
     * This is the test flow. It iterates through the data provider, performing CRUD operations for each use case.
     *
     * @param data the test cases
     */
    @Test(dataProvider = "getManualSuitabilityData", dataProviderClass = SuitabilityDataProviderUtil.class)
    public void performCrudOperations(final AccountSuitabilityTestData data) {
        this.createManualAccount();
        this.getManualAccountAfterCreate();
        this.createAccountSuitability(data);
        this.getSuitabilityAfterCreate();
        this.updateAccountSuitability(data);
        this.getSuitabilityAfterUpdate();
        this.deleteAccountSuitability();
        this.getSuitabilityAfterDelete();
    }

	/**
	 * Create the Retail account. Save the account id.
	 *
	 * Version V1
	 */

    private void createManualAccount() {
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        String institutionName = "AA";
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid), "accountList[0].regCode.mnemonic", equalTo(mnemonic));
        // "accountList[0].accountId.accountNumber", equalTo(accountNumber));

        // Gets and saves the CFP account ID
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        accountId = response.path("accountList[0].accountId.id");
        context.put("accId", accountId);
        context.put("accountNumber", accountNumber);
    }

    /**
     * Validate the account was created correctly.
     */

    private void getManualAccountAfterCreate() {
        // Generate request body
        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid), "accountList[0].regCode.mnemonic", equalTo(mnemonic),
                        "accountList[0].accountId.accountNumber", equalTo(accountNumber), "accountList[0].accountId.id", equalTo(accountId));

    }

    /**
     * Create the account suitability.
     */
    private void createAccountSuitability(final AccountSuitabilityTestData data) {
        // Generate request body
        context.put("investObj_Txt", data.getInvestObjTxt());
        context.put("investObj_Id", data.getInvestObjId());
        context.put("tam_TotalEqty", data.getTamTotalEqty());
        context.put("tam_DomEqty", data.getTamDomEqty());
        context.put("tam_ForeignEqty", data.getTamForeignEqty());
        context.put("tam_Bond", data.getTamBond());
        context.put("tam_Cash", data.getTamCash());
        context.put("tam_lowEqtyPct", data.getTamLowEqtyPct());
        context.put("tam_upEqtyPct", data.getTamUpEqtyPct());
        context.put("tam_assetAlloc_Id", data.getTamAssetAllocId());
        context.put("tam_context", data.getTamContext());
        context.put("investPurp_Txt", data.getInvestPurpTxt());
        context.put("investPurp_Id", data.getInvestPurpId());
        context.put("investKnow_Txt", data.getInvestKnowTxt());
        context.put("investKnow_Id", data.getInvestKnowId());
        context.put("annualIncRng_Txt", data.getAnnualIncRngTxt());
        context.put("annualIncRng_Id", data.getAnnualIncRngId());
        context.put("liqNWRng_Txt", data.getLiqNWRngTxt());
        context.put("liqNWRng_Id", data.getLiqNWRngId());
        context.put("netWorthRng_Txt", data.getNetWorthRngTxt());
        context.put("netWorthRng_Id", data.getNetWorthRngId());
        context.put("taxBrktRng_Txt", data.getTaxBrktRngTxt());
        context.put("taxBrktRng_Id", data.getTaxBrktRngId());
        context.put("essExpRng_Txt", data.getEssExpRngTxt());
        context.put("essExpRng_Id", data.getEssExpRngId());
        context.put("spendLikeRng_Txt", data.getSpendLikeRngTxt());
        context.put("spendLikeRng_Id", data.getSpendLikeRngId());
        context.put("invesTimeHrzn_Txt", data.getInvesTimeHrznTxt());
        context.put("invesTimeHrzn_Id", data.getInvesTimeHrznId());
        context.put("riskTolerance", "1");
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_CREATE_TEMPLATE_V1)).log()
                .ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.CREATE_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid), "accountSuitability", not(empty()));

        // Assert on Investment Objective if present
        if (data.getInvestObjTxt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix.name", equalTo(data.getInvestObjTxt()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix.context", equalTo(data.getTamContext()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.id", equalTo(data.getInvestObjId()));

        }

        // Assert on Investment Purpose if present
        if (data.getInvestPurpTxt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentPurpose", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentPurpose.values[0].value", equalTo(data.getInvestPurpTxt()));
            Integer investPurpId =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentPurpose.values[0].id");
            assertThat(investPurpId.toString(), equalTo(data.getInvestPurpId()));

        }

        // Assert on Investment Knowledge if present
        if (data.getInvestKnowTxt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentKnowledge", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentKnowledge.values[0].value", equalTo(data.getInvestKnowTxt()));
            Integer investKnowId =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentKnowledge.values[0].id");
            assertThat(investKnowId.toString(), equalTo(data.getInvestKnowId()));

        }

        // Assert on Liquid Net Worth Range if present
        if (data.getLiqNWRngTxt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.liquidNetworthRange", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.liquidNetworthRange.values[0].value", equalTo(data.getLiqNWRngTxt()));

            Integer ligNWRng =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.liquidNetworthRange.values[0].id");
            assertThat(ligNWRng.toString(), equalTo(data.getLiqNWRngId()));

        }

        // Assert on Net Worth Range if present
        if (data.getNetWorthRngTxt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.networthRange", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.networthRange.values[0].value", equalTo(data.getNetWorthRngTxt()));
            Integer netWorthRng = response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.networthRange.values[0].id");
            assertThat(netWorthRng.toString(), equalTo(data.getNetWorthRngId()));

        }

        // Assert on Tax Bracket Range if present
        if (data.getTaxBrktRngTxt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.taxBracketRange", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.taxBracketRange.values[0].value", equalTo(data.getTaxBrktRngTxt()));
            Integer taxBrktRng =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.taxBracketRange.values[0].id");
            assertThat(taxBrktRng.toString(), equalTo(data.getTaxBrktRngId()));

        }

        // Assert on Essential Expense Range if present
        if (data.getEssExpRngTxt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.essentialExpensesRange", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.essentialExpensesRange.values[0].value", equalTo(data.getEssExpRngTxt()));
            Integer essExpRng =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.essentialExpensesRange.values[0].id");
            assertThat(essExpRng.toString(), equalTo(data.getEssExpRngId()));

        }

        // Assert on Spending Likelihood Range if present
        if (data.getSpendLikeRngTxt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.spendingLikelihoodRange", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.spendingLikelihoodRange.values[0].value",
                    equalTo(data.getSpendLikeRngTxt()));
            Integer spendLikeRng =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.spendingLikelihoodRange.values[0].id");
            assertThat(spendLikeRng.toString(), equalTo(data.getSpendLikeRngId()));

        }

        // Assert on Investment Time Horizon if present
        if (data.getInvesTimeHrznTxt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentTimeHorizon", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentTimeHorizon.values[0].value", equalTo(data.getInvesTimeHrznTxt()));
            Integer timeHorizon =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentTimeHorizon.values[0].id");
            assertThat(timeHorizon.toString(), equalTo(data.getInvesTimeHrznId()));

        }
        // Assert on accountPreferencesIA
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.accountPreferencesIA", not(empty()))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.accountPreferencesIA.riskTolerance", equalTo(1))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.accountPreferencesIA.withdrawalStartYear", equalTo(startYear))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear));

    }

    /**
     * Validate the suitability information just created.
     */
    private void getSuitabilityAfterCreate() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true));

    }

    /**
     * Update the suitability just created.
     */
    private void updateAccountSuitability(final AccountSuitabilityTestData data) {
        // Generate request body
        context.put("investObj_Txt", data.getInvestObjTxtUpdt());
        context.put("investObj_Id", data.getInvestObjIdUpdt());
        context.put("tam_TotalEqty", data.getTamTotalEqtyUpdt());
        context.put("tam_DomEqty", data.getTamDomEqtyUpdt());
        context.put("tam_ForeignEqty", data.getTamForeignEqtyUpdt());
        context.put("tam_Bond", data.getTamBondUpdt());
        context.put("tam_Cash", data.getTamCashUpdt());
        context.put("tam_lowEqtyPct", data.getTamLowEqtyPctUpdt());
        context.put("tam_upEqtyPct", data.getTamUpEqtyPctUpdt());
        context.put("tam_assetAlloc_Id", data.getTamAssetAllocIdUpdt());
        context.put("tam_context", data.getTamContextUpdt());
        context.put("investPurp_Txt", data.getInvestPurpTxtUpdt());
        context.put("investPurp_Id", data.getInvestPurpIdUpdt());
        context.put("investKnow_Txt", data.getInvestKnowTxtUpdt());
        context.put("investKnow_Id", data.getInvestKnowIdUpdt());
        context.put("annualIncRng_Txt", data.getAnnualIncRngTxtUpdt());
        context.put("annualIncRng_Id", data.getAnnualIncRngIdUpdt());
        context.put("liqNWRng_Txt", data.getLiqNWRngTxtUpdt());
        context.put("liqNWRng_Id", data.getLiqNWRngIdUpdt());
        context.put("netWorthRng_Txt", data.getNetWorthRngTxtUpdt());
        context.put("netWorthRng_Id", data.getNetWorthRngIdUpdt());
        context.put("taxBrktRng_Txt", data.getTaxBrktRngTxtUpdt());
        context.put("taxBrktRng_Id", data.getTaxBrktRngIdUpdt());
        context.put("essExpRng_Txt", data.getEssExpRngTxtUpdt());
        context.put("essExpRng_Id", data.getEssExpRngIdUpdt());
        context.put("spendLikeRng_Txt", data.getSpendLikeRngTxtUpdt());
        context.put("spendLikeRng_Id", data.getSpendLikeRngIdUpdt());
        context.put("invesTimeHrzn_Txt", data.getInvesTimeHrznTxtUpdt());
        context.put("invesTimeHrzn_Id", data.getInvesTimeHrznIdUpdt());
        context.put("riskTolerance", "2");
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_UPDATE_TEMPLATE_V1));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.UPDATE_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true));

        // Assert on Investment Objective if present
        if (data.getInvestObjTxtUpdt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix.name",
                    equalTo(data.getInvestObjTxtUpdt()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix.context",
                    equalTo(data.getTamContextUpdt()), "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.id",
                    equalTo(data.getInvestObjIdUpdt()));

        }

        // Assert on Investment Purpose if present
        if (data.getInvestPurpTxtUpdt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentPurpose", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentPurpose.values[0].value", equalTo(data.getInvestPurpTxtUpdt()));
            Integer investPurpId =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentPurpose.values[0].id");
            assertThat(investPurpId.toString(), equalTo(data.getInvestPurpIdUpdt()));

        }

        // Assert on Investment Knowledge if present
        if (data.getInvestKnowTxtUpdt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentKnowledge", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentKnowledge.values[0].value", equalTo(data.getInvestKnowTxtUpdt()));
            Integer investKnowId =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentKnowledge.values[0].id");
            assertThat(investKnowId.toString(), equalTo(data.getInvestKnowIdUpdt()));

        }

        // Assert on Liquid Net Worth Range if present
        if (data.getLiqNWRngTxtUpdt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.liquidNetworthRange", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.liquidNetworthRange.values[0].value", equalTo(data.getLiqNWRngTxtUpdt()));

            Integer ligNWRng =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.liquidNetworthRange.values[0].id");
            assertThat(ligNWRng.toString(), equalTo(data.getLiqNWRngIdUpdt()));

        }

        // Assert on Net Worth Range if present
        if (data.getNetWorthRngTxtUpdt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.networthRange", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.networthRange.values[0].value", equalTo(data.getNetWorthRngTxtUpdt()));
            Integer netWorthRng = response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.networthRange.values[0].id");
            assertThat(netWorthRng.toString(), equalTo(data.getNetWorthRngIdUpdt()));

        }

        // Assert on Tax Bracket Range if present
        if (data.getTaxBrktRngTxtUpdt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.taxBracketRange", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.taxBracketRange.values[0].value", equalTo(data.getTaxBrktRngTxtUpdt()));
            Integer taxBrktRng =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.taxBracketRange.values[0].id");
            assertThat(taxBrktRng.toString(), equalTo(data.getTaxBrktRngIdUpdt()));

        }

        // Assert on Essential Expense Range if present
        if (data.getEssExpRngTxtUpdt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.essentialExpensesRange", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.essentialExpensesRange.values[0].value",
                    equalTo(data.getEssExpRngTxtUpdt()));
            Integer essExpRng =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.essentialExpensesRange.values[0].id");
            assertThat(essExpRng.toString(), equalTo(data.getEssExpRngIdUpdt()));

        }

        // Assert on Spending Likelihood Range if present
        if (data.getSpendLikeRngTxtUpdt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.spendingLikelihoodRange", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.spendingLikelihoodRange.values[0].value",
                    equalTo(data.getSpendLikeRngTxtUpdt()));
            Integer spendLikeRng =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.spendingLikelihoodRange.values[0].id");
            assertThat(spendLikeRng.toString(), equalTo(data.getSpendLikeRngIdUpdt()));

        }

        // Assert on Investment Time Horizon if present
        if (data.getInvesTimeHrznTxtUpdt() != null) {
            response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentTimeHorizon", not(empty()),
                    "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentTimeHorizon.values[0].value",
                    equalTo(data.getInvesTimeHrznTxtUpdt()));
            Integer timeHorizon =
                    response.body().jsonPath().getInt("accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentTimeHorizon.values[0].id");
            assertThat(timeHorizon.toString(), equalTo(data.getInvesTimeHrznIdUpdt()));

        }
        // Assert on accountPreferencesIA
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.accountPreferencesIA", not(empty()))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.accountPreferencesIA.riskTolerance", equalTo(2))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.accountPreferencesIA.withdrawalStartYear", equalTo(startYear))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear));


    }

    /**
     * Validate the suitability was updated.
     */
    private void getSuitabilityAfterUpdate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true));

    }

    /**
     * Delete the account.
     * <p>
     * Version V1
     */

    private void deleteAccountSuitability() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

    }

    /**
     * Validate no suitability is returned.
     * <p>
     * Version V1
     */

    private void getSuitabilityAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "accountSuitability", empty());

    }

}
