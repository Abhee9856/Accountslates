package com.fmr.restassured.account.v1.account.crud.retail.hiddenaccounts;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.v1.account.get.retail.GetRetail_IsHiddenTestV1;
import io.restassured.RestAssured;
import io.restassured.config.HeaderConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.config.HeaderConfig.headerConfig;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.*;

public class Retail_V1_hiddenAccount_negative extends PAPBaseServiceTest {

    protected Retail_V1_hiddenAccount_negative() { super(Services.Account); }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private final float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String source = "RETAIL";

    private final String asOfDate1 = "2014-10-31";

    private static final String sourceSystem = "RETAIL";

    private String mid;// = "RetailAccountV1TestMid";

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accId;

    private String accNumber;

    private String mnemonic;

    private static final String CALLING_APP_ID = "AP106532";

    private static final String APP_ID = "AP106532";

    private static final String LOG_TRACKING_ID = Retail_V1_hiddenAccount_negative.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    final String oAuth = AccountUtil.getOauthToken();

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        RestAssured.filters(new RequestLoggingFilter(),new ResponseLoggingFilter());

        accountsCommonTestData = TestDataUtil.populateRegressionTestData("retail_is_hidden_account", oAuth);
        testDataUtil = new TestDataUtil();
        this.mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(this.mid);
        accountsCommonTestData.setAsOfDate1(asOfDate1);
        accountsCommonTestData.setValue1(value);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", String.valueOf(value));

    }

    /**
     * Create Retail account with different combination of Regcodes from DataProvider.
     * <p>
     * Version V1
     */

    //Get account info from the backend.
    @Test
    public void getRetailAccountWithHidden() {
        // Generate request body
        this.context.put("source", this.source);
        this.context.put("externalDataSources", false);
        request.header("return-hidden-accounts", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
                response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
            Assert.assertEquals(dssResultCode, false);
        }
        response.then().log().ifValidationFails()
                .body("accountList", not(emptyArray()));

        accNumber = response.path("accountList.find{it.isHidden == true}.accountId.accountNumber");
        mnemonic = response.path("accountList.find{it.isHidden == true}.regCode.mnemonic");
    }

    //Create Retail Account failed due to return-hidden-accounts false
    @Test(dependsOnMethods = {"getRetailAccountWithHidden"})
    public void createRetailAccountWithHiddenNegative() {
        // Generate request body
        this.request.given().
                config(RestAssured.config().headerConfig(headerConfig().overwriteHeadersWithName("return-hidden-accounts"
                        , "Content-Type")));
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("value", String.valueOf(this.value));
        this.context.put("mnemonic", mnemonic);
        this.context.put("source", sourceSystem);
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("id", null);
        this.context.put("excludeExternalDataSources", false);
        request.header("return-hidden-accounts", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(false));
    }


    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}
