/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.workplace;

import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.List;
import java.util.Map;

import com.fmr.restassured.account.v1.account.crud.manual.negative.Multiple_Manual_Accounts_With_Invalid_Request;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operations for Workplace accounts against V1.
 *
 * @author a644258
 *
 */
@Test(groups = { 
		
		Tags.ASYNCHRONOUS,
		Tags.WORKPLACE,
		Tags.ACCOUNT,
		Tags.V1
		 })
public class Workplace_EEDS_false extends PAPBaseServiceTest
{	
	protected Workplace_EEDS_false()
	{
		super(Services.Account);
	}

	// Data setup
	private AccountsCommonTestData accountsCommonTestData ;
	private String accountCreatePath = AccountsPaths.CREATE_ACCOUNT_V1;
	
	private String accountGetPath = AccountsPaths.GET_ACCOUNT_V1;
	
	private String accountUpdatePath = AccountsPaths.UPDATE_ACCOUNT_V1;
	
	private String accountDeletePath = AccountsPaths.DELETE_ACCOUNT_V1;
	
	private VelocityContext context;
	
	private float value;

	private float updatedValue = 426.85f;

	private String mid;// = "WorkplaceAccountV1TestMid";
	private static final String CALLING_APP_ID = "AP136091";

	private static final String APP_ID = "AP136091";

	private static final String LOG_TRACKING_ID = Workplace_EEDS_false.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
	 * for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
		accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_manual",oAuth);
		this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

		// Populate request variables
		context = new VelocityContext();
		context.put("mnemonicFilter", "401K");
		context.put("poe", "NETBENEFITS");
		context.put("mid", accountsCommonTestData.getMid());
		context.put("fescoLid", accountsCommonTestData.getSsn());
		context.put("source", AccountConstants.WORKPLACE);
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("value", String.valueOf(value));

	}

	/**
	 * Get account info from the backend. Save the account number.
	 */
	@Test
	public void getWorkplaceAccountInfo() 
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(accountGetPath);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true));
		
		accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
		accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
		accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
		accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
		accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
		accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
		accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
	}
	
	/**
	 * Create the account.
	 * 
	 * Version V1
	 */
	@Test(dependsOnMethods="getWorkplaceAccountInfo")
	public void createWorkplaceAccount()
	{
		context.put("mnemonic", accountsCommonTestData.getMnemonic1());
		context.put("value", accountsCommonTestData.getValue1());
		context.put("source", accountsCommonTestData.getSourceSystem1());
		context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		context.put("institutionName", accountsCommonTestData.getInstitutionName1());
		context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
		
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(accountCreatePath);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true), 
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
					"accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()));

		// Gets and saves the CFP account ID
		accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
		context.put("accId", accountsCommonTestData.getAccountId1());
	}
	
	
	/**
	 * Validate the account.
	 * 
	 * Version V1
	 */
	@Test(dependsOnMethods="createWorkplaceAccount")
	public void getWorkplaceAccountAfterCreate()
	{
		//Exclude external data sources
		context.put("externalDataSources", "false");
		context.put("source", null);
		
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(accountGetPath);
		
		int accountPos = 0;
		List<Map<String, String>> acctResponse = response.jsonPath().getList("accountList");
		for (int i = 0; i < acctResponse.size(); i++) {

			String accNumber = response.path("accountList[" + i + "].accountId.accountNumber");
			if(accNumber.equals(accountsCommonTestData.getAccountNumber1()))
			{
				accountPos = i;
				break;
			}
		}
		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true),
						"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
						"accountList[" + accountPos + "].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
						"accountList[" + accountPos + "].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
						"accountList[" + accountPos + "].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
						"accountList[" + accountPos + "].sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()));
	}
	
	/**
	 * Update the account.
	 * 
	 * Version V1
	 */
	@Test(dependsOnMethods="getWorkplaceAccountAfterCreate")
	public void updateWorkplaceAccount()
	{
		//Change the amount of the account
		context.put("value", updatedValue);
		context.put("source", AccountConstants.WORKPLACE);
		context.put("externalDataSources", "false");	
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));
	
		// Call Account service
		response = request.log().ifValidationFails().post(accountUpdatePath);
		
		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true),
						"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
						"accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
						"accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
						"accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
						"accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));
	}
	
	/**
	 * Validate the updated account.
	 * 
	 * Version V1
	 */
	@Test(dependsOnMethods="updateWorkplaceAccount")
	public void getWorkplaceAccountAfterUpdateEEDStrue()
	{
		context.put("externalDataSources", "true");
		// Generate request body
		context.put("source", null);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(accountGetPath);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true),
						"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
						"accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
						"accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
						"accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
						"accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));
	}	
	/**
	 * Validate the updated account.
	 * 
	 * Version V1
	 */
	@Test(dependsOnMethods="getWorkplaceAccountAfterUpdateEEDStrue")
	public void getWorkplaceAccountAfterUpdateEEDSfalse()
	{
		// Generate request body
		context.put("source", null);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(accountGetPath);

		int accountPos = 0;
		List<Map<String, String>> acctResponse = response.jsonPath().getList("accountList");
		for (int i = 0; i < acctResponse.size(); i++) {

			String accNumber = response.path("accountList[" + i + "].accountId.accountNumber");
			if(accNumber.equals(accountsCommonTestData.getAccountNumber1()))
			{
				accountPos = i;
				break;
			}
		}
		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true),
						"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
						"accountList[" + accountPos + "].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
						"accountList[" + accountPos + "].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
						"accountList[" + accountPos + "].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
						"accountList[" + accountPos + "].sourceMarketValue.amount.value", equalTo(updatedValue));
	}
	
	
	/**
	 * Delete the account.
	 * 
	 * Version V1
	 */
	@Test(dependsOnMethods="getWorkplaceAccountAfterUpdateEEDSfalse")
	public void deleteWorkplaceAccount()
	{
		// Generate request body
		context.put("source", AccountConstants.WORKPLACE);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(accountDeletePath);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true));
	}
	
	/**
	 * Validate the account was deleted.
	 * 
	 * Version V1
	 */
	@Test(dependsOnMethods="deleteWorkplaceAccount")
	public void getWorkplaceAccountAfterDeleteEEDStrue()
	{	
		context.put("externalDataSources", "true");

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(accountGetPath);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true),
						"accountList", empty());

	}
	
	/**
	 * Validate the account was deleted.
	 * 
	 * Version V1
	 */
	@Test(dependsOnMethods="getWorkplaceAccountAfterDeleteEEDStrue")
	public void getWorkplaceAccountAfterDeleteEEDSfalse()
	{	
		context.put("externalDataSources", "false");

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		
		// Call Account service
		response = request.log().ifValidationFails().post(accountGetPath);
		
		int accountPos = 0;
		List<Map<String, String>> acctResponse = response.jsonPath().getList("accountList");
		for (int i = 0; i < acctResponse.size(); i++) {

			String accNumber = response.path("accountList[" + i + "].accountId.accountNumber");
			if(accNumber.equals(accountsCommonTestData.getAccountNumber1()))
			{
				accountPos = i;
				break;
			}
		}
		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true),
						"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
						"accountList[" + accountPos + "].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
						"accountList[" + accountPos + "].sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()));
	}
}
