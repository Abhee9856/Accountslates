/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.equalTo;

/**
 * Tests CRUD operations for Retail Account details against V1.
 *
 * @author a631781
 * Updated by a608077 on 10/09/2023 to include 3 new asset classes: Private Equity, Private Credit,
 * and Real Assets(PFCP-13826)
 * Updated by a608077 on 02/29/2024 to include suitabilityStatus changes(PFCP-15267)
 * Updated by a608077 on 09/23/2024 to include isManaged flag(PFCP-17274)
 */
@Test(groups = {Tags.CRITICAL, Tags.RETAIL, Tags.DETAILS, Tags.V1, Tags.TAM})
public class Retail_Detail_CriticalTest_V1 extends PAPBaseServiceTest
{

    protected Retail_Detail_CriticalTest_V1()
    {
	super(Services.Account);
    }

    private final TestDataUtil testDataUtil = new TestDataUtil();
    private AccountsCommonTestData accountsCommonTestData = null;
    private VelocityContext context;
	private String accId;
	private static final String LOG_TRACKING_ID = Retail_Detail_CriticalTest_V1.class.getSimpleName();
	private static final String FSREQID = LOG_TRACKING_ID;

    private static final String productSubType = "FIXED INCOME";
    private static final String updatedProductSubType = "EQUITY";

    // Velocity Keys
    private static final String IS_TRANSFER_TO_SURVIVOR_IND = "isTransferToSurvivorIndicator";
    private static final String VESTED_VALUE = "vestedValue";
    private static final String UNVESTED_VALUE = "unvestedValue";
    private static final String YEARS_REMAINING = "yearsRemaining";
    private static final String BENEFICIARY_AVAILABLE = "beneficiaryAvailable";
    private static final String COMPLEMENTARY_ADJUSTMENT_OPT = "complementaryAdjustmentOption";
    private static final String PRODUCT_SUB_TYPE = "productSubType";

    private final String originalOwnerBirthDate = "1960-11-30T00:00:00.000+0000";
    private final String originalOwnerDeceasedDate = "2022-12-30T00:00:00.000+0000";
	private final String withdrawalEligibilityStartDate = "2020-01-01T00:00:00.000+0000";
    private final String withdrawalEligibilityEndDate = "2020-01-01T00:00:00.000+0000";
    private final String federalTaxWithholding = "0.7";
    private final String stateTaxWithholding = "0.5";
    private final String equityPercent = "0.5";
	private final String updatedEquityPercent = "1.5";
    private final String tamAssetClass = "TOTAL_EQUITY";

    // AssetAllocation
	private final String assetClass = "CASH";
    private final String assetClass_T_Equity = "TOTAL_EQUITY";
    private final String foreignEquity = "FOREIGN_EQUITY";
    private final String domesticEquity = "DOMESTIC_EQUITY";
	private final String assetClass3 = "BOND";
	private final String assetClass4 = "OTHER";
	private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
	private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
	private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
	private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";

	private final float netPercentageValue = 1.0f;
    private final float netPercentage_T_Equity = 1.0f;
    private final float netPercentage_FE = 0.5f;
    private final float netPercentage_DE = 0.5f;
    private final float netPercentage3 = 0.3f;
    private final float netPercentage4 = 0.2f;
    private final float netPercentageUpdated3 = 0.5f;
    private final float netPercentageUpdated4 = 0.7f;
    private final float netPercentage_T_ALTERNATIVE = 0.8f;
    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
	private final float netPercentage_PEA = 0.4f;
	private final float netPercentage_Updated_PEA = 0.2f;
	private final float netPercentage_PCA = 0.2f;
	private final float netPercentage_Updated_PCA = 0.3f;
	private final float netPercentage_PRAA = 0.2f;
	private final float netPercentage_Updated_PRAA = 0.1f;
	private Boolean isManagedFromBackend;


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();
	accountsCommonTestData = TestDataUtil.populateRegressionTestData("accountCRUD_Retail", oAuth);

	String mid = accountsCommonTestData.getMid();
	accountsCommonTestData.setMid(mid);
	accountsCommonTestData.set(IS_TRANSFER_TO_SURVIVOR_IND, "true");
	accountsCommonTestData.set(VESTED_VALUE, "100.0");
	accountsCommonTestData.set(UNVESTED_VALUE, "200.0");
	accountsCommonTestData.set(YEARS_REMAINING, "10");
	accountsCommonTestData.set(BENEFICIARY_AVAILABLE, "true");
	accountsCommonTestData.set(COMPLEMENTARY_ADJUSTMENT_OPT, "MANAGED_LOCK_CURRENT_ALLOCATION");
	accountsCommonTestData.set(PRODUCT_SUB_TYPE, productSubType);

	DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


	accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	// Populate request variables
	context = new VelocityContext();
	context.put("mid", accountsCommonTestData.getMid());
	context.put("retailLid", accountsCommonTestData.getSsn());
	String source = "RETAIL";
	context.put("source", source);
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put(IS_TRANSFER_TO_SURVIVOR_IND, accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND));
	context.put(VESTED_VALUE, accountsCommonTestData.get(VESTED_VALUE));
	context.put(UNVESTED_VALUE, accountsCommonTestData.get(UNVESTED_VALUE));
	context.put(YEARS_REMAINING, accountsCommonTestData.get(YEARS_REMAINING));
	context.put(BENEFICIARY_AVAILABLE, accountsCommonTestData.get(BENEFICIARY_AVAILABLE));
	context.put(COMPLEMENTARY_ADJUSTMENT_OPT, accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT));

    }

    /**
     * Get account info for Retail Account from the backend. Save the account number.
     * <p>
     * Version V1
     */
    @Test
    public void getRetailAccountInfo()
    {

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
	accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
	accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
	accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
	accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));

    }

    /**
     * Create the Retail account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount()
    {
	context.put("mid", accountsCommonTestData.getMid());
	context.put("sid", accountsCommonTestData.getSid());
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.id", notNullValue());

	accId = response.path("accountList[0].accountId.id");

    }

    /**
     * Validate the Retail account details before create.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createRetailAccount")
    public void getRetailAccountDetailsBeforeCreate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
			"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
			"accountDetails.find{it.accountId.id=='" + accId + "'}.coreBalance", notNullValue(),
			"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", notNullValue(),
			"accountDetails.find{it.accountId.id=='" + accId + "'}.accountLevel", notNullValue(),
			"accountDetails.find{it.accountId.id=='" + accId + "'}.isBrokerageLinkAccount", notNullValue(),
			"accountDetails.find{it.accountId.id=='" + accId + "'}.fidelityAccount", notNullValue(),
			"accountDetails.find{it.accountId.id=='" + accId + "'}.isPasAccount", notNullValue(),
			"accountDetails.find{it.accountId.id=='" + accId + "'}.isManaged", notNullValue());

	isManagedFromBackend= response.path("accountDetails.find{it.accountId.id=='" + accId + "'}.isManaged");

    }

    /**
     * Create Retail account Details Request.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getRetailAccountDetailsBeforeCreate")
    public void createRetailAccountDetails()
    {
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isProductSuitable", "true");
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "RetailAccountDetails");
	context.put("_type", "RetailAccountDetails");
	context.put("emergencyFundAmount", 2500.0F);
	context.put("externalDataSources", "true");
	context.put("productSubType", productSubType);
	context.put("tamAssetClass", tamAssetClass);
	context.put("originalOwnerBirthDate", originalOwnerBirthDate);
	String originalOwnerSpouse = "false";
	context.put("originalOwnerSpouse", originalOwnerSpouse);
	context.put("originalOwnerDeceasedDate", originalOwnerDeceasedDate);
	context.put("withdrawalEligibilityStartDate", withdrawalEligibilityStartDate);
	context.put("withdrawalEligibilityEndDate", withdrawalEligibilityEndDate);
	context.put("federalTaxWithholding", federalTaxWithholding);
	context.put("stateTaxWithholding", stateTaxWithholding);
	context.put("equityPercent", equityPercent);
	context.put("assetClass", assetClass);
	context.put("netPercentageValue", netPercentageValue);
	context.put("assetClass_T_Equity", assetClass_T_Equity);
	context.put("netPercentage_T_Equity", netPercentage_T_Equity);
	context.put("assetClass_FOREIGN_EQUITY", foreignEquity);
	context.put("netPercentage_FE", netPercentage_FE);
	context.put("assetClass_DOMESTIC_EQUITY", domesticEquity);
	context.put("netPercentage_DE", netPercentage_DE);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentage3);
	context.put("assetClass4", assetClass4);
	context.put("netPercentage4", netPercentage4);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE",netPercentage_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA",netPercentage_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA",netPercentage_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA",netPercentage_PRAA);
	context.put("isManaged", false);
	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
	// Call Account service
	response =
			request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id",
					equalTo(accId),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.state",
					equalTo(accountsCommonTestData.get("state")),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerSpouse",
					equalTo(false),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.targetAssetMixes.targetAssetMix[0].allocation[0].assetClass",
					equalTo(tamAssetClass),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isBrokerageLinkAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.fidelityAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isPasAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.productSubType",
					equalTo(accountsCommonTestData.get(PRODUCT_SUB_TYPE)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.equityPercent",
					equalTo(Float.valueOf(equityPercent)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.isProductSuitable",
					equalTo(true),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.isManaged",
					equalTo(false),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.suitabilityStatus",
					equalTo("SUITABLE"),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentage3),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentage4),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
					equalTo(netPercentage_FE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_T_ALTERNATIVE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PCA),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PEA),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PRAA));
    }

    /**
     * Validate the Retail account details after create.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createRetailAccountDetails")
    public void getRetailAccountDetailsAfterCreate()
    {
	context.put("externalDataSources", "false");
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

	// Assert on response

	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id",
					equalTo(accId),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.state",
					equalTo(accountsCommonTestData.get("state")),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerSpouse",
					equalTo(false),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.targetAssetMixes.targetAssetMix[0].allocation[0].assetClass",
					equalTo(tamAssetClass),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isBrokerageLinkAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.fidelityAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isPasAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.productSubType",
					equalTo(accountsCommonTestData.get(PRODUCT_SUB_TYPE)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.isProductSuitable",
					equalTo(true),
					/*The isManaged flag should be saved and the DB value returned when EEDS=true.
							* In this case, when EEDS=false the backend (DSS) data should have precedent.  */
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.isManaged",
					equalTo(isManagedFromBackend),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.suitabilityStatus",
					equalTo("SUITABLE"),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.equityPercent",
					equalTo(Float.valueOf(equityPercent)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentage3),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentage4),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
					equalTo(netPercentage_FE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_T_ALTERNATIVE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PCA),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PEA),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PRAA));
    }


    /**
     * Update the account details for Retail account.
     * <p>
     * Version V1
     * <p>
     * Add the EEDS flag value as TRUE
     */
    @Test(dependsOnMethods = "getRetailAccountDetailsAfterCreate")
    public void updateRetailAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
		float updatedValue = 426.85f;
		context.put("value", updatedValue);
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("accId", accId);
	context.put("isPasAccount", true);
	context.put("isInherited", false);
	context.put("isProductSuitable", "false");
	context.put("productSubType", updatedProductSubType);
	context.put("isBrokerageLinkAccount", true);
	context.put("state", "NC");
	context.put("type", "RetailAccountDetails");
	context.put("_type", "RetailAccountDetails");
	float emergencyFund = 3500f;
	context.put("emergencyFundAmount", emergencyFund);
	context.put("externalDataSources", "true");
	context.put("equityPercent", updatedEquityPercent);
	context.put("assetClass", assetClass);
	context.put("netPercentageValue", netPercentageValue);
	context.put("assetClass_T_Equity", assetClass_T_Equity);
	context.put("netPercentage_T_Equity", netPercentage_T_Equity);
	context.put("assetClass_FOREIGN_EQUITY", foreignEquity);
	context.put("netPercentage_FE", netPercentage_FE);
	context.put("assetClass_DOMESTIC_EQUITY", domesticEquity);
	context.put("netPercentage_DE", netPercentage_DE);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentageUpdated3);
	context.put("assetClass4", assetClass4);
	context.put("netPercentage4", netPercentageUpdated4);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE",netPercentage_Updated_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA",netPercentage_Updated_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA",netPercentage_Updated_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA",netPercentage_Updated_PRAA);
	context.put("isManaged",true);

	// Generate request body
	request
			.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id",
					equalTo(accId),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.state",
					equalTo(accountsCommonTestData.get("state")),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerSpouse",
					equalTo(false),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isBrokerageLinkAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.fidelityAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isPasAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.productSubType",
					equalTo(updatedProductSubType),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.equityPercent",
					equalTo(Float.valueOf(updatedEquityPercent)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.isProductSuitable",
					equalTo(false),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.isManaged",
					equalTo(true),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.suitabilityStatus",
					equalTo("UNSUITABLE"),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated3),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated4),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
					equalTo(netPercentage_FE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_T_ALTERNATIVE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PCA),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PEA),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PRAA));
    }

    /**
     * Validate the updated Retail account details.
     * <p>
     * Version V1
     * <p>
     * Add the EEDS flag value as FALSE
     */
    @Test(dependsOnMethods = "updateRetailAccountDetails")
    public void getRetailAccountDetailsAfterUpdate()
    {
	context.put("externalDataSources", "false");
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id",
					equalTo(accId),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.state",
					equalTo(accountsCommonTestData.get("state")),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerSpouse",
					equalTo(false),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isBrokerageLinkAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.fidelityAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isPasAccount",
					notNullValue(),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.productSubType",
					equalTo(updatedProductSubType),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.equityPercent",
					equalTo(Float.valueOf(updatedEquityPercent)),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.isProductSuitable",
					equalTo(false),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.isManaged",
					equalTo(isManagedFromBackend),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.suitabilityStatus",
					equalTo("UNSUITABLE"),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated3),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated4),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
					equalTo(netPercentage_FE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_T_ALTERNATIVE),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PCA),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PEA),
					"accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PRAA));
    }

    /**
     * Delete the account details for Retail account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getRetailAccountDetailsAfterUpdate")
    public void deleteRetailAccount()
    {

	context.put("sid", accountsCommonTestData.getSid());
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("id", accId);
	context.put("emergencyFundAmount", 3500.0F);
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountList", Matchers.hasSize(0));

    }


    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}
