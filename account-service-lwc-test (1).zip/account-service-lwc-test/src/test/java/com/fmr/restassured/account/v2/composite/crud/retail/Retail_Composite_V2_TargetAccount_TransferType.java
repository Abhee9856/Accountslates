/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.Matchers.*;

/**
 * Tests combination of TransferType CRUD operations for Composite Retail Target accounts
 *
 * @author a631781
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.COMPOSITE,
		Tags.TARGET_ACCOUNT,
		Tags.V2})
public class Retail_Composite_V2_TargetAccount_TransferType extends PAPBaseServiceTest
{

    protected Retail_Composite_V2_TargetAccount_TransferType()
    {
	super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private TestDataUtil testDataUtil;

    private final float newFundingAmount = 6.66f;

    private final float updatedUnknownAmount = 23.5f;

    int startYear = ZonedDateTime.now().plusYears(1).getYear();

    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";

    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String isProductSuitable = "true";

    private static final String isProductSuitableUpdate = "false";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Composite_v2_withTargetAccount.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private FilterableRequestSpecification frs;

    //Context
    private final VelocityContext context = new VelocityContext();

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	String oAuth = AccountUtil.getOauthToken();
	testDataUtil = new TestDataUtil();
	accountsCommonTestData =
			TestDataUtil.populateRegressionTestData("retail_critical_regcode", oAuth);
	//Data setup
	accountsCommonTestData.set("detailValue", "42619.85");
	accountsCommonTestData.set("contribAmount", "6000.0");
	accountsCommonTestData.set("contribFreq", "YEARLY");
	accountsCommonTestData.set("withdrawAmount", "500.0");
	accountsCommonTestData.set("withdrawFreq", "YEARLY");
	accountsCommonTestData.set("updatedDetailValue", "81819.89");
	accountsCommonTestData.set("updatedAmount", "15000.0");
	accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
	accountsCommonTestData.set("updatedContribAmount", "500.0");
	accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
	accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");

	DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


	accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

	this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	this.request.given()
			.header(new Header("user-poe", AccountConstants.RETAIL))
			.header(new Header("user-mid", accountsCommonTestData.getMid()))
			.header(new Header("user-sid", accountsCommonTestData.getSid()))
			.header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
	frs = (FilterableRequestSpecification) request;
    }

    /**
     * Create Target account with different combination of transferTypes from DataProvider.
     * <p>
     * Version V2
     */
    @Test(dataProvider = "getRetailAccountData",
		    dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data)
    {
	this.getRetailAccountInfo(data);
	this.getCompositeAccount(data);
	this.createCompositeAccount(data);
	this.getCompositeAccountAfterCreate(data);
	this.createTargetAccount(data);
	this.updateCompositeAccount(data);
	this.updateTargetAccount(data);
	this.getCompositeAccountAfterUpdate(data);
	this.deleteTargetAccount(data);
	this.deleteRetailAccount(data);
	this.getCompositeAccountAfterDelete(data);
    }

    /**
     * Get Retail account info from the backend. Save the account number.
     */
    private void getRetailAccountInfo(final AccountRegCodeTestData data)
    {
	//Setting Exclude external data sources flag
	this.frs.removeHeader("excludeExternalDataSources");
	this.request.given()
			.header(new Header("excludeExternalDataSources", "false"));

	// Generate request body
	context.put("source", AccountConstants.RETAIL);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountList", not(empty()));

	accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
	accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
	accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
	accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
	accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V2
     */
    private void getCompositeAccount(final AccountRegCodeTestData data)
    {
	//Setting Exclude external data sources flag
	this.frs.removeHeader("excludeExternalDataSources");
	this.request.given()
			.header(new Header("excludeExternalDataSources", "true"));

	// Exclude external data
	context.put("sourceBasedRegistrationFilter", AccountConstants.RETAIL);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

	// Make post request
	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", empty());

    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V2
     */
    private void createCompositeAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("accId", "");
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
	context.put("contribValue", accountsCommonTestData.get("contribAmount"));
	context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
	context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
	context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
	context.put("detailValue", accountsCommonTestData.get("detailValue"));

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

	// Make post request
	response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", not(empty()));

	//Save account number and ID
	accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
	accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V2
     */
    private void getCompositeAccountAfterCreate(final AccountRegCodeTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
					"accounts[0].account.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accounts[0].account.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()),
					"accounts[0].account.displayName",
					equalTo(accountsCommonTestData.getDisplayName1()),
					"accounts[0].account.regCode.mnemonic",
					equalTo(accountsCommonTestData.getMnemonic1()),
					"accounts[0].account.regCode.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accounts[0].account.institutionName",
					equalTo(accountsCommonTestData.getInstitutionName1()),
					"accounts[0].account.sourceMarketValue.amount.value",
					equalTo(accountsCommonTestData.getValue1()),
					"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation"
							+ ".find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(0f),
					"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation"
							+ ".find{it.assetClass='BOND'}.netPercentage.value",
					equalTo(0f),
					"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation"
							+ ".find{it.assetClass='CASH'}.netPercentage.value",
					equalTo(0f),
					"accounts[0].suitability.investmentObjective.targetAssetMix.name",
					equalTo("Short Term"),
					"accounts[0].contributions.contributions[0].contribution.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("contribAmount"))),
					"accounts[0].contributions.contributions[0].frequency",
					equalTo(accountsCommonTestData.get("contribFreq")),
					"accounts[0].withdrawals[0].amount.amount.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
					"accounts[0].withdrawals[0].amount.frequency",
					equalTo(accountsCommonTestData.get("withdrawFreq")));
    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V2
     */
    private void createTargetAccount(final AccountRegCodeTestData data)
    {
	//Target account fields
	context.put("transferType", data.getTransferType());
	context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
	float fundingAccountAmount = 5.55f;
	context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
	context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
	context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
	context.put("category", "INVESTOR_SELECTED_STRATEGY");
	context.put("isProductSuitable", isProductSuitable);
	context.put("withdrawalNeeds", "TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6");
	context.put("withdrawalStartYear", startYear);
	context.put("withdrawalEndYear", endYear);
	context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
	context.put("riskTolerance", "8");
	float unknownAmount = 25.0f;
	context.put("unknownAmount", String.valueOf(unknownAmount));

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

	// Make post request
	response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", empty(),
					"targetAccounts", not(empty()),
					"targetAccounts[0].sourceMarketValue.amount.value",
					equalTo(fundingAccountAmount),
					"targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"targetAccounts[0].fundingAccounts[0].amount.value",
					equalTo(fundingAccountAmount),
					"targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount),
					"targetAccounts[0].fundingAccounts[0].transferType",
					equalTo(data.getTransferType()),
					"targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
					equalTo("TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6"),
					"targetAccounts[0].complementaryAdjustmentOption",
					equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"),
					"targetAccounts[0].isProductSuitable",
					equalTo(Boolean.valueOf(isProductSuitable)));

	//Save target account number and ID
	accountsCommonTestData
			.set(TARGET_ACCOUNT_NUMBER_KEY, response.path("targetAccounts[0].accountId.accountNumber"));
	accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
    }

    /**
     * Runs an update on the new account and verifies content in the response.
     * <p>
     * Version V2
     */
    private void updateCompositeAccount(final AccountRegCodeTestData data)
    {
	// Populate variables for tests into context
	context.put("value", accountsCommonTestData.get("updatedAmount"));
	context.put("contribFreq", accountsCommonTestData.get("updatedContribFreq"));
	context.put("contribValue", accountsCommonTestData.get("updatedContribAmount"));
	context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
	context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
	context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
	context.put("accId", accountsCommonTestData.getAccountId1());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));

	// Make post request
	response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
					"accounts[0].account.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accounts[0].account.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()),
					"accounts[0].account.displayName",
					equalTo(accountsCommonTestData.getDisplayName1()),
					"accounts[0].account.regCode.mnemonic",
					equalTo(accountsCommonTestData.getMnemonic1()),
					"accounts[0].account.regCode.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accounts[0].account.institutionName",
					equalTo(accountsCommonTestData.getInstitutionName1()),
					"accounts[0].account.sourceMarketValue.amount.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
					"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation"
							+ ".find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(0f),
					"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation"
							+ ".find{it.assetClass='BOND'}.netPercentage.value",
					equalTo(0f),
					"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation"
							+ ".find{it.assetClass='CASH'}.netPercentage.value",
					equalTo(0f),
					"accounts[0].suitability.investmentObjective.targetAssetMix.name",
					equalTo("Short Term"),
					"accounts[0].contributions.contributions[0].contribution.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("updatedContribAmount"))),
					"accounts[0].contributions.contributions[0].frequency",
					equalTo(accountsCommonTestData.get("updatedContribFreq")),
					"accounts[0].withdrawals[0].amount.amount.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("updatedWithdrawAmount"))),
					"accounts[0].withdrawals[0].amount.frequency",
					equalTo(accountsCommonTestData.get("updatedWithdrawFreq")));
    }

    /**
     * Runs an update on the new account and verifies content in the response.
     * <p>
     * Version V2
     */
    private void updateTargetAccount(final AccountRegCodeTestData data)
    {
	//Target account fields
	context.put("targetAccountId", accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
	context.put("targetAccountNumber", accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
	context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("fundingAccountAmount", String.valueOf(newFundingAmount));
	context.put("targetAccountSourceMarketValue", String.valueOf(newFundingAmount));
	context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
	context.put("isProductSuitable", isProductSuitableUpdate);
	context.put("unknownAmount", String.valueOf(updatedUnknownAmount));
	context.put("transferType", data.getTransferType());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_UPDATE_V2_TEMPLATE));

	// Make post request
	response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", empty());
    }

    /**
     * Gets the composite accounts and verifies that content is still coming back.
     * <p>
     * Version V2
     */
    private void getCompositeAccountAfterUpdate(final AccountRegCodeTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", not(empty()),
					"accounts[0].account.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()),
					"accounts[0].account.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accounts[0].account.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()),
					"accounts[0].account.displayName",
					equalTo(accountsCommonTestData.getDisplayName1()),
					"accounts[0].account.regCode.mnemonic",
					equalTo(accountsCommonTestData.getMnemonic1()),
					"accounts[0].account.regCode.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accounts[0].account.institutionName",
					equalTo(accountsCommonTestData.getInstitutionName1()),
					"accounts[0].account.sourceMarketValue.amount.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
					"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(0f),
					"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value",
					equalTo(0f),
					"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value",
					equalTo(0f),
					"accounts[0].suitability.investmentObjective.targetAssetMix.name",
					equalTo("Short Term"),
					"accounts[0].contributions.contributions[0].contribution.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("updatedContribAmount"))),
					"accounts[0].contributions.contributions[0].frequency",
					equalTo(accountsCommonTestData.get("updatedContribFreq")),
					"accounts[0].withdrawals[0].amount.amount.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("updatedWithdrawAmount"))),
					"accounts[0].withdrawals[0].amount.frequency",
					equalTo(accountsCommonTestData.get("updatedWithdrawFreq")),
					"targetAccounts", not(empty()),
					"targetAccounts[0].sourceMarketValue.amount.value", equalTo(newFundingAmount),
					"targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"targetAccounts[0].fundingAccounts[0].amount.value", equalTo(newFundingAmount),
					"targetAccounts[0].fundingAccounts[0].unknownAmount",
					equalTo(updatedUnknownAmount),
					"targetAccounts[0].fundingAccounts[0].transferType",
					equalTo(data.getTransferType()),
					"targetAccounts[0].isProductSuitable",
					equalTo(Boolean.valueOf(isProductSuitableUpdate)),
					"targetAccounts[0].complementaryAdjustmentOption",
					equalTo("MOVE_TO_MANAGED_ACCOUNT"));

    }

    /**
     * Delete target account
     */
    private void deleteTargetAccount(final AccountRegCodeTestData data)
    {
	//Target account fields
	context.put("targetAccountId", accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
	context.put("targetAccountNumber", accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
	context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("fundingAccountAmount", String.valueOf(newFundingAmount));
	context.put("targetAccountSourceMarketValue", String.valueOf(newFundingAmount));
	context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
	context.put("isProductSuitable", isProductSuitableUpdate);
	context.put("unknownAmount", String.valueOf(updatedUnknownAmount));
	context.put("transferType", data.getTransferType());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("isEmpty()", Matchers.is(true));
    }

    /**
     * Delete the retail account.
     */
    private void deleteRetailAccount(final AccountRegCodeTestData data)
    {
	// Generate new request body
	context.put("id", accountsCommonTestData.getAccountId1());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

	response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("isEmpty()", Matchers.is(true));
    }

    /**
     * Call delete and confirm that no accounts come back in the response.
     * <p>
     * Version V2
     */
    private void getCompositeAccountAfterDelete(final AccountRegCodeTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", empty());
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}