/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.get.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.is;

/**
 * Tests IOM-DASSNPRW for Brokerage Link Account details against V1.
 *
 * @author a631781
 */
@Test(groups = {Tags.REGRESSION, Tags.RETAIL, Tags.DETAILS, Tags.V2})
public class RetailBrokerageLinkDetailsV2 extends PAPBaseServiceTest {

    protected RetailBrokerageLinkDetailsV2() {
        super(Services.Account);
    }
    // Data setup
    Logger logger = LogManager.getLogger(getClass());
    TestDataUtil testDataUtil = new TestDataUtil();
    private final String oAuth = AccountUtil.getOauthToken();
    private AccountsCommonTestData accountsCommonTestData = null;
    private VelocityContext context;
    private final String source = "RETAIL";
    public static final String ACCOUNT_CATEGORY = "Brokerage";
    private String ssn;
    private String mid;
    private String sid;
    private String accNum;
    private String brokerageLinkPlanId;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private final Header eedsFalse = new Header("excludeExternalDataSources", "false");
    private static final String LOG_TRACKING_ID = RetailBrokerageLinkDetailsV2.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String APP_NAME = "Advice and Planning Platform";
    private FilterableRequestSpecification frs;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_get_details_sdb", oAuth);
        mid = Identity.getUserIdentifier("lid", accountsCommonTestData.getSsn(), oAuth).get("mid");
        accountsCommonTestData.setMid(mid);
        accountsCommonTestData.setSourceSystem1("RETAIL");
        sid = accountsCommonTestData.getSid().replace("-", "");
        ssn = accountsCommonTestData.getSsn();
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData
                .setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("ppid", accountsCommonTestData.getPpid());
    }

    /**
     * Test to get the DSS workplacePlanDetail
     * <p>
     * Version V2
     */
    @Test
    public void getDSS_V2() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().statusCode(anyOf(is(200), is(206)));
        brokerageLinkPlanId = response.path("acctDetails.find{it.acctAttrDetail.regTypeDesc=='Non-Prototype'}.workplacePlanDetail.planId");
        accNum = response.path("acctDetails.find{it.acctAttrDetail.regTypeDesc=='Non-Prototype'}.acctNum");
    }

    /**
     * Validate Brokerage Link details in the Get response
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void getRetailAccountDetailBrokerageLink() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        setRequestHeadersForAccount();
        // Generate request body
        context.put("accountNumber", accNum);
        context.put("source", source);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
        logger.info("Response :: getRetailAccountDetailsAfterCreate : ");
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body(
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.accountNumber=='" + accNum + "'}.retailAccountDetail.isBrokerageLinkAccount", equalTo(true),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.accountNumber=='" + accNum + "'}.retailAccountDetail.brokerageLinkPlanId", equalTo(brokerageLinkPlanId));
    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS() {
        request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", ssn))
                .header(new Header("rtazallrealmslids", "Retail=" + ssn))
                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + sid))
                .header(new Header("FACMC", "MID=" + mid))
                .header(new Header("FACFC", "SESSION_KEY=1"))
                .header(new Header("Content-Type", "application/json"));
    }

    /**
     * Setting headers for Account Service
     */
    private void setRequestHeadersForAccount() {
        // Account headers setup
        request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-retail-lid", ssn))
                .header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
