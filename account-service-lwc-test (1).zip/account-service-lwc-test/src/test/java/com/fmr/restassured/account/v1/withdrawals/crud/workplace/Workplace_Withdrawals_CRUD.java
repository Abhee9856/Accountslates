/*
 * Copyright 2018, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.withdrawals.crud.workplace;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.BaseServiceTest;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.ServiceVersion;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsWithdrawalsPaths;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.constants.EnvironmentConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.pap.restassured.utilities.IOUtil;

import com.fmr.restassured.account.v1.withdrawals.crud.retail.Retail_CRUD_v1;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operations for withdrawals against V1.
 *
 * @author a601767
 * Updated by a631781
 */
@Test(groups = {
        Tags.CRITICAL,
        Tags.WORKPLACE,
        Tags.WITHDRAWALS,
        Tags.V1})
public class Workplace_Withdrawals_CRUD extends PAPBaseServiceTest {
    protected Workplace_Withdrawals_CRUD() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData ;
    private String ppid;
    private VelocityContext context;

    private final float value = 818.89f;

    private final float updatedValue = 426.85f;
    private final String withdrawalType = "Regular";

    private final String frequency = "MONTHLY";
    private final String updatedFrequency = "YEARLY";
    private static final String LOG_TRACKING_ID = Workplace_Withdrawals_CRUD.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {

        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_withdrawals_CRUD_Workplace_166",oAuth);
        String mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate request context with user IDs
        context = new VelocityContext();

        context.put("mid", mid);
        context.put("fescoLid", accountsCommonTestData.getSsn());
        context.put("ppid", ppid);
        context.put("source", "WORKPLACE");
        context.put("value", String.valueOf(value));
    }

    /**
     * Get account info from the backend. Save the account number.
     */
    @Test
    public void getWorkplaceAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Create the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount() {
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()));

        // Gets and saves the CFP account ID
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
        context.put("accId", accountsCommonTestData.getAccountId1());
    }

    /**
     * Validate the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void createWithdrawal() {
        // Generate request body
        context.put("withdrawalType", withdrawalType);
        context.put("withdrawalValue", value);
        context.put("frequency", frequency);
        context.put("frequencyValue", "818");
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V1);


        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "userIdentifier.fescoLid", equalTo(accountsCommonTestData.getSsn()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].amount.amount.value", equalTo(value),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].amount.frequency", equalTo(frequency),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].withdrawalType", equalTo(withdrawalType),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.owner.id", equalTo(ppid));

    }

    /**
     * Update the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createWithdrawal")
    public void getWithdrawalsAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].amount.amount.value", equalTo(value),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].amount.frequency", equalTo(frequency),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].withdrawalType", equalTo(withdrawalType),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.owner.id", equalTo(ppid));

    }

    /**
     * Validate the updated account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWithdrawalsAfterCreate")
    public void updateWithdrawal() {
        // Generate request body
        context.put("withdrawalValue", updatedValue);
        context.put("frequency", updatedFrequency);
        context.put("frequencyValue", "426");
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_UPDATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.UPDATE_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].amount.amount.value", equalTo(updatedValue),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].amount.frequency", equalTo(updatedFrequency),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].withdrawalType", equalTo(withdrawalType),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.owner.id", equalTo(ppid));

    }

    /**
     * Update the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateWithdrawal")
    public void getWithdrawalsAfterUpdate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V1);
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].amount.amount.value", equalTo(updatedValue),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].amount.frequency", equalTo(updatedFrequency),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.withdrawals[0].withdrawalType", equalTo(withdrawalType),
                        "accountWithdrawals.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.accountId.owner.id", equalTo(ppid));

    }

    /**
     * Delete the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWithdrawalsAfterUpdate")
    public void deleteWithdrawal() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.DELETE_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountWithdrawals", empty());
    }

    /**
     * Validate the account was deleted.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteWithdrawal")
    public void getWithdrawalsAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountWithdrawals", empty());

    }
}
