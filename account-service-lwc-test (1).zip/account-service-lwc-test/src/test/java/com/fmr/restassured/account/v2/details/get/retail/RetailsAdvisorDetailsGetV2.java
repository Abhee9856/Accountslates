/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.get.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Tests IOM-DASSNPRW for Retail Account details against V2.
 *
 * @author a631781
 */
@Test(groups = {Tags.REGRESSION, Tags.RETAIL, Tags.DETAILS, Tags.V2})
public class RetailsAdvisorDetailsGetV2 extends PAPBaseServiceTest {

    protected RetailsAdvisorDetailsGetV2() {
        super(Services.Account);
    }
    Logger logger = LogManager.getLogger(getClass());

    TestDataUtil testDataUtil = new TestDataUtil();

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private final String source = "RETAIL";

    private String mid;


    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private final Header eedsFalse = new Header("excludeExternalDataSources", "false");

    private static List<String> accountList = new ArrayList<String>();


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_get_details_sdb", oAuth);
        mid = Identity.getUserIdentifier("lid", this.accountsCommonTestData.getSsn(), oAuth).get("mid");
        accountsCommonTestData.setMid(this.mid);
        accountsCommonTestData.setSourceSystem1("RETAIL");


        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData
                .setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(oAuth);
        request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("log-tracking-id", Tags.REGRESSION + "_" + getClass().getSimpleName()))
                .header(new Header("fsreqid", Tags.REGRESSION + "_" + getClass().getSimpleName()))
                .header(new Header("AppId", "AP136091")).header(eedsFalse);

        // Populate request variables
        context = new VelocityContext();
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", source);

    }


    /**
     * Validate analyticOptout in advisorRetailAccountDetail object in the Get response
     * <p>
     * Version V2
     */
    @Test
    public void getAdvisorRetailAccountDetail() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
        response.prettyPrint();
        logger.info("Response :: getRetailAccountDetailsAfterCreate : ");
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

        List<Boolean> analyticOptout =
                response.body().jsonPath().get("accountDetails.advisorRetailAccountDetail.analyticOptout");
        assertThat(analyticOptout,notNullValue());

    }


    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}

