/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.crud.fullview;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.constants.TestDataConstants;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

/**
 * Tests CRUD operations for Fullview accounts with Point of Entry as NetBenefits, against V2.
 *
 * @author a608077
 */
@Test(groups = {
        Tags.FULLVIEW,
        Tags.ACCOUNT,
        Tags.V2,
        "PFCP-3051"
})

public class Fullview_V2_With_POE_NetBenefits extends PAPBaseServiceTest {

    protected Fullview_V2_With_POE_NetBenefits() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private VelocityContext context;
    FilterableRequestSpecification frs;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private static final String callingAppId = "AP136091";
    private static final String appId = "AP136091";
    private static final String logTrackingId = Fullview_V2_With_POE_NetBenefits.class.getSimpleName();
    private static final String fsreqid = logTrackingId;
    private final float updatedValue = 426.85f;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {

        final String oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        accountsCommonTestData= TestDataUtil
                .populateRegressionTestData("account_CRUD_Fullview_NetBenifit_POE_147",oAuth);

        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuth, "true");

        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity(AccountConstants.MID, accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

        this.request.given()
                .header(new Header("user-poe", TestDataConstants.POE_NB))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));

        //Populate request variables
        context = new VelocityContext();
        context.put("source", AccountConstants.FULLVIEW);

        frs = (FilterableRequestSpecification) request;

    }

    /**
     * Get account info from the backend. Save the account number.
     */
    @Test
    public void getFullviewAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(empty()));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Create the account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void createFullviewAccount() {

        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(empty()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()));

        // Gets and saves the CFP account ID
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
    }

    /**
     * Validate the account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createFullviewAccount")
    public void getFullviewAccountAfterCreate() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList", not(empty()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountList[0].sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()));

    }


    /**
     * Update the account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getFullviewAccountAfterCreate")
    public void updateFullviewAccount() {

        //Change the amount of the account
        context.put("value", updatedValue);
        context.put("id", accountsCommonTestData.getAccountId1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(empty()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));

    }

    /**
     * Validate the updated account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateFullviewAccount")
    public void getFullviewAccountAfterUpdate() {

        //Exclude external data sources
        this.frs.removeHeader("excludeExternalDataSources");
        this.request.given()
                .header(new Header("excludeExternalDataSources", "true"));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(empty()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));
    }

    /**
     * Delete the account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getFullviewAccountAfterUpdate")
    public void deleteFullviewAccount() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("isEmpty()", Matchers.is(true));
    }

    /**
     * Validate the account was deleted.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteFullviewAccount")
    public void getFullviewAccountAfterDelete() {

        //Exclude external data sources
        this.frs.removeHeader("excludeExternalDataSources");
        this.request.given()
                .header(new Header("excludeExternalDataSources", "true"));
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("isEmpty()", Matchers.is(true));

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}

