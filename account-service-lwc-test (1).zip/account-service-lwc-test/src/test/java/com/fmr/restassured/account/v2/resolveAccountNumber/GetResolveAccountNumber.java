/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.resolveAccountNumber;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountPaths;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.nullValue;

/**
 * Test for validating get/resolve account numbers operation
 *
 * @author a608077
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.ACCOUNT,
		Tags.V2,
		Tags.TARGET_ACCOUNT})
public class GetResolveAccountNumber extends PAPBaseServiceTest
{

	protected GetResolveAccountNumber()
	{
		super(Services.Account);
	}

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	private AccountsCommonTestData accountsCommonTestData;

	private TestDataUtil testDataUtil;

	private static final String LOG_TRACKING_ID = GetResolveAccountNumber.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private VelocityContext context;

	@BeforeClass(alwaysRun = true)
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
		accountsCommonTestData = TestDataUtil
				.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);

		//Set default request headers
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID,
				LOG_TRACKING_ID, FSREQID, oAuth);

		testDataUtil = new TestDataUtil();

		String mid = this.accountsCommonTestData.getMid();
		this.accountsCommonTestData.setMid(mid);

		DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");

		// Create Principal
		Identity.createPrincipal(accountsCommonTestData.getMid(), oAuth);
		this.accountsCommonTestData.setPpid(Identity
				.createHouseholdIdentity("mid", this.accountsCommonTestData.getMid(), oAuth));

		this.request.given()
				.header(new Header("user-poe", AccountConstants.RETAIL))
				.header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
				.header(new Header("user-mid", accountsCommonTestData.getMid()))
				.header(new Header("scenario-product-code", "IGE"))
				.header(new Header("scenario-category-code", "DEF"));
		// Populate request variables
		context = new VelocityContext();

	}

	/**
	 * Get retail account info from the backend.
	 */
	@Test
	public void getRetailAccountInfo()
	{

		// Generate request body
		context.put("source", AccountConstants.RETAIL);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service v2
		response = request.post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(200)
				.body("accountList", not(emptyArray()))
				.body("accountList[0].accountId.accountNumber", notNullValue())
				.body("accountList[0].accountId", notNullValue());

		// use the values below to populate create request
		accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
		accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
		accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
		accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
		accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));

	}

	/**
	 * Create the account
	 */
	@Test(dependsOnMethods = "getRetailAccountInfo")
	public void createRetailAccount()
	{

		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("mnemonic", accountsCommonTestData.getMnemonic1());
		context.put("value", accountsCommonTestData.getValue1());
		context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(200)
				.body("accountList[0].sourceMarketValue.amount.value",
						equalTo(accountsCommonTestData.getValue1()),
						"accountList[0].accountId.id", not(nullValue()),
						"accountList[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()),
						"accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()),
						"accountList[0].regCode.mnemonic",
						equalTo(accountsCommonTestData.getMnemonic1()),
						"accountList[0].sourceMarketValue", not(nullValue()));

		accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
	}

	/**
	 * Call resolve account numbers
	 */
	@Test(dependsOnMethods = "createRetailAccount")
	public void get_resolveAccountNumber()
	{

		this.request.header(new Header("account-id", accountsCommonTestData.getAccountId1()));

		response = request.get(AccountPaths.RESOLVE_ACCOUNT_NUMBER_PATH);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(200)
				.body("accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()));

	}

	/**
	 * Call resolve account numbers
	 */
	@Test(dependsOnMethods = "createRetailAccount")
	public void get_resolveAccountId()
	{

		this.request.header(new Header("account-number", accountsCommonTestData.getAccountNumber1()));

		response = request.get(AccountPaths.RESOLVE_ACCOUNT_NUMBER_PATH);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(200)
				.body("accountId", equalTo(accountsCommonTestData.getAccountId1()));

	}

	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}
}
