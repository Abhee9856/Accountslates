/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.dss.realtimedata;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Tests Account Balances operation with real time data from DSS Accounts API
 *
 * Updated by a608077 on 09/27/2023 for sourcing balances from DSS Balance Detail V2 API(PFCP-13666)
 *
 * @author a702588
 */

@Test(groups = {Tags.REAL_TIME_DATA, Tags.V2})
public class AccountBalancesV2 extends PAPBaseServiceTest
{

    protected AccountBalancesV2()
    {
	super(Services.Account);
    }

    private VelocityContext context;

    public String mid;

    public String ssn;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String APP_NAME = "Advice and Planning Platform";

    private static final String LOG_TRACKING_ID = AccountBalancesV2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private FilterableRequestSpecification frs;

    final String oAuth = AccountUtil.getOauthToken();

    private String accNumber;

    private Float dssSrcMktValueRealTime, dssSrcMktValuePreviousDay;

    public static final String ACCOUNT_CATEGORY = "Brokerage";

    private TestDataUtil testDataUtil;

    @BeforeTest
    public void init()
    {
	    AccountsCommonTestData accountsCommonTestData = TestDataUtil.populateRegressionTestData("retail_esop_account", oAuth);

	this.ssn = accountsCommonTestData.getSsn();
	mid = accountsCommonTestData.getMid();

	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



	this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
	frs = (FilterableRequestSpecification) request;

	testDataUtil = new TestDataUtil();

	context = new VelocityContext();
	context.put("source", AccountConstants.RETAIL);

    }

    /**
     * Tests that account data is brought back for all account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getAccountBalanceDetail_V2_DSS")
    public void getAccounts_V2_RealTimeTrue()
    {
		frs.removeHeaders();
		this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

		this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);

		this.request.header(new Header("user-poe", "RETAIL"))
				.header(new Header("scenario-category-code", "DEF"))
				.header(new Header("scenario-product-code", "IGE"))
				.header(new Header("user-retail-lid", this.ssn))
				.header(new Header("user-mid", mid))
				.header(new Header("realTimeData", "true"))
				.header(new Header("clear-retail-cache", "true"));

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200)
			.body("accountList", not(emptyArray()))
			.body("accountList", not(emptyArray()))
			.body("accountList.find{it.accountId.accountNumber=='" + accNumber
					+ "'}.accountId.accountNumber",equalTo(accNumber))
			.body("accountList.find{it.accountId.accountNumber=='" + accNumber
					+ "'}.accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
			.body("accountList.find{it.accountId.accountNumber=='" + accNumber
					+ "'}.sourceMarketValue.amount.value", equalTo(dssSrcMktValueRealTime));

    }
    
    /**
	 * Tests get account v2 for realTime=false
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "getAccountBalanceDetail_V2_DSS")
	public void getAccounts_V2_RealTimeFalse()
	{
		frs.removeHeaders();
		this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

		this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);

		this.request.header(new Header("user-poe", "RETAIL"))
				.header(new Header("scenario-category-code", "DEF"))
				.header(new Header("scenario-product-code", "IGE"))
				.header(new Header("user-retail-lid", this.ssn))
				.header(new Header("user-mid", mid))
				.header(new Header("realTimeData", "false"))
				.header(new Header("clear-retail-cache", "true"));

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(200)
				.body("accountList", not(emptyArray()))
				.body("accountList.find{it.accountId.accountNumber=='" + accNumber
						+ "'}.accountId.accountNumber",equalTo(accNumber))
				.body("accountList.find{it.accountId.accountNumber=='" + accNumber
								+ "'}.accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
				.body("accountList.find{it.accountId.accountNumber=='" + accNumber
						+ "'}.sourceMarketValue.amount.value", equalTo(dssSrcMktValuePreviousDay));

	}
    @Test
    public void getAccounts_V2_DSS()
    {

	frs.removeHeaders();
	this.setDefaultRequestHeadersForDSS();

	context.put("acctCategory", ACCOUNT_CATEGORY);
	context.put("returnAccountGainLossBalanceDetail", "true");

	this.request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DSS_BALANCE_V2_TEMPLATE));

	response = this.request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
			.body("acctDetails", not(emptyArray()))
			.body("acctDetails[0].acctNum", notNullValue())
			.body("acctDetails[0].acctType",equalTo(ACCOUNT_CATEGORY));
	
	accNumber= response.path("acctDetails[0].acctNum");

    }
    
    @Test(dependsOnMethods = "getAccounts_V2_DSS")
	public void getAccountBalanceDetail_V2_DSS() {

		frs.removeHeaders();
		this.setDefaultRequestHeadersForDSS();

		// Generate request body
		context.put("acctCategory", ACCOUNT_CATEGORY);
		context.put("accountNumber", accNumber);
		context.put("acctSubType", ACCOUNT_CATEGORY);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_DETAILS_V2));

		request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
		response = request.log().ifValidationFails().post(AccountConstants.DSS_ACCOUNT_DETAILS_V2_PATH);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(200);

		dssSrcMktValueRealTime= response.path("balances[0].brokerageAcctDetail.recentBalanceDetail.acctValDetail.netWorth");
		dssSrcMktValuePreviousDay=response.path("balances[0].brokerageAcctDetail.closeBalanceDetail.acctValDetail.netWorth");
	}

    private void setDefaultRequestHeadersForDSS()
    {
	this.request.given().header(new Header("AppId", "AP106532"))
			.header(new Header("fsreqid", FSREQID))
			.header(new Header("Authorization", oAuth))
			.header(new Header("AppName", APP_NAME))
			.header(new Header("rtazlid", this.ssn))
			.header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
			.header(new Header("FACSC", "ROLE=FidCust"))
			.header(new Header("FACMC", "MID=" +mid))
			.header(new Header("Content-Type", "application/json"));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	this.testDataUtil.closeSQLiteConnection();
    }
}
