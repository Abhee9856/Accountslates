/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.fili;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operations of account details V1 for FILI Accounts. First, retrieves FILI account from backend then
 * creates account details for each account.
 *
 * @author a560878 Updated by a608077 on 03/30/2022
 */
@Test(groups = {Tags.FILI, Tags.DETAILS, Tags.V1})

public class Fili_Details_V1_Crud extends PAPBaseServiceTest {

    protected Fili_Details_V1_Crud() {
        super(Services.Account);
    }

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Fili_Details_V1_Crud.class.getSimpleName();

    private static final String fsreqid = logTrackingId;

    private String accId;
    private String mid;

    private static final String TRUSTEE_TYPE = "FPTC";
    private static final String TRUSTEE_TYPE_UPDATE = "ABCD";

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
     * endpoint for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        this.p2TestDataUtil = new TestDataUtil();

        final String oAuth = AccountUtil.getOauthToken();

        this.accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_get_FILI_Reg_Code_I_82", oAuth);

        this.accountsCommonTestData.setMid(Identity
                .getUserIdentifier("lid", this.accountsCommonTestData.getSsn(), oAuth).get("mid"));

        // Clean up test data
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, this.accountsCommonTestData.getMid(), oAuth, "true");

        this.accountsCommonTestData
                .setPpid(Identity.createHouseholdIdentity(this.accountsCommonTestData.getMid(), oAuth));

        // Common Headers setup
        setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

        // Populate request variables
        this.context = new VelocityContext();
        this.context.put("mid", this.accountsCommonTestData.getMid());
        String sourceSystem = AccountConstants.FILI;
        this.context.put("source", sourceSystem);
        this.context.put("poe", "RETAIL");
        this.context.put("ppid", accountsCommonTestData.getPpid());
        this.context.put("filiLid", accountsCommonTestData.getSsn());

    }

    /**
     * Tests that account data is brought back for Fili account.
     * <p>
     * Version V1
     */
    @Test
    public void getFiliAccountInfo() {

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service v1
        this.response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()))
                .body("accountList", Matchers.not(Matchers.hasSize(0)));

        // Save data from backend
        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Creates a new Fili account
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFiliAccountInfo")
    public void createFiliAccount() {

        this.context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        this.context.put("value", accountsCommonTestData.getValue1());
        this.context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        this.context.put("displayName", accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()))
                .body("accountList.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountList.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body("accountList.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
                .body("accountList.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()));

        accId = this.response.path("accountList[0].accountId.id");
    }

    /**
     * Create Fili account Details Request.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createFiliAccount")
    public void createAccountDetails() {

        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("value", accountsCommonTestData.getValue1());
        this.context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        this.context.put("accId", accId);
        this.context.put("isInherited", false);
        this.context.put("isPreviousEmployersAccount", false);
        this.context.put("state", "NC");
        this.context.put("type", "AnnuityAccountDetails");
        this.context.put("_type", "AnnuityAccountDetails");
        context.put("trusteeType", TRUSTEE_TYPE);

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context,
                AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails()
                .post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.id", equalTo(accId))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.owner.relationship", equalTo("PRINCIPAL"))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.owner.id",
                        equalTo(this.accountsCommonTestData.getPpid()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.trusteeType", equalTo(TRUSTEE_TYPE));

    }

    /**
     * Validate the Fili account details after create.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate() {

        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        this.context.put("accId", accId);

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context,
                AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails()
                .post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
                        "accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.id", equalTo(accId),
                        "accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.sourceSystem", equalTo("FILI"))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.trusteeType", equalTo(TRUSTEE_TYPE));

    }

    /**
     * Update the account details for Fili account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails() {

        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        float updatedValue = 426.85f;
        this.context.put("value", updatedValue);
        this.context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        this.context.put("accId", accId);
        this.context.put("isInherited", false);
        this.context.put("isPreviousEmployersAccount", false);
        this.context.put("state", "NC");
        this.context.put("type", "AnnuityAccountDetails");
        this.context.put("_type", "AnnuityAccountDetails");
        context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context,
                AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails()
                .post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.id", equalTo(accId))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.owner.relationship", equalTo("PRINCIPAL"))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.owner.id",
                        equalTo(this.accountsCommonTestData.getPpid()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.trusteeType", equalTo(TRUSTEE_TYPE_UPDATE));
    }

    /**
     * Validate the updated Fili account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate() {

        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        this.context.put("accId", accId);

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context,
                AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails()
                .post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.id", equalTo(accId))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.owner.id",
                        equalTo(this.accountsCommonTestData.getPpid()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.sourceSystem", equalTo("FILI"))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.trusteeType", equalTo(TRUSTEE_TYPE_UPDATE));

    }

    /**
     * Delete the Fili account Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteFiliAccount() {

        this.context.put("accId", accId);
        this.context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        this.context.put("value", accountsCommonTestData.getValue1());
        this.context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        this.context.put("displayName", accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()))
                .body("accountList", empty());
    }

    /**
     * Validate the Fili account was deleted.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteFiliAccount")
    public void getDetailsAfterDelete() {

        context.put("externalDataSources", true);
        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context,
                AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails()
                .post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()))
                .body("accountDetails", empty());

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        this.p2TestDataUtil.closeSQLiteConnection();
    }

}
