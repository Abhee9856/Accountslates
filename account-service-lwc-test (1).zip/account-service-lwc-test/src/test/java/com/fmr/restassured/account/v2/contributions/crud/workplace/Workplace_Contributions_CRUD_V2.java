/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.contributions.crud.workplace;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.*;
import static org.testng.AssertJUnit.assertFalse;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsContributionsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import com.fmr.restassured.account.helpers.testdata.dto.AccountContributionsTestData;

import io.restassured.http.Header;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

/**
 * Tests CRUD operation for Workplace contributions against V2.
 *
 * @author a608077 Updated by a631781 to include changes for "Set method" (PFCP-9562)
 */
@Test(groups = {Tags.WORKPLACE, Tags.CONTRIBUTIONS, Tags.V2})

public class Workplace_Contributions_CRUD_V2 extends PAPBaseServiceTest
{

	protected Workplace_Contributions_CRUD_V2()
	{
		super(Services.Account);
	}

	private VelocityContext context;

	private TestDataUtil testDataUtil;

	private static final String CALLING_APP_ID = "AP136091";

	private static final String APP_ID = "AP136091";

	private static final String LOG_TRACKING_ID = Workplace_Contributions_CRUD_V2.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private static final String MONEY = "MONEY";

	private static final String PERCENT = "PERCENT";
	private static  String oAuth;

	private static final String updatedFrequency = "BIMONTHLY";
	String mid = "WorkplaceContributionV2TestMid";

	// Data setup
	private final AccountContributionsTestData testData = new AccountContributionsTestData();

	private AccountsCommonTestData accountsAccountsCommonTestData;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		oAuth = AccountUtil.getOauthToken();

		accountsAccountsCommonTestData =
				TestDataUtil.populateRegressionTestData("account_contribution_Workplace", oAuth);

		accountsAccountsCommonTestData.setMid(mid);

		DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


		String ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);
		accountsAccountsCommonTestData.setPpid(ppid);

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

		testDataUtil = new TestDataUtil();

		this.request.given().header(new Header("user-poe", AccountConstants.NETBENEFITS))
		.header(new Header("user-mid", accountsAccountsCommonTestData.getMid()))
		.header(new Header("user-fesco-lid", accountsAccountsCommonTestData.getSsn()))
		.header(new Header("scenario-product-code", "IGE"))
		.header(new Header("scenario-category-code", "DEF"));

		// Populate request variables
		context = new VelocityContext();
		context.put("source", AccountConstants.WORKPLACE);
		//to create/get workplace contributions
		request.header("return-workplace-overridden-contributions", true);
	}

	/**
	 * Get Workplace account info from the backend. Save the account number.
	 */
	@Test
	public void getWorkplaceAccountInfo()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList",
				not(empty()));

		accountsAccountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
		accountsAccountsCommonTestData
		.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
		accountsAccountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
		accountsAccountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
		accountsAccountsCommonTestData
		.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
		accountsAccountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
		accountsAccountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
	}

	/**
	 * Create the Workplace account. Save the account id. Version V2
	 */
	@Test(dependsOnMethods = "getWorkplaceAccountInfo")
	public void createWorkplaceAccount()
	{

		context.put("mnemonic", accountsAccountsCommonTestData.getMnemonic1());
		context.put("value", accountsAccountsCommonTestData.getValue1());
		context.put("ppid", accountsAccountsCommonTestData.getPpid());
		context.put("source", accountsAccountsCommonTestData.getSourceSystem1());
		context.put("accountNumber", accountsAccountsCommonTestData.getAccountNumber1());
		context.put("displayName", accountsAccountsCommonTestData.getDisplayName1());
		context.put("institutionName", accountsAccountsCommonTestData.getInstitutionName1());
		context.put("asOfDate", accountsAccountsCommonTestData.getAsOfDate1());

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList", not(empty()),
				"accountList[0].accountId.accountNumber",
				equalTo(accountsAccountsCommonTestData.getAccountNumber1()),
				"accountList[0].accountId.owner.id", equalTo(accountsAccountsCommonTestData.getPpid()),
				"accountList[0].regCode.mnemonic",
				equalTo(accountsAccountsCommonTestData.getMnemonic1()),
				"accountList[0].sourceMarketValue.amount.value",
				equalTo(accountsAccountsCommonTestData.getValue1()));

		// Gets and saves the CFP account ID
		accountsAccountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
		context.put("accId", accountsAccountsCommonTestData.getAccountId1());
	}

	/**
	 * Validate the account was created correctly.
	 */
	@Test(dependsOnMethods = "createWorkplaceAccount")
	public void getWorkplaceAccountAfterCreate()
	{

		// Setting Exclude external data sources flag
		this.request.given().header(new Header("excludeExternalDataSources", "true"));
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList", not(empty()),
				"accountList[0].accountId.accountNumber",
				equalTo(accountsAccountsCommonTestData.getAccountNumber1()),
				"accountList[0].accountId.owner.id", equalTo(accountsAccountsCommonTestData.getPpid()),
				"accountList[0].regCode.mnemonic",
				equalTo(accountsAccountsCommonTestData.getMnemonic1()),
				"accountList[0].sourceMarketValue.amount.value",
				equalTo(accountsAccountsCommonTestData.getValue1()));

	}

	/**
	 * Create the account contributions. Version V2
	 */
	@Test(dependsOnMethods = "getWorkplaceAccountAfterCreate")
	public void createAccountContributions()
	{

		this.request.given().header(new Header("user-fcps-id", accountsAccountsCommonTestData.getFcpsId()));

		// Generate request body
		context.put("contribValue", testData.getContributionValue());
		context.put("valueType", testData.getValueType());
		context.put("contribType", testData.getContributionType());
		context.put("contribTaxType", testData.getContributionTaxType());
		context.put("contribLevelType", testData.getContributionLevelType());
		context.put("frequency", testData.getFrequency());
		context.put("contributor", testData.getContributor());
		context.put("isDetailed", testData.getIsDetailed());

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
				not(empty()), "accountContributions[0].isDetailed ", equalTo(true),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ testData.getContributionValue() + "f}.contributionType",
						equalTo(testData.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ testData.getContributionValue() + "f}.contributionTaxType",
								equalTo(testData.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ testData.getContributionValue() + "f}.contributionLevelType",
										equalTo(testData.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ testData.getContributionValue() + "f}.contributor",
												equalTo(testData.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ testData.getContributionValue() + "f}.contribution.value",
														equalTo(Float.valueOf(testData.getContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ testData.getContributionValue() + "f}.frequency",
																equalTo(testData.getFrequency()));

	}

	/**
	 * Validate the contributions.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "createAccountContributions")
	public void getContributionsAfterCreate()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
				not(empty()), "accountContributions[0].isDetailed ", equalTo(true),
				"accountContributions[0].accountId.accountNumber",
				equalTo(accountsAccountsCommonTestData.getAccountNumber1()),
				"accountContributions[0].accountId.id",
				equalTo(accountsAccountsCommonTestData.getAccountId1()),
				"accountContributions[0].accountId.owner.id",
				equalTo(accountsAccountsCommonTestData.getPpid()),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ testData.getContributionValue() + "f}.contributionType",
						equalTo(testData.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ testData.getContributionValue() + "f}.contributionTaxType",
								equalTo(testData.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ testData.getContributionValue() + "f}.contributionLevelType",
										equalTo(testData.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ testData.getContributionValue() + "f}.contributor",
												equalTo(testData.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ testData.getContributionValue() + "f}.contribution.value",
														equalTo(Float.valueOf(testData.getContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ testData.getContributionValue() + "f}.frequency",
																equalTo(testData.getFrequency()));

	}

	/**
	 * Update the contribution.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "getContributionsAfterCreate")
	public void updateAccountContributions()
	{

		// Generate request body
		context.put("contribType", testData.getContributionType());
		context.put("contribTaxType", testData.getContributionTaxType());
		context.put("contribLevelType", testData.getContributionLevelType());
		context.put("frequency", updatedFrequency);
		context.put("contributor", testData.getContributor());
		context.put("valueType", PERCENT);
		context.put("contribValue", testData.getUpdatedContributionValue());
		context.put("isDetailed", false);

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_UPDATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.UPDATE_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
				not(empty()), "accountContributions[0].isDetailed ", equalTo(false),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ testData.getUpdatedContributionValue() + "f}.contributionType",
						equalTo(testData.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ testData.getUpdatedContributionValue() + "f}.contributionTaxType",
								equalTo(testData.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ testData.getUpdatedContributionValue() + "f}.contributionLevelType",
										equalTo(testData.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ testData.getUpdatedContributionValue() + "f}.contributor",
												equalTo(testData.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ testData.getUpdatedContributionValue() + "f}.contribution.value",
														equalTo(Float.valueOf(testData.getUpdatedContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ testData.getUpdatedContributionValue() + "f}.contribution.valueType",
																equalTo(PERCENT),
																"accountContributions[0].contributions.find{it.contribution.value=="
																		+ testData.getUpdatedContributionValue() + "f}.frequency",
																		equalTo(updatedFrequency));
	}

	/**
	 * Validate the contribution was updated.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "updateAccountContributions")
	public void getContributionsAfterUpdate()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
				not(empty()), "accountContributions[0].isDetailed ", equalTo(false),
				"accountContributions[0].accountId.accountNumber",
				equalTo(accountsAccountsCommonTestData.getAccountNumber1()),
				"accountContributions[0].accountId.id",
				equalTo(accountsAccountsCommonTestData.getAccountId1()),
				"accountContributions[0].accountId.owner.id",
				equalTo(accountsAccountsCommonTestData.getPpid()),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ testData.getUpdatedContributionValue() + "f}.contributionType",
						equalTo(testData.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ testData.getUpdatedContributionValue() + "f}.contributionTaxType",
								equalTo(testData.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ testData.getUpdatedContributionValue() + "f}.contributionLevelType",
										equalTo(testData.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ testData.getUpdatedContributionValue() + "f}.contributor",
												equalTo(testData.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ testData.getUpdatedContributionValue() + "f}.contribution.value",
														equalTo(Float.valueOf(testData.getUpdatedContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ testData.getUpdatedContributionValue() + "f}.contribution.valueType",
																equalTo(PERCENT),
																"accountContributions[0].contributions.find{it.contribution.value=="
																		+ testData.getUpdatedContributionValue() + "f}.frequency",
																		equalTo(updatedFrequency));

		final List<String> list = response.jsonPath()
				.getList("accountContributions[0].contributions.contribution.valueType");
		assertFalse(list.contains(MONEY));

	}

	/**
	 * Set the account contributions. Version V2
	 */
	@Test(dependsOnMethods = "getContributionsAfterUpdate")
	public void setAccountContributions()
	{
		// Generate request body
		context.put("contribValue", testData.getContributionValue());
		context.put("valueType", testData.getValueType());
		context.put("contribType", testData.getContributionType());
		context.put("contribTaxType", testData.getContributionTaxType());
		context.put("contribLevelType", testData.getContributionLevelType());
		context.put("frequency", testData.getFrequency());
		context.put("contributor", testData.getContributor());

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountConstants.SET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
		.body("accountContributions", not(empty()))
		.body("accountContributions[0].contributions.find{it.contribution.value=="
				+ testData.getContributionValue() + "f}.contributionType",
				equalTo(testData.getContributionType()),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ testData.getContributionValue()
						+ "f}.contributionTaxType",
						equalTo(testData.getContributionTaxType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ testData.getContributionValue()
								+ "f}.contributionLevelType",
								equalTo(testData.getContributionLevelType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ testData.getContributionValue() + "f}.contributor",
										equalTo(testData.getContributor()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ testData.getContributionValue()
												+ "f}.contribution.value",
												equalTo(Float.valueOf(testData.getContributionValue())),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ testData.getContributionValue() + "f}.frequency",
														equalTo(testData.getFrequency()));

	}

	/**
	 * Validate the contributions after set.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "setAccountContributions")
	public void getContributionsAfterSet()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
				"accountContributions[0].accountId.accountNumber",
				equalTo(accountsAccountsCommonTestData.getAccountNumber1()),
				"accountContributions[0].accountId.id",
				equalTo(accountsAccountsCommonTestData.getAccountId1()),
				"accountContributions[0].accountId.owner.id",
				equalTo(accountsAccountsCommonTestData.getPpid()),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ testData.getContributionValue() + "f}.contributionType",
						equalTo(testData.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ testData.getContributionValue() + "f}.contributionTaxType",
								equalTo(testData.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ testData.getContributionValue() + "f}.contributionLevelType",
										equalTo(testData.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ testData.getContributionValue() + "f}.contributor",
												equalTo(testData.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ testData.getContributionValue() + "f}.contribution.value",
														equalTo(Float.valueOf(testData.getContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ testData.getContributionValue() + "f}.frequency",
																equalTo(testData.getFrequency()));

	}

	/**
	 * Delete the contribution
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "getContributionsAfterSet")
	public void deleteAccountContributions()
	{

		// Generate request body
		context.put("contribType", testData.getContributionType());
		context.put("contribTaxType", testData.getContributionTaxType());
		context.put("contribLevelType", testData.getContributionLevelType());
		context.put("frequency", testData.getFrequency());
		context.put("contributor", testData.getContributor());
		context.put("valueType", testData.getValueType());
		context.put("contribValue", testData.getUpdatedContributionValue());
		context.put("isDetailed", false);

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_DELETE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.DELETE_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("isEmpty()",
				Matchers.is(true));

	}

	/**
	 * Validate the contributions were deleted.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "deleteAccountContributions")
	public void getContributionsAfterDelete()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("isEmpty()",
				Matchers.is(true));

	}

	/**
	 * Delete the account.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "getContributionsAfterDelete")
	public void deleteWorkplaceAccount()
	{

		context.put("id", accountsAccountsCommonTestData.getAccountId1());
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("isEmpty()",
				Matchers.is(true));
	}

	/**
	 * Validate the account was deleted. Version V2
	 */
	@Test(dependsOnMethods = "deleteWorkplaceAccount")
	public void getWorkplaceAccountAfterDelete()
	{

		this.request.given().header(new Header("excludeExternalDataSources", "true"));

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("isEmpty()",
				Matchers.is(true));

	}

	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");

		testDataUtil.closeSQLiteConnection();
	}

}
