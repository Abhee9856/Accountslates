/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.withdrawals.crud.fullview;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;

import com.fmr.ast.platform.account.domain.Withdrawal;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsWithdrawalsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.WithdrawalsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountWithdrawalsTestData;

import java.util.List;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operation for Fullview withdrawals against V1.
 *
 * @author a601767
 * Updated by a631781
 */
@Test(groups = {
        Tags.CRITICAL,
        Tags.FULLVIEW,
        Tags.WITHDRAWALS,
        Tags.V1,
        "PFCP-3499"})
public class Fullview_CRUD_v1 extends PAPBaseServiceTest {
    protected Fullview_CRUD_v1() {
        super(Services.Account);
    }

    private String mid;

    private String mnemonic;

    private String accountNumber;

    private String accountId;

    private String sourceSystem;

    private String displayName;

    private float value;

    private String institutionName;

    private String asOfDate;

    private VelocityContext context;

    private static final String LOG_TRACKING_ID = Fullview_CRUD_v1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_composite_CRUD_allDetails_Fullview", oAuth);
        mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        String ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate request context with user IDs
        context = new VelocityContext();

        context.put("mid", mid);
        context.put("ppid", ppid);
        context.put("source", "FULLVIEW");

    }

    /**
     * Get Fullview account info from the backend. Save the account number.
     */
    @Test
    public void getFullviewAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true));

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Create the Fullview account. Save the account id.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void createFullviewAccount() {
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountList[0].regCode.mnemonic", equalTo(mnemonic),
                        "accountList[0].accountId.accountNumber", equalTo(accountNumber));

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        context.put("accId", accountId);
    }

    /**
     * Validate the account was created correctly.
     */
    @Test(dependsOnMethods = "createFullviewAccount")
    public void getFullviewAccountAfterCreate() {
        // Generate request body
        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "accountList", not(empty()));


    }

    /**
     * The is the test flow. It iterates through the data provider, performing CRUD operations for each use case.
     *
     * @param data the test cases
     */
    @Test(dependsOnMethods = "createFullviewAccount", dataProvider = "getFullviewWithdrawalData",
            dataProviderClass = WithdrawalsDataProviderUtil.class)
    public void performCrudOperations(final AccountWithdrawalsTestData data) {
        this.createAccountWithdrawals(data);
        this.getWithdrawalsAfterCreate(data);
        this.updateAccountWithdrawals(data);
        this.getWithdrawalsAfterUpdate(data);
        this.deleteAccountWithdrawals(data);
        this.getWithdrawalsAfterDelete();
    }

    /**
     * Create the account withdrawals.
     */
    private void createAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("withdrawalType", data.getType());
        context.put("withdrawalValue", data.getAmountValue());
        context.put("valueType", data.getAmountValueType());
        context.put("frequency", data.getFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_TEMPLATE))
                .log().ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(mid))
                .body("accountWithdrawals", not(empty()))
                .body("accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.withdrawalType", equalTo(data.getType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.valueType", equalTo(data.getAmountValueType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.frequency", equalTo(data.getFrequency()));

    }

    /**
     * Validate the withdrawals.
     */
    private void getWithdrawalsAfterCreate(final AccountWithdrawalsTestData data) {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.withdrawalType", equalTo(data.getType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.valueType", equalTo(data.getAmountValueType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.frequency", equalTo(data.getFrequency()));

    }

    /**
     * Update the withdrawal.
     */
    private void updateAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("withdrawalType", data.getUpdatedType());
        context.put("withdrawalValue", data.getUpdatedAmountValue());
        context.put("valueType", data.getUpdatedAmountValueType());
        context.put("frequency", data.getUpdatedFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_UPDATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.UPDATE_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.withdrawalType", equalTo(data.getUpdatedType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getUpdatedAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.valueType", equalTo(data.getUpdatedAmountValueType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.frequency", equalTo(data.getUpdatedFrequency()));
    }

    /**
     * Validate the withdrawal was updated.
     */
    private void getWithdrawalsAfterUpdate(final AccountWithdrawalsTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.withdrawalType", equalTo(data.getUpdatedType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getUpdatedAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.valueType", equalTo(data.getUpdatedAmountValueType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.frequency", equalTo(data.getUpdatedFrequency()));

    }

    /**
     * Delete the withdrawal
     */
    private void deleteAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("withdrawalType", data.getUpdatedType());
        context.put("withdrawalValue", data.getUpdatedAmountValue());
        context.put("valueType", data.getUpdatedAmountValueType());
        context.put("frequency", data.getUpdatedFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.DELETE_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true));

        final List<Withdrawal> withdrawals =
                response.jsonPath().getList("accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals", Withdrawal.class);
        withdrawals.forEach(withdrawal -> {
            if (withdrawal.getAmount().getFrequency().value().equalsIgnoreCase(data.getFrequency())) {
                Assert.fail();
            }
        });

    }

    /**
     * Validate the withdrawals were deleted.
     */
    private void getWithdrawalsAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "accountWithdrawals", empty());

    }
}
