/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.get.digital;


import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;

import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.is;


/**
 * Tests for Digital Details Account
 *
 * @author a631781
 */

@Test(groups = {Tags.REGRESSION, Tags.DIGITAL, Tags.V1})
public class Digital_Details_Get_V1 extends PAPBaseServiceTest {

    protected Digital_Details_Get_V1() {
        super(Services.Account);
    }

    private static final String sourceSystem = "DIGITAL";

    public static final String ACCOUNT_CATEGORY = "InternalDigital, ExternalDigital";
    public static final String acctSubTypeDescInt = "Internal Digital Currency";
    public static final String acctSubTypeDescExt = "External Digital Currency";

    private String ssn;
    private String mid;
    private String sid;
    private String internalAccountNumber;
    private String externalAccountNumber;
    private String internalAccountNumberDSS;
    private String externalAccountNumberDSS;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Digital_Details_Get_V1.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String APP_NAME = "Advice and Planning Platform";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private Response accountResponse;
    private final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;
    private VelocityContext context;
    private FilterableRequestSpecification frs;

    private String linkedAccountsIntDSS;
    private String linkedAccountsExtDSS;

    private String sourceSystemInt;
    private String linkedAccountsInt;
    private String sourceSystemExt;
    private String linkedAccountsExt;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass

    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_digital", oAuth);

        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid().replace("-", "");

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ssn = accountsCommonTestData.getSsn();
        testDataUtil = new TestDataUtil();

        // Populate request context with user IDs
        context = new VelocityContext();

        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Test to get the DSS digital account
     * <p>
     * Version V2
     */
    @Test
    public void getDSS_V2() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.log().ifValidationFails().post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)));
        internalAccountNumberDSS = response.path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescInt + "'}.acctNum");
        externalAccountNumberDSS = response.path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescExt + "'}.acctNum");
    }

    /**
     * Tests that account data is brought back for Digital account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void getDigitalAccountInfo() {
        //Set Account Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        setRequestHeadersForAccount();
        // Generate request body
        context.put("source", sourceSystem);
        context.put("mid", mid);
        context.put("excludeExternalDataSources", "false");
        context.put("retailLid", ssn);
        context.put("digitalLid", ssn);
        context.put("pointOfEntry", "RETAIL");
        context.put("role", "FidCust");
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);
        request =
                request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        accountResponse = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        accountResponse.then().log().ifValidationFails().statusCode(200);
        Boolean resultCode = accountResponse.path("resultCode");
        Boolean dssResultCode =
        		accountResponse.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
        	Assert.assertEquals(dssResultCode, false);
        }

        accountResponse.then().body("userIdentifier.mid", equalTo(mid))
                .body("accountDetails", Matchers.not(Matchers.hasSize(0)));

    }

    /**
     * Test to validate Digital Account Details
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void validateResponse() {
        //Digital Account elements
        internalAccountNumber = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + internalAccountNumberDSS + "'}.accountId.accountNumber");
        sourceSystemInt = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + internalAccountNumber + "'}.accountId.sourceSystem");
        linkedAccountsInt = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + internalAccountNumber + "'}.linkedAccounts[0].accountNumber");

        externalAccountNumber = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + externalAccountNumberDSS + "'}.accountId.accountNumber");
        sourceSystemExt = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + externalAccountNumber + "'}.accountId.sourceSystem");
        linkedAccountsExt = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + externalAccountNumber + "'}.linkedAccounts[0].accountNumber");

        //Validating Account Digital elements
        Assert.assertEquals(internalAccountNumber, internalAccountNumberDSS);
        Assert.assertEquals(sourceSystemInt, sourceSystem);
        if (linkedAccountsIntDSS != null) {
            Assert.assertEquals(linkedAccountsInt, linkedAccountsIntDSS);
        }
        if (externalAccountNumberDSS != null) {
            Assert.assertEquals(externalAccountNumber, externalAccountNumberDSS);
            Assert.assertEquals(sourceSystemExt, sourceSystem);
            if (linkedAccountsExtDSS != null) {
                Assert.assertEquals(linkedAccountsExt, linkedAccountsExtDSS);
            }
        }
    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS() {
        this.request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", this.ssn))
                .header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
                .header(new Header("FACMC", "MID=" + this.mid))
                .header(new Header("FACFC", "SESSION_KEY=1"))
                .header(new Header("Content-Type", "application/json"));

    }

    /**
     * Setting headers for Account Service
     */
    private void setRequestHeadersForAccount() {
        // Account headers setup
        this.request.given()
                .header(new Header("realTimeData", "true"))
                .header(new Header("mauiCache", "no"));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        testDataUtil.closeSQLiteConnection();
    }
}