/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.v2.positions.crud.manual;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import io.restassured.http.Header;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


/**
 * Test class for V2 manual positions CRUD operations.
 *
 * @author a703000
 */
@Test(groups = {Tags.MANUAL, Tags.POSITIONS, Tags.V2, Tags.CRUD, "PFCP-18051"})
public class Manual_Positions_CRUD_V2_AdvisorInfo extends PAPBaseServiceTest
{

	public static final String LOG_TRACKING_ID = Manual_Positions_CRUD_V2_AdvisorInfo.class.getSimpleName();

	protected Manual_Positions_CRUD_V2_AdvisorInfo()
	{
		super(Services.Account);
	}


	// Data setup
	private String accountNumber;

	private String accountId;

	private String ppid;

	private String poe = "FRIAG";

	private String advisorLoginId = "7690041287";

	private String advisorRealmType = "FRIAG";

	private String advisorPlanNumber = "500958";

	private String gnumber = "G07492038";

	private final String sourceSystem = "MANUAL";
	
	private float value;
	
	private String mnemonic;

	private VelocityContext context;

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	// Financial Instrument IDs and their symbols
	private FinancialInstrumentIds finstIds;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
		finstIds = new FinancialInstrumentIds("FFIDX", "FENY", "QPISQ", "FEDTX");

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
		                LOG_TRACKING_ID, oAuth);

		this.request.given().header(new Header("user-poe", poe))
		                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
		                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
		                .header(new Header("advisor-login-id", advisorLoginId))
		                .header(new Header("advisor-realm-type", advisorRealmType))
		                .header(new Header("advisor-plan-number", advisorPlanNumber))
		                .header(new Header("gnumber", gnumber))
		                .header(new Header("excludeExternalDataSources", "false"));

		context = new VelocityContext();
	}

	@Test
	public void getRetailAccountInfo()
	{
		context.put("source", "RETAIL");

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList",
		                Matchers.notNullValue(), "accountList[0].accountId.accountNumber",
		                Matchers.notNullValue());

		accountNumber = response.path("accountList[0].accountId.accountNumber");
		ppid = response.path("accountList[0].accountId.owner.id");
		context.put("ppid", ppid);
	}

	/**
	 * Create manual accounts.
	 */
	@Test(dependsOnMethods = "getRetailAccountInfo")
	public void createManualAccounts()
	{
		value = 5000.0f;
		context.put("value", value);
		context.put("source", sourceSystem);
		String displayName = "Display_Name";
		context.put("displayName", displayName);
		String institutionName = "InstitutionalName";
		context.put("institutionName", institutionName);
		String asOfDate = "2014-10-31";
		context.put("asOfDate", asOfDate);
		mnemonic = "IRA";
		context.put("mnemonic", mnemonic);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList",
		                Matchers.not(empty()),
		                "accountList[0].regCode.mnemonic", Matchers.notNullValue(),
		                "accountList[0].accountId.accountNumber", Matchers.notNullValue());

		// Gets and saves the CFP account ID
		accountId = response
		                .path("accountList.accountId.find{it.owner.relationship=='PRINCIPAL'}.accountNumber");
		accountNumber = response
		                .path("accountList.accountId.find{it.owner.relationship=='PRINCIPAL'}.accountNumber");

		context.put("id", accountId);
		context.put("accountNumber", accountNumber);
	}

	/**
	 * Validate the accounts were created correctly.
	 */
	@Test(dependsOnMethods = "createManualAccounts")
	public void getManualAccountsAfterCreate()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList",
		                Matchers.not(empty()), "accountList[0].accountId.accountNumber",
		                Matchers.notNullValue(), "accountList.find{it.accountId.accountNumber=='" + accountId
		                                + "'}.accountId.accountNumber",
		                equalTo(accountNumber));
	}

	/**
	 * Get the positions before creation of positions
	 */
	@Test(dependsOnMethods = "getManualAccountsAfterCreate")
	public void getAccountPositionsBeforeCreatePosition()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("accountList",
		                Matchers.not(empty()), "accountList[0].account.accountId.sourceSystem",
		                equalTo(sourceSystem),
		                "accountList.account.accountId.find{it.id==\"" + accountId + "\"}.accountNumber",
		                equalTo(accountNumber),
		                "accountList.account.accountId.find{it.id==\"" + accountId + "\"}.id",
		                equalTo(accountId),
		                "accountList.account.accountId.find{it.id==\"" + accountId + "\"}.owner.id",
		                equalTo(ppid),
		                "accountList.account.accountId.find{it.id==\"" + accountId + "\"}.positions",
		                Matchers.nullValue());
	}

	/**
	 * Create positions
	 */
	@Test(dependsOnMethods = "getAccountPositionsBeforeCreatePosition")
	public void createAccountPositions()
	{
		context.put("positiondesc1", "Description 1");
		context.put("positionMarketVal1", 5000.0f);
		context.put("positionQuantity1", 100.5f);
		context.put("positionPrice1", 50.0f);
		context.put("costBasis1", 222);
		context.put("finstId2", finstIds.getFinstId("FENY"));
		context.put("symbol2", "FENY");
		context.put("type2", finstIds.getType("FENY"));
		context.put("name2", finstIds.getName("FENY"));

		context.put("positiondesc2", "Description 2");
		context.put("positionMarketVal2", 5000.0f);
		context.put("positionQuantity2", 100);
		context.put("positionPrice2", 50.0f);
		context.put("costBasis2", 444);
		context.put("finstId", finstIds.getFinstId("FFIDX"));
		context.put("symbol", "FFIDX");
		context.put("type", finstIds.getType("FFIDX"));
		context.put("name", finstIds.getName("FFIDX"));

		context.put("positiondesc3", "Description 3");
		context.put("positionMarketVal3", 5000.0f);
		context.put("positionQuantity3", 100);
		context.put("positionPrice3", 50.0f);
		context.put("costBasis3", 332);
		context.put("finstId3", finstIds.getFinstId("QPISQ"));
		context.put("symbol3", "QPISQ");
		context.put("type3", finstIds.getType("QPISQ"));
		context.put("name3", finstIds.getName("QPISQ"));

		context.put("positiondesc4", "Description 4");
		context.put("positionMarketVal4", 5000.0f);
		context.put("positionQuantity4", 100);
		context.put("positionPrice4", 50.0f);
		context.put("costBasis4", 332);
		context.put("finstId4", finstIds.getFinstId("FEDTX"));
		context.put("symbol4", "FEDTX");
		context.put("type4", finstIds.getType("FEDTX"));
		context.put("name4", finstIds.getName("FEDTX"));

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_VM));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("accountPositions",
		                notNullValue(), "accountPositions[0].account.accountId.sourceSystem",
		                equalTo(sourceSystem),
		                "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.accountNumber",
		                equalTo(accountNumber),
		                "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.id",
		                equalTo(accountId),
		                "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.owner.id",
		                equalTo(ppid),
		                "accountPositions.find{it.account.accountId.id==\"" + accountId
		                                + "\"}.positions.allPositions[0].financialAssetPosition.position.quantity",
		                equalTo(100.5f), "accountPositions.find{it.account.accountId.id==\"" + accountId
		                                + "\"}.positions.allPositions",
		                Matchers.notNullValue());
	}

	/**
	 * Get the positions after creation of positions
	 */
	@Test(dependsOnMethods = "createAccountPositions")
	public void getAccountPositionsAfterCreate()
	{
		context.put("mnemonicFilter", "IRA");

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
		                .body("accountList.find{it.account.accountId.id=='" + accountId
		                                + "'}.account.accountId.accountNumber", equalTo(accountNumber))
		                .body("accountList.find{it.account.accountId.id=='" + accountId
		                                + "'}.account.accountId.sourceSystem", equalTo(sourceSystem))
		                .body("accountList.find{it.account.accountId.id=='" + accountId
		                                + "'}.account.sourceMarketValue.amount.value", equalTo(value))
		                .body("accountList.find{it.account.accountId.id=='" + accountId
		                                + "'}.account.regCode.mnemonic", equalTo(mnemonic))
		                .body("accountList.find{it.account.accountId.id=='" + accountId
		                                + "'}.positions.allPositions[0].financialAssetPosition.position.marketValue.value",
		                                equalTo(5000.0F));
	}

	/**
	 * Update positions
	 */
	@Test(dependsOnMethods = "getAccountPositionsAfterCreate")
	public void updateAccountPositions()
	{
		context.put("positionMarketVal1", 3000.0f);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_VM));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("accountPositions",
		                notNullValue(), "accountPositions[0].account.accountId.sourceSystem",
		                equalTo(sourceSystem),
		                "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.accountNumber",
		                equalTo(accountNumber),
		                "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.id",
		                equalTo(accountId),
		                "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.owner.id",
		                equalTo(ppid),
		                "accountPositions.find{it.account.accountId.id==\"" + accountId
		                                + "\"}.positions.allPositions",
		                Matchers.notNullValue(),
		                "accountPositions.find{it.account.accountId.id==\"" + accountId
		                                + "\"}.positions.allPositions",
		                hasSize(1),
		                "accountPositions.find{it.account.accountId.id==\"" + accountId
		                                + "\"}.positions.allPositions[0]"
		                                + ".financialAssetPosition.position.marketValue.value",
		                equalTo(3000.0f)

		);
	}

	/**
	 * Get the positions after positions update
	 */
	@Test(dependsOnMethods = "updateAccountPositions")
	public void getAccountPositionsAfterUpdate()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
		                .body("accountList.find{it.account.accountId.id=='" + accountId
		                                + "'}.account.accountId.accountNumber", equalTo(accountNumber))
		                .body("accountList.find{it.account.accountId.id=='" + accountId
		                                + "'}.account.accountId.sourceSystem", equalTo(sourceSystem))
		                .body("accountList.find{it.account.accountId.id=='" + accountId
		                                + "'}.account.sourceMarketValue.amount.value", equalTo(value))
		                .body("accountList.find{it.account.accountId.id=='" + accountId
		                                + "'}.account.regCode.mnemonic", equalTo(mnemonic))
		                .body("accountList.find{it.account.accountId.id=='" + accountId
		                                + "'}.positions.allPositions[0].financialAssetPosition.position.marketValue.value",
		                                equalTo(3000.0F));
	}

	/**
	 * Deletes the manual accounts
	 */
	@Test(dependsOnMethods = "getAccountPositionsAfterUpdate")
	public void deleteManualAccount()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

		// Run test
		response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("isEmpty()",
		                Matchers.is(true));
	}

}
