/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.manual;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.hasSize;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.MatcherAssert;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.restassured.http.Header;

import java.time.ZonedDateTime;

/**
 * Tests Account Composite operation for a Manual account. Test will create, update, and delete a composite account and
 * run get requests before and after each of those operations.
 *
 * @author a623549
 *         <p>
 *         Updated by a608077 on 12/06/2021 to include: Changes for account level preferences(PFCP-6920) Updated by
 *         a608077 on 08/16/2022 to include: Changes for return-asset-allocation details(PFCP-9502) Updated by a608077
 *         on 05/23/2023 to include backdoor IRA changes(PFCP-12448) Updated by a608077 on 10/25/2023 to include 3 new
 *         asset classes: Private Equity, Private Credit, * and Real Assets(PFCP-13826)
 */
@Test(groups = {Tags.MANUAL, Tags.COMPOSITE, Tags.V2, Tags.CRITICAL})
public class Manual_Composite_v2_AllDetails extends PAPBaseServiceTest
{

	// Data setup
	private AccountsCommonTestData accountsCommonTestData;

	/** Global variable holding the oAuth token generated in the initClass method */
	private String oAuth;

	// Paths
	private String accountCompositeGetPath;

	private String accountCompositeCreatePath;

	private String accountCompositeUpdatePath;

	private String accountDeletePath;

	/**
	 * Instance to the test data utility class
	 */
	private TestDataUtil testDataUtil;

	// Financial Instrument IDs and their symbols
	private FinancialInstrumentIds finstIds;

	private static final String LOG_TRACKING_ID = Manual_Composite_v2_AllDetails.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	// Start and End years for accountPreferencesIA - both should be greater than the current year.
	int startYear = ZonedDateTime.now().plusYears(1).getYear();

	int endYear = ZonedDateTime.now().plusYears(2).getYear();

	private final String details = "accounts[0].details.manualAccountDetail.";

	private final String catchupPath = ".contributions.find{it.contributionType=='CATCHUP'}";

	private final String regularPath = ".contributions.find{it.contributionType=='REGULAR'}";

	private VelocityContext context;

	private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";

	private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";

	private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";

	private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";

	private final float netPercentage_T_ALTERNATIVE = 0.8f;

	private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;

	private final float netPercentage_PEA = 0.4f;

	private final float netPercentage_Updated_PEA = 0.2f;

	private final float netPercentage_PCA = 0.2f;

	private final float netPercentage_Updated_PCA = 0.3f;

	private final float netPercentage_PRAA = 0.2f;

	private final float netPercentage_Updated_PRAA = 0.1f;

	private static final String TRUSTEE_TYPE = "FPTC";

	private static final String TRUSTEE_TYPE_UPDATE = "ABCD";

	/**
	 * Constructor
	 */
	protected Manual_Composite_v2_AllDetails()
	{
		super(Services.Account);
	}

	/**
	 * Initialization method used to: </br>
	 * 1. Retrieve the oAuth token </br>
	 * 2. Retrieve the test data from SQLite DB & set up any other test data </br>
	 * 3. Set operation paths </br>
	 * 4. Build partial contents of the velocity context
	 */
	@BeforeClass(alwaysRun = true)
	public void initClass()
	{
		oAuth = AccountUtil.getOauthToken();
		testDataUtil = new TestDataUtil();

		accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN, oAuth);
		// accountsCommonTestData.setMid("ManualCompositeV2TestMid");
		DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


		// Data setup
		accountsCommonTestData.set("updatedAmount", "15000.0");
		accountsCommonTestData.set("contribFreq", "YEARLY");
		accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
		accountsCommonTestData.set("contribValue", "6000.0");
		accountsCommonTestData.set("updatedContribAmount", "500.0");
		accountsCommonTestData.set("withdrawAmount", "500.0");
		accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
		accountsCommonTestData.set("withdrawFreq", "YEARLY");
		accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
		accountsCommonTestData.set("detailValue", "42619.85");
		accountsCommonTestData.set("updatedDetailValue", "81819.89");
		accountsCommonTestData.set("value", "52619.85");
		accountsCommonTestData.set("updatedValue", "62619.85");
		accountsCommonTestData.setMnemonic1("IRA");
		accountsCommonTestData.setDisplayName1("Manual Composite CRUD RestAssured");
		accountsCommonTestData.setInstitutionName1("RETAIL");
		accountsCommonTestData.setSourceSystem1("MANUAL");
		accountsCommonTestData.setPpid(String
				.valueOf(Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth)));

		// Resolve finstIds
		finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

		// Set operation paths
		accountCompositeGetPath = AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2;
		accountCompositeCreatePath = AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2;
		accountCompositeUpdatePath = AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2;
		accountDeletePath = AccountsPaths.DELETE_ACCOUNT_V2;

		context = new VelocityContext();
	}

	/**
	 * Test setup method.
	 */
	@BeforeMethod(alwaysRun = true)
	public void init()
	{
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
				FSREQID, oAuth);
		request.header(new Header("user-poe", "RETAIL")).header(new Header("scenario-category-code", "DEF"))
		.header(new Header("scenario-product-code", "IGE"))
		.header(new Header("user-mid", accountsCommonTestData.getMid()))
		.header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));

	}

	/**
	 * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
	 *
	 * Description: Validates an empty account list when calling get account composite manual before creation of an
	 * account (v2)
	 */
	@Test
	public void getCompositeAccountManualV2BeforeCreate()
	{
		final VelocityContext context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		// Make post request
		response = request.log().ifValidationFails().post(accountCompositeGetPath);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
				hasSize(0));

	}

	/**
	 * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
	 *
	 * Description: Validates the account composite response after a create
	 */
	@Test(dependsOnMethods = {"getCompositeAccountManualV2BeforeCreate"})
	public void createCompositeAccountManualV2()
	{
		// Generate request body
		context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("source", accountsCommonTestData.getSourceSystem1());
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		context.put("mnemonic", accountsCommonTestData.getMnemonic1());
		context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
		context.put("value", accountsCommonTestData.get("value"));
		context.put("detailValue", accountsCommonTestData.get("detailValue"));
		context.put("contribValue", accountsCommonTestData.get("contribValue"));
		context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
		context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
		context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
		context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
		context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
		context.put("GBOND", finstIds.getFinstId("GBOND"));
		context.put("GCASH", finstIds.getFinstId("GCASH"));
		context.put("riskTolerance", 1);
		context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
		context.put("withdrawalStartYear", startYear);
		context.put("withdrawalEndYear", endYear);
		context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
		context.put("equityPercent", 0.35);
		context.put("originalOwnerBirthDate", "1958-11-09");
		context.put("originalOwnerDeceasedDate", "2022-11-09");
		context.put("withdrawalEligibilityStartDate", "2022-11-09");
		context.put("withdrawalEligibilityEndDate", "2052-11-09");
		context.put("originalOwnerSpouse", "false");
		context.put("federalTaxWithholding", 0.15);
		context.put("stateTaxWithholding", 0.05);
		context.put("assetClass1", "UNKNOWN");
		context.put("netPercentage1", 0.177);
		context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
		context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
		context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
		context.put("netPercentage_PEA", netPercentage_PEA);
		context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
		context.put("netPercentage_PCA", netPercentage_PCA);
		context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
		context.put("netPercentage_PRAA", netPercentage_PRAA);
		context.put("contribFreq", "YEARLY");
		context.put("contribValue", "500");
		context.put("contributionTaxType", "POST_TAX");
		context.put("contributionType", "CATCHUP");
		context.put("contributor", "EMPLOYER");
		context.put("contribFreq2", "BIMONTHLY");
		context.put("contribValue2", "900");
		context.put("contributionTaxType2", "AGGREGATE");
		context.put("contributionType2", "REGULAR");
		context.put("contributor2", "INDIVIDUAL");
		context.put("isBackdoorRoth", "true");
		context.put("trusteeType", TRUSTEE_TYPE);

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

		// Make post request
		response = request.log().ifValidationFails().post(accountCompositeCreatePath);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
		.body("accounts[0].account.accountId.owner.id",
				equalTo(accountsCommonTestData.getPpid()))
		.body("accounts[0].account.displayName",
				equalTo(accountsCommonTestData.getDisplayName1()))
		.body("accounts[0].account.regCode.mnemonic",
				equalTo(accountsCommonTestData.getMnemonic1()))
		.body("accounts[0].account.regCode.sourceSystem",
				equalTo(accountsCommonTestData.getSourceSystem1()))
		.body("accounts[0].account.institutionName",
				equalTo(accountsCommonTestData.getInstitutionName1()))
		.body("accounts[0].account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("value"))))
		.body("accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GDSTOCK")))
		.body("accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GFSTOCK")))
		.body("accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GBOND")))
		.body("accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GCASH")))
		.body(details + "accountDetail.costBasis.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))))
		.body(details + "state", equalTo("AK"))
		.body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(Float.valueOf(0)))
		.body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value",
				equalTo(0f))
		.body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value",
				equalTo(0f))
		.body("accounts[0].suitability.investmentObjective.targetAssetMix.name",
				equalTo("Short Term"))
		.body("accounts[0].details.manualAccountDetail.accountDetail.trusteeType",
				equalTo(TRUSTEE_TYPE))
		.body("accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(1))
		.body("accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent",
				equalTo("SELL_LESS_THAN_25"))
		.body("accounts[0].suitability.accountPreferencesIA.withdrawalStartYear",
				equalTo(startYear))
		.body("accounts[0].suitability.accountPreferencesIA.withdrawalEndYear",
				equalTo(endYear))
		.body("accounts[0].withdrawals[0].amount.amount.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))))
		.body("accounts[0].withdrawals[0].amount.frequency",
				equalTo(accountsCommonTestData.get("withdrawFreq")))
		.body(details + "accountDetail.complementaryAdjustmentOption",
				equalTo("MOVE_TO_MANAGED_ACCOUNT"))
		.body(details + "accountDetail.equityPercent", equalTo(0.35f))
		.body(details + "accountDetail.originalOwnerBirthDate",
				equalTo("1958-11-09T00:00:00.000+0000"))
		.body(details + "accountDetail.originalOwnerDeceasedDate",
				equalTo("2022-11-09T00:00:00.000+0000"))
		.body(details + "accountDetail.withdrawalEligibilityStartDate",
				equalTo("2022-11-09T00:00:00.000+0000"))
		.body(details + "accountDetail.withdrawalEligibilityEndDate",
				equalTo("2052-11-09T00:00:00.000+0000"))
		.body(details + "accountDetail.originalOwnerSpouse", equalTo(false))
		.body(details + "accountDetail.federalTaxWithholdingPercent", equalTo(0.15f))
		.body(details + "accountDetail.stateTaxWithholdingPercent", equalTo(0.05f))
		.body(details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"
				+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_T_ALTERNATIVE))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PCA))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PEA))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PRAA))
		.body("accounts[0].contributions" + catchupPath + ".contribution.value",
				equalTo(500.0f))
		.body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body("accounts[0].contributions" + catchupPath + ".contributionTaxType",
				equalTo("POST_TAX"))
		.body("accounts[0].contributions" + catchupPath + ".contributionType",
				equalTo("CATCHUP"))
		.body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body("accounts[0].contributions" + regularPath + ".contribution.value",
				equalTo(900.0f))
		.body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body("accounts[0].contributions" + regularPath + ".contributionTaxType",
				equalTo("AGGREGATE"))
		.body("accounts[0].contributions" + regularPath + ".contributionType",
				equalTo("REGULAR"))
		.body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
		.body("accounts[0].contributions" + ".isBackdoorRoth", equalTo(true))
		.body("accounts[0].suitability.investmentPurpose.values[0].value",
				equalTo("Save for education"))
		.body("accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
		.body("accounts[0].suitability.annualIncomeRange.values[0].value",
				equalTo("$0 to $25K"))
		.body("accounts[0].suitability.liquidNetworthRange.values[0].value",
				equalTo("$0 to $50K"))
		.body("accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
		.body("accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
		.body("accounts[0].suitability.essentialExpensesRange.values[0].value",
				equalTo("Under 25%"))
		.body("accounts[0].suitability.spendingLikelihoodRange.values[0].value",
				equalTo("Not Likely"))
		.body("accounts[0].suitability.investmentTimeHorizon.values[0].value",
				equalTo("Near Term (0-1 year)"));

		// Save account number and ID
		accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
		accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
		accountsCommonTestData.set("asOfDate", response.path("accounts[0].account.sourceMarketValue.asOfDate"));
	}

	/**
	 * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
	 *
	 * Description: Validates the account composite response after a create
	 */
	@Test(dependsOnMethods = "createCompositeAccountManualV2")
	public void getCompositeAccountManualV2AfterCreateEEDSFalse()
	{
		final VelocityContext context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		// Make post request
		response = request.log().ifValidationFails().post(accountCompositeGetPath);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
				"accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
				"accounts[0].account.accountId.accountNumber",
				equalTo(accountsCommonTestData.getAccountNumber1()),
				"accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
				"accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
				"accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
				"accounts[0].account.regCode.sourceSystem",
				equalTo(accountsCommonTestData.getSourceSystem1()),
				"accounts[0].account.institutionName",
				equalTo(accountsCommonTestData.getInstitutionName1()),
				"accounts[0].account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("value"))),
				"accounts[0].details.manualAccountDetail.accountDetail.trusteeType",
				equalTo(TRUSTEE_TYPE),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GDSTOCK")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GFSTOCK")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GBOND")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GCASH")), details + "accountDetail.costBasis.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))), details + "state",
				equalTo("AK"))
		.body(details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"
				+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_T_ALTERNATIVE))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PCA))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PEA))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PRAA),
				// suitability
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(0.0f),
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
				equalTo(0.0f),
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage.value",
				equalTo(1.0f),
				"accounts[0].suitability.investmentObjective.targetAssetMix.name",
				equalTo("Short Term"),
				"accounts[0].suitability.accountPreferencesIA.riskTolerance",
				equalTo(1),
				"accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent",
				equalTo("SELL_LESS_THAN_25"),
				"accounts[0].suitability.accountPreferencesIA.withdrawalStartYear",
				equalTo(startYear),
				"accounts[0].suitability.accountPreferencesIA.withdrawalEndYear",
				equalTo(endYear), "accounts[0].withdrawals[0].amount.amount.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
				"accounts[0].withdrawals[0].amount.frequency",
				equalTo(accountsCommonTestData.get("withdrawFreq")))
		.body("accounts[0].contributions" + catchupPath + ".contribution.value",
				equalTo(500.0f))
		.body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body("accounts[0].contributions" + catchupPath + ".contributionTaxType",
				equalTo("POST_TAX"))
		.body("accounts[0].contributions" + catchupPath + ".contributionType",
				equalTo("CATCHUP"))
		.body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body("accounts[0].contributions" + regularPath + ".contribution.value",
				equalTo(900.0f))
		.body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body("accounts[0].contributions" + regularPath + ".contributionTaxType",
				equalTo("AGGREGATE"))
		.body("accounts[0].contributions" + regularPath + ".contributionType",
				equalTo("REGULAR"))
		.body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
		.body("accounts[0].contributions" + ".isBackdoorRoth", equalTo(true))
		.body("accounts[0].suitability.investmentPurpose.values[0].value",
				equalTo("Save for education"))
		.body("accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
		.body("accounts[0].suitability.annualIncomeRange.values[0].value",
				equalTo("$0 to $25K"))
		.body("accounts[0].suitability.liquidNetworthRange.values[0].value",
				equalTo("$0 to $50K"))
		.body("accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
		.body("accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
		.body("accounts[0].suitability.essentialExpensesRange.values[0].value",
				equalTo("Under 25%"))
		.body("accounts[0].suitability.spendingLikelihoodRange.values[0].value",
				equalTo("Not Likely"))
		.body("accounts[0].suitability.investmentTimeHorizon.values[0].value",
				equalTo("Near Term (0-1 year)"));
	}

	@Test(dependsOnMethods = "getCompositeAccountManualV2AfterCreateEEDSFalse")
	public void getCompositeAccountManualV2AfterCreateEEDSFalseAndRCAMTrue()
	{
		final VelocityContext context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

		request.header(new Header("return-current-asset-allocation", "true"));

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		// Make post request
		response = request.log().ifValidationFails().post(accountCompositeGetPath);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
				"accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
				"accounts[0].account.accountId.accountNumber",
				equalTo(accountsCommonTestData.getAccountNumber1()),
				"accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
				"accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
				"accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
				"accounts[0].account.regCode.sourceSystem",
				equalTo(accountsCommonTestData.getSourceSystem1()),
				"accounts[0].account.institutionName",
				equalTo(accountsCommonTestData.getInstitutionName1()),
				"accounts[0].account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("value"))),
				"accounts[0].details.manualAccountDetail.accountDetail.trusteeType",
				equalTo(TRUSTEE_TYPE),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GDSTOCK")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GFSTOCK")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GBOND")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GCASH")), details + "accountDetail.costBasis.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))), details + "state",
				equalTo("AK"),
				/*
				 * below assetAllocation details attributes will be returned only when the header
				 * "return-current-asset-allocation" is true and the account has positions
				 */
				details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(0.5f),
				details + "accountDetail.assetAllocation.allocation[0].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
				equalTo(0.35f),
				details + "accountDetail.assetAllocation.allocation[0].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
				equalTo(0.15f),
				details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage.value",
				equalTo(0.1f),
				details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
				equalTo(0.4f)).body(
						// suitability
						"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
						equalTo(0.0f),
						"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.0f),
						"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage.value",
						equalTo(1.0f),
						"accounts[0].suitability.investmentObjective.targetAssetMix.name",
						equalTo("Short Term"),
						"accounts[0].suitability.accountPreferencesIA.riskTolerance",
						equalTo(1),
						"accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent",
						equalTo("SELL_LESS_THAN_25"),
						"accounts[0].suitability.accountPreferencesIA.withdrawalStartYear",
						equalTo(startYear),
						"accounts[0].suitability.accountPreferencesIA.withdrawalEndYear",
						equalTo(endYear), "accounts[0].withdrawals[0].amount.amount.value",
						equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
						"accounts[0].withdrawals[0].amount.frequency",
						equalTo(accountsCommonTestData.get("withdrawFreq")))
		.body("accounts[0].contributions" + catchupPath + ".contribution.value",
				equalTo(500.0f))
		.body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body("accounts[0].contributions" + catchupPath + ".contributionTaxType",
				equalTo("POST_TAX"))
		.body("accounts[0].contributions" + catchupPath + ".contributionType",
				equalTo("CATCHUP"))
		.body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body("accounts[0].contributions" + regularPath + ".contribution.value",
				equalTo(900.0f))
		.body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body("accounts[0].contributions" + regularPath + ".contributionTaxType",
				equalTo("AGGREGATE"))
		.body("accounts[0].contributions" + regularPath + ".contributionType",
				equalTo("REGULAR"))
		.body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
		.body("accounts[0].contributions" + ".isBackdoorRoth", equalTo(true))
		.body("accounts[0].suitability.investmentPurpose.values[0].value",
				equalTo("Save for education"))
		.body("accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
		.body("accounts[0].suitability.annualIncomeRange.values[0].value",
				equalTo("$0 to $25K"))
		.body("accounts[0].suitability.liquidNetworthRange.values[0].value",
				equalTo("$0 to $50K"))
		.body("accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
		.body("accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
		.body("accounts[0].suitability.essentialExpensesRange.values[0].value",
				equalTo("Under 25%"))
		.body("accounts[0].suitability.spendingLikelihoodRange.values[0].value",
				equalTo("Not Likely"))
		.body("accounts[0].suitability.investmentTimeHorizon.values[0].value",
				equalTo("Near Term (0-1 year)"));
	}

	@Test(dependsOnMethods = "createCompositeAccountManualV2")
	public void getCompositeAccountManualV2AfterCreateEEDSTrue()
	{

		context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

		FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
		frs.removeHeader("return-current-asset-allocation");
		frs.removeHeader("excludeExternalDataSources");

		this.request.header(new Header("excludeExternalDataSources", "true"));

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		// Make post request
		response = request.log().ifValidationFails().post(accountCompositeGetPath);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
				"accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
				"accounts[0].account.accountId.accountNumber",
				equalTo(accountsCommonTestData.getAccountNumber1()),
				"accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
				"accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
				"accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
				"accounts[0].account.regCode.sourceSystem",
				equalTo(accountsCommonTestData.getSourceSystem1()),
				"accounts[0].account.institutionName",
				equalTo(accountsCommonTestData.getInstitutionName1()),
				"accounts[0].account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("value"))),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GDSTOCK")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GFSTOCK")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GBOND")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GCASH")), details + "accountDetail.costBasis.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))), details + "state",
				equalTo("AK"), "accounts[0].details.manualAccountDetail.accountDetail.trusteeType",
				equalTo(TRUSTEE_TYPE))

		.body(details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"
				+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_T_ALTERNATIVE))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PCA))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PEA))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PRAA),
				// suitability
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(0.0f),
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
				equalTo(0.0f),
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage.value",
				equalTo(1.0f),
				"accounts[0].suitability.investmentObjective.targetAssetMix.name",
				equalTo("Short Term"),
				"accounts[0].suitability.accountPreferencesIA.riskTolerance",
				equalTo(1),
				"accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent",
				equalTo("SELL_LESS_THAN_25"),
				"accounts[0].suitability.accountPreferencesIA.withdrawalStartYear",
				equalTo(startYear),
				"accounts[0].suitability.accountPreferencesIA.withdrawalEndYear",
				equalTo(endYear), "accounts[0].withdrawals[0].amount.amount.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
				"accounts[0].withdrawals[0].amount.frequency",
				equalTo(accountsCommonTestData.get("withdrawFreq")))
		.body("accounts[0].contributions" + catchupPath + ".contribution.value",
				equalTo(500.0f))
		.body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body("accounts[0].contributions" + catchupPath + ".contributionTaxType",
				equalTo("POST_TAX"))
		.body("accounts[0].contributions" + catchupPath + ".contributionType",
				equalTo("CATCHUP"))
		.body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body("accounts[0].contributions" + regularPath + ".contribution.value",
				equalTo(900.0f))
		.body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body("accounts[0].contributions" + regularPath + ".contributionTaxType",
				equalTo("AGGREGATE"))
		.body("accounts[0].contributions" + regularPath + ".contributionType",
				equalTo("REGULAR"))
		.body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
		.body("accounts[0].contributions" + ".isBackdoorRoth", equalTo(true))
		.body("accounts[0].suitability.investmentPurpose.values[0].value",
				equalTo("Save for education"))
		.body("accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
		.body("accounts[0].suitability.annualIncomeRange.values[0].value",
				equalTo("$0 to $25K"))
		.body("accounts[0].suitability.liquidNetworthRange.values[0].value",
				equalTo("$0 to $50K"))
		.body("accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
		.body("accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
		.body("accounts[0].suitability.essentialExpensesRange.values[0].value",
				equalTo("Under 25%"))
		.body("accounts[0].suitability.spendingLikelihoodRange.values[0].value",
				equalTo("Not Likely"))
		.body("accounts[0].suitability.investmentTimeHorizon.values[0].value",
				equalTo("Near Term (0-1 year)"));
	}

	/**
	 * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
	 *
	 * Description: Validates the account composite response after an update
	 */
	@Test(dependsOnMethods = "getCompositeAccountManualV2AfterCreateEEDSTrue")
	public void updateCompositeAccountManualV2()
	{
		// Generate request body
		context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("accId", accountsCommonTestData.getAccountId1());
		context.put("source", accountsCommonTestData.getSourceSystem1());
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		context.put("mnemonic", accountsCommonTestData.getMnemonic1());
		context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
		context.put("value", accountsCommonTestData.get("updatedValue"));
		context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
		context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
		context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
		context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
		context.put("netPercentage_PEA", netPercentage_Updated_PEA);
		context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
		context.put("netPercentage_PCA", netPercentage_Updated_PCA);
		context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
		context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
		context.put("contribFreq", "YEARLY");
		context.put("contribValue", "600");
		context.put("contributionTaxType", "POST_TAX");
		context.put("contributionType", "CATCHUP");
		context.put("contributor", "EMPLOYER");
		context.put("contribFreq2", "BIMONTHLY");
		context.put("contribValue2", "700");
		context.put("contributionTaxType2", "AGGREGATE");
		context.put("contributionType2", "REGULAR");
		context.put("contributor2", "INDIVIDUAL");
		context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
		context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
		context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
		context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
		context.put("GBOND", finstIds.getFinstId("GBOND"));
		context.put("GCASH", finstIds.getFinstId("GCASH"));
		context.put("riskTolerance", 2);
		context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
		context.put("withdrawalStartYear", startYear);
		context.put("withdrawalEndYear", endYear);
		context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
		context.put("isBackdoorRoth", "false");
		context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));

		request.header(new Header("user-mid", accountsCommonTestData.getMid()))
		.header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));

		// Make post request
		response = request.log().ifValidationFails().post(accountCompositeUpdatePath);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body(
				"accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
				"accounts[0].account.accountId.accountNumber",
				equalTo(accountsCommonTestData.getAccountNumber1()),
				"accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
				"accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
				"accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
				"accounts[0].account.regCode.sourceSystem",
				equalTo(accountsCommonTestData.getSourceSystem1()),
				"accounts[0].account.institutionName",
				equalTo(accountsCommonTestData.getInstitutionName1()),
				"accounts[0].account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("updatedValue"))),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GDSTOCK")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GFSTOCK")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GBOND")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GCASH")), details + "accountDetail.costBasis.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("updatedDetailValue"))),
				details + "state", equalTo("AK"),
				"accounts[0].details.manualAccountDetail.accountDetail.trusteeType",
				equalTo(TRUSTEE_TYPE_UPDATE),
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(0f),
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value",
				equalTo(0f),
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value",
				equalTo(0f), "accounts[0].suitability.investmentObjective.targetAssetMix.name",
				equalTo("Short Term"))
		.body(details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"
				+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_T_ALTERNATIVE))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PCA))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PEA))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PRAA),
				"accounts[0].suitability.accountPreferencesIA.riskTolerance",
				equalTo(2),
				"accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent",
				equalTo("SELL_LESS_THAN_25"),
				"accounts[0].suitability.accountPreferencesIA.withdrawalStartYear",
				equalTo(startYear),
				"accounts[0].suitability.accountPreferencesIA.withdrawalEndYear",
				equalTo(endYear), "accounts[0].withdrawals[0].amount.amount.value",
				equalTo(Float.valueOf(
						accountsCommonTestData.get("updatedWithdrawAmount"))),
				"accounts[0].withdrawals[0].amount.frequency",
				equalTo(accountsCommonTestData.get("updatedWithdrawFreq")))
		.body(details + "accountDetail.complementaryAdjustmentOption",
				equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
		.body(details + "accountDetail.equityPercent", equalTo(0.35f))
		.body(details + "accountDetail.originalOwnerBirthDate",
				equalTo("1958-11-09T00:00:00.000+0000"))
		.body(details + "accountDetail.originalOwnerDeceasedDate",
				equalTo("2022-11-09T00:00:00.000+0000"))
		.body(details + "accountDetail.originalOwnerSpouse", equalTo(false))
		.body(details + "accountDetail.federalTaxWithholdingPercent", equalTo(0.15f))
		.body(details + "accountDetail.stateTaxWithholdingPercent", equalTo(0.05f))
		.body("accounts[0].contributions" + catchupPath + ".contribution.value",
				equalTo(600.0f))
		.body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body("accounts[0].contributions" + catchupPath + ".contributionTaxType",
				equalTo("POST_TAX"))
		.body("accounts[0].contributions" + catchupPath + ".contributionType",
				equalTo("CATCHUP"))
		.body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body("accounts[0].contributions" + regularPath + ".contribution.value",
				equalTo(700.0f))
		.body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body("accounts[0].contributions" + regularPath + ".contributionTaxType",
				equalTo("AGGREGATE"))
		.body("accounts[0].contributions" + regularPath + ".contributionType",
				equalTo("REGULAR"))
		.body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
		.body("accounts[0].contributions" + ".isBackdoorRoth", equalTo(false))
		.body("accounts[0].suitability.investmentPurpose.values[0].value",
				equalTo("Save for education"))
		.body("accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
		.body("accounts[0].suitability.annualIncomeRange.values[0].value",
				equalTo("$0 to $25K"))
		.body("accounts[0].suitability.liquidNetworthRange.values[0].value",
				equalTo("$0 to $50K"))
		.body("accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
		.body("accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
		.body("accounts[0].suitability.essentialExpensesRange.values[0].value",
				equalTo("Under 25%"))
		.body("accounts[0].suitability.spendingLikelihoodRange.values[0].value",
				equalTo("Not Likely"))
		.body("accounts[0].suitability.investmentTimeHorizon.values[0].value",
				equalTo("Near Term (0-1 year)"));
	}

	/**
	 * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
	 *
	 * Description: Validates the account composite response after an update
	 */
	@Test(dependsOnMethods = "updateCompositeAccountManualV2")
	public void getCompositeAccountManualV2AfterUpdate()
	{
		final VelocityContext context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		// Make post request
		response = request.log().ifValidationFails().post(accountCompositeGetPath);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
				"accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
				"accounts[0].account.accountId.accountNumber",
				equalTo(accountsCommonTestData.getAccountNumber1()),
				"accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
				"accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
				"accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
				"accounts[0].account.regCode.sourceSystem",
				equalTo(accountsCommonTestData.getSourceSystem1()),
				"accounts[0].account.institutionName",
				equalTo(accountsCommonTestData.getInstitutionName1()),
				"accounts[0].account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("updatedValue"))),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GDSTOCK")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GFSTOCK")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GBOND")),
				"accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
				equalTo(finstIds.getFinstId("GCASH")), details + "accountDetail.costBasis.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("updatedDetailValue"))),
				details + "state", equalTo("AK"),
				"accounts[0].details.manualAccountDetail.accountDetail.trusteeType",
				equalTo(TRUSTEE_TYPE_UPDATE),
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(0f),
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value",
				equalTo(0f),
				"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value",
				equalTo(0f), "accounts[0].suitability.investmentObjective.targetAssetMix.name",
				equalTo("Short Term"), "accounts[0].suitability.accountPreferencesIA.riskTolerance",
				equalTo(2), "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent",
				equalTo("SELL_LESS_THAN_25"),
				"accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
				"accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),
				"accounts[0].withdrawals[0].amount.amount.value",
				equalTo(Float.valueOf(accountsCommonTestData.get("updatedWithdrawAmount"))),
				"accounts[0].withdrawals[0].amount.frequency",
				equalTo(accountsCommonTestData.get("updatedWithdrawFreq")))
		.body("accounts[0].suitability.investmentPurpose.values[0].value",
				equalTo("Save for education"))
		.body(details + "accountDetail.complementaryAdjustmentOption",
				equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
		.body(details + "accountDetail.equityPercent", equalTo(0.35f))
		.body(details + "accountDetail.originalOwnerBirthDate",
				equalTo("1958-11-09T00:00:00.000+0000"))
		.body(details + "accountDetail.originalOwnerDeceasedDate",
				equalTo("2022-11-09T00:00:00.000+0000"))
		.body(details + "accountDetail.originalOwnerSpouse", equalTo(false))
		.body(details + "accountDetail.federalTaxWithholdingPercent", equalTo(0.15f))
		.body(details + "accountDetail.stateTaxWithholdingPercent", equalTo(0.05f))
		.body(details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"
				+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_T_ALTERNATIVE))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PCA))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PEA))
		.body(details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PRAA))
		.body("accounts[0].contributions" + catchupPath + ".contribution.value",
				equalTo(600.0f))
		.body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body("accounts[0].contributions" + catchupPath + ".contributionTaxType",
				equalTo("POST_TAX"))
		.body("accounts[0].contributions" + catchupPath + ".contributionType",
				equalTo("CATCHUP"))
		.body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body("accounts[0].contributions" + regularPath + ".contribution.value",
				equalTo(700.0f))
		.body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body("accounts[0].contributions" + regularPath + ".contributionTaxType",
				equalTo("AGGREGATE"))
		.body("accounts[0].contributions" + regularPath + ".contributionType",
				equalTo("REGULAR"))
		.body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
		.body("accounts[0].contributions" + ".isBackdoorRoth", equalTo(false))
		.body("accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
		.body("accounts[0].suitability.annualIncomeRange.values[0].value",
				equalTo("$0 to $25K"))
		.body("accounts[0].suitability.liquidNetworthRange.values[0].value",
				equalTo("$0 to $50K"))
		.body("accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
		.body("accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
		.body("accounts[0].suitability.essentialExpensesRange.values[0].value",
				equalTo("Under 25%"))
		.body("accounts[0].suitability.spendingLikelihoodRange.values[0].value",
				equalTo("Not Likely"))
		.body("accounts[0].suitability.investmentTimeHorizon.values[0].value",
				equalTo("Near Term (0-1 year)"));
	}

	/**
	 * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
	 *
	 * Description: Validates the account composite response after a delete
	 */
	@Test(dependsOnMethods = "getCompositeAccountManualV2AfterUpdate")
	public void deleteCompositeAccountManualV2()
	{
		final VelocityContext context = new VelocityContext();
		context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("accId", accountsCommonTestData.getAccountId1());
		context.put("source", accountsCommonTestData.getSourceSystem1());
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		context.put("mnemonic", accountsCommonTestData.getMnemonic1());
		context.put("institutionName", accountsCommonTestData.getInstitutionName1());
		context.put("value", accountsCommonTestData.get("updatedValue"));
		context.put("asOfDate", accountsCommonTestData.get("asOfDate"));

		request.header(new Header("user-mid", accountsCommonTestData.getMid()))
		.header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

		// Make post request
		response = request.post(accountDeletePath);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

		final String emptyResponse = response.jsonPath().getString("$");
		MatcherAssert.assertThat(emptyResponse, equalTo("[:]"));
	}

	/**
	 * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
	 *
	 * Description: Validates an empty account list when calling get account composite manual after delete
	 */
	@Test(dependsOnMethods = "deleteCompositeAccountManualV2")
	public void getCompositeAccountManualV2AfterDelete()
	{
		final VelocityContext context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", accountsCommonTestData.get("sourceSystem"));

		request.header(new Header("user-mid", accountsCommonTestData.getMid()))
		.header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
		.header(new Header("excludeExternalDataSources", "true"));

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
				hasSize(0));
	}

	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		testDataUtil.closeSQLiteConnection();
	}
}