/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.retail;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Tests Advisor Info for v1 CRUD operations for Retail accounts composite
 *
 * @author a631781
 * Updated by a608077 on 01/15/2025
 * to include -deleting an existing account before create
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.ACCOUNT,
		Tags.V1, Tags.TAM})
public class Retail_Composite_AdvisorInfo extends PAPBaseServiceTest
{

    protected Retail_Composite_AdvisorInfo()
    {
	super(Services.Account);
    }

    private VelocityContext context;

    private final float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String source = "RETAIL";

    private final String asOfDate1 = "2014-10-31";

    private final String displayName = "Retail Account Advisor Info";

    private String acctRoot;

    private String accId;

    private String accNumber;

    private String ppid;

    private String mnemonic;

    private final String poe = "FRIAG";

    private final String advisorId = "7690112176";

    private final String advisorRealm = "FRIAG";

    private final String advisorPlanNumber = "500958";

    private final String gnumber = "G07492038";

    private static final String tamName = "Growth with Income";
    private static final float tamTotalEquity = 0.60F;
    private static final float tamDomesticEquity = 0.42F;
    private static final float tamForeignEquity = 0.18F;
    private static final float tamBond = 0.35F;
    private static final float tamCash = 0.05F;

    private static final String tamCategory = "FINAL";
    private static final Integer tamRepositoryTamId = 179;
    private static final Integer tamAssetAllocationId = 60;
    private static final Integer tamAssetAllocationIdUpdate = 40;


    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
		
		final String oAuth = AccountUtil.getOauthToken();
	// Set default headers
	setDefaultRequestHeaders(oAuth);

	// Populate request variables
	context = new VelocityContext();

    }

    //Test Composite Account V1 for Advisor Info
    @Test
    public void performCrudOperations()
    {
	this.getRetailAccount();
	this.createRetailAccount();
	this.getRetailAccountAfterCreate();
	this.updateRetailAccount();
	this.getRetailAccountAfterUpdate();
	this.deleteRetailAccount();
    }

    //Get account info from the backend.
    private void getRetailAccount()
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", false);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	response.then().log().ifValidationFails().body("accounts", not(emptyArray()));
	accNumber = response.path("accounts[0].account.accountId.accountNumber");
	ppid = response.path("accounts[0].account.accountId.owner.id");
	mnemonic = response.path("accounts[0].account.regCode.mnemonic");


	    // Gets and saves the CFP account ID
	    String accountId = response.path("accounts[0].account.accountId.id");

	    if(null != response.path("accounts[0].account.accountId.id"))
	    {
		    //Data cleanup - delete the retail account before creating Retail account
		    context.put("accId", accountId);
		    this.deleteRetailAccount();

	    }
    }

    //Create Composite Retail Account
    private void createRetailAccount()
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", true);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	context.put("ppid", ppid);
	context.put("value", String.valueOf(value));
	context.put("mnemonic", mnemonic);
	context.put("sourceSystem2", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("accId", null);
	context.put("detailValue", "111111.11");
	context.put("emergencyFundAmount", "111111.11");
	context.put("assetClass1", "UNKNOWN");
	context.put("netPercentage1", 0.177);
	context.put("assetClass_T_Equity", "TOTAL_EQUITY");
	context.put("netPercentage_T_Equity", 0);
	context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
	context.put("netPercentage_FE", 0.0f);
	context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
	context.put("netPercentage_DE", 0.0f);
	context.put("TAM_name", tamName);
	context.put("TAM_repositoryTamId", tamRepositoryTamId);
	context.put("TAM_assetAllocationId", tamAssetAllocationId);
	context.put("TAM_category", tamCategory);
	context.put("TAM_total_equity", tamTotalEquity);
	context.put("TAM_domestic_equity", tamDomesticEquity);
	context.put("TAM_foreign_equity", tamForeignEquity);
	context.put("TAM_bond", tamBond);
	context.put("TAM_cash", tamCash);
	context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
	context.put("type", "RetailAccountDetails");
	context.put("contribFreq", "YEARLY");
	context.put("contribValue", "500");
	context.put("contributionTaxType", "POST_TAX");
	context.put("contributionType", "CATCHUP");
	context.put("contributor", "EMPLOYER");
	context.put("contribBasisTypeCd", "BASE");
	context.put("withdrawAmount", "1000");
	context.put("withdrawFreq", "DAILY");
	context.put("isProductSuitable", "false");
	context.put("riskTolerance", 2);
	context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
	context.put("withdrawalStartYear", 2055);
	context.put("withdrawalEndYear", 2085);
	context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
	context.put("equityPercent", 0.35);
	context.put("originalOwnerBirthDate", "1958-11-09");
	context.put("originalOwnerDeceasedDate", "2022-11-09");
	context.put("withdrawalEligibilityStartDate", "2022-11-09");
	context.put("withdrawalEligibilityEndDate", "2052-11-09");
	context.put("originalOwnerSpouse", "false");
	context.put("federalTaxWithholding", 0.15);
	context.put("stateTaxWithholding", 0.05);

	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

	response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);
	//Asset on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("userIdentifier.pointOfEntry", equalTo(poe))
			.body("userIdentifier.advisorInformation.advisorId", equalTo(advisorId))
			.body("userIdentifier.advisorInformation.advisorRealm", equalTo(advisorRealm))
			.body("userIdentifier.advisorInformation.advisorPlanNumber", equalTo(advisorPlanNumber))
			.body("accounts[0].account.accountId.accountNumber", equalTo(accNumber))
			.body("accounts[0].account.sourceMarketValue.amount.value", equalTo(value))
			.body("accounts[0].account.displayName", equalTo(displayName))
			.body("accounts[0].details.complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
			.body("accounts[0].details.originalOwnerBirthDate", equalTo("1958-11-09T00:00:00.000+0000"))
			.body("accounts[0].details.originalOwnerDeceasedDate", equalTo("2022-11-09T00:00:00.000+0000"))
			.body("accounts[0].details.withdrawalEligibilityStartDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body("accounts[0].details.withdrawalEligibilityEndDate",
					equalTo("2052-11-09T00:00:00.000+0000"))
			.body("accounts[0].details.originalOwnerSpouse", equalTo(false))
			.body("accounts[0].details.federalTaxWithholding.value", equalTo(0.15f))
			.body("accounts[0].details.stateTaxWithholding.value", equalTo(0.05f))
			.body("accounts[0].details.emergencyFundAmount.value", equalTo(111111.11f))
			.body("accounts[0].details.isProductSuitable", equalTo(false))
			.body("accounts[0].details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
					equalTo(0.177f))
			.body("accounts[0].details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(0f))
			.body("accounts[0].details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					equalTo(0.0f))
			.body("accounts[0].details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					equalTo(0.0f))
			.body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(tamTotalEquity))
			.body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					equalTo(tamDomesticEquity))
			.body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					equalTo(tamForeignEquity))
			.body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					equalTo(tamBond))
			.body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
					equalTo(tamCash))
			.body("accounts[0].details.targetAssetMixes.targetAssetMix[0].category", equalTo(tamCategory))
			.body("accounts[0].details.targetAssetMixes.targetAssetMix[0].name",
					equalTo(tamName))
			.body("accounts[0].details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(tamRepositoryTamId))
			.body("accounts[0].details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(tamAssetAllocationId))
			.body("accounts[0].contributions", notNullValue())
			.body("accounts[0].withdrawals", notNullValue())
			.body("accounts[0].withdrawals[0].amount.amount.value", equalTo(1000.0f))
			.body("accounts[0].withdrawals[0].amount.frequency", equalTo("DAILY"));

	accId = response.path("accounts[0].account.accountId.id");
    }

    //Get after create
    private void getRetailAccountAfterCreate()
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", true);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	acctRoot = "accounts.find{it.account.accountId.id=='" + accId + "'}.";
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("userIdentifier.pointOfEntry", equalTo(poe))
			.body("userIdentifier.advisorInformation.advisorId", equalTo(advisorId))
			.body("userIdentifier.advisorInformation.advisorRealm", equalTo(advisorRealm))
			.body("userIdentifier.advisorInformation.advisorPlanNumber", equalTo(advisorPlanNumber))
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(value))
			.body(acctRoot + "account.displayName", equalTo(displayName))
			.body(acctRoot + "details.complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
			.body(acctRoot + "details.originalOwnerBirthDate", equalTo("1958-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.originalOwnerDeceasedDate", equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.withdrawalEligibilityStartDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.withdrawalEligibilityEndDate",
					equalTo("2052-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.originalOwnerSpouse", equalTo(false))
			.body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.15f))
			.body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.05f))
			.body(acctRoot + "details.emergencyFundAmount.value", equalTo(111111.11f))
			.body(acctRoot + "details.isProductSuitable", equalTo(false))
			.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
					equalTo(0.177f))
			.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(0f))
			.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					equalTo(0.0f))
			.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					equalTo(0.0f))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(tamTotalEquity))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					equalTo(tamDomesticEquity))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					equalTo(tamForeignEquity))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					equalTo(tamBond))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
					equalTo(tamCash))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category", equalTo(tamCategory))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name",
					equalTo(tamName))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(tamRepositoryTamId))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(tamAssetAllocationId))
			.body(acctRoot + "contributions", notNullValue())
			.body(acctRoot + "withdrawals", notNullValue())
			.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(1000.0f))
			.body(acctRoot + "withdrawals[0].amount.frequency", equalTo("DAILY"));

    }

    //Update Retail Account
    private void updateRetailAccount()
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", true);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	context.put("ppid", ppid);
	context.put("value", String.valueOf(updatedValue));
	context.put("mnemonic", mnemonic);
	context.put("sourceSystem2", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("accId", accId);
	context.put("detailValue", "111111.11");
	context.put("emergencyFundAmount", "111111.11");
	context.put("assetClass1", "UNKNOWN");
	context.put("netPercentage1", 0.177);
	context.put("assetClass_T_Equity", "TOTAL_EQUITY");
	context.put("netPercentage_T_Equity", 0);
	context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
	context.put("netPercentage_FE", 0.0f);
	context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
	context.put("netPercentage_DE", 0.0f);
	context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
	context.put("type", "RetailAccountDetails");
	context.put("contribFreq", "YEARLY");
	context.put("contribValue", "500");
	context.put("contributionTaxType", "POST_TAX");
	context.put("contributionType", "CATCHUP");
	context.put("contributor", "EMPLOYER");
	context.put("contribBasisTypeCd", "BASE");
	context.put("withdrawAmount", "1000");
	context.put("withdrawFreq", "DAILY");
	context.put("isProductSuitable", "false");
	context.put("riskTolerance", 2);
	context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
	context.put("withdrawalStartYear", 2055);
	context.put("withdrawalEndYear", 2085);
	context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
	context.put("equityPercent", 0.35);
	context.put("originalOwnerBirthDate", "1958-11-09");
	context.put("originalOwnerDeceasedDate", "2022-11-09");
	context.put("withdrawalEligibilityStartDate", "2022-11-09");
	context.put("withdrawalEligibilityEndDate", "2052-11-09");
	context.put("originalOwnerSpouse", "false");
	context.put("federalTaxWithholding", 0.15);
	context.put("stateTaxWithholding", 0.05);

	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

	response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);
	//Asset on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("userIdentifier.pointOfEntry", equalTo(poe))
			.body("userIdentifier.advisorInformation.advisorId", equalTo(advisorId))
			.body("userIdentifier.advisorInformation.advisorRealm", equalTo(advisorRealm))
			.body("userIdentifier.advisorInformation.advisorPlanNumber", equalTo(advisorPlanNumber))
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(updatedValue))
			.body(acctRoot + "account.displayName", equalTo(displayName))
			.body(acctRoot + "details.complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
			.body(acctRoot + "details.originalOwnerBirthDate", equalTo("1958-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.originalOwnerDeceasedDate", equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.withdrawalEligibilityStartDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.withdrawalEligibilityEndDate",
					equalTo("2052-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.originalOwnerSpouse", equalTo(false))
			.body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.15f))
			.body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.05f))
			.body(acctRoot + "details.emergencyFundAmount.value", equalTo(111111.11f))
			.body(acctRoot + "details.isProductSuitable", equalTo(false))
			.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
					equalTo(0.177f))
			.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(0f))
			.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					equalTo(0.0f))
			.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					equalTo(0.0f))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(tamTotalEquity))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					equalTo(tamDomesticEquity))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					equalTo(tamForeignEquity))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					equalTo(tamBond))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
					equalTo(tamCash))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category", equalTo(tamCategory))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name",
					equalTo(tamName))
			.body(acctRoot + "contributions", notNullValue())
			.body(acctRoot + "withdrawals", notNullValue())
			.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(1000.0f))
			.body(acctRoot + "withdrawals[0].amount.frequency", equalTo("DAILY"));

    }

    // Get after Update
    private void getRetailAccountAfterUpdate()
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", true);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("userIdentifier.pointOfEntry", equalTo(poe))
			.body("userIdentifier.advisorInformation.advisorId", equalTo(advisorId))
			.body("userIdentifier.advisorInformation.advisorRealm", equalTo(advisorRealm))
			.body("userIdentifier.advisorInformation.advisorPlanNumber", equalTo(advisorPlanNumber))
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(updatedValue))
			.body(acctRoot + "account.displayName", equalTo(displayName))
			.body(acctRoot + "details.complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
			.body(acctRoot + "details.originalOwnerBirthDate", equalTo("1958-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.originalOwnerDeceasedDate", equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.withdrawalEligibilityStartDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.withdrawalEligibilityEndDate",
					equalTo("2052-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.originalOwnerSpouse", equalTo(false))
			.body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.15f))
			.body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.05f))
			.body(acctRoot + "details.emergencyFundAmount.value", equalTo(111111.11f))
			.body(acctRoot + "details.isProductSuitable", equalTo(false))
			.body(acctRoot
							+ "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
					equalTo(0.177f))
			.body(acctRoot
							+ "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(0f))
			.body(acctRoot
							+ "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					equalTo(0.0f))
			.body(acctRoot
							+ "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					equalTo(0.0f))
			.body(acctRoot
							+ "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(0.6f))
			.body(acctRoot
							+ "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					equalTo(0.42f))
			.body(acctRoot
							+ "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					equalTo(0.18f))
			.body(acctRoot
							+ "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					equalTo(0.35f))
			.body(acctRoot
							+ "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
					equalTo(0.05f))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category", equalTo("FINAL"))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name",
					equalTo("Growth with Income"))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(179))
			.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(60))
			.body(acctRoot + "contributions", notNullValue())
			.body(acctRoot + "withdrawals", notNullValue())
			.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(1000.0f))
			.body(acctRoot + "withdrawals[0].amount.frequency", equalTo("DAILY"));

    }

    //Delete Retail Account
    private void deleteRetailAccount()
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", true);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	context.put("ppid", ppid);
	context.put("value", String.valueOf(value));
	context.put("mnemonic", mnemonic);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("id", accId);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

	// Call Account service response
	request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

    }
}
