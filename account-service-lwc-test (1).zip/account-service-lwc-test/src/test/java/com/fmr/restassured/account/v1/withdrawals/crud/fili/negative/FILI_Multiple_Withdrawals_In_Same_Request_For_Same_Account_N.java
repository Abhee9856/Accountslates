/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.withdrawals.crud.fili.negative;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsWithdrawalsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.*;

/**
 * The objective of this test is to verify the principal FILI account withdrawal cannot create 2 withdrawals through same create request.
 * Test flow:
 * 1. Create identity
 * 2. Create FILI account
 * 3. Create and verify withdrawal service
 * 4. Get and verify withdrawal service
 * 5. Create another withdrawal(Expected Results is to Fail the test with error: "Could not insert withdrawals data to database!")
 * 6. Delete identity
 *
 * @author a608077
 */
@Test(groups = {
        Tags.FILI,
        Tags.WITHDRAWALS,
        Tags.V1,
        Tags.NEGATIVE,
        "PFCP-4873"})

public class FILI_Multiple_Withdrawals_In_Same_Request_For_Same_Account_N extends PAPBaseServiceTest {
    // Data setup
    private AccountsCommonTestData accountsCommonTestData;
    private String mid;
    private String ppid;
    private String accountNumber;
    private final String sourceSystem = "FILI";

    private VelocityContext context;
    private static final String LOG_TRACKING_ID = FILI_Multiple_Withdrawals_In_Same_Request_For_Same_Account_N.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private TestDataUtil testDataUtil;

    protected FILI_Multiple_Withdrawals_In_Same_Request_For_Same_Account_N() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_withdrawals_multiple withdrawals for same account Fili_N",oAuth);
        testDataUtil = new TestDataUtil();
        mid = accountsCommonTestData.getMid();

        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate request context with user IDs
        context = new VelocityContext();
        context.put("mid", mid);
        context.put("ppid", ppid);
        context.put("source", sourceSystem);
        context.put("filiLid", accountsCommonTestData.getSsn());

    }

    /**
     * Get FILI account info from the backend. Save the account number.
     */
    @Test
    public void getFiliAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);


        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("accountList", not(empty()));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Create a FILI account
     */
    @Test(dependsOnMethods = "getFiliAccountInfo")
    public void createFILIAccount() {

        context.put("pointOfEntry", "RETAIL");
        context.put("ppid", ppid);
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);


        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", Matchers.equalTo(true))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        // Gets and saves the CFP account ID
        String accountId = response.path("accountList[0].accountId.id");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        context.put("accId", accountId);
        context.put("accId2", accountId);
        context.put("accountNumber", accountNumber);
        context.put("accountNumber2", accountNumber);
    }

    /**
     * Tests that account data is brought back for FILI account.
     * Version V1
     */
    @Test(dependsOnMethods = "createFILIAccount")
    public void verifyAfterCreate() {

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Set URL to V1 before running again
        response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);


        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", Matchers.equalTo(true))
                .body("userIdentifier.mid", Matchers.equalTo(mid))
                .body("accountList", Matchers.not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", Matchers.equalTo(sourceSystem));


    }

    /**
     * Create the account withdrawals.
     */
    @Test(dependsOnMethods = "verifyAfterCreate")
    public void createAccountWithdrawals() {

        // Generate request body
        context.put("accountNumber", accountNumber);
        context.put("accountNumber2", accountNumber);
        context.put("frequency", "HOURLY");
        context.put("frequencyValue", "456");
        context.put("withdrawalType", "Regular");
        context.put("withdrawalValue", "500");
        context.put("valueType", "MONEY");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_TEMPLATE))
                .log().ifValidationFails();


        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V1);


        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(false))
                .body("userIdentifier.mid", equalTo(mid))
                .body("errorString", equalTo("Could not insert withdrawals data to database!"));

    }

    /**
     * Verifies the withdrawal was created correctly for the account.
     */
    @Test(dependsOnMethods = "createAccountWithdrawals")
    public void verifyWithdrawalAfterCreate() {
        // Generate new request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_TEMPLATE));

        response = request.post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V1);


        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", Matchers.equalTo(true))
                .body("accountWithdrawals", empty());
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
