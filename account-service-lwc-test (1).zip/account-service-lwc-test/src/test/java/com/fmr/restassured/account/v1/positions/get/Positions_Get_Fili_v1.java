/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.positions.get;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.empty;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.PositionsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountPositionsTestData;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests account positions get for Fili accounts. Starts by retrieving a Fili account,
 * and then retrieving positions from backend.
 *
 * @author a608077
 */
@Test(groups = {
        Tags.FILI,
        Tags.POSITIONS,
        Tags.V1})

public class Positions_Get_Fili_v1 extends PAPBaseServiceTest {
    protected Positions_Get_Fili_v1() {
        super(Services.Account);
    }

    private String mid;
    private String ppid;
    private String mnemonic;
    private String accountNumber;
    private String sourceSystem;
    private String displayName;
    private float value;

    private VelocityContext context;
    private static final String LOG_TRACKING_ID = Positions_Get_Fili_v1.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();

        // Data setup
        AccountsCommonTestData accountsCommonTestData =
                        TestDataUtil.populateRegressionTestData("account_CRUD_RK_FILI_70", oAuth);
        mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate request context with user IDs
        context = new VelocityContext();

        context.put("mid", mid);
        context.put("filiLid", accountsCommonTestData.getSsn());
        context.put("ppid", ppid);
        context.put("source", "FILI");
    }

    /**
     * Get FILI account info from the backend. Save the account number.
     */
    @Test
    public void getFiliAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("accountList", Matchers.not(empty()));

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");

    }
    /**
     * Validate the positions.
     */
    @Test(dependsOnMethods = "getFiliAccountInfo")
    public void getPositions() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_POSITIONS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(mid))
                .body("accountList[0].account.accountId.sourceSystem", equalTo(sourceSystem))
                .body("accountList[0].account.accountId.accountNumber", equalTo(accountNumber))
                .body("accountList[0].account.regCode.mnemonic", equalTo(mnemonic))
                .body("accountList[0].account.displayName", equalTo(displayName))
                .body("accountList[0].account.accountId.owner.id", equalTo(ppid))
                .body("accountList[0].account.sourceMarketValue.amount.value", equalTo(value))
                .body("accountList.account.accountId.find{it.accountNumber==\"" + accountNumber + "\"}.positions", Matchers.nullValue());

    }

}
