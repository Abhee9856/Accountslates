/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.withdrawals.crud.manual.negative;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.emptyArray;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsWithdrawalsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * The objective of this test is to verify the principal manual account withdrawal cannot create 2 withdrawals through separate create requests.
 * Test flow:
 * 1. Create identity
 * 2. Create Manual account
 * 3. Create and verify withdrawal service
 * 4. Get and verify withdrawal service
 * 5. Create another withdrawal(Expected Results is to Fail the test with error: "Could not insert withdrawals data to database!")
 * 6. Delete identity
 *
 * @author a608077
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.WITHDRAWALS,
        Tags.V1,
        Tags.NEGATIVE,
        "PFCP-4873"})

public class Manual_Multiple_Withdrawals_For_Same_Account_N extends PAPBaseServiceTest {

    private String mid;
    private String ppid;
    private String accountNumber;
    private final String sourceSystem = "MANUAL";

    private VelocityContext context;
    private static final String LOG_TRACKING_ID = Manual_Multiple_Withdrawals_For_Same_Account_N.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private TestDataUtil testDataUtil;

    protected Manual_Multiple_Withdrawals_For_Same_Account_N() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("accountCRUD_Manual", oAuth);
        testDataUtil = new TestDataUtil();
        mid = accountsCommonTestData.getMid();

        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate request context with user IDs
        context = new VelocityContext();
        context.put("mid", mid);
        context.put("ppid", ppid);
        context.put("source", sourceSystem);

    }

    /**
     * Create a manual account
     */
    @Test
    public void createManualAccount() {

        float value = 818.89f;
        context.put("pointOfEntry", "RETAIL");
        context.put("ppid", ppid);
        context.put("mnemonic", "IRA");
        context.put("value", value);
        String asOfDate1 = "2014-10-31";
        context.put("asOfDate", asOfDate1);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);


        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", Matchers.equalTo(true))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        // Gets and saves the CFP account ID
        String accountId = response.path("accountList[0].accountId.id");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        context.put("accId", accountId);
        context.put("accountNumber", accountNumber);

    }

    /**
     * Tests that account data is brought back for manual account.
     * Version V1
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void verifyAfterCreate() {

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Set URL to V1 before running again
        response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);


        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", Matchers.equalTo(true))
                .body("userIdentifier.mid", Matchers.equalTo(mid))
                .body("accountList", Matchers.not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", Matchers.equalTo(sourceSystem));


    }

    /**
     * Create the account withdrawals.
     */
    @Test(dependsOnMethods = "verifyAfterCreate")
    public void createAccountWithdrawals() {

        // Generate request body
        context.put("accountNumber", accountNumber);
        context.put("frequency", "HOURLY");
        context.put("frequencyValue", "456");
        context.put("withdrawalType", "Regular");
        context.put("withdrawalValue", "500");
        context.put("valueType", "MONEY");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_TEMPLATE))
                .log().ifValidationFails();


        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V1);


        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(mid))
                .body("accountWithdrawals[0].accountId.accountNumber", Matchers.equalTo(accountNumber))
                .body("accountWithdrawals[0].accountId.owner.id", Matchers.equalTo(ppid))
                .body("accountWithdrawals[0].withdrawals[0].amount.amount.value", Matchers.equalTo(500f))
                .body("accountWithdrawals[0].withdrawals[0].amount.frequency", Matchers.equalTo("HOURLY"));

    }

    /**
     * Verifies the withdrawal was created correctly for the account.
     */
    @Test(dependsOnMethods = "createAccountWithdrawals")
    public void verifyWithdrawalAfterCreate() {
        // Generate new request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_TEMPLATE));

        response = request.post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V1);

        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", Matchers.equalTo(true))
                .body("accountWithdrawals[0].accountId.accountNumber", Matchers.equalTo(accountNumber))
                .body("accountWithdrawals[0].accountId.owner.id", Matchers.equalTo(ppid))
                .body("accountWithdrawals[0].withdrawals[0].amount.amount.value", Matchers.equalTo(500f))
                .body("accountWithdrawals[0].withdrawals[0].amount.frequency", Matchers.equalTo("HOURLY"));
    }

    /**
     * Create Another withdrawal for Principal
     */
    @Test(dependsOnMethods = "verifyWithdrawalAfterCreate")
    public void createAccountWithdrawals2() {

        // Generate request body
        context.put("accountNumber", accountNumber);
        context.put("frequency", "HOURLY");
        context.put("frequencyValue", "456");
        context.put("withdrawalType", "Regular");
        context.put("withdrawalValue", "500");
        context.put("valueType", "MONEY");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_TEMPLATE))
                .log().ifValidationFails();


        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V1);


        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(false))
                .body("userIdentifier.mid", equalTo(mid))
                .body("errorString", equalTo("Could not insert withdrawals data to database!"));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
