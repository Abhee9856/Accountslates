/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.crud.fullview;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.Matchers.emptyArray;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.specification.FilterableRequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.assertj.core.api.Assertions;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.http.Header;

/**
 * Tests Account Details V2 for isFullviewDetailOverridden combinations for Fullview Account
 *
 * @author a631781
 */
@Test(groups = {Tags.FULLVIEW, Tags.CRUD, Tags.V2, Tags.REGRESSION})
public class Fullview_Details_isFullviewDetailOverridden_v2 extends PAPBaseServiceTest {

    Logger logger = LogManager.getLogger(getClass());

    protected Fullview_Details_isFullviewDetailOverridden_v2() {
        super(Services.Account);
    }

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private String ppid;

    // Test data
    private String accountId;

    private String sourceSystem = "FULLVIEW";
    private String displayName;

    private String mid;
    private String sid;

    private String mnemonic;

    private String asOfDate;

    private VelocityContext context;

    private float value = 818.89f;

    private final float updatedValue = 426.85f;

    private String accountNumber;

    private String institutionName;
    private float historicMarketValue = 8888f;
    private float historicMarketValueResponse;
    private Boolean isFullviewDetailOverridden;
    private Boolean isFullviewDetailOverriddenReq;
    private String acctRoot;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private FilterableRequestSpecification frs;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        p2TestDataUtil = new TestDataUtil();

        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_FV, oAuth);
        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



        ppid = Identity.createHouseholdIdentity(mid, oAuth);
        logger.debug("New PpID created from Identity : " + ppid);
        // Data setup
        accountsCommonTestData.setPpid(ppid);

        logger.debug("OwnerID from Accounts : " + accountsCommonTestData.getPpid());
        // Endpoint setup
        setDefaultRequestHeaders(oAuth);
        request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-sid", sid))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
        // Populate request variables
        context = new VelocityContext();
        context.put("source", sourceSystem);
        frs = (FilterableRequestSpecification) request;

    }

    /**
     * Create Fullview account Details with different combination of isFullviewDetailOverridden from DataProvider.
     * <p>
     * Version V2
     */
    @Test(dataProvider = "getFullViewData",
            dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data) {
        getFullviewAccountInfo();
        createFullviewAccount();
        createAccountDetails();
        getDetailsAfterCreate();
        updateAccountDetails(data);
        getDetailsAfterUpdate();
        deleteFullviewAccount();
    }

    //Get Fullview Account
    private void getFullviewAccountInfo() {
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "false"));
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", Matchers.not(emptyArray()));

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Creates a new Fullview account
     * <p>
     * Version V2
     */

    private void createFullviewAccount() {
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "true"));
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);
        context.put("id", "");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(200)
                .body("accountList", notNullValue())
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(value));
        accountId = response.path("accountList[0].accountId.id");

    }

    /**
     * Create FV account Details Request.
     * <p>
     * Version V2
     */
    private void createAccountDetails() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("accId", accountId);
        context.put("isInherited", true);
        context.put("isPreviousEmployersAccount", true);
        context.put("state", "NC");
        context.put("type", "fullviewAccountDetail");
        context.put("_type", "FullviewAccountDetails");
        context.put("isFullviewDetailOverridden", "");
        context.put("historicMarketValue", "");
        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));
        // Call Account service
        response =
                request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails", notNullValue())
                .body("accountDetails[0].fullviewAccountDetail.historicMarketValue.amount.value", equalTo(value));

    }


    /**
     * Validate the FV account.
     * <p>
     * Version V2
     */
    private void getDetailsAfterCreate() {
        // Generate request body
        context.put("sourceBasedRegistrationFilter", sourceSystem);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
        acctRoot = "accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.accountNumber='" + accountNumber + "'}.";
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body(acctRoot + "fullviewAccountDetail.accountDetail.accountId.id", equalTo(accountId))
                .body(acctRoot + "fullviewAccountDetail.accountDetail.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "fullviewAccountDetail.accountDetail.accountId.sourceSystem", equalTo(sourceSystem))
                .body(acctRoot + "fullviewAccountDetail.historicMarketValue.amount.value", equalTo(value));

    }

    /**
     * Update the details for FV account.
     * <p>
     * Version V2
     */
    private void updateAccountDetails(final AccountRegCodeTestData data) {
        // Generate request body
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "false"));
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", updatedValue);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("accId", accountId);
        context.put("isInherited", false);
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "fullviewAccountDetail");
        context.put("_type", "FullviewAccountDetails");
        context.put("historicMarketValue", historicMarketValue);
        if (data.getIsFullviewDetailOverridden().equals("Y")) {
            isFullviewDetailOverriddenReq = true;
            isFullviewDetailOverridden = true;

        } else if (data.getIsFullviewDetailOverridden().equals("N")) {
            isFullviewDetailOverriddenReq = false;
            isFullviewDetailOverridden = false;
        } else {
            isFullviewDetailOverriddenReq = null;
            isFullviewDetailOverridden = false;
        }

        context.put("isFullviewDetailOverridden", isFullviewDetailOverriddenReq);

        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE_V2));
        // Call Account service
        response =
                request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body(acctRoot + "fullviewAccountDetail.accountDetail.accountId.id", equalTo(accountId))
                .body(acctRoot + "fullviewAccountDetail.accountDetail.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "fullviewAccountDetail.accountDetail.accountId.sourceSystem", equalTo(sourceSystem));
        historicMarketValueResponse = response.path(acctRoot + "fullviewAccountDetail.historicMarketValue.amount.value");
        if (isFullviewDetailOverridden) {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(historicMarketValue);
        } else {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(value);
        }
    }


    /**
     * Validate the updated FV account.
     * <p>
     * Version V2
     */
    private void getDetailsAfterUpdate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body(acctRoot + "fullviewAccountDetail.accountDetail.accountId.id", equalTo(accountId))
                .body(acctRoot + "fullviewAccountDetail.accountDetail.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "fullviewAccountDetail.accountDetail.accountId.sourceSystem", equalTo(sourceSystem));

        if (isFullviewDetailOverridden) {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(historicMarketValue);
        } else {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(value);
        }
    }

    /**
     * Delete the Fullview account Version V2
     */
    private void deleteFullviewAccount() {
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "true"));
        context.put("id", accountId);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(200).body("isEmpty()", Matchers.is(true));
    }


    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        p2TestDataUtil.closeSQLiteConnection();
    }
}