/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;

/**
 * Class to test TAM is created successfully via UPDATE method.
 *
 * @author a631781
 */
@Test(groups = {Tags.PIPELINE, Tags.REGRESSION, Tags.WORKPLACE, Tags.COMPOSITE, Tags.V2
})
public class Workplace_Composite_V2_Update_TAM_Test extends PAPBaseServiceTest {

    /**
     * Constructor
     */
    protected Workplace_Composite_V2_Update_TAM_Test() {
        super(Services.Account);
    }

    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Workplace_Composite_V2_Update_TAM_Test.class);

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    /**
     * Global variable holding workplaceAccount information
     */
    private HashMap<String, String> workplaceAccountMap;

    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountTestData;

    private String accNum;

    private String acctRoot;
    private String details = "details.workplaceAccountDetail.accountDetail.";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Workplace_Composite_V2_Update_TAM_Test.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static String tamName = "Moderate with Income";
    private static float tamTotalEquity = 0.30F;
    private static float tamDomesticEquity = 0.21F;
    private static float tamForeignEquity = 0.09F;
    private static float tamBond = 0.50F;
    private static float tamCash = 0.20F;
    private static String tamCategory = "INVESTOR_SELECTED_STRATEGY";
    private static Integer tamRepositoryTamId = 176;
    private static Integer tamAssetAllocationId = 30;
    private VelocityContext context;

    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        workplaceAccountMap = new HashMap<>();

        accountTestData = TestDataUtil.populateRegressionTestData("default_ssn_workplace", oAuth);
        accountTestData.setMid("WorkplaceContributionV2TestMid");
        workplaceAccountMap = getWorkplaceAccountInformationV2(accountTestData, oAuth);

        DataCleanup.deleteCustomerDataFromCP("mid", accountTestData.getMid(), oAuth, "true");

        final String ppid = Identity.createHouseholdIdentity(accountTestData.getMid(), oAuth);
        accountTestData.setPpid(ppid);
        context = new VelocityContext();
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"));
    }

    // Get Composite account before create
    @Test
    public void getCompositeAccountWorkplaceV2BeforeCreate() {
        if (workplaceAccountMap.isEmpty()) {
            throw new SkipException(
                    "'getCompositeAccountWorkplaceBeforeCreate' test scenario cannot run due to failure to retrieve "
                            + "retail account information!");
        }

        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", workplaceAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-fesco-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    //Create composite account
    @Test(dependsOnMethods = "getCompositeAccountWorkplaceV2BeforeCreate")
    public void createCompositeAccountWorkplaceV2() {
        // Generate request body
        accNum = workplaceAccountMap.get("accountNumber");
        context.put("accountNumber", accNum);
        context.put("source", workplaceAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", workplaceAccountMap.get("displayName"));
        context.put("mnemonic", workplaceAccountMap.get("mnemonic"));
        context.put("sourceSystem2", workplaceAccountMap.get("sourceSystem"));
        context.put("institutionName", workplaceAccountMap.get("institutionName"));
        context.put("value", workplaceAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", workplaceAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "111111.11");
        context.put("emergencyFundAmountValue", "111111.11");

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-fesco-lid", accountTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";

        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(workplaceAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(workplaceAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(workplaceAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(workplaceAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(workplaceAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(workplaceAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details", notNullValue())
                .body(acctRoot + details + "emergencyFundAmount.value",
                        equalTo(111111.11f));

        accountTestData
                .setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
    }

    //Get composite account after create
    @Test(dependsOnMethods = "createCompositeAccountWorkplaceV2")
    public void getCompositeAccountWorkplaceV2AfterCreate() {
        // Generate request body
        context.put("sourceBasedRegistrationFilter", workplaceAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-fesco-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(workplaceAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(workplaceAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(workplaceAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(workplaceAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(workplaceAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(
                        Float.valueOf(workplaceAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details", notNullValue())
                .body(acctRoot + details + "emergencyFundAmount.value", equalTo(111111.11f));

    }

    //Create TAM via update call
    @Test(dependsOnMethods = "getCompositeAccountWorkplaceV2AfterCreate")
    public void updateCompositeAccountWorkplaceV2() {
        // Generate request body
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", workplaceAccountMap.get("accountNumber"));
        context.put("source", workplaceAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", workplaceAccountMap.get("displayName"));
        context.put("mnemonic", workplaceAccountMap.get("mnemonic"));
        context.put("sourceSystem2", workplaceAccountMap.get("sourceSystem"));
        context.put("institutionName", workplaceAccountMap.get("institutionName"));
        context.put("value", workplaceAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", workplaceAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "211111.11");
        context.put("emergencyFundAmountValue", "211111.11");
        context.put("TAM_name", tamName);
        context.put("TAM_total_equity", tamTotalEquity);
        context.put("TAM_domestic_equity", tamDomesticEquity);
        context.put("TAM_foreign_equity", tamForeignEquity);
        context.put("TAM_bond", tamBond);
        context.put("TAM_cash", tamCash);
        context.put("TAM_category", tamCategory);
        context.put("TAM_repositoryTamId", tamRepositoryTamId);
        context.put("TAM_assetAllocationId", tamAssetAllocationId);


        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-fesco-lid", accountTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(workplaceAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(workplaceAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(workplaceAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(workplaceAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(workplaceAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(
                        Float.valueOf(workplaceAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details", notNullValue())
                .body(acctRoot + details + "emergencyFundAmount.value", equalTo(211111.11f))
                .body(acctRoot + details + "targetAssetMixes[0].name", equalTo(tamName))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage", equalTo(tamTotalEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage", equalTo(tamDomesticEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage", equalTo(tamForeignEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage", equalTo(tamBond))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage", equalTo(tamCash));

    }

    //Get composite account after update
    @Test(dependsOnMethods = "updateCompositeAccountWorkplaceV2")
    public void getCompositeAccountWorkplaceV2AfterUpdate() {
        // Generate request body
        context.put("sourceBasedRegistrationFilter", workplaceAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-fesco-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(workplaceAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem",
                        equalTo(workplaceAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName",
                        equalTo(workplaceAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic",
                        equalTo(workplaceAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(workplaceAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(
                        Float.valueOf(workplaceAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details", notNullValue())
                .body(acctRoot + details + "emergencyFundAmount.value", equalTo(211111.11f))
                .body(acctRoot + details + "targetAssetMixes[0].name", equalTo(tamName))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage", equalTo(tamTotalEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage", equalTo(tamDomesticEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage", equalTo(tamForeignEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage", equalTo(tamBond))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage", equalTo(tamCash));
    }

    //Delete Composite Account
    @Test(dependsOnMethods = "getCompositeAccountWorkplaceV2AfterUpdate")
    public void deleteCompositeAccountWorkplaceV2() {
        // Generate request body
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", workplaceAccountMap.get("accountNumber"));
        context.put("source", workplaceAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", workplaceAccountMap.get("displayName"));
        context.put("mnemonic", workplaceAccountMap.get("mnemonic"));
        context.put("institutionName", workplaceAccountMap.get("institutionName"));
        context.put("value", workplaceAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", workplaceAccountMap.get("sourceMarketAsOfDate"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-fesco-lid", accountTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = response.jsonPath().getString("$");
        assertThat(emptyResponse, equalTo("[:]"));
    }

    //Get composite after Delete
    @Test(dependsOnMethods = "deleteCompositeAccountWorkplaceV2")
    public void getCompositeAccountWorkplaceV2AfterDelete() {
        // Generate request body
        context.put("sourceBasedRegistrationFilter", workplaceAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-fesco-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown() {
        testDataUtil.closeSQLiteConnection();
    }

    /**
     * Returns the response of retrieving a workplace account
     *
     * @param accountsCommonTestData the test data
     * @return workplaceAccountMap
     */
    private static HashMap<String, String> getWorkplaceAccountInformationV2(
            final AccountsCommonTestData accountsCommonTestData,
            final String oAuth) {
        final VelocityContext context = new VelocityContext();
        context.put("source", "WORKPLACE");

        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();

        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);

        request.header(new Header("user-mid", accountsCommonTestData.getMid())).header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        final Response response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        if (response.statusCode() != HTTPStatusCodes.STATUS_200) {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));

            return null;
        }

        final JsonPath workplaceResponseJP = response.jsonPath();

        final HashMap<String, String> workplaceAccountMap = new HashMap<String, String>();
        workplaceAccountMap.put("accountNumber",
                workplaceResponseJP.getString("accountList[0].accountId.accountNumber"));
        workplaceAccountMap.put("sourceSystem",
                workplaceResponseJP.getString("accountList[0].accountId.sourceSystem"));
        workplaceAccountMap.put("displayName", workplaceResponseJP.getString("accountList[0].displayName"));
        workplaceAccountMap.put("mnemonic", workplaceResponseJP.getString("accountList[0].regCode.mnemonic"));
        workplaceAccountMap.put("institutionName",
                workplaceResponseJP.getString("accountList[0].institutionName"));
        workplaceAccountMap.put("sourceMarketAmountValue",
                workplaceResponseJP.getString("accountList[0].sourceMarketValue.amount.value"));
        workplaceAccountMap.put("sourceMarketAmountValueType",
                workplaceResponseJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        workplaceAccountMap.put("sourceMarketAmountCurrency",
                workplaceResponseJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        workplaceAccountMap.put("sourceMarketAsOfDate",
                workplaceResponseJP.getString("accountList[0].sourceMarketValue.asOfDate"));

        return workplaceAccountMap;
    }
}