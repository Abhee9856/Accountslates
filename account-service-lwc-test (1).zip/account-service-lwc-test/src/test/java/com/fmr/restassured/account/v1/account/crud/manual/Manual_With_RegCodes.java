/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.manual;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;

import java.util.HashMap;
import java.util.Map;

import com.fmr.restassured.account.v1.account.crud.fullview.Fullview_With_POE_NetBenefits;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

/**
 * Tests for account/get operation,v1 for manual accounts for multiple regCodes.
 *
 * @author a608077
 */
@Test(groups = {
        Tags.PIPELINE,
        Tags.ASYNCHRONOUS,
        Tags.MANUAL,
        Tags.ACCOUNT,
        Tags.V1,
        Tags.CRUD})

public class Manual_With_RegCodes extends PAPBaseServiceTest {

    protected Manual_With_RegCodes() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private final float updatedValue = 426.85f;
    private final String source = "MANUAL";
    private final String asOfDate1 = "2014-10-31";
    private String mid;// = "ManualAccountV1TestMid";
    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Manual_With_RegCodes.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private final Map<String, String> accIdRegCodeMap = new HashMap<>();

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        String oAuthToken = AccountUtil.getOauthToken();

        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("default_ssn_manual",oAuthToken);
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);

        testDataUtil = new TestDataUtil();

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuthToken, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuthToken));

        // Populate request variables
        context = new VelocityContext();

        context.put("mid", accountsCommonTestData.getMid());
        context.put("source", source);

    }

    /**
     * Test for creating manual accounts with multiple reg codes.
     * Version V1
     */
    @Test(dataProvider = "getManualRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void createManualAccountsWithRegCodes(final AccountRegCodeTestData data) {

        float value = 818.89f;

        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", data.getRegCode1());
        context.put("value", value);
        context.put("asOfDate", asOfDate1);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);
        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        String accId = response.path("accountList[0].accountId.id");
        accIdRegCodeMap.put(data.getRegCode1(), accId);
    }


    /**
     * Tests that account data is brought back for manual account.
     * Version v1
     */
    @Test(dependsOnMethods = "createManualAccountsWithRegCodes",
            dataProvider = "getManualRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void verifyAfterCreate(final AccountRegCodeTestData data) {

        context.put("mnemonicFilter", data.getRegCode1());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Set URL to V1 before running again
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo(source))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId", notNullValue());

    }

    /**
     * Update the account.
     * Version V1
     */
    @Test(dependsOnMethods = "verifyAfterCreate",
            dataProvider = "getManualRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void updateManualAccount(final AccountRegCodeTestData data) {


        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("accId", accIdRegCodeMap.get(data.getRegCode1()));
        context.put("value", updatedValue);
        context.put("mnemonic", data.getRegCode1());
        context.put("asOfDate", asOfDate1);


        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.UPDATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo(source))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));

    }

    /**
     * Tests that updated account data is brought back for manual account.
     * Version v1
     */
    @Test(dependsOnMethods = "updateManualAccount",
            dataProvider = "getManualRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void verifyAfterUpdate(final AccountRegCodeTestData data) {

        context.put("mnemonicFilter", data.getRegCode1());
        context.put("filterType", data.getFilterType());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Set URL to V1 before running again
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo(source))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));

    }

    /**
     * Delete the account.
     * Version V1
     */
    @Test(dependsOnMethods = "verifyAfterUpdate",
            dataProvider = "getManualRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void deleteManualAccount(final AccountRegCodeTestData data) {

        context.put("accId", accIdRegCodeMap.get(data.getRegCode1()));
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", data.getRegCode1());
        context.put("value", updatedValue);
        context.put("asOfDate", asOfDate1);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("accountList", empty());
    }

    /**
     * Validate the manual account was deleted.
     * Version V1
     */
    @Test(dependsOnMethods = "deleteManualAccount",
            dataProvider = "getManualRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void getManualAccountAfterDelete(final AccountRegCodeTestData data) {

        context.put("mnemonicFilter", data.getRegCode1());
        context.put("filterType", data.getFilterType());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Set URL to V1 before running again
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("accountList", empty());
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}
