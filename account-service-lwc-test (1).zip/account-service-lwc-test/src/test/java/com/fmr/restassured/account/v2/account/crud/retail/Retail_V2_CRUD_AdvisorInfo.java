/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.crud.retail;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Tests Advisor Info for V2 CRUD operations for Retail accounts
 *
 * @author a631781
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.ACCOUNT,
		Tags.V2})
public class Retail_V2_CRUD_AdvisorInfo extends PAPBaseServiceTest
{

    protected Retail_V2_CRUD_AdvisorInfo()
    {
	super(Services.Account);
    }

    Logger logger = LogManager.getLogger(getClass());

    private VelocityContext context;

    private float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String source = "RETAIL";

    private final String asOfDate1 = "2014-10-31";

    private final String displayName = "Retail Account Advisor Info";

    /**
     * Instance to the test data utility class
     */

    private String accId;

    private String accNumber;

    private String ppid;

    private String mnemonic;

    private String poe = "FRIAG";

    private String advisorLoginId = "7690041287";

    private String advisorRealmType = "FRIAG";

    private String advisorPlanNumber = "500958";

    private String gnumber = "G07492038";

    FilterableRequestSpecification frs = null;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_V2_CRUD_AdvisorInfo.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();
	// Set default Headers
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
	request.given().header(new Header("user-poe", poe))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
			.header(new Header("advisor-login-id", advisorLoginId))
			.header(new Header("advisor-realm-type", advisorRealmType))
			.header(new Header("advisor-plan-number", advisorPlanNumber))
			.header(new Header("gnumber", gnumber))
			.header(new Header("excludeExternalDataSources", "false"));

	// Populate request variables
	context = new VelocityContext();
	context.put("source", source);

	frs = (FilterableRequestSpecification) request;
    }

    //Test Account with Advisor Info
    @Test
    public void performCrudOperations()
    {
	this.getRetailAccountInfo();
	this.createRetailAccount();
	this.getAccountInfoAfterCreate();
	this.updateRetailAccount();
	this.getAccountInfoAfterUpdate();
	this.deleteRetailAccount();
    }

    /**
     * Get account info from the backend. Save the account number.
     * <p>
     * Version V2
     */
    private void getRetailAccountInfo()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountList", not(emptyArray()));
	accNumber = response.path("accountList[0].accountId.accountNumber");
	ppid = response.path("accountList[0].accountId.owner.id");
	mnemonic = response.path("accountList[0].regCode.mnemonic");

    }

    /**
     * Create the Retail account.
     * <p>
     * Version V2
     * <p>
     * Add the EEDS header value as TRUE
     */
    private void createRetailAccount()
    {
	frs.removeHeader("excludeExternalDataSources");
	request.given().header(new Header("excludeExternalDataSources", "true"));

	// Generate request body
	context.put("ppid", ppid);
	context.put("value", String.valueOf(value));
	context.put("mnemonic", mnemonic);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("id", null);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

	// Call Account service
	response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(200)
			.body("accountList[0].accountId.accountNumber", equalTo(accNumber))
			.body("accountList[0].sourceMarketValue.amount.value", equalTo(value))
			.body("accountList[0].displayName", equalTo(displayName));
	accId = response.path("accountList[0].accountId.id");
    }

    //Get Account Info after create
    private void getAccountInfoAfterCreate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountList", not(emptyArray()))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNumber))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value",
					equalTo(value))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(displayName));
    }

    //Update Account details
    private void updateRetailAccount()
    {
	// Generate request body
	context.put("ppid", ppid);
	context.put("value", String.valueOf(updatedValue));
	context.put("mnemonic", mnemonic);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("id", accId);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(200)
			.body("accountList", not(emptyArray()))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNumber))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value",
					equalTo(updatedValue))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(displayName));
    }

    //Get after Updating Account details
    private void getAccountInfoAfterUpdate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountList", not(emptyArray()))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNumber))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value",
					equalTo(updatedValue))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(displayName));
    }

    //Delete Account
    private void deleteRetailAccount()
    {
	// Generate request body
	context.put("ppid", ppid);
	context.put("value", String.valueOf(updatedValue));
	context.put("mnemonic", mnemonic);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("id", accId);

	// Generate request body
	this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

	// Call Account service response =
	this.request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(200);

    }

}