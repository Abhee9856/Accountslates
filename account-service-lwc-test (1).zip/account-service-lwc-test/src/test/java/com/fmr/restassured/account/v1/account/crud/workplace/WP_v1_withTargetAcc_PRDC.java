/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

/**
 * Tests Account CRUD operation for a workplace account for PRDC Account numbers. Test will create,
 * update, and delete an account and run get requests before and after
 * each of those operations.
 *
 * @author a608077
 */
@Test(groups = {Tags.WORKPLACE, Tags.V1, Tags.TARGET_ACCOUNT, Tags.PRDC_DATA})
public class WP_v1_withTargetAcc_PRDC extends PAPBaseServiceTest {
    protected WP_v1_withTargetAcc_PRDC() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private final String accountCreatePath = AccountsPaths.CREATE_ACCOUNT_V1;

    private final String accountGetPath = AccountsPaths.GET_ACCOUNT_V1;

    private final String accountUpdatePath = AccountsPaths.UPDATE_ACCOUNT_V1;

    private final String accountDeletePath = AccountsPaths.DELETE_ACCOUNT_V1;

    private VelocityContext context;

    private final float fundingAccountAmount = 5.55f;

    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";

    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";

    private static final String TARGET_ACCOUNT_NAME = "NewTargetAccount";
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = WP_v1_withTargetAcc_PRDC.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();

        //Data Setup
        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_get_PRDC", oAuth);

        String mid = this.accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(mid);

        //Set default REST header with authorization token
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


        //Set ppid
        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth));

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("fescoLid", accountsCommonTestData.getSsn());
        context.put("source", AccountConstants.WORKPLACE);
        context.put("ppid", accountsCommonTestData.getPpid());

        this.request.given().
                header(new Header("return-prdc-accounts", "true"));
    }

    /**
     * Get account info from the backend. Save the account number.
     */
    @Test
    public void getWorkplaceAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountGetPath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));


        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Create the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount() {
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountCreatePath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()));

        // Gets and saves the CFP account ID
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
        context.put("accId", accountsCommonTestData.getAccountId1());
    }

    /**
     * Create target account
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void createTargetAccount() {
        context.remove("displayName");

        context.put("targetAccountSourceSystem", accountsCommonTestData.getSourceSystem1());
        context.put("targetAccountPpid", accountsCommonTestData.getPpid());
        context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
        context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("fundingAccountValue", String.valueOf(fundingAccountAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("category", "INVESTOR_SELECTED_STRATEGY");
        context.put("excludeExternalDataSources", "false");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountCreatePath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
                .body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body("targetAccounts[0].targetAssetMixes[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"));

        accountsCommonTestData.set(TARGET_ACCOUNT_NUMBER_KEY, response.path("targetAccounts[0].accountId.accountNumber"));
        accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
    }

    /**
     * Validate the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void getWorkplaceAccountAfterCreate() {

        context.put("source", null);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountGetPath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body("accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()))
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
                .body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body("targetAccounts[0].targetAssetMixes[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"));

    }

    /**
     * Update the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWorkplaceAccountAfterCreate")
    public void updateWorkplaceAccount() {
        //Change the amount of the account
        float updatedValue = 426.85f;
        context.put("value", updatedValue);
        context.put("source", AccountConstants.WORKPLACE);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountUpdatePath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body("accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue))
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
                .body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body("targetAccounts[0].targetAssetMixes[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"));

    }

    /**
     * Update target account
     */
    @Test(dependsOnMethods = "updateWorkplaceAccount")
    public void updateTargetAccount() {
        context.put(TARGET_ACCOUNT_NUMBER_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
        context.put(TARGET_ACCOUNT_ID_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
        context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
        context.put("category", "FINAL");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountUpdatePath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
                .body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
                .body("targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"));


    }

    /**
     * Validate the updated account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateTargetAccount")
    public void getWorkplaceAccountAfterUpdate() {
        // Generate request body
        context.put("source", null);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountGetPath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body("accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                //.body(        "accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue))
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
                .body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
                .body("targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"));

    }

    /**
     * Delete target account
     */
    @Test(dependsOnMethods = "getWorkplaceAccountAfterUpdate")
    public void deleteTargetAccount() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountDeletePath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", empty());
    }

    /**
     * Validate the updated retail account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteTargetAccount")
    public void getWorkplaceAccountAfterTargetAccountDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountGetPath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body("accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body("targetAccounts", empty());

    }

    /**
     * Delete the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWorkplaceAccountAfterTargetAccountDelete")
    public void deleteWorkplaceAccount() {
        // Generate request body
        context.put("source", AccountConstants.WORKPLACE);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountDeletePath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));
    }

    /**
     * Validate the account was deleted.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteWorkplaceAccount")
    public void getWorkplaceAccountAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(accountGetPath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body("accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountList[0].accountId.id", nullValue());
    }

}

