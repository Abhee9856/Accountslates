/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.positions.get;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;

import static com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds.*;
import static com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.APP_ID;
import static com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.CALLING_APP_ID;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Tests account positions get for Fullview accounts v2. Starts by retrieving a fullview account,
 * and then retrieving positions from DSS backend.
 *
 * @author a608077
 * updated by a631781 for PFCP-18705 and PFCP-18959
 * updated by a783909 for PFCP-19268
 * updated by a783909 for PFCP-15962
 */
@Test(groups = {
        Tags.FULLVIEW,
        Tags.POSITIONS,
        Tags.V2})

public class Positions_Get_Fullview_v2 extends PAPBaseServiceTest {
    protected Positions_Get_Fullview_v2() {
        super(Services.Account);
    }

    private String ppid;
    private String mnemonic;
    private String accountNumber;
    private String sourceSystem;
    private String displayName;
    private float value;
    private VelocityContext context;
    private FilterableRequestSpecification frs;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    public static final String ACCOUNT_CATEGORY = "ExternalLinked";
    private static final String APP_NAME = "Advice and Planning Platform";
    private static final String LOG_TRACKING_ID = Positions_Get_Fullview_v2.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private int finstId = 999999991;
    private int marketValue;

    /**
     * Global variable holding retailAccount information
     */
    private HashMap<String, String> fundCodeFinstIdMap = new HashMap<>();
    private String externalCustomerID;
    final String oAuth = AccountUtil.getOauthToken();
    AccountsCommonTestData accountsCommonTestData;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_get_corePosition_Fullview", oAuth);

        accountsCommonTestData.setMid(Identity.getUserIdentifier("lid", accountsCommonTestData.getSsn(), oAuth).get("mid"));
        String mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setSid(Identity.getUserIdentifier("lid", accountsCommonTestData.getSsn(), oAuth).get("sid"));
        String sid = accountsCommonTestData.getSid();

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");

        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("excludeExternalDataSources", "false"));

        // Populate request context with user IDs
        context = new VelocityContext();

        context.put("mid", mid);
        context.put("sid", sid);
        context.put("ppid", ppid);
        context.put("source", "FULLVIEW");
    }

    /**
     * Get Fullview account info from the backend. Save the account number.
     */
    @Test
    public void getFullviewAccountInfo() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList", Matchers.not(empty()));

        String dagPath = "accountList.find{it.institutionName=='Fidelity API Tester-DAG Bank'}.";

        mnemonic = response.path(dagPath + "regCode.mnemonic");
        accountNumber = response.path(dagPath + "accountId.accountNumber");
        sourceSystem = response.path(dagPath + "accountId.sourceSystem");
        displayName = response.path(dagPath + "displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
    }

    /**
     * Validate the positions.
     * Tests fund code and finstId in position get response
     */
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void getPositionsFullview() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList.find{it.account.institutionName=='Fidelity API Tester-DAG Bank'}.account.accountId.sourceSystem", equalTo(sourceSystem))
                .body("accountList.find{it.account.institutionName=='Fidelity API Tester-DAG Bank'}.account.accountId.accountNumber", equalTo(accountNumber))
                .body("accountList.find{it.account.institutionName=='Fidelity API Tester-DAG Bank'}.account.regCode.mnemonic", equalTo(mnemonic))
                .body("accountList.find{it.account.institutionName=='Fidelity API Tester-DAG Bank'}.account.displayName", equalTo(displayName))
                .body("accountList.find{it.account.institutionName=='Fidelity API Tester-DAG Bank'}.account.accountId.owner.id", equalTo(ppid))
                .body("accountList[0].account.sourceMarketValue.amount.value", equalTo(value))
                .body("accountList.account.accountId.find{it.accountNumber=='" + accountNumber + "'}.positions", Matchers.nullValue());

        marketValue = (int) Math.round(response.path("accountList.find{it.account.accountId.accountNumber == '"+ accountNumber + "'}.positions.marketValue.amount.value"));

        int positionSize = response.path("accountList.find{it.account.accountId.accountNumber == '"+ accountNumber + "'}.positions.allPositions.size()");

        for(int count = 0; count<positionSize; count++ ){

            String fundCode = response.path("accountList.find{it.account.accountId.accountNumber == '"+ accountNumber + "'}.positions.allPositions["+count + "].financialAssetPosition.financialInstrumentId.fundCode");
            String finstId = response.path("accountList.find{it.account.accountId.accountNumber == '"+ accountNumber + "'}.positions.allPositions["+count + "].financialAssetPosition.financialInstrumentId.finstId").toString();
            fundCodeFinstIdMap.put(fundCode, finstId);
        }

        //Validate corePosition
        int actualFinstId = response.path("accountList[0].positions.allPositions.find{it.financialAssetPosition.position.corePosition==" + true + "}.financialAssetPosition.financialInstrumentId.finstId");
        Assert.assertEquals(actualFinstId, finstId);
        float corePositionPrice = response.path("accountList[0].positions.allPositions.find{it.financialAssetPosition.position.corePosition==" + true + "}.financialAssetPosition.position.price.value");
        final float expectedCorePositionPrice = 1.0f;
        float corePositionQuantity = response.path("accountList[0].positions.allPositions.find{it.financialAssetPosition.position.corePosition==" + true + "}.financialAssetPosition.position.quantity");
        Assert.assertEquals(corePositionPrice, expectedCorePositionPrice);
        Assert.assertEquals(corePositionQuantity, value);
    }

    @Test(dependsOnMethods = "getPositionsFullview")
    public void getDSS_V2() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));


        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().statusCode(anyOf(is(200), is(206)));
        externalCustomerID = response.path("customerAttrDetail.externalCustomerID");
    }

    @Test(dependsOnMethods = "getDSS_V2")
    public void getDSS_AccountPositions_V2()
    {
        // Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("returnAvailabilityStatus", "true");
        context.put("returnAccountGainLossDetail", "true");
        context.put("returnPositionMarketValDetail", "true");
        context.put("externalCustomerID", externalCustomerID);
        context.put("accountNumber", accountNumber);
        context.put("acctType", "External");

        this.request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_POSITION_V2));

        Response dssPositionResponse = this.request.post(AccountConstants.DSS_ACCOUNT_POSITIONS_V2_PATH);

        // Assert on response
        dssPositionResponse.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
                .body("position.acctDetails.acctDetail", not(emptyArray()))
                .body("position.acctDetails.acctDetail[0].acctNum", equalTo(accountNumber));

       int positionSize = dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail.size()");
        Float actualMarketValue = 0.0F;

        for(int count = 0; count<positionSize-1; count++ ) {

            actualMarketValue = actualMarketValue + Float.parseFloat(dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail["+count+"].marketValDetail.marketVal").toString());
            String symbol = dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail["+count+"].symbol");
            String securityProvider = dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail["+count+"].securityProvider");

            if(securityProvider.equals("Fidelity"))
            {
                VelocityContext fiContext = new VelocityContext();
                fiContext.put("cusip", "null");
                fiContext.put("symbol", "");
                fiContext.put("fundcode", symbol);
                //Build request body, set the host, and retrieve the resource path
                request.body(IOUtil.generateJsonRequest(fiContext, FINANCIAL_INSTRUMENTS_GET_ID_TEMPLATE));

                //Call financial Instruments service
                response = request.post(FINANCIAL_INSTRUMENTS_QA_BASE_URI+FINANCIAL_INSTRUMENTS_GET_ID_PATH);

                //Assert on response
                response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", Matchers.equalTo(true))
                .body("finstIdList[0].fundCode", equalTo(symbol));

                String actualfinstId = response.path("finstIdList[0].finstId").toString();
                Assert.assertEquals(actualfinstId, fundCodeFinstIdMap.get(symbol));
            }
        }
        int count = positionSize-1;
        actualMarketValue = actualMarketValue + Float.parseFloat(dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail["+ count +"].marketValDetail.marketVal").toString());
        Assert.assertEquals(actualMarketValue, marketValue);
    }

    private void setDefaultRequestHeadersForDSS() {
        request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", accountsCommonTestData.getSsn()))
                .header(new Header("rtazallrealmslids", "Retail=" + accountsCommonTestData.getSsn()))
                .header(new Header("FACSC", "ROLE=FidCust"))
                .header(new Header("FACMC", "MID="+accountsCommonTestData.getMid()))
                .header(new Header("Content-Type", "application/json"));

    }
}