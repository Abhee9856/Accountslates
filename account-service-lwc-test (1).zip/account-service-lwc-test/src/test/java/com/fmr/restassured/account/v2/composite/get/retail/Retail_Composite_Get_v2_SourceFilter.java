/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.get.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.hasSize;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * Contains  V2 account tests that validate the  GET Account Composite operation with Source Based Registration Filter for Retail Accounts & Also WorkPlace Account
 *
 * @author a754289
 */
@Test(groups = {Tags.RETAIL, Tags.COMPOSITE, Tags.V2, Tags.GET})
public class Retail_Composite_Get_v2_SourceFilter extends PAPBaseServiceTest
{

	protected Retail_Composite_Get_v2_SourceFilter()
	{
		super(Services.Account);
	}

	/**
	 * Logger to print appropriate error, warning, or info messages
	 **/
	private static final Logger LOGGER = LogManager.getLogger(Retail_Composite_Get_v2_SourceFilter.class);

	//Velocity Context
	private VelocityContext context;

	//Instance to the test data utility class
	private TestDataUtil testDataUtil;

	/**
	 * Global variable holding the oAuth token generated in the initClass method
	 */
	private String oAuth;

	/**
	 * Global variable holding retailAccount information
	 */
	private HashMap<String, String> retailAccountMap;

	/**
	 * Global variable holding account test data from sqlite
	 */
	private AccountsCommonTestData accountsCommonTestData;

	private String accNum;

	private String acctRoot;

	private String retailAccNum1;

	private String retailAccNum2;

	private String workplaceAccNum1;

	private static final String CALLING_APP_ID = "AP106564";

	private static final String APP_ID = "AP106564";

	private static final String LOG_TRACKING_ID = Retail_Composite_Get_v2_SourceFilter.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private static final String includeFilter = "INCLUDE";

	private static final String excludeFilter = "EXCLUDE";

	private static final String source = "RETAIL";

	private static final String source2 = "WORKPLACE";

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
	 * for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void initClass()
	{
		oAuth = AccountUtil.getOauthToken();

		testDataUtil = new TestDataUtil();
		retailAccountMap = new HashMap<>();

		// Data setup
		accountsCommonTestData = TestDataUtil.populateRegressionTestData("accountGET_Retail_Filter", oAuth);
		retailAccountMap = getRetailAccountInformationV2(accountsCommonTestData, oAuth);

		//Data cleanup
		DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuth, "true");
		accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

	}

	@BeforeMethod(alwaysRun = true)
	public void init()
	{
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
		request.header(new Header("user-poe", "RETAIL")).header(
				new Header("scenario-category-code", SCENARIO_CATEGORY_CODE)).header(
				new Header("scenario-product-code", SCENARIO_PRODUCT_CODE)).header(
				new Header("user-mid", accountsCommonTestData.getMid())).header(
				new Header("user-retail-lid", accountsCommonTestData.getSsn())).header(
				new Header("user-fesco-lid", accountsCommonTestData.getSsn()));
	}

	/**
	 * Description: Validates the account composite response without source based registration filter
	 */
	@Test
	public void getCompositeAccountWithoutFilter()
	{
		context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", source);
		context.put("source2", source2);
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
		if (null != response.path("accounts"))
		{
			final ArrayList<String> retailAccountList;
			workplaceAccNum1 = response.path("accounts.find{it.account.accountId.sourceSystem =='" + source2
					+ "'}.account.accountId.accountNumber").toString();
			retailAccountList = response.path("accounts.findAll{it.account.accountId.sourceSystem =='" + source
					+ "'}.account.accountId.accountNumber");
			if (retailAccountList.size() > 2)
			{
				retailAccNum1 = retailAccountList.get(1);
				retailAccNum2 = retailAccountList.get(2);
			}
			final ArrayList<String> totalAccountList = response.path("accounts.account.accountId.accountNumber");
			final int totalAccountsSize = totalAccountList.size();

			response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
					hasSize(totalAccountsSize));
		}
	}

	/**
	 * Description: Validates the account composite response with multiple source based registration filter
	 */
	@Test(dependsOnMethods = "getCompositeAccountWithoutFilter")
	public void getCompositeAccountRetailIncludeFilter()
	{
		context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", source);
		context.put("source2", source2);
		context.put("filterType", includeFilter);
		context.put("accountNumbers1",
				Arrays.asList(String.format("\"%s\"", retailAccNum1), String.format("\"%s\"", retailAccNum2)));
		context.put("accountNumbers2", Arrays.asList(String.format("\"%s\"", workplaceAccNum1)));
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts", hasSize(3));
	}

	/**
	 * Description: Validates the account composite response with exclude source based registration filter
	 */
	@Test(dependsOnMethods = "getCompositeAccountWithoutFilter")
	public void getCompositeAccountRetailExcludeFilter()
	{
		context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", source);
		context.put("source2", source2);
		context.put("filterType", excludeFilter);
		context.put("accountNumbers1",
				Arrays.asList(String.format("\"%s\"", retailAccNum1), String.format("\"%s\"", retailAccNum2)));
		context.put("accountNumbers2", Arrays.asList(String.format("\"%s\"", workplaceAccNum1)));
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts", hasSize(8));
	}

	/**
	 * Description: Validates the account composite response with no accounts found
	 */
	@Test
	public void getCompositeAccountRetailIncludeFilterNoAccount()
	{
		context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", source);
		context.put("accountNumbers1", "123");

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts", hasSize(0));
	}

	/**
	 * Description: Validates the account composite response after a create with withdrawals and contributions
	 */
	@Test
	public void createCompositeAccountRetailV2()
	{
		context = new VelocityContext();
		accNum = retailAccountMap.get("accountNumber");
		context.put("accountNumber", accNum);
		context.put("source", source);
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("displayName", retailAccountMap.get("displayName"));
		context.put("mnemonic", retailAccountMap.get("mnemonic"));
		context.put("sourceSystem2", source);
		context.put("institutionName", retailAccountMap.get("institutionName"));
		context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
		context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
		context.put("detailValue", "111111.11");
		context.put("emergencyFundAmountValue", "111111.11");
		context.put("contribFreq", "YEARLY");
		context.put("contribValue", "500");
		context.put("contributionTaxType", "POST_TAX");
		context.put("contributionType", "CATCHUP");
		context.put("contributor", "EMPLOYER");
		context.put("withdrawAmount", "500");
		context.put("withdrawFreq", "HOURLY");
		context.put("riskTolerance", 2);
		context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
		context.put("withdrawalStartYear", 2055);
		context.put("withdrawalEndYear", 2085);
		context.put("assetClass1", "UNKNOWN");
		context.put("netPercentage1", 0.177);
		context.put("assetClass_T_Equity", "TOTAL_EQUITY");
		context.put("netPercentage_T_Equity", 0);
		context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
		context.put("netPercentage_FE", 0.0f);
		context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
		context.put("netPercentage_DE", 0.0f);
		context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
		context.put("equityPercent", 0.35);
		context.put("originalOwnerBirthDate", "1958-11-09");
		context.put("originalOwnerDeceasedDate", "2022-11-09");
		context.put("withdrawalEligibilityStartDate", "2022-11-09");
		context.put("withdrawalEligibilityEndDate", "2052-11-09");
		context.put("originalOwnerSpouse", "false");
		context.put("federalTaxWithholding", 0.15);
		context.put("stateTaxWithholding", 0.05);
		context.put("isBackdoorRoth", "true");

		request.header(new Header("user-mid", accountsCommonTestData.getMid())).header(
				new Header("user-retail-lid", accountsCommonTestData.getSsn())).header(
				new Header("excludeExternalDataSources", "true"));

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

		acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";

		response = request.log().all().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body(
				acctRoot + "account.accountId.id", notNullValue()).body(acctRoot + "account.accountId.accountNumber",
				equalTo(retailAccountMap.get("accountNumber"))).body(acctRoot + "account.accountId.sourceSystem",
				equalTo(retailAccountMap.get("sourceSystem"))).body(acctRoot + "account.accountId.owner.id",
				equalTo(accountsCommonTestData.getPpid())).body(acctRoot + "account.displayName",
				equalTo(retailAccountMap.get("displayName"))).body(acctRoot + "account.regCode.mnemonic",
				equalTo(retailAccountMap.get("mnemonic"))).body(acctRoot + "account.institutionName",
				equalTo(retailAccountMap.get("institutionName"))).body(
				acctRoot + "account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue")))).body(
				acctRoot + "contributions", notNullValue()).body(acctRoot + "withdrawals", hasSize(1));

		accountsCommonTestData.setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
	}

	/**
	 * Description: Validates the account composite response with exclude contributions flag and exclude withdrawals as true
	 */
	@Test(dependsOnMethods = "createCompositeAccountRetailV2")
	public void getCompositeAccountRetailWithExcludeFlags()
	{
		request.header(new Header("user-mid", accountsCommonTestData.getMid())).header(
				new Header("user-retail-lid", accountsCommonTestData.getSsn())).header(
				new Header("excludeExternalDataSources", "true")).header(
				new Header("exclude-withdrawals-details", "true")).header(
				new Header("exclude-contributions-details", "true"));

		final VelocityContext context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", retailAccountMap.get("sourceSystem"));

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body(
				acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1())).body(
				acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber"))).body(
				acctRoot + "account.accountId.sourceSystem", equalTo(source)).body(
				acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid())).body(
				acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName"))).body(
				acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic"))).body(
				acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName"))).body(
				acctRoot + "account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue")))).body(
				acctRoot + "contributions", nullValue()).body(acctRoot + "withdrawals", hasSize(0));
	}

	/**
	 * Returns the response of retrieving a retail account
	 *
	 * @param accountsCommonTestData
	 * 		the test data
	 * @return retailAccountMap
	 */
	private static HashMap<String, String> getRetailAccountInformationV2(
			final AccountsCommonTestData accountsCommonTestData, final String oAuth)
	{
		final VelocityContext context = new VelocityContext();
		context.put("sourceBasedRegistrationFilter", source);
		//        context.put("mnemonicFilter", "IRA");

		RestAssured.reset();
		RestAssured.baseURI = currentHost;
		RestAssured.useRelaxedHTTPSValidation();

		final RequestSpecification request = OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA",
				oAuth);

		request.header(new Header("user-mid", accountsCommonTestData.getMid())).header(new Header("user-poe", "RETAIL"))
				.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE)).header(
				new Header("scenario-product-code", SCENARIO_CATEGORY_CODE)).header(
				new Header("user-retail-lid", accountsCommonTestData.getSsn()));

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		final Response response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		if (response.statusCode() != HTTPStatusCodes.STATUS_200)
		{
			LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
					accountsCommonTestData.getSsn()));

			return null;
		}

		final JsonPath retailAccountJP = response.jsonPath();

		final HashMap<String, String> retailAccountMap = new HashMap<>();
		retailAccountMap.put("accountNumber", retailAccountJP.getString("accountList[0].accountId.accountNumber"));
		retailAccountMap.put("sourceSystem", retailAccountJP.getString("accountList[0].accountId.sourceSystem"));
		retailAccountMap.put("displayName", retailAccountJP.getString("accountList[0].displayName"));
		retailAccountMap.put("mnemonic", retailAccountJP.getString("accountList[0].regCode.mnemonic"));
		retailAccountMap.put("institutionName", retailAccountJP.getString("accountList[0].institutionName"));
		retailAccountMap.put("sourceMarketAmountValue",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
		retailAccountMap.put("sourceMarketAmountValueType",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
		retailAccountMap.put("sourceMarketAmountCurrency",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
		retailAccountMap.put("sourceMarketAsOfDate",
				retailAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));

		return retailAccountMap;
	}

	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}
}

