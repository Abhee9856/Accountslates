/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.dss.realtimedata;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.MatcherAssert;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Tests Account Positions operation with real time data from DSS Positions API
 *
 * @author a702588 Updated by a608077 on 09/13/2022 to include changes for
 * clear-retail-cache flag(PFCP-10001)
 * @author a730306 Updated by a730306 on 11/08/2022 to include unsettledCash,
 * UnsettledMargin and unsettledShort for real time check(PFCP-10801)
 */

@Test(groups = {Tags.REAL_TIME_DATA, Tags.V2})
public class AccountPositionsV2 extends PAPBaseServiceTest
{

    protected AccountPositionsV2()
    {
	super(Services.Account);
    }

    private static final String sourceSystem = "RETAIL";

    public static final String ACCOUNT_CATEGORY = "BROKERAGE";

    public static final String acctTypeDSS = "Brokerage";

    private String ssn;

    private String mid;

    private String sid;

    private String ppid;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = AccountPositionsV2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String APP_NAME = "Advice and Planning Platform";

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private Response accountResponse;

    private Response dssPositionResponse;

    private String acctRoot;

    private final String oAuth = AccountUtil.getOauthToken();

    private TestDataUtil testDataUtil;

    private VelocityContext context;

    private FilterableRequestSpecification frs;

    private String accountNumber;

    private Float value;

    private Float dssValue;

    private String accountAsOfDateTime;

    private Integer dssAsOFDate;

    private Float unsettledCash;

    private Float unsettledMargin;

    private Float unsettledShort;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
	// Data setup
	AccountsCommonTestData accountsCommonTestData = TestDataUtil
			.populateRegressionTestData("account_get_Retail_DSS_gainlossbalancedetail", oAuth);

	mid = accountsCommonTestData.getMid();
	sid = accountsCommonTestData.getSid().replace("-", "");
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


	ppid = Identity.createHouseholdIdentity(mid, oAuth);

	ssn = accountsCommonTestData.getSsn();
	testDataUtil = new TestDataUtil();

	// Populate request context with user IDs
	context = new VelocityContext();

	// Common headers setup
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Test to get the DSS Retail account
     * <p>
     * Version V2
     */
    @Test
    public void getDSS_V2()
    {
	//Set DSS Headers
	frs = (FilterableRequestSpecification) request;
	frs.removeHeaders();
	setDefaultRequestHeadersForDSS();

	// Generate request body
	context.put("acctCategory", ACCOUNT_CATEGORY);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

	request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
	response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

	// Assert on response
	response.then().statusCode(anyOf(is(200), is(206)));
	accountNumber = response.path("acctDetails[0].acctNum");
    }

    @Test(dependsOnMethods = "getDSS_V2")
    public void getDSS_AccountPositions_V2()
    {
	// Generate request body
	context.put("returnAvailabilityStatus", "true");
	context.put("returnAccountGainLossDetail", "true");
	context.put("returnPositionMarketValDetail", "true");
	context.put("accountNumber", accountNumber);
	context.put("acctType", acctTypeDSS);

	request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_POSITION_V2));

	dssPositionResponse = request.post(AccountConstants.DSS_ACCOUNT_POSITIONS_V2_PATH);

	// Assert on response
	dssPositionResponse.then().statusCode(anyOf(is(200), is(206)))
			.body("position.acctDetails.acctDetail", not(emptyArray()))
			.body("position.acctDetails.acctDetail[0].acctNum", equalTo(accountNumber));
	dssValue = dssPositionResponse.path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
			+ "'}.accountGainLossDetail.accountMarketVal");
    }

    /**
     * Tests that account data is brought back for Retail account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDSS_AccountPositions_V2"})
    public void getRetailAccountPositionInfo()
    {
	//Set Account Headers
	frs = (FilterableRequestSpecification) request;
	frs.removeHeaders();
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
	setRequestHeadersForAccount();
	// Generate request body
	context.put("source", sourceSystem);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	// Call Account service
	accountResponse = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

	acctRoot = "accountList.find{it.account.accountId.accountNumber=='" + accountNumber + "'}.";
	// Assert on response
	accountResponse.then().statusCode(200)
			.body("accountList", not(emptyArray()))
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accountNumber))
			.body(acctRoot + "account.accountId.sourceSystem", equalTo(sourceSystem));
	value = accountResponse.path(acctRoot + "account.sourceMarketValue.amount.value");
	accountAsOfDateTime = accountResponse.path(acctRoot + "account.sourceMarketValue.asOfDate");
	unsettledCash = accountResponse.path(acctRoot + "account.unsettledCashValue.value");
	unsettledMargin = accountResponse.path(acctRoot + "account.unsettledMargin.value");
	unsettledShort = accountResponse.path(acctRoot + "account.unsettledShort.value");

	// Validation
	assertThat(value).isCloseTo(dssValue, within(dssValue*0.01f));
	if (null != dssPositionResponse.path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
			+ "'}.activityDetail.unsettledCash"))
	{
	    Assert.assertEquals(dssPositionResponse
			    .path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
					    + "'}.activityDetail.unsettledCash"), unsettledCash);
	}

	if (null != dssPositionResponse.path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
			+ "'}.activityDetail.unsettledMargin"))
	{
	    Assert.assertEquals(dssPositionResponse
			    .path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
					    + "'}.activityDetail.unsettledMargin"), unsettledMargin);
	}

	if (null != dssPositionResponse.path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
			+ "'}.activityDetail.unsettledShort"))
	{
	    Assert.assertEquals(dssPositionResponse
			    .path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
					    + "'}.activityDetail.unsettledShort"), unsettledShort);
	}
	dssAsOFDate = dssPositionResponse.path("position.acctDetails.acctDetail[0].asOfDateTime");
	validateDate();
    }

    private void validateDate()
    {

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.ENGLISH);

	String dssAsOfDateTime = AccountUtil.parseDSSDate(dssAsOFDate.longValue());

	ZonedDateTime formattedDateDSS = ZonedDateTime.parse(dssAsOfDateTime, formatter);

	String DSSDateValue = dssAsOfDateTime.substring(0, 10);
	String AccountDateValue = accountAsOfDateTime.substring(0, 10);

	ZonedDateTime formattedDateAccount = ZonedDateTime.parse(accountAsOfDateTime, formatter);
	//Validations on Date and Time
	Assert.assertEquals(accountAsOfDateTime.length() - 15, dssAsOfDateTime.length() - 15);

	//Validates the date
	Assert.assertEquals(DSSDateValue, AccountDateValue);

	//Validates the second of time is within a range of 60second of DSS(Added for clear-cache-retail flag)
	MatcherAssert.assertThat(formattedDateAccount.getSecond(),
			is(both(greaterThan(formattedDateDSS.getSecond() - 60))
					.and(lessThan(formattedDateDSS.getSecond() + 60))));

    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS()
    {
	request.given().header(new Header("AppId", "AP106532"))
			.header(new Header("fsreqid", FSREQID))
			.header(new Header("Authorization", oAuth))
			.header(new Header("AppName", APP_NAME))
			.header(new Header("rtazlid", ssn))
			.header(new Header("rtazallrealmslids", "Retail=" + ssn))
			.header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + sid))
			.header(new Header("FACMC", "MID=" + mid))
			.header(new Header("FACFC", "SESSION_KEY=1"))
			.header(new Header("Content-Type", "application/json"));

    }

    /**
     * Setting headers for Account Service
     */
    private void setRequestHeadersForAccount()
    {
	// Account headers setup
	request.given()
			.header(new Header("user-poe", AccountConstants.RETAIL))
			.header(new Header("user-mid", mid))
			.header(new Header("user-retail-lid", ssn))
			.header(new Header("excludeExternalDataSources", "false"))
			.header(new Header("realTimeData", "true"))
			.header(new Header("mauiCache", "no"))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));

    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


	testDataUtil.closeSQLiteConnection();
    }

}