/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.suitability.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsSuitabilityPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import java.time.ZonedDateTime;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;

/**
 * Tests CRUD operations for Account Suitability V2 for Retail accounts owned by the Principal.
 *
 * @author a703000
 * 
 */

@Test(groups = {Tags.RETAIL, Tags.SUITABILITY, Tags.V2, "PFCP-18051"})

public class Retail_Suitability_CRUD_v2_AdvisorInfo extends PAPBaseServiceTest
{

	protected Retail_Suitability_CRUD_v2_AdvisorInfo()
	{
		super(Services.Account);
	}

	private String mnemonic;

	private String ppid;

	private String accountId;

	private String accountNumber;

	private String sourceSystem;

	private String displayName;

	private float value;

	private String institutionName;

	private String asOfDate;

	private String poe = "FRIAG";

	private String advisorLoginId = "7690041287";

	private String advisorRealmType = "FRIAG";

	private String advisorPlanNumber = "500958";

	private String gnumber = "G07492038";

	private VelocityContext context;
	
	FilterableRequestSpecification frs = null;

	/**
	 * Instance to the test data utility class
	 */
	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private static final String LOG_TRACKING_ID = Retail_Suitability_Only_IAPreferences_v2.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	// Start and End years for accountPreferencesIA - both should be greater than the current year.
	int startYear = ZonedDateTime.now().plusYears(1).getYear();

	int endYear = ZonedDateTime.now().plusYears(2).getYear();

	// investmentObjectiveIA, withdrawalNeeds, anticipatedExpenses and annualWithdrawalPercent for
	// accountPreferencesIA
	private static String investmentObjectiveIA = "NONE";

	private static String withdrawalNeeds = "NO_WITHDRAWAL";

	private static String anticipatedExpenses = "LIKELY";

	private static float annualWithdrawalPercent = 0.02f;

	private static String updatedInvestmentObjectiveIA = "CONSERVATIVE";

	private static String updatedWithdrawalNeeds = "CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5";

	private static String updatedAnticipatedExpenses = "SOMEWHAT_LIKELY";

	private static float updatedAnnualWithdrawalPercent = 0.05f;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
		                FSREQID, oAuth);

		this.request.given().header(new Header("user-poe", poe))
		                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
		                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
		                .header(new Header("advisor-login-id", advisorLoginId))
		                .header(new Header("advisor-realm-type", advisorRealmType))
		                .header(new Header("advisor-plan-number", advisorPlanNumber))
		                .header(new Header("gnumber", gnumber))
		                .header(new Header("excludeExternalDataSources", "false"));

		// Populate request context with user IDs
		context = new VelocityContext();
	}

	/**
	 * Get Retail account info from the backend. Save the account number.
	 */
	@Test
	public void getRetailAccountInfo()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);

		ppid = response.path("accountList[0].accountId.owner.id");
		mnemonic = response.path("accountList[0].regCode.mnemonic");
		accountNumber = response.path("accountList[0].accountId.accountNumber");
		sourceSystem = response.path("accountList[0].accountId.sourceSystem");
		displayName = response.path("accountList[0].displayName");
		value = response.path("accountList[0].sourceMarketValue.amount.value");
		institutionName = response.path("accountList[0].institutionName");
		asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
		// Gets and saves the CFP account ID
		accountId = response.path("accountList[0].accountId.id");
		context.put("accId", accountId);
	}

	/**
	 * Create the Retail account. Save the account id.
	 * <p>
	 * Version V2
	 */

	@Test(dependsOnMethods = "getRetailAccountInfo")
	public void createRetailAccount()
	{
		context.put("mnemonic", mnemonic);
		context.put("value", value);
		context.put("source", sourceSystem);
		context.put("accountNumber", accountNumber);
		context.put("displayName", displayName);
		context.put("institutionName", institutionName);
		context.put("asOfDate", asOfDate);
		context.put("ppid", ppid);
		FilterableRequestSpecification frs = (FilterableRequestSpecification) this.request;
		frs.removeHeader("excludeExternalDataSources");

		this.request.given().header(new Header("excludeExternalDataSources", "true"));

		if(accountId != null)
		{
			//Data cleanup - delete the retail account before creating Retail account
			this.deleteRetailAccount();
			frs.removeHeader("accId");
			context.remove("id");

		}
		
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
		                "accountList[0].regCode.mnemonic", equalTo(mnemonic),
		                "accountList[0].accountId.accountNumber", equalTo(accountNumber));

		// Gets and saves the CFP account ID
		accountId = response.path("accountList[0].accountId.id");
		context.put("accId", accountId);
	}

	/**
	 * Validate the account was created correctly.
	 */
	@Test(dependsOnMethods = "createRetailAccount")
	public void getRetailAccountAfterCreate()
	{
		context.put("ppid", ppid);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
		                "accountList[0].regCode.mnemonic", equalTo(mnemonic),
		                "accountList[0].accountId.accountNumber", equalTo(accountNumber));

	}

	/**
	 * Create the account suitability.
	 */
	@Test(dependsOnMethods = "getRetailAccountAfterCreate")
	public void createAccountSuitability()
	{

		// Generate request body
		context.put("riskTolerance", 1);
		context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
		context.put("withdrawalStartYear", startYear);
		context.put("withdrawalEndYear", endYear);
		context.put("investmentObjectiveIA", investmentObjectiveIA);
		context.put("withdrawalNeeds", withdrawalNeeds);
		context.put("anticipatedExpenses", anticipatedExpenses);
		context.put("annualWithdrawalPercent", annualWithdrawalPercent);
		context.put("investObj_Txt", "Short Term");
		context.put("investObj_Id", "26");
		context.put("tam_TotalEqty", 0);
		context.put("tam_lowEqtyPct", 1.01);
		context.put("tam_upEqtyPct", "0");
		context.put("tam_assetAlloc_Id", "TOTAL_EQUITY");
		context.put("tam_context", "Standard");
		context.put("investPurp_Txt", "Save for education");
		context.put("investPurp_Id", "31");
		context.put("investKnow_Txt", "Limited");
		context.put("investKnow_Id", "46");
		context.put("annualIncRng_Txt", "$0 to $25K");
		context.put("annualIncRng_Id", "39");
		context.put("liqNWRng_Txt", "$0 to $50K");
		context.put("liqNWRng_Id", "49");
		context.put("netWorthRng_Txt", "$0 to $50K");
		context.put("netWorthRng_Id", "53");
		context.put("taxBrktRng_Txt", "Under 15%");
		context.put("taxBrktRng_Id", "43");
		context.put("essExpRng_Txt", "Under 25%");
		context.put("essExpRng_Id", "57");
		context.put("spendLikeRng_Txt", "Not Likely");
		context.put("spendLikeRng_Id", "62");
		context.put("invesTimeHrzn_Txt", "Near Term (0-1 year)");
		context.put("invesTimeHrzn_Id", "73");
		context.put("riskTolerance", 1);
		context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
		context.put("withdrawalStartYear", startYear);
		context.put("withdrawalEndYear", endYear);

		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V2)).log()
		                .ifValidationFails();

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsSuitabilityPaths.CREATE_ACCOUNTS_SUITABILITY_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
		                .body("accountSuitability", not(empty()))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA", not(empty()))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.riskTolerance", equalTo(1))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.stockMarketDeclinePercent",
		                                equalTo("SELL_LESS_THAN_25"))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.withdrawalStartYear", equalTo(startYear))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.investmentObjectiveIA",
		                                equalTo(investmentObjectiveIA))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.withdrawalNeeds", equalTo(withdrawalNeeds))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.anticipatedExpenses",
		                                equalTo(anticipatedExpenses))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.annualWithdrawalPercent",
		                                equalTo(annualWithdrawalPercent));

	}

	/**
	 * Validate the suitability information just created.
	 */
	@Test(dependsOnMethods = "createAccountSuitability")
	public void getSuitabilityAfterCreate()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
		                .body("accountSuitability", not(empty()))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA", not(empty()))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.riskTolerance", equalTo(1))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.stockMarketDeclinePercent",
		                                equalTo("SELL_LESS_THAN_25"))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.withdrawalStartYear", equalTo(startYear))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.investmentObjectiveIA",
		                                equalTo(investmentObjectiveIA))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.withdrawalNeeds", equalTo(withdrawalNeeds))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.anticipatedExpenses",
		                                equalTo(anticipatedExpenses))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.annualWithdrawalPercent",
		                                equalTo(annualWithdrawalPercent));
	}

	/**
	 * Update the suitability just created.
	 */
	@Test(dependsOnMethods = "getSuitabilityAfterCreate")
	public void updateAccountSuitability()
	{
		// Generate request body
		context.put("riskTolerance", 2);
		context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
		context.put("withdrawalStartYear", startYear);
		context.put("withdrawalEndYear", endYear);
		context.put("investmentObjectiveIA", updatedInvestmentObjectiveIA);
		context.put("withdrawalNeeds", updatedWithdrawalNeeds);
		context.put("anticipatedExpenses", updatedAnticipatedExpenses);
		context.put("annualWithdrawalPercent", updatedAnnualWithdrawalPercent);

		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsSuitabilityPaths.UPDATE_ACCOUNTS_SUITABILITY_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
		                .body("accountSuitability", not(empty()))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA", not(empty()))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.riskTolerance", equalTo(2))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.stockMarketDeclinePercent",
		                                equalTo("SELL_LESS_THAN_25"))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.withdrawalStartYear", equalTo(startYear))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.investmentObjectiveIA",
		                                equalTo(updatedInvestmentObjectiveIA))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.withdrawalNeeds",
		                                equalTo(updatedWithdrawalNeeds))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.anticipatedExpenses",
		                                equalTo(updatedAnticipatedExpenses))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.annualWithdrawalPercent",
		                                equalTo(updatedAnnualWithdrawalPercent));

	}

	/**
	 * Validate the suitability was updated.
	 */
	@Test(dependsOnMethods = "updateAccountSuitability")
	public void getSuitabilityAfterUpdate()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
		                .body("accountSuitability", not(empty()))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.investmentObjectiveIA",
		                                equalTo(updatedInvestmentObjectiveIA))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.withdrawalNeeds",
		                                equalTo(updatedWithdrawalNeeds))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.anticipatedExpenses",
		                                equalTo(updatedAnticipatedExpenses))
		                .body("accountSuitability.find{it.accountId.id == '" + accountId
		                                + "'}.accountPreferencesIA.annualWithdrawalPercent",
		                                equalTo(updatedAnnualWithdrawalPercent));
	}

	/**
	 * Delete the account.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "getSuitabilityAfterUpdate")
	public void deleteAccountSuitability()
	{
		context.put("ppid", ppid);
		context.put("source", "RETAIL");
		context.put("id", accountId);
		context.put("mnemonic", mnemonic);
		context.put("value", value);
		context.put("accountNumber", accountNumber);
		context.put("displayName", displayName);
		context.put("institutionName", institutionName);
		context.put("asOfDate", asOfDate);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));
		
		//Delete Account
		this.deleteRetailAccount();

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);
	}

	/**
	 * Validate no suitability is returned.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "deleteAccountSuitability")
	public void getSuitabilityAfterDelete()
	{

		FilterableRequestSpecification frs = (FilterableRequestSpecification) this.request;
		frs.removeHeader("excludeExternalDataSources");

		this.request.given().header(new Header("excludeExternalDataSources", "true"));

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountSuitability",
		                empty());

	}
	
	// Delete Account
	private void deleteRetailAccount()
	{
		// Generate request body
		context.put("ppid", ppid);
		context.put("value", String.valueOf(value));
		context.put("mnemonic", mnemonic);
		context.put("displayName", displayName);
		context.put("institutionName", displayName);
		context.put("asOfDate", asOfDate);
		context.put("accountNumber", accountNumber);
		context.put("id", accountId);

		// Generate request body
		this.request.body(
		                IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

		// Call Account service response =
		this.request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);
		// Assert on response
		response.then().log().ifValidationFails().statusCode(200);

	}
}
