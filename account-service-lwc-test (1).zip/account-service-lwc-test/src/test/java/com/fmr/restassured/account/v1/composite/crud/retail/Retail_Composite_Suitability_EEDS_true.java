/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

/**
 * PFCP-18423 Contains tests that validate To remove the account object from suitability
 * call in the get composite call when suitability questions do not go back in the response
 *
 * @author a783909
 */
@Test(groups = {Tags.RETAIL, Tags.ACCOUNT, Tags.V1, Tags.CRITICAL, Tags.TAM})
public class Retail_Composite_Suitability_EEDS_true extends PAPBaseServiceTest
{

	/**
	 * Logger to print appropriate error, warning, or info messages
	 **/
	private static final Logger LOGGER = LogManager.getLogger(Retail_Composite_Suitability_EEDS_true.class);

	/**
	 * Instance to the test data utility class
	 */
	private TestDataUtil testDataUtil;

	private String accNum;

	private String acctRoot;

	/**
	 * Global variable holding the oAuth token generated in the initClass method
	 */
	private String oAuth;

	/**
	 * Global variable holding retailAccount information
	 */
	private HashMap<String, String> retailAccountMap;

	/**
	 * Global variable holding account test data from sqlite
	 */
	private AccountsCommonTestData accountTestData;

	private static final String LOG_TRACKING_ID = Retail_Composite_Suitability_EEDS_true.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private static final String source = "RETAIL";

	private String scenarioId;

	private VelocityContext context;

	private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";

	private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";

	private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";

	private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";

	private final float netPercentage_T_ALTERNATIVE = 0.8f;

	private final float netPercentage_PEA = 0.4f;

	private final float netPercentage_PCA = 0.2f;

	private final float netPercentage_PRAA = 0.2f;

	/**
	 * Constructor
	 */
	protected Retail_Composite_Suitability_EEDS_true()
	{
		super(Services.Account);
	}

	/**
	 * Instantiates TestDataUtil & retrieves oAuth token
	 */
	@BeforeClass(alwaysRun = true)
	public void initClass()
	{

		oAuth = AccountUtil.getOauthToken();
		testDataUtil = new TestDataUtil();
		retailAccountMap = new HashMap<>();

		accountTestData = TestDataUtil.populateRegressionTestData("accountCRUD_Retail", oAuth);

		retailAccountMap = getRetailAccountInformation(accountTestData, oAuth);

		DataCleanup.deleteCustomerDataFromCP("mid", accountTestData.getMid(), oAuth, "true");
		final String ppid = Identity.createHouseholdIdentity(accountTestData.getMid(), oAuth);
		accountTestData.setPpid(ppid);
		// Get/Create ScenarioId
		Response allScenarioIDs = Scenario.getAllScenarios(accountTestData.getMid(), oAuth);
		scenarioId = allScenarioIDs.path("scenario[0].id").toString();
		if (scenarioId == null)
		{
			scenarioId = Scenario.createScenarioWithProductCode(accountTestData.getMid(), "IGE", "DEF",
					oAuth);
		}
	}

	/**
	 * JIRA Item: PFCP-18423 RA Regression Conversion: accountComposite CRUD Retail V1&V2
	 * <p>
	 * Description: Validates an empty account list when calling get account composite retail before creation of an
	 * account
	 */
	@Test()
	public void getCompositeAccountRetailBeforeCreate()
	{
		if (retailAccountMap.isEmpty())
		{
			throw new SkipException(
					"'getCompositeAccountRetailBeforeCreate' test scenario cannot run due to failure to retrieve "
							+ "retail account information!");
		}

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
		context = new VelocityContext();
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("poe", source);
		context.put("externalDataSources", true);
		context.put("source", source);
		context.put("scenarioId", scenarioId);

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
				hasSize(0));
	}

	/**
	 * Description: Validates the account composite response after a create
	 */
	@Test(dependsOnMethods = "getCompositeAccountRetailBeforeCreate")
	public void createCompositeAccountRetail()
	{
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
		accNum = retailAccountMap.get("accountNumber");
		context.put("externalDataSources", true);
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("accountNumber", accNum);
		context.put("source", source);
		context.put("ppid", accountTestData.getPpid());
		context.put("displayName", retailAccountMap.get("displayName"));
		context.put("mnemonic", retailAccountMap.get("mnemonic"));
		context.put("sourceSystem2", source);
		context.put("institutionName", retailAccountMap.get("institutionName"));
		context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
		context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
		context.put("detailValue", "111111.11");
		context.put("emergencyFundAmount", "111111.11");
		context.put("assetClass1", "UNKNOWN");
		context.put("netPercentage1", 0.177);
		context.put("assetClass_T_Equity", "TOTAL_EQUITY");
		context.put("netPercentage_T_Equity", 0);
		context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
		context.put("netPercentage_FE", 0.0f);
		context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
		context.put("netPercentage_DE", 0.0f);
		context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
		context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
		context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
		context.put("netPercentage_PEA", netPercentage_PEA);
		context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
		context.put("netPercentage_PCA", netPercentage_PCA);
		context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
		context.put("netPercentage_PRAA", netPercentage_PRAA);
		context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
		context.put("type", "RetailAccountDetails");
		context.put("contribFreq", "YEARLY");
		context.put("contribValue", "500");
		context.put("contributionTaxType", "POST_TAX");
		context.put("contributionType", "CATCHUP");
		context.put("contributor", "EMPLOYER");
		context.put("contribBasisTypeCd", "BASE");
		context.put("contribFreq2", "BIMONTHLY");
		context.put("contribValue2", "900");
		context.put("contributionTaxType2", "AGGREGATE");
		context.put("contributionType2", "REGULAR");
		context.put("contributor2", "INDIVIDUAL");
		context.put("contribBasisTypeCd2", "BASEBONUS");
		context.put("withdrawAmount", "1000");
		context.put("withdrawFreq", "DAILY");
		context.put("scenarioId", scenarioId);
		context.put("isProductSuitable", "false");
		context.put("suitabilityStatus", "SUITABLE");
		context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
		context.put("withdrawalStartYear", 2055);
		context.put("withdrawalEndYear", 2085);
		context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
		context.put("equityPercent", 0.35);
		context.put("originalOwnerBirthDate", "1958-11-09");
		context.put("originalOwnerDeceasedDate", "2022-11-09");
		context.put("withdrawalEligibilityStartDate", "2022-11-09");
		context.put("withdrawalEligibilityEndDate", "2052-11-09");
		context.put("originalOwnerSpouse", "false");
		context.put("federalTaxWithholding", 0.15);
		context.put("stateTaxWithholding", 0.05);
		context.put("isBackdoorRoth", "true");
		context.put("isManaged", false);
		context.put("TAM_name", "Growth with Income");

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

		response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

		acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
		.body("resultCode", equalTo(true))
		.body(acctRoot + "account.accountId.id", notNullValue());

		accountTestData.setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
	}

	/**
	 * Description:
	 * The suitability object should not be returned when includeSuitabilityDetails is false.
	 * In this case, when EEDS=true.
	 */
	@Test(dependsOnMethods = "createCompositeAccountRetail")
	public void getCompositeAccountRetailwithoutSuitability() {
		final VelocityContext context = new VelocityContext();

		String[] appIdList = {"AP144952", "AP144949", "AP135253", "AP132853", "AP139658", "AP133542", "AP139538", "AP139829", "AP138186", "AP139810", "AP145066", "AP141526", "AP141528", "AP135336", "AP160755", "AP137989", "AP140141"};

		for (String appId : appIdList) {
			setDefaultRequestHeaders(appId, appId, LOG_TRACKING_ID, FSREQID, oAuth);
			context.put("mid", accountTestData.getMid());
			context.put("retailLid", accountTestData.getSsn());
			context.put("poe", source);
			context.put("externalDataSources", true);
			context.put("source", source);
			context.put("scenarioId", scenarioId);

			this.request.given()
					.header(new Header("include-suitability-details", "false"));

			request.body(IOUtil.generateJsonRequest(context,
					AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

			response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
			response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
					.body(acctRoot + "suitability", equalTo(null));
		}
	}

	/**
	 * Description:
	 * The suitability object should be returned when includeSuitabilityDetails is true for whitelisted appIds.
	 * In this case, when EEDS=true.
	 */
	@Test(dependsOnMethods = "getCompositeAccountRetailwithoutSuitability")
	public void getCompositeAccountRetailwithSuitabilityAndWhiteListedAppIds() {
		final VelocityContext context = new VelocityContext();

		String[] appIdList = {"AP144952", "AP144949", "AP135253", "AP132853", "AP139658", "AP133542", "AP139538", "AP139829", "AP138186", "AP139810", "AP145066", "AP141526", "AP141528", "AP135336", "AP160755", "AP137989", "AP140141"};

		for (String appId : appIdList) {
			setDefaultRequestHeaders(appId, appId, LOG_TRACKING_ID, FSREQID, oAuth);
			context.put("mid", accountTestData.getMid());
			context.put("retailLid", accountTestData.getSsn());
			context.put("poe", source);
			context.put("externalDataSources", true);
			context.put("source", source);
			context.put("scenarioId", scenarioId);

			this.request.given()
					.header(new Header("include-suitability-details", "true"));

			request.body(IOUtil.generateJsonRequest(context,
					AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

			response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
			response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
					.body(acctRoot + "suitability", notNullValue());
		}
	}

	/**
	 * Description:
	 * The suitability object should not be returned when includeSuitabilityDetails is false.
	 * In this case, when EEDS=true.
	 */
	@Test(dependsOnMethods = "getCompositeAccountRetailwithSuitabilityAndWhiteListedAppIds")
	public void getCompositeAccountRetailwithSuitability() {
		final VelocityContext context = new VelocityContext();

		String[] appIdList = {"AP106564", "AP118468", "AP145081", "AP136091"};

		for (String appId : appIdList) {
			setDefaultRequestHeaders(appId, appId, LOG_TRACKING_ID, FSREQID, oAuth);
			context.put("mid", accountTestData.getMid());
			context.put("retailLid", accountTestData.getSsn());
			context.put("poe", source);
			context.put("externalDataSources", true);
			context.put("source", source);
			context.put("scenarioId", scenarioId);

			this.request.given()
					.header(new Header("include-suitability-details", "false"));

			request.body(IOUtil.generateJsonRequest(context,
					AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

			response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
			response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
					.body(acctRoot + "suitability", notNullValue());
		}
	}

	/**
	 * Description:
	 * The suitability object should not be returned when includeSuitabilityDetails is true.
	 * In this case, when EEDS=true.
	 */
	@Test(dependsOnMethods = "getCompositeAccountRetailwithSuitability")
	public void getCompositeAccountRetailwithSuitabilityAndNonWhiteListedAppIds() {
		final VelocityContext context = new VelocityContext();

		String[] appIdList = {"AP106564", "AP118468", "AP145081", "AP136091"};

		for (String appId : appIdList) {
			setDefaultRequestHeaders(appId, appId, LOG_TRACKING_ID, FSREQID, oAuth);
			context.put("mid", accountTestData.getMid());
			context.put("retailLid", accountTestData.getSsn());
			context.put("poe", source);
			context.put("externalDataSources", true);
			context.put("source", source);
			context.put("scenarioId", scenarioId);

			this.request.given()
					.header(new Header("include-suitability-details", "true"));

			request.body(IOUtil.generateJsonRequest(context,
					AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

			response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
			response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
					.body(acctRoot + "suitability", notNullValue());
		}
	}

	/**
	 * Description: Validates the account composite response after a delete
	 */
	@Test(dependsOnMethods = "getCompositeAccountRetailwithSuitabilityAndNonWhiteListedAppIds")
	public void deleteCompositeAccountRetail()
	{
		final VelocityContext context = new VelocityContext();

		context.put("externalDataSources", true);
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("accId", accountTestData.getAccountId1());
		context.put("accountNumber", retailAccountMap.get("accountNumber"));
		context.put("source", source);
		context.put("ppid", accountTestData.getPpid());
		context.put("displayName", retailAccountMap.get("displayName"));
		context.put("mnemonic", retailAccountMap.get("mnemonic"));
		context.put("sourceSystem2", source);
		context.put("institutionName", retailAccountMap.get("institutionName"));
		context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
		context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

		response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accountList",
				hasSize(0));
	}

	/**
	 * Description: Validates an empty account list when calling get account composite retail after delete
	 */
	@Test(dependsOnMethods = "deleteCompositeAccountRetail")
	public void getCompositeAccountRetailAfterDelete()
	{
		final VelocityContext context = new VelocityContext();
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("poe", source);
		context.put("externalDataSources", true);
		context.put("source", source);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
				hasSize(0));
	}

	/**
	 * Returns the response of retrieving a retail account
	 *
	 * @param accountsCommonTestData
	 *                the test data
	 * @return retailAccountMap
	 */
	private static HashMap<String, String> getRetailAccountInformation(
			final AccountsCommonTestData accountsCommonTestData, final String oAuth)
	{
		final VelocityContext context = new VelocityContext();
		context.put("mid", accountsCommonTestData.getMid());
		context.put("retailLid", accountsCommonTestData.getSsn());
		context.put("source", "RETAIL");

		RestAssured.reset();
		RestAssured.baseURI = currentHost;
		RestAssured.useRelaxedHTTPSValidation();

		final RequestSpecification request =
				OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		request.given().log().all();
		final Response response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		response.then().log().all();
		if (response.statusCode() != HTTPStatusCodes.STATUS_200)
		{
			LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
					accountsCommonTestData.getSsn()));

			return null;
		}

		final JsonPath retailAccountJP = response.jsonPath();

		final HashMap<String, String> retailAccountMap = new HashMap<>();
		retailAccountMap.put("accountNumber",
				retailAccountJP.getString("accountList[0].accountId.accountNumber"));
		retailAccountMap.put("sourceSystem",
				retailAccountJP.getString("accountList[0].accountId.sourceSystem"));
		retailAccountMap.put("displayName", retailAccountJP.getString("accountList[0].displayName"));
		retailAccountMap.put("mnemonic", retailAccountJP.getString("accountList[0].regCode.mnemonic"));
		retailAccountMap.put("institutionName", retailAccountJP.getString("accountList[0].institutionName"));
		retailAccountMap.put("sourceMarketAmountType",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount._type"));
		retailAccountMap.put("sourceMarketAmountValue",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
		retailAccountMap.put("sourceMarketAmountValueType",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
		retailAccountMap.put("sourceMarketAmountCurrency",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
		retailAccountMap.put("sourceMarketAsOfDate",
				retailAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));

		return retailAccountMap;
	}

	/**
	 * Tear down method
	 */
	@AfterClass(alwaysRun = true)
	public void tearDown()
	{
		testDataUtil.closeSQLiteConnection();
	}
}