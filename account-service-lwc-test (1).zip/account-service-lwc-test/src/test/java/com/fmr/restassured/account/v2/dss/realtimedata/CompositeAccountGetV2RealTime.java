/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.dss.realtimedata;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.MatcherAssert;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Test Composite Account Get operation with real time data from DSS Accounts,Balance Details and Positions API
 *
 * @author a631781
 * Updated by a608077 on 09/13/2022 to include changes for clear-retail-cache flag(PFCP-10001)
 * Updated by a730306 on 08/11/2022 to check unsettledCash, unsettledMargin and unsettledShort value(PFCP-10801)
 * Updated by a608077 on 05/08/2023 to remove unsettled balances when RealTimeData flag is not true(PFCP-12703)
 * Updated by a608077 on 09/25/2023 to add tests for positions data(PFCP-13666)
 */

@Test(groups = {Tags.REAL_TIME_DATA, Tags.V2})
public class CompositeAccountGetV2RealTime extends PAPBaseServiceTest
{

    protected CompositeAccountGetV2RealTime()
    {
	super(Services.Account);
    }

    private VelocityContext context;

    public String mid;

    public String ssn;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String APP_NAME = "Advice and Planning Platform";

    private static final String LOG_TRACKING_ID = CompositeAccountGetV2RealTime.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private FilterableRequestSpecification frs;

    final String oAuth = AccountUtil.getOauthToken();

    private String accNumber;

    private Float value;

    private Float dssRealTimeMktValue, dssPreviousDayMktValue, dssRealTimePrice, dssPreviousDayPrice;

    private Float dssRealTimeQuantity, dssPreviousDayQuantity;

    private Float dssUnsettledCash, dssUnsettledMargin, dssUnsettledShort;

    private Float dssSrcMktValueRealTime, dssSrcMktValuePreviousDay;

    private Float dssCoreBalanceRealTime, dssCoreBalancePreviousDay;

    public static final String ACCOUNT_CATEGORY = "Brokerage";

    private String accountAsOfDateTime;

    private Integer dssAsOFDate;

    private TestDataUtil testDataUtil;

    @BeforeTest
    public void init()
    {
	AccountsCommonTestData accountsCommonTestData = TestDataUtil
			.populateRegressionTestData("retail_esop_account", oAuth);

	this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);
	this.ssn = accountsCommonTestData.getSsn();
	mid = accountsCommonTestData.getMid();

	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



	frs = (FilterableRequestSpecification) request;

	testDataUtil = new TestDataUtil();

	context = new VelocityContext();
	context.put("source", AccountConstants.RETAIL);
	context.put("sourceBasedRegistrationFilter", AccountConstants.RETAIL);

    }

    /**
     * Tests that DSS service data is brought back for all account.
     */
    @Test
    public void getAccounts_V2_DSS()
    {

	frs.removeHeaders();
	this.setDefaultRequestHeadersForDSS();

	context.put("acctCategory", ACCOUNT_CATEGORY);
	context.put("returnAccountGainLossBalanceDetail", "true");

	this.request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DSS_BALANCE_V2_TEMPLATE));

	response = this.request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
			.body("acctDetails", not(emptyArray()))
			.body("acctDetails[0].acctNum", notNullValue())
			.body("acctDetails[0].gainLossBalanceDetail.totalMarketVal", notNullValue())
			.body("acctDetails[0].acctType", equalTo(ACCOUNT_CATEGORY));

	accNumber = this.response.path("acctDetails[0].acctNum");
	value = this.response.path("acctDetails[0].gainLossBalanceDetail.totalMarketVal");
	dssAsOFDate = this.response.path("acctDetails[0].gainLossBalanceDetail.asOfDateTime");

    }

    @Test(dependsOnMethods = "getAccounts_V2_DSS")
    public void getDSS_AccountPosition_V2()
    {

	FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
	frs.removeHeaders();

	this.setDefaultRequestHeadersForDSS();

	context.put("acctCategory", ACCOUNT_CATEGORY);
	context.put("returnAvailabilityStatus", "true");
	context.put("returnAccountGainLossDetail", "true");
	context.put("returnPositionMarketValDetail", "true");
	context.put("returnAdditionalPositionDetail", "true");
	context.put("accountNumber", accNumber);

	this.request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_POSITION_V2));

	Response dssPositionResponse = this.request.post(AccountConstants.DSS_ACCOUNT_POSITIONS_V2_PATH);

	// Assert on response
	dssPositionResponse.then().statusCode(anyOf(is(200), is(206)))
			.body("position.acctDetails.acctDetail", not(emptyArray()))
			.body("position.acctDetails.acctDetail.acctNum", notNullValue())
			.body("position.acctDetails.acctDetail.accountGainLossDetail.accountMarketVal", notNullValue())
			.body("position.acctDetails.acctDetail.activityDetail.unsettledCash", notNullValue());

	dssAsOFDate = dssPositionResponse.path("position.acctDetails.acctDetail[0].asOfDateTime");
	dssUnsettledCash = dssPositionResponse.path("position.acctDetails.acctDetail[0].activityDetail.unsettledCash");
	dssUnsettledMargin =
			dssPositionResponse.path("position.acctDetails.acctDetail[0].activityDetail.unsettledMargin");
	dssUnsettledShort =
			dssPositionResponse.path("position.acctDetails.acctDetail[0].activityDetail.unsettledShort");
	//positions related data
	dssRealTimeMktValue = dssPositionResponse
			.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[0].marketValDetail.marketVal");
	dssPreviousDayMktValue = dssPositionResponse
			.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[0].marketValDetail.closingMktValue");
	dssRealTimePrice = dssPositionResponse
			.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[0].priceDetail.lastPrice");
	dssPreviousDayPrice = dssPositionResponse
			.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[0].priceDetail.closingPrice");
	dssRealTimeQuantity = dssPositionResponse
			.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[0].quantity");
	dssPreviousDayQuantity = dssPositionResponse
			.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[0].endOfDaySettledShareQuantity");

    }

    @Test(dependsOnMethods = "getAccounts_V2_DSS")
    public void getAccountBalanceDetail_V2_DSS()
    {

	frs.removeHeaders();
	this.setDefaultRequestHeadersForDSS();

	// Generate request body
	context.put("acctCategory", ACCOUNT_CATEGORY);
	context.put("accountNumber", accNumber);
	context.put("acctSubType", ACCOUNT_CATEGORY);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_DETAILS_V2));

	request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
	response = request.log().ifValidationFails().post(AccountConstants.DSS_ACCOUNT_DETAILS_V2_PATH);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200);

	dssSrcMktValueRealTime =
			response.path("balances[0].brokerageAcctDetail.recentBalanceDetail.acctValDetail.netWorth");
	dssSrcMktValuePreviousDay =
			response.path("balances[0].brokerageAcctDetail.closeBalanceDetail.acctValDetail.netWorth");
	dssCoreBalanceRealTime =
			response.path("balances[0].brokerageAcctDetail.recentBalanceDetail.cashDetail.coreBalance");
	dssCoreBalancePreviousDay =
			response.path("balances[0].brokerageAcctDetail.closeBalanceDetail.cashDetail.coreBalance");
    }

    /**
     * get composite account call with realTimeData=true
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getDSS_AccountPosition_V2")
    public void getCompositeAccounts_V2RealTimeDataTrue()
    {
	frs.removeHeaders();
	this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

	this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);

	this.request.header(new Header("user-poe", "RETAIL"))
			.header(new Header("scenario-category-code", "DEF"))
			.header(new Header("scenario-product-code", "IGE"))
			.header(new Header("user-retail-lid", this.ssn))
			.header(new Header("user-mid", mid))
			.header(new Header("realTimeData", "true"))
			.header(new Header("clear-retail-cache", "true"));

	this.request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

	Response accountResponse = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
	accountResponse.then().log().ifValidationFails().statusCode(200)
			.body("accounts.find{it.account.accountId.accountNumber=='" + accNumber
					+ "'}.account.sourceMarketValue.asOfDate", notNullValue())
			.body("accounts.find{it.account.accountId.accountNumber=='" + accNumber
					+ "'}.account.sourceMarketValue.amount.value", notNullValue());

	Float AccUnsettledCash = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + accNumber
			+ "'}.account.unsettledCashValue.value");
	Float AccUnsettledMargin =
			accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + accNumber
					+ "'}.account.unsettledMargin.value");
	Float AccUnsettledShort = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + accNumber
			+ "'}.account.unsettledShort.value");
	accountAsOfDateTime = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
			+ accNumber + "'}.account.sourceMarketValue.asOfDate");

	// Assert on response
	accountResponse.then().body("accounts", not(emptyArray()))
			.body("accounts[0].account.accountId", not(emptyArray()))
			.body("accounts.find{it.account.accountId.accountNumber=='" + accNumber
					+ "'}.account.accountId.accountNumber", equalTo(accNumber))
			.body("accounts.find{it.account.accountId.accountNumber=='" + accNumber
					+ "'}.account.accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
			//positions assertions
			.body("accounts.find{it.account.accountId.accountNumber=='"
							+ accNumber
							+ "'}.positions.allPositions[0].financialAssetPosition.position.quantity",
					equalTo(dssRealTimeQuantity));
	Float realTimeMktValue = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + accNumber + "'}.positions.allPositions[0].financialAssetPosition.position.marketValue.value");

			Float realTimePrice = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
					+ accNumber
					+ "'}.positions.allPositions[0].financialAssetPosition.position.price.value");

	assertThat(realTimeMktValue).isCloseTo(dssRealTimeMktValue, within(dssRealTimeMktValue * 0.01f));
	assertThat(realTimePrice).isCloseTo(dssRealTimePrice, within(dssRealTimePrice * 0.01f));

	//balances assertions
	Float srcMktValueRealTime = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
			+ accNumber + "'}.account.sourceMarketValue.amount.value");

	Float coreBalanceRealTime = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
			+ accNumber
			+ "'}.details.retailAccountDetail.accountDetail.coreBalance.amount.value");

	assertThat(srcMktValueRealTime).isCloseTo(dssSrcMktValueRealTime, within(dssSrcMktValueRealTime * 0.01f));
	assertThat(coreBalanceRealTime).isCloseTo(dssCoreBalanceRealTime, within(dssCoreBalanceRealTime * 0.01f));
	if (null != dssUnsettledCash)
	{
	    Assert.assertEquals(dssUnsettledCash, AccUnsettledCash);
	}

	if (null != dssUnsettledMargin)
	{
	    Assert.assertEquals(dssUnsettledMargin, AccUnsettledMargin);
	}

	if (null != dssUnsettledShort)
	{
	    Assert.assertEquals(dssUnsettledShort, AccUnsettledShort);
	}
	validateDate();

    }

    /*
     * Get composite account v2 call with realTimeData=false
     */
        @Test(dependsOnMethods = {"getCompositeAccounts_V2RealTimeDataTrue"})
        public void getCompositeAccounts_V2RealTimeDataFalse()
        {
    	frs.removeHeaders();
    	this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

    	this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);

    	this.request.header(new Header("user-poe", "RETAIL"))
    			.header(new Header("scenario-category-code", "DEF"))
    			.header(new Header("scenario-product-code", "IGE"))
    			.header(new Header("user-retail-lid", this.ssn))
    			.header(new Header("realTimeData", "false"))
    			.header(new Header("clear-retail-cache", "true"));

    	this.request.body(IOUtil.generateJsonRequest(context,
    			AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

    	this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

    	// Assert on response
    	response.then().log().ifValidationFails().statusCode(200).body("accounts", not(emptyArray()))
    			.body("accounts[0].account.accountId", not(emptyArray()))
    			.body("accounts.find{it.account.accountId.accountNumber=='" + accNumber
    					+ "'}.account.accountId.accountNumber", equalTo(accNumber))
    			.body("accounts.find{it.account.accountId.accountNumber=='" + accNumber
    					+ "'}.account.accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
    			.body("accounts.find{it.account.accountId.accountNumber=='" + accNumber
    					+ "'}.account.unsettledCashValue.value", Matchers.equalTo(null))
    			.body("accounts.find{it.account.accountId.accountNumber=='" + accNumber
    					+ "'}.account.unsettledMargin.value", Matchers.equalTo(null))
    			.body("accounts.find{it.account.accountId.accountNumber=='" + accNumber
    					+ "'}.account.unsettledShort.value", Matchers.equalTo(null))
    			//positions assertions
    			.body("accounts.find{it.account.accountId.accountNumber=='"
    							+ accNumber
    							+ "'}.positions.allPositions[0].financialAssetPosition.position.marketValue.value",
    					equalTo(dssPreviousDayMktValue))
    			.body("accounts.find{it.account.accountId.accountNumber=='"
    							+ accNumber
    							+ "'}.positions.allPositions[0].financialAssetPosition.position.price.value",
    					equalTo(dssPreviousDayPrice))
    			.body("accounts.find{it.account.accountId.accountNumber=='"
    							+ accNumber
    							+ "'}.positions.allPositions[0].financialAssetPosition.position.quantity",
    					equalTo(dssPreviousDayQuantity))
    			//balances assertions
    			.body("accounts.find{it.account.accountId.accountNumber=='"
    							+ accNumber + "'}.account.sourceMarketValue.amount.value",
    					equalTo(dssSrcMktValuePreviousDay))
    			.body("accounts.find{it.account.accountId.accountNumber=='"
    							+ accNumber
    							+ "'}.details.retailAccountDetail.accountDetail.coreBalance.amount.value",
    					equalTo(dssCoreBalancePreviousDay));

        }

    private void validateDate()
    {

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.ENGLISH);

	String dssAsOfDateTime = AccountUtil.parseDSSDate(dssAsOFDate.longValue());

	ZonedDateTime formattedDateDSS = ZonedDateTime.parse(dssAsOfDateTime, formatter);

	String DSSDateValue = dssAsOfDateTime.substring(0, 10);

	String AccountDateValue = accountAsOfDateTime.substring(0, 10);

	ZonedDateTime formattedDateAccount = ZonedDateTime.parse(accountAsOfDateTime, formatter);

	/*
	 * Validations on Date and Time
	 */
	Assert.assertEquals(accountAsOfDateTime.length() - 15, dssAsOfDateTime.length() - 15);

	// Validates the date
	Assert.assertEquals(DSSDateValue, AccountDateValue);

	// Validates the second of time is within a range of 60second of DSS(Added for clear-cache-retail flag)
	MatcherAssert.assertThat(formattedDateAccount.getSecond(),
			is(both(greaterThan(formattedDateDSS.getSecond() - 60))
					.and(lessThan(formattedDateDSS.getSecond() + 60))));

    }

    private void setDefaultRequestHeadersForDSS()
    {
	this.request.given().header(new Header("AppId", "AP106532"))
			.header(new Header("fsreqid", FSREQID))
			.header(new Header("Authorization", oAuth))
			.header(new Header("AppName", APP_NAME))
			.header(new Header("rtazlid", this.ssn))
			.header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
			.header(new Header("FACSC", "ROLE=FidCust"))
			.header(new Header("FACMC", "MID=" + mid))
			.header(new Header("Content-Type", "application/json"));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	this.testDataUtil.closeSQLiteConnection();
    }
}