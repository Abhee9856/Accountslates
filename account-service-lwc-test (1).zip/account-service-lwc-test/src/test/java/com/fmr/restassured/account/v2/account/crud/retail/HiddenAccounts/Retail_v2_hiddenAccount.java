package com.fmr.restassured.account.v2.account.crud.retail.HiddenAccounts;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.config.HeaderConfig.headerConfig;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

public class Retail_v2_hiddenAccount extends PAPBaseServiceTest {

    protected Retail_v2_hiddenAccount() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private final String source = "RETAIL";

    private final float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String asOfDate1 = "2014-10-31";

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private String mid;// = "RetailAccountV2TestMid";

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accNumber;

    private String accId;

    private static final String sourceSystem = "RETAIL";

    private String mnemonic;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {

        RestAssured.filters(new RequestLoggingFilter(),new ResponseLoggingFilter());

        final String oAuth = AccountUtil.getOauthToken();
        this.accountsCommonTestData = TestDataUtil.populateRegressionTestData("retail_is_hidden_account", oAuth);
        this.testDataUtil = new TestDataUtil();

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
        this.accountsCommonTestData.setAsOfDate1(this.asOfDate1);
        this.accountsCommonTestData.setValue1(this.value);
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


        this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", this.accountsCommonTestData.getMid(), oAuth));

        this.setDefaultRequestHeaders(oAuth);
        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()))
                .header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("log-tracking-id", "AP136091PFCP"));

        this.request.given().
                config(RestAssured.config().headerConfig(headerConfig().overwriteHeadersWithName("excludeExternalDataSources"
                        , "Content-Type", "return-hidden-accounts")));
        // Populate request variables
        this.context = new VelocityContext();

    }

    /**
     * Create Retail account with different combination of Regcodes from DataProvider.
     * <p>
     * Version V2
     */

    //Get account info from the backend.
    @Test
    private void getRetailAccountWithHidden() {
        request.header(new Header("excludeExternalDataSources", "false"));
        request.header("return-hidden-accounts", true);
        // Generate request body
        this.context.put("source", this.source);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()));

        accNumber = response.path("accountList.find{it.isHidden == true}.accountId.accountNumber");
        mnemonic = response.path("accountList.find{it.isHidden == true}.regCode.mnemonic");
    }

    //Create Retail Account
    @Test(dependsOnMethods = {"getRetailAccountWithHidden"})
    private void createRetailAccountWithHidden() {
        request.header(new Header("excludeExternalDataSources", "false"));
        // Generate request body
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("value", String.valueOf(this.value));
        this.context.put("mnemonic", mnemonic);
        this.context.put("source", sourceSystem);
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("id", null);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));
        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        accId = response.path("accountList[0].accountId.id");
    }


    // Validate the created account.
    @Test(dependsOnMethods = {"createRetailAccountWithHidden"})
    private void getRetailAccountAfterCreateWithHidden() {
        // Exclude external data sources
        this.request.given().header(new Header("excludeExternalDataSources", "true"));
        this.context.put("source", this.source);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source));
    }

    // Update account
    @Test(dependsOnMethods = {"getRetailAccountAfterCreateWithHidden"})
    private void updateRetailAccountWithHidden() {
        // Generate request body
        this.context.put("source", sourceSystem);
        this.context.put("id", accId);
        this.context.put("value", this.updatedValue);
        this.context.put("mnemonic", mnemonic);
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(updatedValue));

    }

    // Validate Updated account
    @Test(dependsOnMethods = {"updateRetailAccountWithHidden"})
    private void getRetailAccountAfterUpdateWithHidden() {
        // Exclude external data sources
        this.request.given().header(new Header("excludeExternalDataSources", "true"));
        this.context.put("source", this.source);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(updatedValue));
    }


    // Delete Account
    @Test(dependsOnMethods = {"getRetailAccountAfterUpdateWithHidden"})
    private void deleteRetailAccountWithHidden() {
        // Generate request body
        this.context.put("source", sourceSystem);
        this.context.put("value", this.updatedValue);
        this.context.put("mnemonic", mnemonic);
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("id", accId);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service response =
        this.request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

    }

    //Validate Account after delete
    @Test(dependsOnMethods = {"deleteRetailAccountWithHidden"})
    private void getRetailAccountAfterDeleteWithHidden() {
        this.context.put("source", this.source);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }

}
