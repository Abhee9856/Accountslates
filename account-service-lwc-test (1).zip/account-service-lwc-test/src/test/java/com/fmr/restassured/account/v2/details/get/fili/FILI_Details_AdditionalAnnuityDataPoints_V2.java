/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.get.fili;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;

import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.is;

/**
 * Contains tests that validate additional data elements for the FILI Details operation
 *
 * @author a631781
 */
public class FILI_Details_AdditionalAnnuityDataPoints_V2 extends PAPBaseServiceTest {

    protected FILI_Details_AdditionalAnnuityDataPoints_V2() {
        super(Services.Account);
    }

    private String accountNumber;
    private String acctSubTypeDSSAccount = "Fixed Deferred Annuity";
    private String acctSubType = "Fixed Annuity";
    private String filiSystem = "OCI";
    private String ssn;
    private String mid;
    public static final String ACCOUNT_CATEGORY = "Annuity";
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = FILI_Details_AdditionalAnnuityDataPoints_V2.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String APP_NAME = "Advice and Planning Platform";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private static final String sourceSystem = "FILI";
    private Response accountResponse;
    private final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;
    private VelocityContext context;
    private FilterableRequestSpecification frs;

    private String deferredAnnuityIndicator;
    private Boolean isTaxQualified;
    private String maturityDate;
    private String surrenderChargeFreeDate;
    private Float guaranteedInterestRate;
    private String guaranteePeriod;
    private String guaranteedInterestRateEndDate;
    private String productName;
    private String insuranceCompanyName;

    private String deferredAnnuityIndicatorDSS;
    private Boolean isTaxQualifiedDSS;
    private Long maturityDateDSS;
    private Integer surrenderChargeFreeDateDSS;
    private Float guaranteedInterestRateDSS;
    private String guaranteePeriodDSS;
    private Integer guaranteedInterestRateEndDateDSS;
    private String productNameDSS;
    private String insuranceCompanyNameDSS;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_get_FILI_Reg_Code_T_85", oAuth);

        mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ssn = accountsCommonTestData.getSsn();
        testDataUtil = new TestDataUtil();

        // Populate request context with user IDs
        context = new VelocityContext();

        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Tests that account data is brought back for Fili account.
     * <p>
     * Version V2
     */
    @Test
    public void getFiliAccountInfo() {
        // Generate request body
        setRequestHeadersForAccount();
        context.put("source", sourceSystem);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service v2
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(200)
                .body("accountList[0].accountId.sourceSystem", equalTo(sourceSystem))
                .body("accountList", Matchers.not(Matchers.hasSize(0)));

    }

    /**
     * Test to get the DSS FILI account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getFiliAccountInfo"})
    public void getDSS_FILIAccount_V2() {
        //Set DSS Headers
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().statusCode(anyOf(is(200), is(206)));
        accountNumber = response.path("acctDetails.find{it.acctSubType=='" + acctSubTypeDSSAccount + "'}.acctNum");

    }

    /**
     * Test to get the DSS FILI Details
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDSS_FILIAccount_V2"})
    public void getDSS_FILIDetails_V2() {
        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);
        context.put("accountNumber", accountNumber);
        context.put("acctSubType", acctSubType);
        context.put("filiSystem", filiSystem);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_DETAILS_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_DETAILS_V2_PATH);

        // Assert on response
        response.then().statusCode(200);
        accountNumber = response.path("balances[0].acctNum");
        deferredAnnuityIndicatorDSS = response.path("balances[0].annuityContractDetail.fixedVarInd");
        isTaxQualifiedDSS = response.path("balances[0].annuityContractDetail.taxQualifiedInd");
        maturityDateDSS = response.path("balances[0].annuityContractDetail.maturityDate");
        surrenderChargeFreeDateDSS = response.path("balances[0].annuityContractDetail.spdaContractDetail.surrenderChargeEndDate");
        guaranteedInterestRateDSS = response.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteedInterestRate");
        guaranteePeriodDSS = response.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteePeriod");
        guaranteedInterestRateEndDateDSS = response.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteedinterestRateEndDate");
        productNameDSS = response.path("balances[0].annuityContractDetail.productName");
        insuranceCompanyNameDSS = response.path("balances[0].annuityContractDetail.insuranceCompanyName");
    }


    /**
     * Tests that Additional Annuity details data is brought back for Details Fili account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDSS_FILIDetails_V2"})
    public void getDetailsAccounts() {
        //Set Account Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        setRequestHeadersForAccount();
        // Generate request body
        context.put("accountNumber", accountNumber);
        context.put("source", sourceSystem);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

        // Call Account service
        accountResponse = request.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

        // Assert on response
        accountResponse.then().statusCode(200)
                .body("accountDetails", not(emptyArray()))
                .body("accountDetails[0].annuityAccountDetail.accountDetail.accountId.accountNumber", notNullValue());
    }

    /**
     * Test to validate Account Details Annuity additional elements
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDetailsAccounts"})
    public void validateResponse() {

        //Account Annuity Details elements
        deferredAnnuityIndicator = accountResponse.path("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='" + accountNumber + "'}.annuityAccountDetail.deferredAnnuityIndicator");
        isTaxQualified = accountResponse.path("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='" + accountNumber + "'}.annuityAccountDetail.isTaxQualified");
        maturityDate = accountResponse.path("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='" + accountNumber + "'}.annuityAccountDetail.maturityDate");
        surrenderChargeFreeDate = accountResponse.path("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='" + accountNumber + "'}.annuityAccountDetail.surrenderChargeFreeDate");
        guaranteedInterestRate = accountResponse.path("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='" + accountNumber + "'}.annuityAccountDetail.guaranteedInterestRate.value");
        guaranteePeriod = accountResponse.path("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='" + accountNumber + "'}.annuityAccountDetail.guaranteePeriod");
        guaranteedInterestRateEndDate = accountResponse.path("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='" + accountNumber + "'}.annuityAccountDetail.guaranteedInterestRateEndDate");
        productName = accountResponse.path("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='" + accountNumber + "'}.annuityAccountDetail.productName");
        insuranceCompanyName = accountResponse.path("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='" + accountNumber + "'}.annuityAccountDetail.insuranceCompanyName");

        //Comparing Account Details Details elements with DSS Details elements
        Assert.assertEquals(productName, productNameDSS);
        Assert.assertEquals(deferredAnnuityIndicator, deferredAnnuityIndicatorDSS);
        Assert.assertEquals(isTaxQualified, isTaxQualifiedDSS);
        Assert.assertEquals(maturityDate, (AccountUtil.parseDSSDate(maturityDateDSS)));
        Assert.assertEquals(insuranceCompanyName, insuranceCompanyNameDSS);
        Assert.assertEquals(guaranteedInterestRate, (guaranteedInterestRateDSS / 100));
        Assert.assertEquals(guaranteePeriod, guaranteePeriodDSS);
        Assert.assertEquals(guaranteedInterestRateEndDate, AccountUtil.parseDSSDate(guaranteedInterestRateEndDateDSS.longValue()));
        Assert.assertEquals(surrenderChargeFreeDate, (AccountUtil.parseDSSDate(surrenderChargeFreeDateDSS.longValue())));
    }


    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS() {
        this.request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", this.ssn))
                .header(new Header("rtazallrealmslids", "FILI=" + this.ssn))
                .header(new Header("FACSC", "ROLE=FidCust"))
                .header(new Header("Content-Type", "application/json"));
    }

    /**
     * Setting  headers for Account Service Services
     */
    private void setRequestHeadersForAccount() {
        // Account headers setup
        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-fili-lid", ssn))
                .header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }
}
