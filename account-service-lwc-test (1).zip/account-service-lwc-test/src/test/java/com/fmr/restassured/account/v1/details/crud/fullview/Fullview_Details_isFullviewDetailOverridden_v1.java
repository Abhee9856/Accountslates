/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.fullview;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.assertj.core.api.Assertions;
import org.hamcrest.CoreMatchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests Account Details V1 for isFullviewDetailOverridden combinations for Fullview Account
 *
 * @author a631781
 */
@Test
public class Fullview_Details_isFullviewDetailOverridden_v1 extends PAPBaseServiceTest {
    protected Fullview_Details_isFullviewDetailOverridden_v1() {
        super(Services.Account);
    }
    Logger logger = LogManager.getLogger(getClass());

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private String ppid;

    // Test data
    private String accountId;

    private String accountNum;

    private String sourceSystem = AccountConstants.FULLVIEW;

    private String displayName;

    private String mnemonic;

    private String institutionName;

    private String asOfDate;

    private VelocityContext context;

    private float value = 818.89f;

    private final float updatedValue = 426.85f;
    private float historicMarketValue = 8888f;
    private float historicMarketValueResponse;
    private Boolean isFullviewDetailOverridden;
    private String acctRoot;
    private Boolean isFullviewDetailOverriddenReq;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        p2TestDataUtil = new TestDataUtil();

        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_FV, oAuth);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        ppid = Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth);
        // Endpoint setup
        setDefaultRequestHeaders(oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("sid", accountsCommonTestData.getSid());
        context.put("source", sourceSystem);

    }
    /**
     * Create Fullview account Details with different combination of isFullviewDetailOverridden from DataProvider.
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getFullViewData",
            dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data) {
        getFullviewAccountInfo();
        createFullviewAccount();
        createAccountDetails();
        getDetailsAfterCreate();
        updateAccountDetails(data);
        getDetailsAfterUpdate();
        deleteAccountDetails();
        getDetailsAfterDelete();
        deleteFullviewAccount();
    }
    /**
     * Tests that account data is brought back for Fullview account.
     * <p>
     * Version V1
     */
    private void getFullviewAccountInfo() {
        // Generate request body
        context.put("externalDataSources", "false");
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service v1
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));
        accountNum = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        mnemonic = response.path("accountList[0].regCode.mnemonic");
        if (null != response.path("accountList[0].sourceMarketValue.amount.value")) {
            value = response.path("accountList[0].sourceMarketValue.amount.value");
        }

    }

    /**
     * Creates a new Fullview account
     * <p>
     * Version V1
     */
    private void createFullviewAccount() {
        context.put("mid", accountsCommonTestData.getMid());
        context.put("sid", accountsCommonTestData.getSid());
        context.put("ppid", ppid);
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNum);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(empty()));
        accountId = response.path("accountList[0].accountId.id");

    }

    /**
     * Create FV account Details Request.
     * <p>
     * Version V1
     */
    private void createAccountDetails() {
        context.put("ppid", ppid);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNum);
        context.put("accId", accountId);
        context.put("isInherited", false);
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "FullViewAccountDetails");
        context.put("_type", "FullviewAccountDetails");
        context.put("externalDataSources", "true");
        context.put("isFullviewDetailOverridden", "");
        context.put("historicMarketValue", "");
        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
        // Call Account service
        response =
                request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

    }

    /**
     * Validate the FV account details after create.
     * <p>
     * Version V1
     */
    private void getDetailsAfterCreate() {

        context.put("externalDataSources", "true");
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        acctRoot = "accountDetails.find{it.accountId.accountNumber='" + accountNum + "'}.";
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode",  equalTo(true))
                .body(acctRoot + "accountId.id", CoreMatchers.equalTo(accountId))
                .body(acctRoot + "accountId.accountNumber", CoreMatchers.equalTo(accountNum))
                .body(acctRoot + "accountId.sourceSystem", CoreMatchers.equalTo(sourceSystem))
                .body(acctRoot + "historicMarketValue.amount.value", CoreMatchers.equalTo(value));
    }

    /**
     * Update the account details for FV account.
     * <p>
     * Version V1
     */
    private void updateAccountDetails(final AccountRegCodeTestData data) {
        context.put("externalDataSources", "false");
        context.put("ppid", ppid);
        context.put("value", updatedValue);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNum);
        context.put("accId", accountId);
        context.put("isInherited", false);
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "FullViewAccountDetails");
        context.put("_type", "FullviewAccountDetails");
        context.put("historicMarketValue", historicMarketValue);
        if (data.getIsFullviewDetailOverridden().equals("Y")) {
            isFullviewDetailOverriddenReq = true;
            isFullviewDetailOverridden = true;

        } else if (data.getIsFullviewDetailOverridden().equals("N")) {
            isFullviewDetailOverriddenReq = false;
            isFullviewDetailOverridden = false;
        } else {
            isFullviewDetailOverriddenReq = null;
            isFullviewDetailOverridden = false;
        }
        context.put("isFullviewDetailOverridden", isFullviewDetailOverriddenReq);
        // Generate request body
        request
                .body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body(acctRoot + "accountId.id", CoreMatchers.equalTo(accountId))
                .body(acctRoot + "accountId.accountNumber", CoreMatchers.equalTo(accountNum))
                .body(acctRoot + "accountId.sourceSystem", CoreMatchers.equalTo(sourceSystem));
        historicMarketValueResponse = response.path(acctRoot + "historicMarketValue.amount.value");
        if (isFullviewDetailOverridden) {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(historicMarketValue);
        } else {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(value);
        }
    }

    /**
     * Validate the updated FV account details.
     * <p>
     * Version V1
     */
    private void getDetailsAfterUpdate() {
        context.put("externalDataSources", "false");
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body(acctRoot + "accountId.id", CoreMatchers.equalTo(accountId))
                .body(acctRoot + "accountId.accountNumber", CoreMatchers.equalTo(accountNum))
                .body(acctRoot + "accountId.sourceSystem", CoreMatchers.equalTo(sourceSystem));

        if (isFullviewDetailOverridden) {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(historicMarketValue);
        } else {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(value);
        }
    }

    /**
     * Delete the FV account details.
     * <p>
     * Version V1
     */
    private void deleteAccountDetails() {
        context.put("externalDataSources", "true");
        context.put("ppid",ppid);
        context.put("value", updatedValue);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNum);
        context.put("accountId", accountId);
        context.put("isInherited", false);
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "FullViewAccountDetails");
        context.put("_type", "FullviewAccountDetails");
        // Generate request body
        request
                .body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));
    }

    /**
     * Validate the manual account was deleted.
     * <p>
     * Version V1
     */
    private void getDetailsAfterDelete() {
        context.put("externalDataSources", "true");
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()), "accountDetails[0].costBasis",
                nullValue());

    }

    //Delete Fullview Account
    private void deleteFullviewAccount() {
        // Generate request body
        context.put("externalDataSources", "true");
        this.context.put("source", sourceSystem);
        this.context.put("value", value);
        this.context.put("mnemonic", mnemonic);
        this.context.put("displayName", displayName);
        this.context.put("institutionName", institutionName);
        this.context.put("asOfDate", asOfDate);
        this.context.put("accountNumber", accountNum);
        this.context.put("id", accountId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service response
        request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

    }


    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        p2TestDataUtil.closeSQLiteConnection();
    }
}


