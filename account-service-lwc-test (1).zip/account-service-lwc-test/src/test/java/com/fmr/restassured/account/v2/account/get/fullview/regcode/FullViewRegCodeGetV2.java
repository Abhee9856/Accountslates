/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.get.fullview.regcode;

import static org.hamcrest.CoreMatchers.notNullValue;
import static io.restassured.config.HeaderConfig.headerConfig;

import org.apache.commons.collections.CollectionUtils;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.http.Header;

/**
 * Tests for v2/account/get operation for FullView accounts using DataProvider
 * (for handling multiiple regCodes).
 *
 * @author a653510
 *
 */
@Test(groups = { Tags.PIPELINE, Tags.ASYNCHRONOUS, Tags.FULLVIEW, Tags.ACCOUNT, Tags.V2, Tags.GET })
public class FullViewRegCodeGetV2 extends PAPBaseServiceTest {
	protected FullViewRegCodeGetV2() {
		super(Services.Account);
	}

	private VelocityContext context;

	/** Instance to the test data utility class */
	private TestDataUtil testDataUtil;

	private String token;
	
	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";
	private Header eeds = new Header("excludeExternalDataSources", "false");

	/**
	 * Initialization method used to populate the UserIdentifiers object based on
	 * the default SSN, set up the endpoint for the test, and build the request body
	 * from Velocity.
	 */
	@BeforeClass
	public void init() {

		this.token = AccountUtil.getOauthToken();
		this.testDataUtil = new TestDataUtil();
		this.setDefaultRequestHeaders(this.token);

		// Endpoint setup
		setDefaultRequestHeaders(token);


		this.request.given()
				.header(new Header("user-poe", AccountConstants.RETAIL))
				.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
				.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
				.header(new Header("log-tracking-id", "AP136091"))
				.header(eeds);
		this.request.given().
		config(RestAssured.config()
				.headerConfig(headerConfig().overwriteHeadersWithName(
						"user-retail-lid",
						"user-mid",
						"Content-Type")));
	}

	/**
	 * Test for getting Fullview Accounts using data provider.
	 *
	 * Version V2
	 */
	@Test(dataProvider = "getFullViewRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
	public void getFullViewAccountsForRegCodes(final AccountRegCodeTestData data) {
		request.given()
		.header(new Header("user-retail-lid", data.getSsn()))
		.header(new Header("user-mid", data.getMidInRequest()));
		
		this.context = new VelocityContext();
		this.context.put("mnemonicFilter", data.getRegCode1());
		this.context.put("mnemonicFilter2", data.getRegCode2());
		this.context.put("mnemonicFilter3", data.getRegCode3());		
		this.context.put("source", data.getSrcFilter());
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accounts", Matchers.not(Matchers.empty()));
		if (CollectionUtils.isNotEmpty(response.path("accountList"))
				&& (response.jsonPath().getList("accountList").size() > 0)) {
			response.then().body("accountList[0].accountId", notNullValue())
			.body("accountList[0].accountId.owner.id", notNullValue())
			.body("accountList[0].accountId.accountNumber", notNullValue())
			.body("accountList[0].regCode.mnemonic", Matchers
					.isOneOf(new String[] { data.getRegCode1(), data.getRegCode2(), data.getRegCode3() }));
		}

	}

	/**
	 *
	 * Cleanup operation for SQLite DB connection
	 *
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections() {
		this.testDataUtil.closeSQLiteConnection();
	}
}
