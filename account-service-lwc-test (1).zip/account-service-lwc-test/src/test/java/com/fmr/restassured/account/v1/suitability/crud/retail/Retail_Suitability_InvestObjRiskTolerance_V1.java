/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.suitability.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsSuitabilityPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;

/**
 * Tests CRUD operations for Account Suitability V1 for Retail accounts when riskTolerance is provided in the investment objective for Create and Update then service should return TAM(not RiskTolerance) based on the riskTolerance mapping.
 *
 * @author a631781
 * <p>
 * Test flow:
 * 1. Create Principal
 * 2. Search for Retail accounts owned by the Principal
 * 3. Create then get Retail account
 * 4. Create then get account suitability for the account created in ICS
 * 5. Update then get account suitability created in step 4
 * 6. Delete the account then get accountsuitability to validate Retail account and
 * suitabililty were deleted
 */
@Test(groups = {Tags.RETAIL, Tags.SUITABILITY, Tags.V1})
public class Retail_Suitability_InvestObjRiskTolerance_V1 extends PAPBaseServiceTest {

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private static final String LOG_TRACKING_ID = Retail_Suitability_InvestObjRiskTolerance_V1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String investObjId = "26";
    private static final Integer investObjRiskTolerance = 2;
    private static final String tamName = "Conservative";
    private static final Integer investObjRiskToleranceUpdate = 5;
    private static final String tamNameUpdated = "Balanced";

    private VelocityContext context;

    private TestDataUtil testDataUtil;

    protected Retail_Suitability_InvestObjRiskTolerance_V1() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the TestData object based on the  SSN, set up the endpoint
     * for the test, and initialize the request context for Velocity with global data.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_suitability_CRUD_Retail", oAuth);

        this.testDataUtil = new TestDataUtil();

        String mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



        // create identity
        String ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        accountsCommonTestData.setPpid(ppid);
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        accountsCommonTestData.setSourceSystem1("RETAIL");

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());

    }

    /**
     * Get retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
                response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode) {
            Assert.assertEquals(dssResultCode, false);
        }

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
    }

    /**
     * Create the retail account in CFP. Save the account ID.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount() {
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()),
                        "accountList[0].regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()));

        // Gets and saves the CFP account ID
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
        context.put("accId", accountsCommonTestData.getAccountId1());
    }

    // Create the account suitability with investmentObjective riskTolerance in ICS.
    @Test(dependsOnMethods = "createRetailAccount")
    public void createAccountSuitability() {
        // Generate request body
        context.put("externalDataSources", false);
        context.put("investObj_riskTolerance", investObjRiskTolerance);
        context.put("investObj_Id", investObjId);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_CREATE_TEMPLATE_V1));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.CREATE_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
                response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2'}.result");
        if (dssResultCode != null) {
            Assert.assertEquals(resultCode, false);
        } else {
            Assert.assertEquals(resultCode, true);
        }
        response.then().log().ifValidationFails()
                .body("accountSuitability", not(empty()));
    }

    //Validate Suitability TAM is saved in ICS.
    @Test(dependsOnMethods = "createAccountSuitability")
    public void getSuitabilityAfterCreate() {
        // Generate request body
        context.put("externalDataSources", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountSuitability", not(empty()))
                .body("accountSuitability.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.investmentObjective.targetAssetMix", not(empty()),
                        "accountSuitability.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.investmentObjective.targetAssetMix.name", equalTo(tamName),
                        "accountSuitability.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.investmentObjective.id", equalTo(investObjId));
    }

    // Update the suitability investmentObjective riskTolerance in ICS.
    @Test(dependsOnMethods = "getSuitabilityAfterCreate")
    public void updateAccountSuitability() {
        // Generate request body
        context.put("externalDataSources", false);
        context.put("investObj_riskTolerance", investObjRiskToleranceUpdate);
        context.put("investObj_Id", investObjId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_UPDATE_TEMPLATE_V1));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.UPDATE_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("accountSuitability", not(empty()))
                .body("accountSuitability.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.investmentObjective.targetAssetMix", not(empty()),
                        "accountSuitability.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.investmentObjective.targetAssetMix.name", equalTo(tamNameUpdated),
                        "accountSuitability.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.investmentObjective.id", equalTo(investObjId));
    }

    //Validate the suitability was updated in ICS.
    @Test(dependsOnMethods = "updateAccountSuitability")
    public void getSuitabilityAfterUpdate() {
        // Generate request body
        context.put("externalDataSources", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", not(empty()))
                .body("accountSuitability.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.investmentObjective.targetAssetMix", not(empty()),
                        "accountSuitability.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.investmentObjective.targetAssetMix.name", equalTo(tamNameUpdated),
                        "accountSuitability.find{it.accountId.id=='" + accountsCommonTestData.getAccountId1() + "'}.investmentObjective.id", equalTo(investObjId));
    }

    // Delete the account.
    @Test(dependsOnMethods = "getSuitabilityAfterUpdate")
    public void deleteAccountSuitability() {
        // Generate request body
        context.put("externalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

    }

    // Validate no suitability is returned.
    @Test(dependsOnMethods = "deleteAccountSuitability")
    public void getSuitabilityAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountSuitability", empty());

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }
}