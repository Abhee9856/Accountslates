/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;


import io.restassured.response.Response;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.equalTo;

/**
 * Tests account/CRUD operation for manual account with Rep Info. Tests will run against V1.
 *
 * @author a608077
 * Updated by a608077 on 10/13/2021 to include changes for 'scenario-id' header(PFCP-6168)
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.ACCOUNT,
        Tags.V1,
        Tags.CRUD})
public class Manual_With_RepInfo extends PAPBaseServiceTest {

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;
    private String mid;// = "ManualAccountV1TestMid";

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private final float updatedValue = 426.85f;
    private String accId;
    private final String workstationId = "4321";
    private final String repId = "1234";

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Manual_With_RepInfo.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;


    protected Manual_With_RepInfo() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {

        final String oAuth = AccountUtil.getOauthToken();

        testDataUtil = new TestDataUtil();
        //Data Setup
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_manual", oAuth);

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);

        //Set default REST header with authorization token
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


        //Set ppid
        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth));
        // Get/Create ScenarioId
        Response allScenarioIDs = Scenario.getAllScenarios(mid, oAuth);

        String scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null) {
            scenarioId = Scenario.createScenarioWithProductCode(mid, "IGE", "DEF", oAuth);
        }
        // Populate request variables
        context = new VelocityContext();

        context.put("mid", accountsCommonTestData.getMid());
        String source = "MANUAL";
        context.put("source", source);
        context.put("scenarioId", scenarioId);


    }

    /**
     * Create a manual account
     */
    @Test
    public void createManualAccount() {

        float value = 818.89f;
        context.put("pointOfEntry", "RETAIL");
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "IRA");
        context.put("value", value);
        String asOfDate1 = "2014-10-31";
        context.put("asOfDate", asOfDate1);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_WITH_SCENARIO_ID_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);

        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        accId = response.path("accountList[0].accountId.id");

    }

    /**
     * Tests that account data is brought back for manual account.
     * Version V1
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void verifyAfterCreate() {

        context.put("repId", repId);
        context.put("workstationId", workstationId);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

        // Set URL to V1 before running again
        response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("userIdentifier.repInformation.repId", equalTo(repId))
                .body("userIdentifier.repInformation.workstationId", equalTo(workstationId))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo("MANUAL"));
    }


    /**
     * Update the account
     */
    @Test(dependsOnMethods = "verifyAfterCreate")
    public void updateManualAccount() {

        context.put("repId", repId);
        context.put("workstationId", workstationId);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("accId", accId);
        context.put("mnemonic", "IRA");
        context.put("value", updatedValue);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_WITH_SCENARIO_ID_TEMPLATE));

        response = request.post(AccountsPaths.UPDATE_ACCOUNT_V1);

        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("userIdentifier.repInformation.repId", equalTo(repId))
                .body("userIdentifier.repInformation.workstationId", equalTo(workstationId))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));
    }

    /**
     * Tests that updated data is brought back from account/get
     * Version V1
     */
    @Test(dependsOnMethods = "updateManualAccount")
    public void verifyAfterUpdate() {
        context.put("repId", repId);
        context.put("workstationId", workstationId);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("userIdentifier.repInformation.repId", equalTo(repId))
                .body("userIdentifier.repInformation.workstationId", equalTo(workstationId))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));

    }

    /**
     * Deletes the manual account
     */
    @Test(dependsOnMethods = "verifyAfterUpdate")
    public void deleteManualAccount() {
        context.put("repId", repId);
        context.put("workstationId", workstationId);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().
                statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("userIdentifier.repInformation.repId", equalTo(repId))
                .body("userIdentifier.repInformation.workstationId", equalTo(workstationId))
                // No accounts are returned
                .body("accountList", hasSize(0));
    }

    /**
     * Tests that updated data is brought back from account/get
     * Version V1
     */
    @Test(dependsOnMethods = "deleteManualAccount")
    public void verifyAfterDelete() {
        context.put("repId", repId);
        context.put("workstationId", workstationId);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().
                statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("userIdentifier.repInformation.repId", equalTo(repId))
                .body("userIdentifier.repInformation.workstationId", equalTo(workstationId))
                // No accounts are returned
                .body("accountList", hasSize(0));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
