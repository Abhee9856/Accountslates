/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.fili;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;

/**
 * Tests Account Composite operation for a FILI account. Test will create, update, and delete a composite
 * account and run get requests before and after each of those operations. 
 *
 * @author a601767
 * Updated by a608077 on 08/26/2022 to include asset allocation changes(PFCP-9908)
 */
@Test(groups = {
		Tags.REGRESSION,
		Tags.FILI,
		Tags.COMPOSITE,
		Tags.V2,
		Tags.TARGET_ACCOUNT })
public class Fili_Composite_v2_withTargetAccount extends PAPBaseServiceTest
{
	// Data setup
	private AccountsCommonTestData accountsCommonTestData;
	private static final float newFundingAmount = 6.66f;

	private final float updatedUnknownAmount = 23.5f;

	private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";
	private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";

	private static final String SCENARIO_CATEGORY_CODE = "DEF";
	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private TestDataUtil testDataUtil;
	//Context
	private final VelocityContext context = new VelocityContext();

	//Financial Instrument IDs and their symbols
	private FinancialInstrumentIds finstIds;

	private static final String CALLING_APP_ID = "AP136091";
	private static final String APP_ID = "AP136091";
	private static final String LOG_TRACKING_ID = Fili_Composite_v2_withTargetAccount.class.getSimpleName();
	private static final String FSREQID = LOG_TRACKING_ID;

	private static final String TRUSTEE_TYPE = "FPTC";
	private static final String TRUSTEE_TYPE_UPDATE = "ABCD";


	protected Fili_Composite_v2_withTargetAccount()
    {
        super(Services.Account);
    }
	
	/**
	 * Initialization method used to:
	 * </br>1. Get the default SSN and use it to retrieve the MID.
	 * </br>2. Set the Base URI
	 * </br>3. Get the account service operation paths.
	 * </br>4. Build the request header (with OAuth token).
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{
		String oAuth = AccountUtil.getOauthToken();

		testDataUtil= new TestDataUtil();

		accountsCommonTestData =
				TestDataUtil.populateRegressionTestData("account_CRUD_RK_FILI_70",oAuth);
		//Data setup
		accountsCommonTestData.set("detailValue", "42619.85");
		accountsCommonTestData.set("contribAmount", "6000.0");
		accountsCommonTestData.set("contribFreq", "YEARLY");
		accountsCommonTestData.set("withdrawAmount", "500.0");
		accountsCommonTestData.set("withdrawFreq", "YEARLY");
		accountsCommonTestData.set("updatedDetailValue", "81819.89");
		accountsCommonTestData.set("updatedAmount", "15000.0");
		accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
		accountsCommonTestData.set("updatedContribAmount", "500.0");
		accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
		accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

		this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        
		//Resolve finstIds      
		finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK","GCASH", "GDSTOCK");

		this.request.given()
	        .header(new Header("user-poe", AccountConstants.RETAIL))
	        .header(new Header("user-mid", accountsCommonTestData.getMid()))
	        .header(new Header("user-sid", accountsCommonTestData.getSid()))
            .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
	        .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
	        .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));

	}

	/**
	 * Get FILI account info from the backend. Save the account number.
	 */
	@Test
	public void getFiliAccountInfo() 
	{
		// Generate request body
		context.put("source", AccountConstants.FILI);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accountList", not(empty()));

		accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
		accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
		accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
		accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
		accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
		accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
		accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
	}
	
	/**
	 * Get composite accounts for user.
	 * 
	 * Version V2
	 */
	@Test(dependsOnMethods="getFiliAccountInfo")
	public void getCompositeAccount()
	{
		// Exclude external data
		context.put("sourceBasedRegistrationFilter", AccountConstants.FILI);
		
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		// Make post request
		response = request.log().ifValidationFails()
				.given()
					.header(new Header("excludeExternalDataSources", "true"))
				.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accounts", empty());

	}
	
	/**
	 * Create a new composite account. Save the account ID and account number.
	 * 
	 * Version V2
	 */
	@Test(dependsOnMethods="getCompositeAccount")
	public void createCompositeAccount()
	{
		// Generate request body
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
		context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
		context.put("GBOND", finstIds.getFinstId("GBOND"));
		context.put("GCASH", finstIds.getFinstId("GCASH"));
		context.put("mnemonic", accountsCommonTestData.getMnemonic1());
		context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
		context.put("value", accountsCommonTestData.getValue1());
		context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		context.put("institutionName", accountsCommonTestData.getInstitutionName1());
		context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
		context.put("contribValue", accountsCommonTestData.get("contribAmount"));
		context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
		context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
		context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
		context.put("detailValue", accountsCommonTestData.get("detailValue"));
		context.put("trusteeType", TRUSTEE_TYPE);
		
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

		// Make post request
		response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accounts", not(empty()));
		
		//Save account number and ID
		accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
		accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
	}
	

	
	/**
	 * Gets composite account and verifies there is content in the response.
	 * 
	 * Version V2 
	 */
	@Test(dependsOnMethods="createCompositeAccount")
	public void getCompositeAccountAfterCreate()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Make post request
		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
						"accounts[0].account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
						"accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
						"accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
						"accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
						"accounts[0].account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
						"accounts[0].account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()),
						"accounts[0].account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()),
						"accounts[0].details.annuityAccountDetail.accountDetail.trusteeType", equalTo(TRUSTEE_TYPE),
						"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value", equalTo(0f),
						"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value", equalTo(0f),
						"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value", equalTo(0f),
						"accounts[0].suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"),
						"accounts[0].contributions.contributions[0].contribution.value", equalTo(Float.valueOf(accountsCommonTestData.get("contribAmount"))),
						"accounts[0].contributions.contributions[0].frequency", equalTo(accountsCommonTestData.get("contribFreq")),
						"accounts[0].withdrawals[0].amount.amount.value", equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
						"accounts[0].withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("withdrawFreq")));
	}
	
	/**
	 * Create a new composite account. Save the account ID and account number.
	 * 
	 * Version V2 
	 */
	@Test(dependsOnMethods="getCompositeAccountAfterCreate")
	public void createTargetAccount()
	{	
		//Target account fields
		context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
		float fundingAccountAmount = 5.55f;
		context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
  		context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
  		context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
  		context.put("category", "INVESTOR_SELECTED_STRATEGY");
		float unknownAmount = 25.0f;
		context.put("unknownAmount", String.valueOf(unknownAmount));
		context.put("trusteeType", TRUSTEE_TYPE);
		
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

		// Make post request
		response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accounts", empty(),
						"targetAccounts", not(empty()),
	  					"targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount),
	  					"targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
	  					"targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
						"targetAccounts[0].fundingAccounts[0].amount.value", equalTo(fundingAccountAmount),
						"targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount),
	  					"targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"),
						"targetAccounts[0].trusteeType", equalTo(TRUSTEE_TYPE));
		
		//Save target account number and ID
		accountsCommonTestData.set(TARGET_ACCOUNT_NUMBER_KEY, response.path("targetAccounts[0].accountId.accountNumber"));
  		accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
	}
	
	
	
	/**
	 * Runs an update on the new account and verifies content in the response.
	 * 
	 * Version V2
	 */
	@Test(dependsOnMethods="createTargetAccount")
	public void updateCompositeAccount()
	{
		// Populate variables for tests into context
		context.put("value", accountsCommonTestData.get("updatedAmount"));
		context.put("contribFreq", accountsCommonTestData.get("updatedContribFreq"));
		context.put("contribValue", accountsCommonTestData.get("updatedContribAmount"));
		context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
		context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
		context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
		context.put("_type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS_TYPE);
		context.put("accId", accountsCommonTestData.getAccountId1());
		context.put("trusteeType", TRUSTEE_TYPE_UPDATE);
		
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));

		// Make post request
		response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accounts", not(empty()));
	}
	
	/**
	 * Runs an update on the new account and verifies content in the response.
	 * 
	 * Version V2
	 */
	@Test(dependsOnMethods="updateCompositeAccount")
	public void updateTargetAccount()
	{
		//Target account fields
		context.put("targetAccountId", accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
		context.put("targetAccountNumber", accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
		context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("fundingAccountAmount", String.valueOf(newFundingAmount));
		context.put("targetAccountSourceMarketValue", String.valueOf(newFundingAmount));
		context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
		context.put("unknownAmount",String.valueOf(updatedUnknownAmount));
		context.put("trusteeType", TRUSTEE_TYPE_UPDATE);
		
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_UPDATE_V2_TEMPLATE));

		// Make post request
		response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accounts", empty(),
						"targetAccounts", not(empty()));
	}
	
	/**
	 * Gets the composite accounts and verifies that content is still coming back.
	 * 
	 * Version V2
	 */
	@Test(dependsOnMethods="updateTargetAccount")
	public void getCompositeAccountAfterUpdate()
	{
		// Generate request body
		context.put("source", null);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Make post request
		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accounts", not(empty()),
						"accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
						"accounts[0].account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
						"accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
						"accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
						"accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
						"accounts[0].account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
						"accounts[0].account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()),
						"accounts[0].account.sourceMarketValue.amount.value", equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
						"accounts[0].details.annuityAccountDetail.accountDetail.trusteeType", equalTo(TRUSTEE_TYPE_UPDATE),
						"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value", equalTo(0f),
						"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value", equalTo(0f),
						"accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value", equalTo(0f),
						"accounts[0].suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"),
						"accounts[0].contributions.contributions[0].contribution.value", equalTo(Float.valueOf(accountsCommonTestData.get("updatedContribAmount"))),
						"accounts[0].contributions.contributions[0].frequency", equalTo(accountsCommonTestData.get("updatedContribFreq")),
						"accounts[0].withdrawals[0].amount.amount.value", equalTo(Float.valueOf(accountsCommonTestData.get("updatedWithdrawAmount"))),
						"accounts[0].withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("updatedWithdrawFreq")),
						"targetAccounts", not(empty()),
	  					"targetAccounts[0].sourceMarketValue.amount.value", equalTo(newFundingAmount),
	  					"targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
	  					"targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
						"targetAccounts[0].fundingAccounts[0].amount.value", equalTo(newFundingAmount),
						"targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(updatedUnknownAmount),
	  					"targetAccounts[0].complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"),
						"targetAccounts[0].trusteeType", equalTo(TRUSTEE_TYPE_UPDATE));
	}
	
	/**
	 * Delete the composite account that we created. Verify the account list is empty.
	 * 
	 * Version V2
	 */
	@Test(dependsOnMethods="getCompositeAccountAfterUpdate")
	public void deleteCompositeAccount()
	{
		// Generate request body
		context.put("source", AccountConstants.FILI);
		context.put("id", accountsCommonTestData.getAccountId1());
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

		// Make post request
		response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("isEmpty()", Matchers.is(true));
	}
	
	/**
	 * Call delete and confirm that no accounts come back in the response.
	 * 
	 * Version V2
	 */
	@Test(dependsOnMethods="deleteCompositeAccount")
	public void getCompositeAccountAfterDelete()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Make post request
		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accounts", empty());
	}
	@AfterClass(alwaysRun = true)
	public void closeDBConnections() {
		testDataUtil.closeSQLiteConnection();
	}
}
