/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.fullview;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.equalTo;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests Account Details V1 for Fullview Account with multiple accounts in a single request
 *
 * @author a653510
 */
@Test(groups = {Tags.FULLVIEW, Tags.CRUD, Tags.V1, Tags.REGRESSION})
public class MultipleFullviewDetailsV1CrudTest extends PAPBaseServiceTest
{

	Logger logger = LogManager.getLogger(this.getClass());

	protected MultipleFullviewDetailsV1CrudTest()
	{
		super(Services.Account);
	}

	/**
	 * Instance to the p2 test data utility class
	 */
	private TestDataUtil p2TestDataUtil;

	private AccountsCommonTestData accountsCommonTestData;

	private String ppid;

	// Test data
	private String accountNum;

	private String sourceSystem = "FULLVIEW";

	private String displayName;

	private String mnemonic;

	private String institutionName;

	private String asOfDate;

	private VelocityContext context;

	private float value = 818.89f;

	private final float updatedValue = 426.85f;

	private final Map<String, String> accNumberRegCodeMap = new HashMap<>();

	private final Map<String, String> accNumberAccIdMap = new HashMap<>();

	private String accountId;

	private String ownerId;

	private final List<AccountsCommonTestData> multiAccountList = new ArrayList<AccountsCommonTestData>();

	private String accId_1;

	private String accId_2;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
	 * for the test, and build the request body from Velocity.
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{
		this.p2TestDataUtil = new TestDataUtil();

		final String oAuth = AccountUtil.getOauthToken();
		this.accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_FV, oAuth);
		DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


		this.ppid = Identity.createHouseholdIdentity(this.accountsCommonTestData.getMid(), oAuth);
		this.logger.debug("New PpID created from Identity : " + this.ppid);
		// Data setup
		this.accountsCommonTestData.setPpid(this.ppid);

		this.logger.debug("OwnerID from Accounts : " + this.accountsCommonTestData.getPpid());
		// Endpoint setup
		this.setDefaultRequestHeaders(oAuth);

		// Populate request variables
		this.context = new VelocityContext();
		this.context.put("mid", this.accountsCommonTestData.getMid());
		this.context.put("sid", this.accountsCommonTestData.getSid());
		this.context.put("source", "FULLVIEW");
	}

	/**
	 * Tests that account data is brought back for Fullview account.
	 * <p>
	 * Version V1
	 */
	@Test
	public void getFullviewAccountInfo()
	{

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE));
		// Call Account service v1
		this.response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));
		final int size = this.response.getBody().jsonPath().getList("accountList").size();
		if (size > 0)
		{
			for (int i = 0; i < size; i++)
			{
				final AccountsCommonTestData data = new AccountsCommonTestData();
				this.accountId = this.response.path("accountList[" + i + "].accountId.id");
				data.setAccountId1(this.accountId);
				this.accountNum = this.response.path("accountList[" + i + "].accountId.accountNumber");
				data.setAccountNumber1(this.accountNum);
				this.sourceSystem = this.response.path("accountList[" + i + "].accountId.sourceSystem");
				data.setSourceSystem1(this.sourceSystem);
				this.displayName = this.response.path("accountList[" + i + "].displayName");
				this.logger.debug("Display Name " + (i + 1) + " : " + this.displayName);
				data.setDisplayName1(this.displayName);
				this.mnemonic = this.response.path("accountList[" + i + "].regCode.mnemonic");
				data.setMnemonic1(this.mnemonic);
				if (null != this.response.path("accountList[" + i + "].sourceMarketValue.amount.value"))
				{
					this.value = this.response.path("accountList[" + i + "].sourceMarketValue.amount.value");
				}
				data.setValue1(this.value);
				this.institutionName = this.response.path("accountList[" + i + "].institutionName");
				data.setInstitutionName1(this.institutionName);
				this.asOfDate = this.response.path("accountList[" + i + "].sourceMarketValue.asOfDate");
				data.setAsOfDate1(this.asOfDate);
				this.ownerId = this.response.path("accountList[" + i + "].accountId.owner.id");

				this.logger.debug("accountNum : " + this.accountNum);
				this.logger.debug("RegCode : " + this.mnemonic);
				this.accNumberRegCodeMap.put(this.mnemonic, this.accountNum);
				this.accNumberAccIdMap.put(this.accountNum, this.accountId);
				this.multiAccountList.add(data);

			}
		}
		this.logger.debug("Data Size : " + this.multiAccountList.size());
		this.logger.debug("Owner ID : " + this.ownerId);
		this.accountsCommonTestData.setPpid(this.ownerId);
		this.logger.debug("AccNumber_RegCode Map : " + this.accNumberRegCodeMap);
		this.logger.debug("AccNumber_AccID Map : " + this.accNumberAccIdMap);
	}

	/**
	 * Creates a new Fullview account
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "getFullviewAccountInfo")
	public void createFullviewAccount()
	{

		final AccountsCommonTestData data1 = this.multiAccountList.get(0);
		final AccountsCommonTestData data2 = this.multiAccountList.get(1);

		this.logger.debug("Acc1 : " + data1.getAccountNumber1());
		this.logger.debug("RegCd1 : " + data1.getMnemonic1());
		this.logger.debug("Acc2 : " + data2.getAccountNumber1());
		this.logger.debug("RegCd2 : " + data2.getMnemonic1());

		this.context.put("mid", this.accountsCommonTestData.getMid());
		this.context.put("sid", this.accountsCommonTestData.getSid());
		this.context.put("ppid", this.accountsCommonTestData.getPpid());
		this.context.put("mnemonic", data1.getMnemonic1());
		this.context.put("value", this.value);
		this.context.put("source", this.sourceSystem);
		this.context.put("accountNumber", data1.getAccountNumber1());
		this.context.put("displayName", data1.getDisplayName1());
		this.context.put("institutionName", data1.getInstitutionName1());
		this.context.put("asOfDate", data1.getAsOfDate1());
		this.context.put("accountNumber2", data2.getAccountNumber1());
		this.context.put("ppid2", accountsCommonTestData.getPpid());
		this.context.put("mnemonic2", data2.getMnemonic1());
		this.context.put("displayName2", data2.getDisplayName1());
		this.context.put("source2", this.sourceSystem);
		this.context.put("value2", this.value);
		this.context.put("asOfDate2", data2.getAsOfDate1());

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V1);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200)
		        // .body("resultCode", equalTo(true))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));
		this.accId_1 = this.response.path(
		        "accountList.find{it.accountId.accountNumber == \"" + data1.getAccountNumber1() + "\" }.accountId.id");
		this.logger.debug(this.accId_1);
		this.multiAccountList.get(0).setAccountId1(this.accId_1);
		this.accId_2 = this.response.path(
		        "accountList.find{it.accountId.accountNumber == \"" + data2.getAccountNumber1() + "\" }.accountId.id");
		this.logger.debug(this.accId_2);
		this.multiAccountList.get(1).setAccountId1(this.accId_2);
		this.logger.debug("MultiAccount List : " + this.multiAccountList.toString());
	}

	/**
	 * Create new FV account Details for the existing account.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "createFullviewAccount")
	public void createAccountDetails()
	{
		final AccountsCommonTestData data1 = this.multiAccountList.get(0);
		final AccountsCommonTestData data2 = this.multiAccountList.get(1);

		this.logger.debug("Acc1 : " + data1.getAccountNumber1());
		this.logger.debug("RegCd1 : " + data1.getMnemonic1());
		this.logger.debug("Acc2 : " + data2.getAccountNumber1());
		this.logger.debug("RegCd2 : " + data2.getMnemonic1());

		this.context.put("mid", this.accountsCommonTestData.getMid());
		this.context.put("sid", this.accountsCommonTestData.getSid());
		this.context.put("ppid", this.accountsCommonTestData.getPpid());

		this.context.put("value", this.value);
		this.context.put("source", this.sourceSystem);
		this.context.put("accountNumber", data1.getAccountNumber1());
		this.context.put("accId", data1.getAccountId1());

		this.context.put("accountNumber2", data2.getAccountNumber1());
		this.context.put("source2", this.sourceSystem);
		this.context.put("value2", this.value);
		this.context.put("accId2", data2.getAccountId1());

		this.context.put("isInherited", false);
		this.context.put("isPreviousEmployersAccount", false);
		this.context.put("state", "NC");
		this.context.put("type", "FullViewAccountDetails");
		this.context.put("_type", "FullviewAccountDetails");
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("userIdentifier.mid",
		        equalTo(this.accountsCommonTestData.getMid()));

	}

	/**
	 * Validate the FV account.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "createAccountDetails")
	public void getDetailsAfterCreate()
	{
		// context.put("externalDataSources", "true");
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()), "accountDetails[0].isInherited",
		        equalTo(false), "accountDetails[0].isPreviousEmployersAccount", equalTo(false),
		        "accountDetails[0].state", equalTo("NC"));

	}

	/**
	 * Update the details for FV account.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "getDetailsAfterCreate")
	public void updateAccountDetails()
	{
		final AccountsCommonTestData data1 = this.multiAccountList.get(0);
		final AccountsCommonTestData data2 = this.multiAccountList.get(1);

		this.logger.debug("Acc1 : " + data1.getAccountNumber1());
		this.logger.debug("RegCd1 : " + data1.getMnemonic1());
		this.logger.debug("Acc2 : " + data2.getAccountNumber1());
		this.logger.debug("RegCd2 : " + data2.getMnemonic1());

		this.context.put("mid", this.accountsCommonTestData.getMid());
		this.context.put("sid", this.accountsCommonTestData.getSid());
		this.context.put("ppid", this.accountsCommonTestData.getPpid());

		this.context.put("value", this.updatedValue);
		this.context.put("source", this.sourceSystem);
		this.context.put("accountNumber", data1.getAccountNumber1());
		this.context.put("accId", data1.getAccountId1());

		this.context.put("accountNumber2", data2.getAccountNumber1());
		this.context.put("source2", this.sourceSystem);
		this.context.put("value2", this.updatedValue);
		this.context.put("accId2", data2.getAccountId1());

		this.context.put("isInherited", true);
		this.context.put("isPreviousEmployersAccount", true);
		this.context.put("state", "NC");
		this.context.put("type", "FullViewAccountDetails");
		this.context.put("_type", "FullviewAccountDetails");
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("userIdentifier.mid",
		        equalTo(this.accountsCommonTestData.getMid()));
	}

	/**
	 * Validate the updated FV account.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "updateAccountDetails")
	public void getDetailsAfterUpdate()
	{
		// context.put("externalDataSources", "true");
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()), "accountDetails[0].isInherited",
		        equalTo(true), "accountDetails[0].isPreviousEmployersAccount", equalTo(true), "accountDetails[0].state",
		        equalTo("NC"));

	}

	/**
	 * Delete the FV account details.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "getDetailsAfterUpdate")
	public void deleteAccountDetails()
	{
		final AccountsCommonTestData data1 = this.multiAccountList.get(0);
		final AccountsCommonTestData data2 = this.multiAccountList.get(1);

		this.context.put("mid", this.accountsCommonTestData.getMid());
		this.context.put("sid", this.accountsCommonTestData.getSid());
		this.context.put("ppid", this.accountsCommonTestData.getPpid());

		this.context.put("value", this.updatedValue);
		this.context.put("source", this.sourceSystem);
		this.context.put("accountNumber", data1.getAccountNumber1());
		this.context.put("accId", data1.getAccountId1());

		this.context.put("accountNumber2", data2.getAccountNumber1());
		this.context.put("source2", this.sourceSystem);
		this.context.put("value2", this.updatedValue);
		this.context.put("accId2", data2.getAccountId1());

		this.context.put("isInherited", true);
		this.context.put("isPreviousEmployersAccount", true);
		this.context.put("state", "NC");
		this.context.put("type", "FullViewAccountDetails");
		this.context.put("_type", "FullviewAccountDetails");
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("userIdentifier.mid",
		        equalTo(this.accountsCommonTestData.getMid()));
	}

	/**
	 * Validate the FullView account details which have been deleted.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "deleteAccountDetails")
	public void getDetailsAfterDelete()
	{
		// context.put("externalDataSources", "true");
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()), "accountDetails[0].costBasis",
		        nullValue());

	}

	@AfterClass(alwaysRun = true)
	public void closeDBConnections()
	{
		this.p2TestDataUtil.closeSQLiteConnection();
	}
}
