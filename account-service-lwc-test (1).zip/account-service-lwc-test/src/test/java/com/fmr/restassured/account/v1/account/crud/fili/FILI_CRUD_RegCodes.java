/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.fili;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.equalTo;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

/**
 * Tests for v1 CRUD operations for FILI accounts using DataProvider (for
 * handling multiiple regCodes).
 *
 * @author a653510
 *
 */
@Test(groups = {Tags.ASYNCHRONOUS, Tags.FILI, Tags.ACCOUNT, Tags.V1})
public class FILI_CRUD_RegCodes extends PAPBaseServiceTest {
	Logger logger = LogManager.getLogger(this.getClass());

	protected FILI_CRUD_RegCodes() {
		super(Services.Account);
	}

	// Data setup
	private AccountsCommonTestData accountsCommonTestData = null;

	private VelocityContext context;

	private float value = 120.0F;

	private final float updatedValue = 426.85f;
	private final String source = "FILI";
	private final String asOfDate1 = "2014-10-31";

	/** Instance to the test data utility class */
	private TestDataUtil testDataUtil;
	private final Map<String, String> accIdRegCodeMap = new TreeMap<>();
	private final Map<String, String> accNumberRegCodeMap = new TreeMap<>();
	private String mid;//;
	private String accId;

	private String accNumber;

	private String accRegCode;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on
	 * the default SSN, set up the endpoint for the test, and build the request body
	 * from Velocity.
	 */
	@BeforeClass(alwaysRun = true)
	public void init() {
		final String oAuth = AccountUtil.getOauthToken();
		this.accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_FILI_70", oAuth);
		this.testDataUtil = new TestDataUtil();
		this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
		this.accountsCommonTestData.setAsOfDate1(this.asOfDate1);
		this.accountsCommonTestData.setValue1(value);
		DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


		this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", this.accountsCommonTestData.getMid(), oAuth));

		this.setDefaultRequestHeaders(oAuth);

		// Populate request variables
		this.context = new VelocityContext();
		this.context.put("mid", this.accountsCommonTestData.getMid());
		this.context.put("filiLid", this.accountsCommonTestData.getSsn());

		this.context.put("ppid", this.accountsCommonTestData.getPpid());
		this.context.put("value", String.valueOf(this.value));

	}

	/**
	 * Get account info from the backend. Save the account number.
	 */
	@Test
	public void getFiliAccountInfo() {
		this.context.put("source", source);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE));
		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
				equalTo(true));
		this.accountsCommonTestData.setMnemonic1(this.response.path("accountList[0].regCode.mnemonic"));

		List<Map<String, String>> acctResponse = response.jsonPath().getList("accountList");
		for (int i = 0; i < acctResponse.size(); i++) {

			accRegCode = this.response.path("accountList[" + i + "].regCode.mnemonic").toString();
			accNumber = response.path("accountList[" + i + "].accountId.accountNumber");
			this.accNumberRegCodeMap.put(accRegCode, accNumber);
		}

		this.accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
		this.accountsCommonTestData.setSourceSystem1(this.response.path("accountList[0].accountId.sourceSystem"));
		this.accountsCommonTestData.setDisplayName1(this.response.path("accountList[0].displayName"));

		if (null != (response.path("accountList[0].sourceMarketValue"))) {
			accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
			this.accountsCommonTestData.setAsOfDate1(this.response.path("accountList[0].sourceMarketValue.asOfDate"));
		}

		this.accountsCommonTestData.setInstitutionName1(this.response.path("accountList[0].institutionName"));

		logger.info("Account Number : " + response.path("accountList[0].accountId.accountNumber"));
		logger.info("AccountNumber Map : " + this.accNumberRegCodeMap.toString());

	}

	/**
	 * Create the account.
	 *
	 * Version V1
	 */
	@Test(dataProvider = "getFiliRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class, dependsOnMethods = "getFiliAccountInfo")
	public void createFiliAccount(final AccountRegCodeTestData data) {
		this.context.put("mnemonic", data.getRegCode1());
		this.context.put("source", data.getSrcFilter());
		if (null != this.accNumberRegCodeMap.get(data.getRegCode1())) {
			this.context.put("accountNumber", this.accNumberRegCodeMap.get(data.getRegCode1()));
		} else {
			this.context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
		}
		this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
		this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
		this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

		// Gets and saves the CFP account ID
		this.accountsCommonTestData.setAccountId1(this.response.path("accountList[0].accountId.id"));
		accId = this.response.path("accountList[0].accountId.id");
		if (null != accId) {
			this.accIdRegCodeMap.put(data.getRegCode1(), accId);

		}
		logger.info("AccountID Map : " + accIdRegCodeMap.toString());
	}

	/**
	 * Validate the account.
	 *
	 * Version V1
	 */
	@Test(dataProvider = "getFiliRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class, dependsOnMethods = "createFiliAccount")
	public void getFiliAccountAfterCreate(final AccountRegCodeTestData data) {
		// Exclude external data sources
		this.context.put("mnemonicFilter", data.getRegCode1());
		this.context.put("externalDataSources", "true");
		this.context.put("source", data.getSrcFilter());

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
				equalTo(true));

		if (CollectionUtils.isNotEmpty(this.response.path("accountList"))
				&& (this.response.jsonPath().getList("accountList").size() > 0)) {

			if (null != this.response.path("accountList[0].accountId.id")) {
				this.response.then().body("accountList[0].accountId", notNullValue())
						.body("accountList[0].accountId.owner.id", notNullValue())
						.body("accountList[0].accountId.accountNumber", notNullValue(),
								"accountList[0].accountId.accountNumber",
								equalTo(this.accNumberRegCodeMap.get(data.getRegCode1())),
								"accountList[0].accountId.id", notNullValue())
						.body("accountList[0].regCode.mnemonic", Matchers
								.isOneOf(new String[] { data.getRegCode1(), data.getRegCode2(), data.getRegCode3() }));
			}
		}

	}

	/**
	 * Update the account.
	 *
	 * Version V1
	 */
	@Test(dataProvider = "getFiliRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class, dependsOnMethods = "getFiliAccountAfterCreate")
	public void updateFiliAccount(final AccountRegCodeTestData data) {
		// Change the amount of the account
		this.context.put("source", data.getSrcFilter());
		this.context.put("accId", this.accIdRegCodeMap.get(data.getRegCode1()));
		this.context.put("value", this.updatedValue);

		this.context.put("mnemonic", data.getRegCode1());
		if (null != this.accNumberRegCodeMap.get(data.getRegCode1())) {
			this.context.put("accountNumber", this.accNumberRegCodeMap.get(data.getRegCode1()));
		} else {
			this.context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
		}
		this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
		this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
		this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

	}

	/**
	 * Validate the updated account.
	 *
	 * Version V1
	 */
	@Test(dataProvider = "getFiliRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class, dependsOnMethods = "updateFiliAccount")
	public void getFiliAccountAfterUpdate(final AccountRegCodeTestData data) {
		// We don't want to filter by source here
		this.context.put("mnemonicFilter", data.getRegCode1());
		this.context.put("externalDataSources", "true");
		this.context.put("source", data.getSrcFilter());

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
				equalTo(true));
		if (CollectionUtils.isNotEmpty(this.response.path("accountList"))
				&& (this.response.jsonPath().getList("accountList").size() > 0)) {
			this.response.then().body("accountList[0].accountId", notNullValue())
					.body("accountList[0].accountId.owner.id", notNullValue())
					.body("accountList[0].accountId.accountNumber", notNullValue(),
							"accountList[0].accountId.accountNumber",
							equalTo(this.accNumberRegCodeMap.get(data.getRegCode1())), "accountList[0].accountId.id",
							equalTo(this.accIdRegCodeMap.get(data.getRegCode1())))
					.body("accountList[0].regCode.mnemonic", Matchers
							.isOneOf(new String[] { data.getRegCode1(), data.getRegCode2(), data.getRegCode3() }));
		}

	}

	/**
	 * Delete the account.
	 *
	 * Version V1
	 */

	@Test(dataProvider = "getFiliRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class, dependsOnMethods = "getFiliAccountAfterUpdate")

	public void deleteFiliAccount(final AccountRegCodeTestData data) {
		// Generate request body
		this.context.put("source", data.getSrcFilter());
		this.context.put("value", this.updatedValue);

		this.context.put("mnemonic", data.getRegCode1());
		this.context.put("accId", this.accIdRegCodeMap.get(data.getRegCode1()));
		if (null != this.accNumberRegCodeMap.get(data.getRegCode1())) {
			this.context.put("accountNumber", this.accNumberRegCodeMap.get(data.getRegCode1()));
		} else {
			this.context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
		}
		this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
		this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
		this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

		// Call Account service response =
		this.request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
				equalTo(true));

	}

	/**
	 * Validate the account was deleted.
	 *
	 * Version V1
	 */

	@Test(dataProvider = "getFiliRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class, dependsOnMethods = "deleteFiliAccount")
	public void getFiliAccountAfterDelete(final AccountRegCodeTestData data) {

		this.context.put("mnemonicFilter", data.getRegCode1());
		this.context.put("source", data.getSrcFilter());
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service response =
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
				equalTo(true), "accountList", Matchers.empty());

	}

	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections() {
		this.testDataUtil.closeSQLiteConnection();
	}
}
