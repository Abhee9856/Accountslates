/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.response.Response;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;

/**
 * Tests CRUD operation for manual details against V1.
 *
 * Updated by a608077 on 10/09/2023 to include 3 new asset classes: Private Equity, Private Credit,
 * and Real Assets(PFCP-13826)
 * 
 * @author a631781
 */

@Test(groups = {
		Tags.CRITICAL,
		Tags.MANUAL,
		Tags.DETAILS,
		Tags.V1, Tags.TAM})
public class Manual_Details_CriticalTest_V1 extends PAPBaseServiceTest
{

    protected Manual_Details_CriticalTest_V1()
    {
	super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private final float value = 818.89f;

    private final float updatedValue = 426.85f;

    // Velocity Keys
    private static final String IS_TRANSFER_TO_SURVIVOR_IND = "isTransferToSurvivorIndicator";

    private static final String VESTED_VALUE = "vestedValue";

    private static final String UNVESTED_VALUE = "unvestedValue";

    private static final String YEARS_REMAINING = "yearsRemaining";

    private static final String BENEFICIARY_AVAILABLE = "beneficiaryAvailable";

    private static final String COMPLEMENTARY_ADJUSTMENT_OPT = "complementaryAdjustmentOption";

    private TestDataUtil testDataUtil;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Manual_Details_V1_CRUD.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private String mid;

    private String originalOwnerBirthDate = "1960-11-30T00:00:00.000+0000";

    private String originalOwnerDeceasedDate = "2022-12-30T00:00:00.000+0000";

    private String originalOwnerSpouse = "false";

    private String withdrawalEligibilityStartDate = "2020-01-01T00:00:00.000+0000";

    private String withdrawalEligibilityEndDate = "2020-01-01T00:00:00.000+0000";

    private String federalTaxWithholding = "0.7";

    private String stateTaxWithholding = "0.5";

    private String equityPercent = "0.5";

    private String tamAssetClass = "TOTAL_EQUITY";

    // AssetAllocation
    private String assetClass = "CASH";

    private float netPercentageValue = 1.0f;

    private float netPercentageUpdatedValue = 0.7f;

    private String assetClass_T_Equity = "TOTAL_EQUITY";

    private String foreignEquity = "FOREIGN_EQUITY";

    private String domesticEquity = "DOMESTIC_EQUITY";

    private float netPercentage_T_Equity = 1.0f;

    private float netPercentage_FE = 0.5f;

    private float netPercentage_DE = 0.5f;

    private String assetClass3 = "BOND";

    private String assetClass4 = "OTHER";

    private float netPercentage3 = 0.3f;

    private float netPercentage4 = 0.2f;

    private float netPercentageUpdated3 = 0.5f;

    private float netPercentageUpdated4 = 0.7f;
    
    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
    
    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";

    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";

    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";

    private final float netPercentage_T_ALTERNATIVE = 0.8f;

    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
	
    private final float netPercentage_PEA = 0.4f;
	
    private final float netPercentage_Updated_PEA = 0.2f;
	
    private final float netPercentage_PCA = 0.2f;
	
    private final float netPercentage_Updated_PCA = 0.3f;
	
    private final float netPercentage_PRAA = 0.2f;
	
    private final float netPercentage_Updated_PRAA = 0.1f;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();

	//Data Setup
	accountsCommonTestData = TestDataUtil.populateRegressionTestData("accountCRUD_Retail", oAuth);

	this.mid = accountsCommonTestData.getMid();
	accountsCommonTestData.setMid(this.mid);

	//Set default REST header with authorization token
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	testDataUtil = new TestDataUtil();
	//Data cleanup
	DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


	//Set ppid
	accountsCommonTestData.setPpid(Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth));
	// Get/Create ScenarioId
	Response allScenarioIDs = Scenario.getAllScenarios(mid, oAuth);
	String scenarioId = allScenarioIDs.path("scenario[0].id").toString();
	if (scenarioId == null)
	{
	    scenarioId = Scenario.createScenarioWithProductCode(mid, "IGE", "DEF",
			    oAuth);
	}

	//Set the regCode for this test
	accountsCommonTestData.setMnemonic1("IRA");
	accountsCommonTestData.set("isInherited", "false");
	accountsCommonTestData.set("isPreviousEmployersAccount", "false");
	accountsCommonTestData.set("state", "AK");
	accountsCommonTestData.setSourceSystem1("MANUAL");
	String asOfDate = "2014-10-31";
	accountsCommonTestData.setAsOfDate1(asOfDate);

	accountsCommonTestData.set(IS_TRANSFER_TO_SURVIVOR_IND, "true");
	accountsCommonTestData.set(VESTED_VALUE, "100.0");
	accountsCommonTestData.set(UNVESTED_VALUE, "200.0");
	accountsCommonTestData.set(YEARS_REMAINING, "10");
	accountsCommonTestData.set(BENEFICIARY_AVAILABLE, "true");
	accountsCommonTestData.set(COMPLEMENTARY_ADJUSTMENT_OPT, "MANAGED_LOCK_CURRENT_ALLOCATION");

	// Populate request variables
	context = new VelocityContext();
	context.put("scenarioId", scenarioId);
	context.put("mid", accountsCommonTestData.getMid());
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("source", accountsCommonTestData.getSourceSystem1());
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", String.valueOf(value));
	context.put("isInherited", accountsCommonTestData.get("isInherited"));
	context.put("isPreviousEmployersAccount", accountsCommonTestData.get("isPreviousEmployersAccount"));
	context.put("state", accountsCommonTestData.get("state"));
	context.put(IS_TRANSFER_TO_SURVIVOR_IND, accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND));
	context.put(VESTED_VALUE, accountsCommonTestData.get(VESTED_VALUE));
	context.put(UNVESTED_VALUE, accountsCommonTestData.get(UNVESTED_VALUE));
	context.put(YEARS_REMAINING, accountsCommonTestData.get(YEARS_REMAINING));
	context.put(BENEFICIARY_AVAILABLE, accountsCommonTestData.get(BENEFICIARY_AVAILABLE));
	context.put(COMPLEMENTARY_ADJUSTMENT_OPT, accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT));
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
    }

    /**
     * Create the manual account.
     * <p>
     * Version V1
     */
    @Test
    public void createManualAccount()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200).body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()));

	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("accId", accountsCommonTestData.getAccountNumber1());
    }

    /**
     * Validate the manual account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void getDetailsAfterCreateAccount()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.id",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()));

    }

    /**
     * Update the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreateAccount")
    public void createAccountDetails()
    {
	context.put("tamAssetClass", tamAssetClass);
	context.put("originalOwnerBirthDate", originalOwnerBirthDate);
	context.put("originalOwnerSpouse", originalOwnerSpouse);
	context.put("originalOwnerDeceasedDate", originalOwnerDeceasedDate);
	context.put("withdrawalEligibilityStartDate", withdrawalEligibilityStartDate);
	context.put("withdrawalEligibilityEndDate", withdrawalEligibilityEndDate);
	context.put("federalTaxWithholding", federalTaxWithholding);
	context.put("stateTaxWithholding", stateTaxWithholding);
	context.put("equityPercent", equityPercent);
	context.put("assetClass", assetClass);
	context.put("netPercentageValue", netPercentageValue);
	context.put("assetClass_T_Equity", assetClass_T_Equity);
	context.put("netPercentage_T_Equity", netPercentage_T_Equity);
	context.put("assetClass_FOREIGN_EQUITY", foreignEquity);
	context.put("netPercentage_FE", netPercentage_FE);
	context.put("assetClass_DOMESTIC_EQUITY", domesticEquity);
	context.put("netPercentage_DE", netPercentage_DE);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentage3);
	context.put("assetClass4", assetClass4);
	context.put("netPercentage4", netPercentage4);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE",netPercentage_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA",netPercentage_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA",netPercentage_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA",netPercentage_PRAA);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.costBasis.value", equalTo(value),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isInherited", equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.targetAssetMixes.targetAssetMix[0].allocation[0].assetClass",
					equalTo(tamAssetClass),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.equityPercent",
					equalTo(Float.valueOf(equityPercent)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isPreviousEmployersAccount",
					equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.state",
					equalTo(accountsCommonTestData.get("state")),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerSpouse", equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.complementaryAdjustmentOption",
					equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentage3),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentage4),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
							equalTo(netPercentage_FE))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_T_ALTERNATIVE))
			.body("accountDetails.find{it.accountId.id=='" +  accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PCA))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PEA))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PRAA));
    }

    /**
     * Validate the updated manual account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.costBasis.value", equalTo(value),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isInherited", equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.targetAssetMixes.targetAssetMix[0].allocation[0].assetClass",
					equalTo(tamAssetClass),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.equityPercent",
					equalTo(Float.valueOf(equityPercent)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isPreviousEmployersAccount",
					equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.state",
					equalTo(accountsCommonTestData.get("state")),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerSpouse", equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isTransferToSurvivorIndicator",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.vestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(VESTED_VALUE))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.unvestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(UNVESTED_VALUE))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.yearsRemaining",
					equalTo(Integer.valueOf(accountsCommonTestData.get(YEARS_REMAINING))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.beneficiaryAvailable",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(BENEFICIARY_AVAILABLE))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.complementaryAdjustmentOption",
					equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)),
					"accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue),
					"accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentage3),
					"accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentage4),
					"accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity),
					"accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_FE),
					"accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
							equalTo(netPercentage_FE))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_T_ALTERNATIVE))
			.body("accountDetails.find{it.accountId.id=='" +  accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PCA))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PEA))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PRAA));
    }

    /**
     * Update account Details
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails()
    {
	context.put("assetClass", assetClass);
	context.put("netPercentageValue", netPercentageValue);
	context.put("tamAssetClass", assetClass);
	context.put("originalOwnerBirthDate", originalOwnerBirthDate);
	context.put("originalOwnerSpouse", originalOwnerSpouse);
	context.put("originalOwnerDeceasedDate", originalOwnerDeceasedDate);
	context.put("withdrawalEligibilityStartDate", withdrawalEligibilityStartDate);
	context.put("withdrawalEligibilityEndDate", withdrawalEligibilityEndDate);
	context.put("federalTaxWithholding", federalTaxWithholding);
	context.put("stateTaxWithholding", stateTaxWithholding);
	context.put("equityPercent", equityPercent);
	context.put("assetClass", assetClass);
	context.put("netPercentageValue", netPercentageValue);
	context.put("assetClass_T_Equity", "TOTAL_EQUITY");
	context.put("netPercentage_T_Equity", netPercentage_T_Equity);
	context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
	context.put("netPercentage_FE", netPercentage_FE);
	context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
	context.put("netPercentage_DE", netPercentage_DE);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentageUpdated3);
	context.put("assetClass4", assetClass4);
	context.put("netPercentage4", netPercentageUpdated4);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE",netPercentage_Updated_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA",netPercentage_Updated_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA",netPercentage_Updated_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA",netPercentage_Updated_PRAA);
	
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_UPDATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.costBasis.value", equalTo(value),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isInherited", equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.equityPercent",
					equalTo(Float.valueOf(equityPercent)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isPreviousEmployersAccount",
					equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.state",
					equalTo(accountsCommonTestData.get("state")),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerSpouse", equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isTransferToSurvivorIndicator",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.vestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(VESTED_VALUE))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.unvestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(UNVESTED_VALUE))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.yearsRemaining",
					equalTo(Integer.valueOf(accountsCommonTestData.get(YEARS_REMAINING))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.beneficiaryAvailable",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(BENEFICIARY_AVAILABLE))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.complementaryAdjustmentOption",
					equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated3),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated4),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
							equalTo(netPercentage_FE))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_T_ALTERNATIVE))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PCA))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PEA))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PRAA));
    }

    /**
     * Validate the manual account was updated.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.costBasis.value", equalTo(value),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isInherited", equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.equityPercent",
					equalTo(Float.valueOf(equityPercent)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isPreviousEmployersAccount",
					equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.state",
					equalTo(accountsCommonTestData.get("state")),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.originalOwnerSpouse", equalTo(false),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.isTransferToSurvivorIndicator",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.vestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(VESTED_VALUE))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.unvestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(UNVESTED_VALUE))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.yearsRemaining",
					equalTo(Integer.valueOf(accountsCommonTestData.get(YEARS_REMAINING))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.beneficiaryAvailable",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(BENEFICIARY_AVAILABLE))),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.complementaryAdjustmentOption",
					equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated3),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated4),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
							equalTo(netPercentage_FE))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_T_ALTERNATIVE))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PCA))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PEA))
			.body("accountDetails.find{it.accountId.id=='" + accountsCommonTestData
							.getAccountNumber1()
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PRAA));
    }

    /**
     * Delete manual account
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteAccountDetails()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_DELETE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.id",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()));
    }

    /**
     * Validate the manual account was updated.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccountDetails")
    public void getDetailsAfterDelete()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.id",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData
							.getAccountNumber1() + "'}.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()));

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}
