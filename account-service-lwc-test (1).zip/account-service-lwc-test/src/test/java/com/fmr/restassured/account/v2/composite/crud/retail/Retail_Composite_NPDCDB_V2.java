/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

/**
 * Contains tests that validate NPDCDB flag for Account Composite operation for Retail Accounts
 *
 * @author a631781
 */

@Test(groups = {Tags.PIPELINE, Tags.REGRESSION, Tags.ASYNCHRONOUS, Tags.RETAIL, Tags.COMPOSITE, Tags.V2})
public class Retail_Composite_NPDCDB_V2 extends PAPBaseServiceTest {
    /**
     * Constructor
     */
    protected Retail_Composite_NPDCDB_V2() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;
    private final String oAuth = AccountUtil.getOauthToken();
    private float value = 120.0F;
    private final float updatedValue = 426.85f;
    private final String displayName = "ABC";
    private final String institutionName = "ABC";
    private final String source = "RETAIL";
    private final String asOfDate1 = "2014-10-31";
    private String mid;
    private String acctRoot;
    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Composite_v2_AllDetails.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;
    FilterableRequestSpecification frs = null;
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accId;

    private String accNumber;

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);
        testDataUtil = new TestDataUtil();
        mid = accountsCommonTestData.getMid();

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth,"true");

        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", mid, oAuth));
        context = new VelocityContext();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", mid))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"));

        frs = (FilterableRequestSpecification) request;
    }


    /**
     * Test isNpDCDBComplied flag for Regcode NPDC/DB
     * <p>
     * Version V2
     */
    @Test(dataProvider = "getNPDCDBRetailAccountData",
            dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data) {
        getRetailAccount(data);
        createCompositeAccountRetail(data);
        getCompositeAccountRetailAfterCreate(data);
        updateCompositeAccountRetail(data);
        getCompositeAccountRetailAfterUpdate(data);
        deleteCompositeAccountRetail(data);
        getCompositeAccountRetailAfterDelete(data);

    }

    //Get account info from the backend.
    private void getRetailAccount(final AccountRegCodeTestData data) {
        // Generate request body
        frs.removeHeader("excludeExternalDataSources");
        request.given().header(new Header("excludeExternalDataSources", "false"));

        context.put("sourceBasedRegistrationFilter", source);
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts.account",
                notNullValue());

        //Get Account number based on the regCode
        if (null != response.path("accounts.find{it.account.regCode.mnemonic=='" + data.getRegCode1() + "'}.account.accountId.accountNumber")) {
            accNumber = response.path("accounts.find{it.regCode.mnemonic=='" + data.getRegCode1() + "'}.account.accountId.accountNumber");
        } else {
            accNumber = response.path("accounts[0].account.accountId.accountNumber");

        }
    }

    /**
     * Description: Validates the account composite response after a create
     */
    private void createCompositeAccountRetail(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("accountNumber", accNumber);
        context.put("accId", "");
        context.put("source", source);
        context.put("displayName", displayName);
        context.put("mnemonic", data.getRegCode1());
        context.put("sourceSystem2", source);
        context.put("value", String.valueOf(value));
        context.put("asOfDate", asOfDate1);
        context.put("detailValue", "111111.11");
        context.put("emergencyFundAmount", "111111.11");
        context.put("isNpDCDBComplied", "true");
        context.put("withdrawAmount", "800");
        context.put("withdrawFreq", "HOURLY");

        frs.removeHeader("excludeExternalDataSources");
        request.given().header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNumber + "'}.";
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(data.getRegCode1()))
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.accountNumber=='" + accNumber + "'}.details.retailAccountDetail.accountDetail.isNpDCDBComplied", equalTo(true));

        accId = response.path(acctRoot + "account.accountId.id");
    }

    /**
     * Description: Validates the account composite response after a create (get)
     */
    private void getCompositeAccountRetailAfterCreate(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("sourceBasedRegistrationFilter", source);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(data.getRegCode1()))
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.accountNumber=='" + accNumber + "'}.details.retailAccountDetail.accountDetail.isNpDCDBComplied", equalTo(true));
    }

    /**
     * Description: Validates the account composite response after a update
     */
    private void updateCompositeAccountRetail(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("accId", accId);
        context.put("accountNumber", accNumber);
        context.put("source", source);
        context.put("displayName", displayName);
        context.put("mnemonic", data.getRegCode1());
        context.put("sourceSystem2", source);
        context.put("value", String.valueOf(updatedValue));
        context.put("asOfDate", asOfDate1);
        context.put("detailValue", "111111.11");
        context.put("emergencyFundAmount", "111111.11");
        context.put("isNpDCDBComplied", "true");
        context.put("withdrawAmount", "800");
        context.put("withdrawFreq", "HOURLY");
        request.log().ifValidationFails().body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(data.getRegCode1()))
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.accountNumber=='" + accNumber + "'}.details.retailAccountDetail.accountDetail.isNpDCDBComplied", equalTo(true));
    }

    /**
     * Description: Validates the account composite response after a update (get)
     */
    private void getCompositeAccountRetailAfterUpdate(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("sourceBasedRegistrationFilter", source);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(data.getRegCode1()))
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.accountNumber=='" + accNumber + "'}.details.retailAccountDetail.accountDetail.isNpDCDBComplied", equalTo(true));
    }

    /**
     * Description: Validates the account composite response after a delete
     */
    private void deleteCompositeAccountRetail(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("accountNumber", accNumber);
        context.put("source", source);
        context.put("displayName", displayName);
        context.put("mnemonic", data.getRegCode1());
        context.put("sourceSystem2", source);
        context.put("value", String.valueOf(updatedValue));
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate1);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        response.then().log().ifValidationFails().
                statusCode(HTTPStatusCodes.STATUS_200)
                .body("isEmpty()", Matchers.is(true));

    }

    /**
     * Description: Validates an empty account list when calling get account composite retail after delete
     */

    private void getCompositeAccountRetailAfterDelete(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("sourceBasedRegistrationFilter", source);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown() {
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        testDataUtil.closeSQLiteConnection();
    }
}
