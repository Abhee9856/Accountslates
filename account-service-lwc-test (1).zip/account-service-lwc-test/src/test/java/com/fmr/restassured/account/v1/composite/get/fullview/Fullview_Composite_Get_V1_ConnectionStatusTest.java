/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.get.fullview;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds.*;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.*;

/**
 * Tests for Return connection status for a Composite Details fullview Account. If DSS returns connectionStatusType as Success then Account Service will also return a Boolean value isConnectionSuccessful as true else false.
 *
 * @author a631781
 * Updated for story PFCP-18705 and PFCP-18959
 * updated by a783909 for PFCP-15962
 */

@Test(groups = {Tags.REGRESSION, Tags.COMPOSITE, Tags.V1})

public class Fullview_Composite_Get_V1_ConnectionStatusTest extends PAPBaseServiceTest {

    protected Fullview_Composite_Get_V1_ConnectionStatusTest() {
        super(Services.Account);
    }

    private String ssn;
    private String mid;
    private String sid;
    private static final String sourceSystem = "FULLVIEW";
    public static final String ACCOUNT_CATEGORY = "ExternalLinked";
    public static final String acctType = "External";
    public static final String acctSubType = "Investment";
    public static String connectionStatusTypeSuccess = "Success";
    public static String connectionStatusTypeNotSuccess = "OutOfDate";
    public static boolean isConnectionSuccessful;
    private String actNbrConStatusSuccess;
    private String actNbrConStatusNotSuccess;

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Fullview_Composite_Get_V1_ConnectionStatusTest.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String APP_NAME = "Advice and Planning Platform";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private Response accountResponse;
    private final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;
    private VelocityContext context;
    private FilterableRequestSpecification frs;
    private final int finstId = 999999991;


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_get_corePosition_Fullview", oAuth);

        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid().replace("-", "");

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ssn = accountsCommonTestData.getSsn();
        testDataUtil = new TestDataUtil();

        // Populate request context with user IDs
        context = new VelocityContext();

        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Test to get the DSS Fullview account with the connectionStatusType
     * <p>
     * Version V2
     */
    @Test
    public void getDSS_V2() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));


        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().statusCode(anyOf(is(200), is(206)));
        actNbrConStatusSuccess = response.path("acctDetails.find{it.acctSubType=='" + acctSubType + "' && it.externalAcctDetail.connectionStatusType=='" + connectionStatusTypeSuccess + "'}.acctNum");
        actNbrConStatusNotSuccess = response.path("acctDetails.find{it.acctSubType=='" + acctSubType + "' && it.externalAcctDetail.connectionStatusType=='" + connectionStatusTypeNotSuccess + "'}.acctNum");
    }

    /**
     * Tests that Composite Details fullview account will also return a Boolean value isConnectionSuccessful based on the DSS connectionStatusType.
     * Tests fund code and finstId in composite get response
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void getCompositeFullViewActWithConStatusV1() {
        //Set Account Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        setRequestHeadersForAccount();
        // Generate request body
        setRequestHeadersForAccount();
        context.put("source", sourceSystem);
        context.put("mid", mid);
        context.put("excludeExternalDataSources", "false");
        context.put("fescoLid", ssn);
        context.put("digitalLid", ssn);
        context.put("pointOfEntry", "RETAIL");
        context.put("role", "FidCust");
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);
        request =
                request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));
         // Call Account service
        accountResponse = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        accountResponse.then().statusCode(200)
                .body("resultCode", equalTo(true))
                .body("accounts", not(empty()));
        if (actNbrConStatusSuccess != null) {
            isConnectionSuccessful = accountResponse.path("accounts.find{it.details.accountId.accountNumber=='" + actNbrConStatusSuccess + "'}.details.isConnectionSuccessful");
            Assert.assertTrue(isConnectionSuccessful);

        }
        if (actNbrConStatusNotSuccess != null) {
            isConnectionSuccessful = accountResponse.path("accounts.find{it.details.accountId.accountNumber=='" + actNbrConStatusNotSuccess + "'}.details.isConnectionSuccessful");
            Assert.assertFalse(isConnectionSuccessful);
        }

        //Validate corePosition
        int actualFinstId = accountResponse.path("accounts[0].positions.position.find{it.corePosition==" + true + "}.financialInstrumentId.finstId");
        Assert.assertEquals(actualFinstId, finstId);
        float corePositionPrice = accountResponse.path("accounts[0].positions.position.find{it.corePosition==" + true + "}.price.value");
        float corePositionQuantity = accountResponse.path("accounts[0].positions.position.find{it.corePosition==" + true + "}.quantity");
        final float expectedCorePositionPrice = 1.0f;
        float value = accountResponse.path("accounts[0].positions.position.find{it.corePosition==" + true + "}.marketValue.value");
        Assert.assertEquals(corePositionPrice, expectedCorePositionPrice);
        Assert.assertEquals(corePositionQuantity, value);


        int positionSize = accountResponse.path("accounts.find{it.account.institutionName='Fidelity API Tester-DAG Bank'}.positions.position.size()");

        for(int count = 0; count<positionSize-1; count++ ) {

            String fundCode = accountResponse.path("accounts.find{it.account.institutionName='Fidelity API Tester-DAG Bank'}.positions.position["+count+"].financialAssetPosition.financialInstrumentId.fundCode");
            String finstId = accountResponse.path("accounts.find{it.account.institutionName='Fidelity API Tester-DAG Bank'}.positions.position["+count+"].financialAssetPosition.financialInstrumentId.finstId");

            VelocityContext fiContext = new VelocityContext();
            fiContext.put("cusip", "null");
            fiContext.put("symbol", "");
            fiContext.put("fundcode", fundCode);
            //Build request body, set the host, and retrieve the resource path
            request.body(IOUtil.generateJsonRequest(fiContext, FINANCIAL_INSTRUMENTS_GET_ID_TEMPLATE));

            //Call financial Instruments service
            response = request.post(FINANCIAL_INSTRUMENTS_QA_BASE_URI+FINANCIAL_INSTRUMENTS_GET_ID_PATH);

            //Assert on response
            response.then().log().ifValidationFails()
                    .statusCode(AccountConstants.HTTP_200)
                    .body("resultCode", Matchers.equalTo(true))
                    .body("finstIdList[0].fundCode", equalTo(fundCode));

            String actualfinstId = response.path("finstIdList[0].finstId").toString();
            Assert.assertEquals(actualfinstId, finstId);
        }
    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS() {
        request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", ssn))
                .header(new Header("rtazallrealmslids", "Retail=" + ssn))
                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + sid))
                .header(new Header("FACMC", "MID=" + mid))
                .header(new Header("FACFC", "SESSION_KEY=1"))
                .header(new Header("Content-Type", "application/json"));

    }

    /**
     * Setting headers for Account Service
     */
    private void setRequestHeadersForAccount() {
        // Account headers setup
        request.given()
                .header(new Header("realTimeData", "true"))
                .header(new Header("mauiCache", "no"));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");
        testDataUtil.closeSQLiteConnection();
    }
}