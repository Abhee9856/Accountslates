/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.fili.masking;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Tests the masking of Display Name. Each step of the test flow will validate the displayName is still masked.
 *
 * Test Flow:
 *  1. Get accounts with EEDS=false
 *  2. Create account without saving a display name (displayName = null)
 *  3. Get accounts V1 with EEDS=true
 *  4. Get composite V1 with EEDS=true
 *  5. Get accounts V2 with EEDS=true
 *  6. Get composite V2 with EEDS=true
 *  7. Update account with account number saved as display name (displayName = accountNumber)
 *  8. Get accounts V1 with EEDS=true
 *  9. Get composite V1 with EEDS=true
 *  10. Get accounts V2 with EEDS=true
 *  11. Get composite V2 with EEDS=true
 *
 * @author a601767
 */
@Test(groups = {
        Tags.FILI,
        Tags.ACCOUNT,
        Tags.V1})
public class DisplayNameMasking_EEDSTrue extends PAPBaseServiceTest
{

    /**
     * The constructor
     */
    protected DisplayNameMasking_EEDSTrue()
    {
        super(Services.Account);
    }

    /** The accountsCommonTestData */
    private AccountsCommonTestData accountsCommonTestData = null;

    /** The Velocity context */
    private VelocityContext context;

    /** The sourceMarketValue */
    private final float value = 120.0F;

    /** The testDataUtil */
    private TestDataUtil testDataUtil;

    /** The accId */
    private String accId;

    /** The accNumber */
    private String accNumber;

    /** The displayName */
    private String displayName;

    /** The displayName from the response */
    private String responseDisplayName;

    /**
     * Initialization method
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
        
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_FILI_70", oAuth);
        testDataUtil = new TestDataUtil();
        accountsCommonTestData.setMid(accountsCommonTestData.getMid());
        accountsCommonTestData.setAsOfDate1("2014-10-31");
        accountsCommonTestData.setValue1(value);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");

        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("filiLid", accountsCommonTestData.getSsn());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", String.valueOf(value));

    }

    /**
     * Get account info from the backend.
     */
    @Test
    public void getFILIAccount()
    {
        // Generate request body
        context.put("source", "FILI");
        context.put("externalDataSources", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode = response.path(
                "responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
            Assert.assertFalse(dssResultCode);
        }

        accNumber = response.path("accountList[0].accountId.accountNumber");
        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        responseDisplayName = "accountList.find{it.accountId.accountNumber=='" + accNumber + "'}.displayName";

        final String maskedAccountNumber = TestDataUtil.getMaskedAccountNumber(accNumber);
        final String nickname =
                response.path("accountList.find{it.accountId.accountNumber=='" + accNumber + "'}.nickName");
        displayName = nickname != null ? nickname + "-" + maskedAccountNumber : maskedAccountNumber;

        response.then().log().ifValidationFails()
                .body("accountList", not(emptyArray()))
                .body(responseDisplayName, equalTo(displayName));

    }

    /**
     * Create FILI Account
     */
    @Test(dependsOnMethods = "getFILIAccount")
    public void createFILIAccount()
    {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", String.valueOf(value));
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("displayName", null);
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("accountNumber", accNumber);
        context.put("excludeExternalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_NULL_DISPLAY_NAME_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body(responseDisplayName, equalTo(displayName));

        accId = response.path("accountList[0].accountId.id");

    }


    /**
     * Validate the created account.
     */
    @Test(dependsOnMethods = "createFILIAccount")
    public void v1AccountGet()
    {
        // Exclude external data sources
        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(displayName));
    }

    /**
     * Validate the created account.
     */
    @Test(dependsOnMethods = "createFILIAccount")
    public void v1CompositeGet()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accounts.find{it.account.accountId.id=='" + accId + "'}.account.displayName",
                        equalTo(displayName));
    }

    /**
     * Validate the created account.
     */
    @Test(dependsOnMethods = "createFILIAccount")
    public void v2AccountGet()
    {
        // Generate request body
        request.given()
                .body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2))
                .header("user-fili-lid", accountsCommonTestData.getSsn())
                .header("user-mid", accountsCommonTestData.getMid())
                .header("user-poe", "RETAIL")
                .header("excludeExternalDataSources", true);

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName",
                        equalTo(displayName));
    }

    /**
     * Validate the created account.
     */
    @Test(dependsOnMethods = "createFILIAccount")
    public void v2CompositeGet()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accounts.find{it.account.accountId.id=='" + accId + "'}.account.displayName",
                        equalTo(displayName));
    }

    /**
     * Create FILI Account
     */
    @Test(dependsOnMethods = {"v1AccountGet", "v1CompositeGet", "v2AccountGet", "v2CompositeGet"})
    public void updateFILIAccountDisplayName()
    {
        // Generate request body
        context.put("displayName", accNumber);
        context.put("accountId", accId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_NULL_DISPLAY_NAME_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body(responseDisplayName, equalTo(displayName));

        accId = response.path("accountList[0].accountId.id");

    }
    /**
     * Validate the updated display name.
     */
    @Test(dependsOnMethods = "updateFILIAccountDisplayName")
    public void v1AccountGet2()
    {
        // Exclude external data sources
        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(displayName));
    }

    /**
     * Validate the updated display name.
     */
    @Test(dependsOnMethods = "updateFILIAccountDisplayName")
    public void v1CompositeGet2()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accounts.find{it.account.accountId.id=='" + accId + "'}.account.displayName",
                        equalTo(displayName));
    }

    /**
     * Validate the updated display name.
     */
    @Test(dependsOnMethods = "updateFILIAccountDisplayName")
    public void v2AccountGet2()
    {
        // Generate request body
        request.given()
                .body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2))
                .header("user-fili-lid", accountsCommonTestData.getSsn())
                .header("user-mid", accountsCommonTestData.getMid())
                .header("user-poe", "RETAIL")
                .header("excludeExternalDataSources", true);

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName",
                        equalTo(displayName));
    }

    /**
     * Validate the updated display name.
     */
    @Test(dependsOnMethods = "updateFILIAccountDisplayName")
    public void v2CompositeGet2()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accounts.find{it.account.accountId.id=='" + accId + "'}.account.displayName",
                        equalTo(displayName));
    }


    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
        testDataUtil.closeSQLiteConnection();
    }
}
