/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.get.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Tests for Account status element in details which is sourced from DSS Account service - field
 * acctStateDetail.statusCode.
 *
 * @author a608077
 */
@Test(groups = {Tags.REGRESSION, Tags.RETAIL, Tags.COMPOSITE, Tags.V1})
public class Retail_Composite_Get_AccountStatus_v1 extends PAPBaseServiceTest
{

	protected Retail_Composite_Get_AccountStatus_v1()
	{
		super(Services.Account);
	}

	TestDataUtil testDataUtil = new TestDataUtil();

	// Data setup
	private AccountsCommonTestData accountsCommonTestData = null;

	private VelocityContext context;

	private final String source = "RETAIL";

	private String mid;

	private String ssn;

	private static final String APP_NAME = "Advice and Planning Platform";

	private static final String LOG_TRACKING_ID = Retail_Composite_Get_AccountStatus_v1.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private static String oAuth;

	private static String accNumber, dssStatusCode;

	private FilterableRequestSpecification frs;

	private static final String ACCOUNT_CATEGORY = "Brokerage";

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{
		oAuth = AccountUtil.getOauthToken();

		accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_Retail", oAuth);

		mid = Identity.getUserIdentifier("lid", this.accountsCommonTestData.getSsn(), oAuth)
				.get("mid");
		ssn = accountsCommonTestData.getSsn();
		accountsCommonTestData.setMid(this.mid);
		accountsCommonTestData.setSourceSystem1("RETAIL");

		DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


		accountsCommonTestData.setPpid(
				Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
				FSREQID, oAuth);

		// Populate request variables
		context = new VelocityContext();
		context.put("source", source);

	}

	/**
	 * Tests that DSS service data is brought back for all account.
	 */
	@Test
	public void getAccounts_V2_DSS()
	{
		frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		this.setDefaultRequestHeadersForDSS();

		context.put("acctCategory", ACCOUNT_CATEGORY);
		this.request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

		response = this.request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
				.body("acctDetails", not(emptyArray()))
				.body("acctDetails[0].acctNum", Matchers.notNullValue())
				.body("acctDetails[0].acctStateDetail.statusCode", Matchers.notNullValue());

		accNumber = this.response.path("acctDetails[0].acctNum");
		dssStatusCode = this.response.path("acctDetails[0].acctStateDetail.statusCode");

	}

	/**
	 *  Validate account status details are coming back in the Get response
	 * Version V1
	 */
	@Test(dependsOnMethods = "getAccounts_V2_DSS")
	public void getRetailAccountCompositeAccountStatusCode_v1()
	{

		frs.removeHeaders();
		// Set request headers
		this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
				FSREQID, oAuth);
		context.put("retailLid", accountsCommonTestData.getSsn());
		context.put("mid", accountsCommonTestData.getMid());
		context.put("source", "RETAIL");

		this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
		Boolean resultCode = response.path("resultCode");
		Boolean dssResultCode =
				response.path("responseDiagnostic.externalSystemDiagnostic" +
						".find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
		if (!resultCode)
		{
			Assert.assertEquals(dssResultCode, false);
		}
		response.then().log().ifValidationFails()
				.body("accounts.find{it.details.accountId.accountNumber=='" + accNumber + "'}" +
								".details.accountId.accountNumber", equalTo(accNumber))
				.body("accounts.find{it.details.accountId.accountNumber=='" + accNumber + "'}" +
								".details.accountStatus", equalTo(dssStatusCode));
	}
	/**
	 * Set the default headers for DSS API call
	 */
	private void setDefaultRequestHeadersForDSS()
	{
		this.request.given().header(new Header("AppId", "AP106532"))
				.header(new Header("fsreqid", FSREQID))
				.header(new Header("Authorization", oAuth))
				.header(new Header("AppName", APP_NAME))
				.header(new Header("rtazlid", this.ssn))
				.header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
				.header(new Header("FACSC", "ROLE=FidCust"))
				.header(new Header("FACMC", "MID=" + mid))
				.header(new Header("Content-Type", "application/json"));
	}

	/**
	 * Clean up method for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void closeDBConnections()
	{
		testDataUtil.closeSQLiteConnection();
	}

}
