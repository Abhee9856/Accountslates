/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.contributions.crud.manual;

import com.fmr.ast.platform.workplaceplan.domain.MatchTier;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsContributionsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.utilities.ContributionsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountContributionsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.ContributionsMatchTiersTestData;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operation for Manual contributions against V1.
 *
 * @author a514676
 */
@Test(groups = {
        Tags.CRITICAL,
        Tags.ASYNCHRONOUS,
        Tags.MANUAL,
        Tags.CONTRIBUTIONS,
        Tags.V1,
        Tags.MATCH_TIERS,
        "PFCP-3064"})
public class Manual_CRUD_V1_MatchTiers extends PAPBaseServiceTest {
    protected Manual_CRUD_V1_MatchTiers() {
        super(Services.Account);
    }
    private String mid;

    private String ppid;

    private String accountNumber;

    private String accountId;

    private String sourceSystem = "MANUAL";

    private String displayName = "Display_Name";

    private float value = 100.0f;

    private String institutionName = "InstitutionalName";

    private String asOfDate = "2014-10-31";

    private VelocityContext context;
    /**
     * Map Integer tier -> String ID
     */
    private Map<Integer, String> tierIdMap = new HashMap<>();


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        AccountsCommonTestData accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("accountCRUD_Manual", oAuth);
       this.mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");

        ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);

        setDefaultRequestHeaders(oAuth);

        // Populate request context with user IDs
        context = new VelocityContext();

        context.put(AccountConstants.MID, mid);
        context.put("ppid", ppid);
        context.put("source", "MANUAL");
    }


    /**
     * Create the Manual account. Save the account id.
     * <p>
     * Version V1
     */
    @Test
    public void createManualAccount() {
        String mnemonic = "401K";
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountList[0].regCode.mnemonic", equalTo(mnemonic),
                        "accountList[0].accountId.accountNumber", Matchers.notNullValue());

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        context.put("accId", accountId);
        context.put("accountNumber", accountNumber);
    }

    /**
     * Validate the account was created correctly.
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void getManualAccountAfterCreate() {
        // Generate request body
        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "accountList", not(empty()));


    }

    /**
     * Create the account contributions.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getManualAccountAfterCreate")
    public void createAccountContributions() {
        final AccountContributionsTestData data = new AccountContributionsTestData();

        // Generate request body
        context.put("contribValue", data.getContributionValue());
        context.put("valueType", data.getValueType());
        context.put("contribType", data.getContributionType());
        context.put("contribTaxType", data.getContributionTaxType());
        context.put("contribLevelType", data.getContributionLevelType());
        context.put("frequency", data.getFrequency());
        context.put("contributor", data.getContributor());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_TEMPLATE))
                .log().ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(mid))
                .body("accountContributions", not(empty()))
                .body("accountContributions[0].contributions.find{it.contribution.value='" +
                        data.getContributionValue() + "'}.contributionType", notNullValue());

    }

    /**
     * Validate the contributions.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountContributions", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void createAccountMatchTiers(final ContributionsMatchTiersTestData data) {
        // Generate request body
        context.put("matchTierTier", data.getTier());
        context.put("matchTierType", data.getType());
        context.put("matchTierRate", data.getRate());
        context.put("matchTierRateAmountLimit", data.getRateAmountLimit());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
                        "accountContributions[0].accountId.id", equalTo(accountId),
                        "accountContributions[0].accountId.owner.id", equalTo(ppid),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit.value", equalTo(Float.valueOf(data.getRateAmountLimit())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit", nullValue());

        tierIdMap.put(data.getTier(),
                response.path("accountContributions[0].matchTiers.find{it.tier==" + data.getTier() + "}.id"));

    }

    /**
     * Validate the contributions.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountContributions", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void getContributionsAfterCreate(final ContributionsMatchTiersTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
                        "accountContributions[0].accountId.id", equalTo(accountId),
                        "accountContributions[0].accountId.owner.id", equalTo(ppid),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit.value", equalTo(Float.valueOf(data.getRateAmountLimit())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit", nullValue());

    }

    /**
     * Update the contribution.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getContributionsAfterCreate", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void updateAccountContributions(final ContributionsMatchTiersTestData data) {
        // Generate request body
        context.put("matchTierTier", data.getTier());
        context.put("matchTierType", data.getType());
        context.put("matchTierRate", data.getRate());
        context.put("matchTierRateAmountLimit", null);
        context.put("matchTierRatePercentLimit", data.getRatePercentLimit());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_UPDATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.UPDATE_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "accountContributions", not(empty()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit", nullValue(),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit.value", equalTo(Float.valueOf(data.getRatePercentLimit())));
    }

    /**
     * Validate the contribution was updated.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountContributions", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void getContributionsAfterUpdate(final ContributionsMatchTiersTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
                        "accountContributions[0].accountId.id", equalTo(accountId),
                        "accountContributions[0].accountId.owner.id", equalTo(ppid),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit", nullValue(),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit.value", equalTo(Float.valueOf(data.getRatePercentLimit())));

    }

    /**
     * Delete the contribution
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getContributionsAfterUpdate", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void deleteAccountContributions(final ContributionsMatchTiersTestData data) {
        // Generate request body
        context.put("matchTierId", tierIdMap.get(data.getTier()));
        context.put("matchTierTier", data.getTier());
        context.put("matchTierType", data.getType());
        context.put("matchTierRate", data.getRate());
        context.put("matchTierRatePercentLimit", data.getRatePercentLimit());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.DELETE_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true));

        final List<MatchTier> matchTiers =
                response.jsonPath().getList("accountContributions[0].matchTiers", MatchTier.class);
        matchTiers.forEach(tier -> {
            if (tier.getTier() == data.getTier()) {
                Assert.fail();
            }
        });

    }

    /**
     * Validate the contributions were deleted.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccountContributions")
    public void getContributionsAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "accountContributions[0].contributions", not(empty()),
                        "accountContributions[0].matchTiers", empty());

    }
}
