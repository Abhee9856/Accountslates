/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.get.digital;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.within;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.empty;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests for Digital Composite Account Positions
 *
 * @author a631781
 */

@Test(groups = {Tags.REGRESSION, Tags.DIGITAL, Tags.V1})
public class Digital_Composite_Position_Get_V1 extends PAPBaseServiceTest {

    protected Digital_Composite_Position_Get_V1() {
        super(Services.Account);
    }

    private static final String sourceSystem = "DIGITAL";

    public static final String ACCOUNT_CATEGORY = "InternalDigital, ExternalDigital";
    public static final String acctSubTypeDescInt = "Internal Digital Currency";
    public static final String acctSubTypeDescExt = "External Digital Currency";
    public static final String acctTypeDSS = "Crypto";
    private String ssn;
    private String mid;
    private String sid;
    private String ppid;

    private String internalAccountNumberDSS;
    private String externalAccountNumberDSS;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Digital_Composite_Position_Get_V1.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String APP_NAME = "Advice and Planning Platform";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private Response accountResponse;
    private Response dssPositionResponse;
    private String acctRoot;
    private String acctRootExt;
    private final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;
    private VelocityContext context;
    private FilterableRequestSpecification frs;
    private String linkedAccountsIntDSS;
    private String linkedAccountsExtDSS;
    private int portfolioPositionCount;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_digital", oAuth);

        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid().replace("-", "");
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth,"true");
        ppid = Identity.createHouseholdIdentity(mid, oAuth);

        ssn = accountsCommonTestData.getSsn();
        testDataUtil = new TestDataUtil();

        // Populate request context with user IDs
        context = new VelocityContext();

        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Test to get the DSS digital account
     * <p>
     * Version V2
     */
    @Test
    public void getDSS_V2() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)));
        internalAccountNumberDSS = response.path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescInt + "'}.acctNum");
        linkedAccountsIntDSS = response.path("acctDetails.find{it.acctNum=='" + internalAccountNumberDSS + "'}.linkedAcctDetails[0].acctNum");
        externalAccountNumberDSS = response.path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescExt + "'}.acctNum");
        linkedAccountsExtDSS = response.path("acctDetails.find{it.acctNum=='" + externalAccountNumberDSS + "'}.linkedAcctDetails[0].acctNum");

    }

    @Test(dependsOnMethods = "getDSS_V2")
    public void getDSS_AccountPositions_V2() {
        // Generate request body
        context.put("returnAvailabilityStatus", "true");
        context.put("returnAccountGainLossDetail", "true");
        context.put("returnPositionMarketValDetail", "true");
        context.put("accountNumber", internalAccountNumberDSS);
        context.put("acctType", acctTypeDSS);

        this.request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_POSITION_V2));

        dssPositionResponse = this.request.post(AccountConstants.DSS_ACCOUNT_POSITIONS_V2_PATH);

        // Assert on response
        dssPositionResponse.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
                .body("position.acctDetails.acctDetail", not(emptyArray()))
                .body("position.acctDetails.acctDetail[0].acctNum", equalTo(internalAccountNumberDSS));
        portfolioPositionCount = dssPositionResponse.path("position.portfolioDetail.portfolioPositionCount");

    }


    /**
     * Tests that account data is brought back for Digital account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDSS_AccountPositions_V2"})
    public void getDigitalAccountPositionInfo() {
        //Set Account Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        setRequestHeadersForAccount();
        // Generate request body
        context.put("source", sourceSystem);
        context.put("mid", mid);
        context.put("excludeExternalDataSources", "false");
        context.put("retailLid", ssn);
        context.put("digitalLid", ssn);
        context.put("pointOfEntry", "RETAIL");
        context.put("role", "FidCust");
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);
        request =
                request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Call Account service
        accountResponse = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        acctRoot = "accounts.find{it.account.accountId.accountNumber=='" + internalAccountNumberDSS + "'}.";
        acctRootExt = "accounts.find{it.account.accountId.accountNumber=='" + externalAccountNumberDSS + "'}.";
        accountResponse.then().log().ifValidationFails().statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(mid))
                .body("accounts", Matchers.not(empty()));

        //Validation
        for (int i = 0; i < portfolioPositionCount; i++) {
            //description
            Assert.assertEquals((accountResponse.path(acctRoot + "positions.position[" + i + "].description")), (dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].securityDescription").toString().toUpperCase()));
            //marketValue
            Float marketValueAct = accountResponse.path(acctRoot + "positions.position[" + i + "].marketValue.value");
            Float marketValueDSS = dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].marketValDetail.marketVal");
            assertThat(marketValueAct).isCloseTo(marketValueDSS, within(marketValueDSS * 0.01f));
            //quantity
            Float quantity = accountResponse.path(acctRoot + "positions.position[" + i + "].quantity");
            Float quantityDSS = dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].quantity");
            Assert.assertEquals(quantity, quantityDSS);
            // price
            Float price = accountResponse.path(acctRoot + "positions.position[" + i + "].price.value");
            Float priceDSS = dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].priceDetail.lastPrice");
            assertThat(price).isCloseTo(priceDSS, within(priceDSS * 0.01f));
            //costBasis
            if( (dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].costBasisDetail.costBasis")) instanceof Double )
            {
                Assert.assertNotNull(accountResponse.path(acctRoot + "positions.position[" + i + "].costBasis.value"));
            }
            //corePosition = true if "securityType": "Core"
            if ((dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].securityType")) == "Core") {
                Assert.assertEquals(accountResponse.path(acctRoot + "positions.position[" + i + "].corePosition"), true);
            }
            //positionType
            Assert.assertEquals(accountResponse.path(acctRoot + "positions.position[" + i + "].positionType"), dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].securityDetail.brokerageHoldingType").toString().toUpperCase());
            //gainOrLossValue
            if ((dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].marketValDetail.totalGainLoss")) instanceof Double) {
                Assert.assertNotNull(accountResponse.path(acctRoot + "positions.position[" + i + "].gainOrLossValue.value"));
            }
            //financialInstrumentId
            Assert.assertNotNull(accountResponse.path(acctRoot + "positions.position[" + i + "].financialInstrumentId"));
        }

        //External Account Positions Validation
        if (externalAccountNumberDSS != null) {
            //marketValue
            Float marketValueActExt = accountResponse.path(acctRootExt + "account.sourceMarketValue.amount.value");
            Float marketValuePositionExt = dssPositionResponse.path("account.positions.marketValue.amount.value");
            Assert.assertEquals(marketValueActExt, marketValuePositionExt);
        }
    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS() {
        this.request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", this.ssn))
                .header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
                .header(new Header("FACMC", "MID=" + this.mid))
                .header(new Header("FACFC", "SESSION_KEY=1"))
                .header(new Header("Content-Type", "application/json"));
    }

    /**
     * Setting headers for Account Service
     */
    private void setRequestHeadersForAccount() {
        // Account headers setup
        this.request.given()
                .header(new Header("realTimeData", "true"))
                .header(new Header("mauiCache", "no"));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        this.testDataUtil.closeSQLiteConnection();
    }

}