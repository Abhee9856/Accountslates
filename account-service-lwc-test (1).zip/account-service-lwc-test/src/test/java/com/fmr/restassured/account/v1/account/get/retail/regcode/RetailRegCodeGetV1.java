/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.get.retail.regcode;

import static org.hamcrest.CoreMatchers.equalTo;

import static org.hamcrest.Matchers.*;

import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

/**
 * Tests for v1/account/get operation for retail accounts using DataProvider (for handling multiple regCodes).
 *
 * @author a653510
 * Updated by a608077 on 09/06/2021 to include: Changes for accountLegalAttributeDetails(PFCP-5456)
 * Updated by a608077 on 09/23/2021 to include: Changes for the new header for legal attributes(PFCP-6187)
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.ACCOUNT,
		Tags.V1,
		Tags.GET})
public class RetailRegCodeGetV1 extends PAPBaseServiceTest
{

    protected RetailRegCodeGetV1()
    {
	super(Services.Account);
    }

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String mid;// = "RetailAccountV1TestMid";

    String oAuthToken = AccountUtil.getOauthToken();

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = RetailRegCodeGetV1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private FilterableRequestSpecification frs;

    private VelocityContext context;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	testDataUtil = new TestDataUtil();
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);
	frs = (FilterableRequestSpecification) request;
    }

    /**
     * Test for getting Retail Accounts using data provider for reg codes
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getRetailAccountRegCodeGet", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void getRetailAccountsForRegCodes(final AccountRegCodeTestData data)
    {
	context = new VelocityContext();
	context.put("retailLid", data.getSsn());
	this.mid = data.getMidInRequest();
	context.put("mid", mid);
	context.put("mnemonicFilter", data.getRegCode1());
	context.put("source", data.getSrcFilter());

	request =
			request.log().ifValidationFails().body(IOUtil.generateJsonRequest(context,
					AccountConstants.ACCOUNT_GET_TEMPLATE));

	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200);

	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	response.then().log().ifValidationFails().body("accountList", not(empty()))
			.body("userIdentifier.mid", equalTo(mid))
			.body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
			.body("accountList[0].regCode.mnemonic", equalTo(data.getRegCode1()))
			.body("accountList[0].accountLegalAttributeDetails.accountTypeCode",
					equalTo(data.getAccountTypeCode()))
			.body("accountList[0].accountLegalAttributeDetails.legalConstructCode",
					equalTo(data.getLegalConstructCode()))
			.body("accountList[0].accountLegalAttributeDetails.legalConstructModifierCode",
					equalTo(data.getLegalConstructModifierCode()));
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }

}
