/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.withdrawals.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsWithdrawalsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.WithdrawalsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountWithdrawalsTestData;
import io.restassured.http.Header;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Tests CRUD operation for manual withdrawals for multiple accounts against V2.
 *
 * @author a608077
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.WITHDRAWALS,
        Tags.V2,
        "PFCP-4873"})

public class Manual_CRUD_Principal_And_Partner_Withdrawal_v2 extends PAPBaseServiceTest {

    private AccountsCommonTestData accountsCommonTestData;
    private String pid_partner;
    private String accId_Partner;
    private String accId_Principal;
    private final String sourceSystem = "MANUAL";

    private VelocityContext context;

    private static final String LOG_TRACKING_ID = Manual_CRUD_Principal_And_Partner_Withdrawal_v2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private TestDataUtil testDataUtil;

    protected Manual_CRUD_Principal_And_Partner_Withdrawal_v2() {
        super(Services.Account);
    }


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        accountsCommonTestData= TestDataUtil
                .populateRegressionTestData("Manual_CRUD_Principal_And_Partner_Withdrawal",oAuth);

        accountsCommonTestData.setMid(Identity.getUserIdentifier("lid", accountsCommonTestData.getSsn(), oAuth).get("mid"));

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        pid_partner = Identity.createHouseholdIdentityPartner(accountsCommonTestData.getMid(), oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("scenario-category-code", "DEF"));

        context = new VelocityContext();
        context.put("source", sourceSystem);

    }

    /**
     * Create a manual account
     */
    @Test
    public void createManualAccount() {

        float value = 818.89f;
        float value2 = 33333f;
        String asOfDate1 = "2014-10-31";
        String asOfDate2 = "2015-02-15";

        context.put("pointOfEntry", "RETAIL");
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "IRA");
        context.put("mnemonic2", "401K");
        context.put("value", value);
        context.put("asOfDate", asOfDate1);
        context.put("source2", sourceSystem);
        context.put("partnerPId", pid_partner);
        context.put("relationShip1", "PARTNER");
        context.put("value2", value2);
        context.put("asOfDate2", asOfDate2);
        context.put("displayName2", "RA Test Manual Account Partner");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));


        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);


        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        // Gets and saves the CFP account ID
        accId_Principal = response.path("accountList.accountId.find{it.owner.relationship == \"PRINCIPAL\" }.accountNumber");
        accId_Partner = response.path("accountList.accountId.find{it.owner.relationship == \"PARTNER\" }.accountNumber");


    }

    /**
     * Tests that account data is brought back for manual account.
     * Version V2
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void verifyAfterCreate() {

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Set URL to V2 before running again
        response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", Matchers.not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", Matchers.equalTo(sourceSystem));


    }


    /**
     * The is the test flow. It iterates through the data provider, performing CRUD operations for each use case.
     *
     * @param data the test cases
     */
    @Test(dependsOnMethods = "createManualAccount", dataProvider = "getManualWithdrawalData",
            dataProviderClass = WithdrawalsDataProviderUtil.class)

    public void performCrudOperations(final AccountWithdrawalsTestData data) {
        this.createAccountWithdrawals(data);
        this.getWithdrawalsAfterCreate(data);
        this.updateAccountWithdrawals(data);
        this.getWithdrawalsAfterUpdate(data);
        this.deleteAccountWithdrawals(data);
        this.getWithdrawalsAfterDelete();
    }

    /**
     * Create the account withdrawals.
     */
    private void createAccountWithdrawals(final AccountWithdrawalsTestData data) {

        // Generate request body
        context.put("accId", accId_Principal);
        context.put("accId2", accId_Partner);
        context.put("pid", pid_partner);
        context.put("accountNumber", accId_Principal);
        context.put("accountNumber2", accId_Partner);
        context.put("withdrawalType", data.getType());
        context.put("withdrawalValue", data.getAmountValue());
        context.put("valueType", data.getAmountValueType());
        context.put("frequency", data.getFrequency());
        context.put("withdrawalType2", data.getType());
        context.put("withdrawalValue2", data.getAmountValue());
        context.put("frequency2", data.getFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_V2_TEMPLATE))
                .log().ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()))
                .body("accountWithdrawals.accountId.find{it.owner.relationship == \"PRINCIPAL\" }.owner.id", Matchers.equalTo(accountsCommonTestData.getPpid()))
                .body("accountWithdrawals.accountId.find{it.owner.relationship == \"PARTNER\" }.owner.id", Matchers.equalTo(pid_partner))
                .body("accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.withdrawalType", equalTo(data.getType()),
                        "accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getAmountValue())),
                        "accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.frequency", equalTo(data.getFrequency()))
                .body("accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.withdrawalType", equalTo(data.getType()),
                        "accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getAmountValue())),
                        "accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.frequency", equalTo(data.getFrequency()));

    }

    /**
     * Validate the withdrawals.
     */
    private void getWithdrawalsAfterCreate(final AccountWithdrawalsTestData data) {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()))
                .body("accountWithdrawals.accountId.find{it.owner.relationship == \"PRINCIPAL\" }.owner.id", Matchers.equalTo(accountsCommonTestData.getPpid()))
                .body("accountWithdrawals.accountId.find{it.owner.relationship == \"PARTNER\" }.owner.id", Matchers.equalTo(pid_partner))
                .body("accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.withdrawalType", equalTo(data.getType()),
                        "accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getAmountValue())),
                        "accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.frequency", equalTo(data.getFrequency()))
                .body("accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.withdrawalType", equalTo(data.getType()),
                        "accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getAmountValue())),
                        "accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.frequency", equalTo(data.getFrequency()));

    }

    /**
     * Update the withdrawal.
     */
    private void updateAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("withdrawalType", data.getUpdatedType());
        context.put("withdrawalValue", data.getUpdatedAmountValue());
        context.put("valueType", data.getUpdatedAmountValueType());
        context.put("frequency", data.getUpdatedFrequency());
        context.put("withdrawalType2", data.getUpdatedType());
        context.put("withdrawalValue2", data.getUpdatedAmountValue());
        context.put("frequency2", data.getUpdatedFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_UPDATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.UPDATE_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals.accountId.find{it.owner.relationship == \"PRINCIPAL\" }.owner.id", Matchers.equalTo(accountsCommonTestData.getPpid()))
                .body("accountWithdrawals.accountId.find{it.owner.relationship == \"PARTNER\" }.owner.id", Matchers.equalTo(pid_partner))
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.withdrawalType", equalTo(data.getUpdatedType()),
                        "accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getUpdatedAmountValue())),
                        "accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.frequency", equalTo(data.getUpdatedFrequency()))
                .body("accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.withdrawalType", equalTo(data.getUpdatedType()),
                        "accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getUpdatedAmountValue())),
                        "accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.frequency", equalTo(data.getUpdatedFrequency()));
    }

    /**
     * Validate the withdrawal was updated.
     */
    private void getWithdrawalsAfterUpdate(final AccountWithdrawalsTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals.accountId.find{it.owner.relationship == \"PRINCIPAL\" }.owner.id", Matchers.equalTo(accountsCommonTestData.getPpid()))
                .body("accountWithdrawals.accountId.find{it.owner.relationship == \"PARTNER\" }.owner.id", Matchers.equalTo(pid_partner))
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.withdrawalType", equalTo(data.getUpdatedType()),
                        "accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getUpdatedAmountValue())),
                        "accountWithdrawals[0].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.frequency", equalTo(data.getUpdatedFrequency()))
                .body("accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.withdrawalType", equalTo(data.getUpdatedType()),
                        "accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getUpdatedAmountValue())),
                        "accountWithdrawals[1].withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.frequency", equalTo(data.getUpdatedFrequency()));

    }

    /**
     * Delete the withdrawal
     */
    private void deleteAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("withdrawalType", data.getUpdatedType());
        context.put("withdrawalValue", data.getUpdatedAmountValue());
        context.put("valueType", data.getUpdatedAmountValueType());
        context.put("frequency", data.getUpdatedFrequency());
        context.put("withdrawalType2", data.getUpdatedType());
        context.put("withdrawalValue2", data.getUpdatedAmountValue());
        context.put("frequency2", data.getUpdatedFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_DELETE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.DELETE_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                // No accounts are returned
                .body("isEmpty()", Matchers.is(true));

    }

    /**
     * Validate the withdrawals were deleted.
     */
    private void getWithdrawalsAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                // No accounts are returned
                .body("isEmpty()", Matchers.is(true));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
