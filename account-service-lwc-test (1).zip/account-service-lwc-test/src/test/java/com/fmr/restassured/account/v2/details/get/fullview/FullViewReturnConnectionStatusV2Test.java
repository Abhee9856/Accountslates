/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.get.fullview;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;


/**
 * Tests for Return connection status for a fullview Account. If DSS returns connectionStatusType as Success then Account Service will also return a Boolean value isConnectionSuccessful as true else false.
 *
 * @author a631781
 */

@Test(groups = {Tags.REGRESSION, Tags.FULLVIEW, Tags.DETAILS, Tags.V2})
public class FullViewReturnConnectionStatusV2Test extends PAPBaseServiceTest {

    protected FullViewReturnConnectionStatusV2Test() {
        super(Services.Account);
    }

    private String ssn;
    private String mid;
    private String sid;
    private String ppid;
    private static final String sourceSystem = "FULLVIEW";
    public static final String ACCOUNT_CATEGORY = "ExternalLinked";
    public static final String acctType = "External";
    public static String connectionStatusTypeSuccess = "Success";
    public static String connectionStatusTypeNotSuccess = "OutOfDate";
    public static boolean isConnectionSuccessful;
    private String actNbrConStatusSuccess;
    private String actNbrConStatusNotSuccess;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = FullViewReturnConnectionStatusV2Test.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String APP_NAME = "Advice and Planning Platform";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private Response accountResponse;
    private final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;
    private VelocityContext context;
    private FilterableRequestSpecification frs;


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_digital", oAuth);
        ssn = accountsCommonTestData.getSsn();
        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid().replace("-", "");

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity(mid, oAuth);

        testDataUtil = new TestDataUtil();

        // Populate request context with user IDs
        context = new VelocityContext();

        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Test to get the DSS Fullview account with the connectionStatusType
     * <p>
     * Version V2
     */
    @Test
    public void getDSS_V2() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().statusCode(anyOf(is(200), is(206)));
        actNbrConStatusSuccess = response.path("acctDetails.find{it.acctSubType=='Investment' && it.externalAcctDetail.connectionStatusType=='" + connectionStatusTypeSuccess + "'}.acctNum");
        actNbrConStatusNotSuccess = response.path("acctDetails.find{it.acctSubType=='Investment' && it.externalAcctDetail.connectionStatusType=='" + connectionStatusTypeNotSuccess + "'}.acctNum");
    }

    /**
     * Tests that Account Service will also return a Boolean value isConnectionSuccessful based on the DSS connectionStatusType
     *
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void getFullviewActWithConStatusTrue() {
        //Set Account Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        setRequestHeadersForAccount();
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

        // Call Account service
        accountResponse = request.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

        // Assert on response
        accountResponse.then().statusCode(200)
                .body("accountDetails", not(emptyArray()));
        if (actNbrConStatusSuccess != null) {
            isConnectionSuccessful = accountResponse.path("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.accountNumber=='" + actNbrConStatusSuccess + "'}.fullviewAccountDetail.isConnectionSuccessful");
            Assert.assertTrue(isConnectionSuccessful);

        }
        if (actNbrConStatusNotSuccess != null) {
            isConnectionSuccessful = accountResponse.path("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.accountNumber=='" + actNbrConStatusNotSuccess + "'}.fullviewAccountDetail.isConnectionSuccessful");
            Assert.assertFalse(isConnectionSuccessful);
        }
    }

     /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS() {
        request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", ssn))
                .header(new Header("rtazallrealmslids", "Retail=" + ssn))
                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + sid))
                .header(new Header("FACMC", "MID=" + mid))
                .header(new Header("FACFC", "SESSION_KEY=1"))
                .header(new Header("Content-Type", "application/json"));

    }

    /**
     * Setting headers for Account Service
     */
    private void setRequestHeadersForAccount() {
        // Account headers setup
        request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-fesco-lid", ssn))
                .header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("realTimeData", "true"))
                .header(new Header("mauiCache", "no"))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));

    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        testDataUtil.closeSQLiteConnection();
    }

}