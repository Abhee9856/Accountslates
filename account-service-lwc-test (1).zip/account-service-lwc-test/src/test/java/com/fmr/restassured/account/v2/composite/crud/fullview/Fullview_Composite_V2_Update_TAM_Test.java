/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.fullview;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;

/**
 * Class to test TAM is created successfully via UPDATE method.
 *
 * @author a631781
 */
@Test(groups = {Tags.FULLVIEW, Tags.COMPOSITE, Tags.V2})
public class Fullview_Composite_V2_Update_TAM_Test extends PAPBaseServiceTest
{
    /**
     * Constructor
     */
    protected Fullview_Composite_V2_Update_TAM_Test()
    {
        super(Services.Account);
    }
    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Fullview_Composite_V2_Update_TAM_Test.class);

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountsCommonTestData;

    private String accNum;

    private String acctRoot;

    private static String tamName = "Aggressive Growth";
    private static float tamTotalEquity = 0.85F;
    private static float tamDomesticEquity = 0.6F;
    private static float tamForeignEquity = 0.25F;
    private static float tamBond = 0.15F;
    private static float tamCash = 0.0F;

    private static String tamCategory = "INVESTOR_SELECTED_STRATEGY";
    private static Integer tamRepositoryTamId = 181;
    private static Integer tamAssetAllocationId = 85;
    private final String details = "details.fullviewAccountDetail.accountDetail.";

    /**
     * Financial Instrument IDs and their symbols
     */
    private FinancialInstrumentIds finstIds;
    private static final String LOG_TRACKING_ID = Fullview_Composite_V2_Update_TAM_Test.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private VelocityContext context;



    /**
     * Initialization method used to: </br>
     * 1. Get the default SSN and use it to retrieve the MID. </br>
     * 2. Set the Base URI </br>
     * 3. Get the account service operation paths. </br>
     * 4. Build the request header (with OAuth token).
     */
    @BeforeClass(alwaysRun = true)
    public void initClass()
    {
        oAuth = AccountUtil.getOauthToken();
        // Data setup
        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Fullview",oAuth);
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");
        accountsCommonTestData.set("emergencyFundAmountValue", "111111.11");
        accountsCommonTestData.set("updatedEmergencyFundAmountValue", "211111.11");

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(
                Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));
        context = new VelocityContext();
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init()
    {
        
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"));
    }

    //Get composite account before creating composite account
    public void getCompositeAccountFullviewV2BeforeCreate()
    {
        // Retrieve fullview test data
        accountsCommonTestData = getFullviewAccountInformationV2(accountsCommonTestData, oAuth);
        assert this.accountsCommonTestData != null;
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));

    }

    //Create Composite Account
    @Test(dependsOnMethods = "getCompositeAccountFullviewV2BeforeCreate")
    public void createCompositeAccountFullviewV2()
    {
        // Generate request body
        accNum = accountsCommonTestData.getAccountNumber1();
        context.put("accountNumber", accNum);
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("detailValue", accountsCommonTestData.get("detailValue"));


        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        // Make post request
        response = request.log().ifValidationFails()
                .post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()))
                .body(acctRoot + "details", notNullValue());


        accountsCommonTestData
                .setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
    }

    //Get Composite account after create
    @Test(dependsOnMethods = "createCompositeAccountFullviewV2")
    public void getCompositeAccountFullviewV2AfterCreate() {
        //Generate request body
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()))
                .body(acctRoot + "details", notNullValue());
    }

    //Create TAM via update call
    @Test(dependsOnMethods = "getCompositeAccountFullviewV2AfterCreate")
    public void updateCompositeAccountFullviewV2()
    {
        // Generate request body
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
        context.put("emergencyFundAmountValue", accountsCommonTestData.get("updatedEmergencyFundAmountValue"));
        context.put("TAM_name", tamName);
        context.put("TAM_total_equity", tamTotalEquity);
        context.put("TAM_domestic_equity", tamDomesticEquity);
        context.put("TAM_foreign_equity", tamForeignEquity);
        context.put("TAM_bond", tamBond);
        context.put("TAM_cash", tamCash);
        context.put("TAM_category", tamCategory);
        context.put("TAM_repositoryTamId", tamRepositoryTamId);
        context.put("TAM_assetAllocationId", tamAssetAllocationId);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        // Make post request
        response = request.log().ifValidationFails()
                .post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))))
                .body(acctRoot + details + "targetAssetMixes[0].name", equalTo(tamName))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage", equalTo(tamTotalEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage", equalTo(tamDomesticEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage", equalTo(tamForeignEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage", equalTo(tamBond))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage", equalTo(tamCash));


    }

    //Get composite account after update
    @Test(dependsOnMethods = "updateCompositeAccountFullviewV2")
    public void getCompositeAccountFullviewV2AfterUpdate()
    {
        // Generate request body
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))))
                .body(acctRoot + details + "targetAssetMixes[0].name", equalTo(tamName))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage", equalTo(tamTotalEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage", equalTo(tamDomesticEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage", equalTo(tamForeignEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage", equalTo(tamBond))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage", equalTo(tamCash));

    }

    //Delete Composite Account
    @Test(dependsOnMethods = "getCompositeAccountFullviewV2AfterUpdate")
    public void deleteCompositeAccountFullviewV2()
    {
        // Generate request body
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        request.header(new Header("user-mid", accountsCommonTestData.getMid()));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = response.jsonPath().getString("$");
        assertThat(emptyResponse, equalTo("[:]"));
    }

    //Get composite after Delete
    @Test(dependsOnMethods = "deleteCompositeAccountFullviewV2")
    public void getCompositeAccountFullviewV2AfterDelete()
    {
        // Generate request body
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Returns the response of retrieving a fullview account
     *
     * @param accountsCommonTestData
     * @param oAuth
     * @return accountsCommonTestData
     */
    private static AccountsCommonTestData getFullviewAccountInformationV2(
            final AccountsCommonTestData accountsCommonTestData, final String oAuth)
    {
        final VelocityContext context = new VelocityContext();
        context.put("source", "FULLVIEW");
        context.put("mnemonicFilter", "IRA");

        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();

        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        final Response response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        if (response.statusCode() != HTTPStatusCodes.STATUS_200)
        {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));

            return null;
        }

        final JsonPath filiAccountJP = response.jsonPath();

        final HashMap<String, String> filiAccountMap = new HashMap<String, String>();
        filiAccountMap.put("accountNumber", filiAccountJP.getString("accountList[0].accountId.accountNumber"));
        filiAccountMap.put("sourceSystem", filiAccountJP.getString("accountList[0].accountId.sourceSystem"));
        filiAccountMap.put("displayName", filiAccountJP.getString("accountList[0].displayName"));
        filiAccountMap.put("mnemonic", filiAccountJP.getString("accountList[0].regCode.mnemonic"));
        filiAccountMap.put("institutionName", filiAccountJP.getString("accountList[0].institutionName"));
        filiAccountMap.put("sourceMarketAmountValue",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
        filiAccountMap.put("sourceMarketAmountValueType",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        filiAccountMap.put("sourceMarketAmountCurrency",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        filiAccountMap.put("sourceMarketAsOfDate",
                filiAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));

        return accountsCommonTestData;
    }

}