/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.retail;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.time.ZonedDateTime;

import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests Account Composite operation for a retail account with Target Account. Test will create, update, and delete a composite
 * account and run get requests before and after each of those operations.
 *
 * @author a601767
 * Updated by a608077 on 08/26/2022 to include unknown funding amount changes(PFCP-9908)
 * Updated by a608077 on 08/30/2023 to include include-suitability-details header(PFCP-12115)
 * Updated by a608077 on 02/29/2024 to include suitabilityStatus changes(PFCP-15267)
 * Updated by a608077 on 10/17/2024 to update Validation for trustType and trustTypeInd(PFCP-17321)
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.COMPOSITE,
		Tags.V1,
		Tags.TARGET_ACCOUNT})
public class Retail_Composite_withTargetAccount extends PAPBaseServiceTest
{

    protected Retail_Composite_withTargetAccount()
    {
	super(Services.Account);
    }

    //Context
    private VelocityContext context;

    int startYear = ZonedDateTime.now().plusYears(1).getYear();

    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    private final float fundingAccountAmount = 5.55f;

    private final float updatedFundingAccountAmount = 6.78f;

    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";

    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";

    private static final String TARGET_ACCOUNT_NAME = "NewTargetAccount";

    private static final String isProductSuitable = "true";

    private static final String isProductSuitableUpdate = "false";

    private AccountsCommonTestData accountsCommonTestData;

    private TestDataUtil testDataUtil;

    private String acctRoot;
    private String mid;
    private static final String LOG_TRACKING_ID = Retail_Composite_withTargetAccount.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private final float unknownAmount = 20.0f;

    private final float updatedUnknownAmount = 26.0f;

	private static final String TRUSTEE_TYPE = "FPTC";
	private static final String TRUSTEE_TYPE_UPDATE = "ABCD";

    //Financial Instrument IDs and their symbols
    private FinancialInstrumentIds finstIds;

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init()
    {

	String oAuth = AccountUtil.getOauthToken();
	testDataUtil = new TestDataUtil();

	accountsCommonTestData = TestDataUtil
			.populateRegressionTestData("account_contributions_CRUD_RK_Retail_Principal_104", oAuth);
	this.mid = accountsCommonTestData.getMid();

	//Data setup
	accountsCommonTestData.set("updatedAmount", "15000.0");
	accountsCommonTestData.set("contribFreq", "YEARLY");
	accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
	accountsCommonTestData.set("contribAmount", "6000.0");
	accountsCommonTestData.set("updatedContribAmount", "500.0");
	accountsCommonTestData.set("withdrawAmount", "500.0");
	accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
	accountsCommonTestData.set("withdrawFreq", "YEARLY");
	accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
	accountsCommonTestData.set("detailValue", "42619.85");
	accountsCommonTestData.set("updatedDetailValue", "81819.89");

	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



	accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", mid, oAuth));

	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	//Resolve finstIds
	finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

	// Populate common variables for tests into context
	context = new VelocityContext();
	context.put("retailLid", accountsCommonTestData.getSsn());
	context.put("mid", mid);
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("source", "RETAIL");
    }

    /**
     * Get retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			    .body("accountList", not(anyOf(nullValue(),empty())));

        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }

	accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
	accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
	accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
	accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
	accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void getCompositeAccount()
    {
	// Exclude external data
	context.put("externalDataSources", "true");

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"accounts", empty());

    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getCompositeAccount"})
    public void createCompositeAccount()
    {
	// Generate request body
	    String accNum = accountsCommonTestData.getAccountNumber1();
	acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";

	context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
	context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
	context.put("GBOND", finstIds.getFinstId("GBOND"));
	context.put("GCASH", finstIds.getFinstId("GCASH"));
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accountNumber", accNum);
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
	context.put("contribValue", accountsCommonTestData.get("contribAmount"));
	context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
	context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
	context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
	context.put("detailValue", accountsCommonTestData.get("detailValue"));
	context.put("_type", AccountConstants.RETAIL_ACCOUNT_DETAILS_TYPE);
	context.put("type", AccountConstants.RETAIL_ACCOUNT_DETAILS);
	context.put("suitabilityStatus", "INCOMPLETE");
		context.put("trusteeType", TRUSTEE_TYPE);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

	// Make post request
	response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true))
			.body(acctRoot + "details.suitabilityStatus", equalTo("INCOMPLETE"));

	//Save account number and ID
	accountsCommonTestData.setAccountId1(response.path(acctRoot + "account.accountId.id"));
    }

    /**
     * Create target account
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void createTargetAccount()
    {
	context.remove("displayName");
	context.put("targetAccountSourceSystem", accountsCommonTestData.getSourceSystem1());
	context.put("targetAccountPpid", accountsCommonTestData.getPpid());
	context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
	context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("fundingAccountValue", String.valueOf(fundingAccountAmount));
	context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
	context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
	context.put("category", "INVESTOR_SELECTED_STRATEGY");
	context.put("withdrawalStartYear", startYear);
	context.put("withdrawalEndYear", endYear);
	context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
	context.put("riskTolerance", "8");
	context.put("withdrawalNeeds", "TIME_TO_TIME_WITHDRAWAL_LESS_THAN_EQUAL_TO_6");
	context.put("isProductSuitable", isProductSuitable);
	context.put("unknownAmount", String.valueOf(unknownAmount));
	context.put("suitabilityStatus", "INCOMPLETE");
	context.put("trusteeType", TRUSTEE_TYPE);
	context.put("irrevocableTrust", "false");
	context.put("trustType", null);
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("targetAccounts", not(empty()))
			.body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
			.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
			.body("targetAccounts[0].accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()))
			.body("targetAccounts[0].fundingAccounts[0].accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()))
			.body("targetAccounts[0].complementaryAdjustmentOption",
					equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
			.body("targetAccounts[0].isProductSuitable",
					equalTo(null))
			.body("targetAccounts[0].irrevocableTrust", equalTo(false))
			.body("targetAccounts[0].trustType", equalTo(null))
			.body("targetAccounts[0].suitabilityStatus", equalTo("INCOMPLETE"))
			.body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
			.body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
					equalTo("TIME_TO_TIME_WITHDRAWAL_LESS_THAN_EQUAL_TO_6"))
			.body("targetAccounts[0].targetAssetMixes[0].category",
					equalTo("INVESTOR_SELECTED_STRATEGY"))
			.body("targetAccounts[0].trusteeType", equalTo(TRUSTEE_TYPE));

	accountsCommonTestData
			.set(TARGET_ACCOUNT_NUMBER_KEY, response.path("targetAccounts[0].accountId.accountNumber"));
	accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void getCompositeAccountAfterCreate()
    {
        this.request.given()
                .header(new Header("include-suitability-details", "true"));
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));
        
        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        
        // Assert on response
	    response.then().log().ifValidationFails()
			    .statusCode(AccountConstants.HTTP_200)
			    .body("resultCode", equalTo(true))
			    .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
			    .body(acctRoot + "account.accountId.accountNumber",
					    equalTo(accountsCommonTestData.getAccountNumber1()))
			    .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
			    .body(acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
			    .body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
			    .body(acctRoot + "account.regCode.sourceSystem",
					    equalTo(accountsCommonTestData.getSourceSystem1()))
			    .body(acctRoot + "account.institutionName",
					    equalTo(accountsCommonTestData.getInstitutionName1()))
			    .body(acctRoot + "account.sourceMarketValue.amount.value",
					    equalTo(accountsCommonTestData.getValue1()))
			    .body(acctRoot + "details.suitabilityStatus", equalTo("INCOMPLETE"))
			    .body(acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							    + ".assetClass='TOTAL_EQUITY'}.netPercentage.value",
					    equalTo(0f))
			    .body(acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							    + ".assetClass='BOND'}.netPercentage.value",
					    equalTo(0f))
			    .body(acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							    + ".assetClass='CASH'}.netPercentage.value",
					    equalTo(0f))
			    .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name",
					    equalTo("Short Term"))
			    .body(acctRoot + "contributions.contributions[0].contribution.value",
					    equalTo(Float.valueOf(accountsCommonTestData.get("contribAmount"))))
			    .body(acctRoot + "contributions.contributions[0].frequency",
					    equalTo(accountsCommonTestData.get("contribFreq")))
			    .body(acctRoot + "withdrawals[0].amount.amount.value",
					    equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))))
			    .body(acctRoot + "withdrawals[0].amount.frequency",
					    equalTo(accountsCommonTestData.get("withdrawFreq")))
			    .body("targetAccounts", not(empty()))
			    .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
			    .body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
			    .body("targetAccounts[0].accountId.sourceSystem",
					    equalTo(accountsCommonTestData.getSourceSystem1()))
			    .body("targetAccounts[0].fundingAccounts[0].accountNumber",
					    equalTo(accountsCommonTestData.getAccountNumber1()))
			    .body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
			    .body("targetAccounts[0].complementaryAdjustmentOption",
					    equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
			    .body("targetAccounts[0].isProductSuitable", equalTo(null))
			    .body("targetAccounts[0].suitabilityStatus", equalTo("INCOMPLETE"))
			    .body("targetAccounts[0].irrevocableTrust", equalTo(false))
			    .body("targetAccounts[0].trustType", equalTo(null))
			    .body("targetAccounts[0].targetAssetMixes[0].category",
					    equalTo("INVESTOR_SELECTED_STRATEGY"))
				.body("targetAccounts[0].trusteeType", equalTo(TRUSTEE_TYPE));
    }

    /**
     * Update target account
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterCreate")
    public void updateTargetAccount()
    {
	context.put("fundingAccountValue", String.valueOf(updatedFundingAccountAmount));
	context.put("targetAccountSourceMarketValue", String.valueOf(updatedFundingAccountAmount));
	context.put(TARGET_ACCOUNT_NUMBER_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
	context.put(TARGET_ACCOUNT_ID_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
	context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
	context.put("category", "FINAL");
	context.put("isProductSuitable", isProductSuitableUpdate);
	context.put("suitabilityStatus", "UNSUITABLE");
	context.put("unknownAmount", String.valueOf(updatedUnknownAmount));
	context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	    response.then().log().ifValidationFails()
			    .statusCode(AccountConstants.HTTP_200)
			    .body("targetAccounts", not(empty()))
			    .body("targetAccounts[0].sourceMarketValue.amount.value",
					    equalTo(updatedFundingAccountAmount))
			    .body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
			    .body("targetAccounts[0].accountId.sourceSystem",
					    equalTo(accountsCommonTestData.getSourceSystem1()))
			    .body("targetAccounts[0].fundingAccounts[0].accountNumber",
					    equalTo(accountsCommonTestData.getAccountNumber1()))
			    .body("targetAccounts[0].complementaryAdjustmentOption",
					    equalTo("MOVE_TO_MANAGED_ACCOUNT"))
			    .body("targetAccounts[0].isProductSuitable",
					    equalTo(Boolean.valueOf(isProductSuitableUpdate)))
			    .body("targetAccounts[0].suitabilityStatus", equalTo("UNSUITABLE"))
			    .body("targetAccounts[0].fundingAccounts[0].unknownAmount",
					    equalTo(updatedUnknownAmount))
			    .body("targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"))
				.body("targetAccounts[0].trusteeType", equalTo(TRUSTEE_TYPE_UPDATE));

    }

    /**
     * Runs an update on the new account and verifies content in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateTargetAccount")
    public void updateCompositeAccount()
    {
    	context.remove("displayName");
	// Populate variables for tests into context
	context.put("value", accountsCommonTestData.get("updatedAmount"));
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("contribFreq", accountsCommonTestData.get("updatedContribFreq"));
	context.put("contribValue", accountsCommonTestData.get("updatedContribAmount"));
	context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
	context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
	context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
	context.put("accId", accountsCommonTestData.getAccountId1());
	context.put("suitabilityStatus", "SUITABLE");
		context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE));

	// Make post request
	response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true));
    }

    /**
     * Gets the composite accounts and verifies that content is still coming back.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateCompositeAccount")
    public void getCompositeAccountAfterUpdate()
    {
        this.request.given()
                .header(new Header("include-suitability-details", "true"));
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));
        
        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        
        // Assert on response
	    response.then().log().ifValidationFails()
			    .statusCode(AccountConstants.HTTP_200)
			    .body("resultCode", equalTo(true))
			    .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
			    .body(acctRoot + "account.accountId.accountNumber",
					    equalTo(accountsCommonTestData.getAccountNumber1()))
			    .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
			    .body(acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
			    .body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
			    .body(acctRoot + "account.regCode.sourceSystem",
					    equalTo(accountsCommonTestData.getSourceSystem1()))
			    .body(acctRoot + "account.institutionName",
					    equalTo(accountsCommonTestData.getInstitutionName1()))
			    .body(acctRoot + "account.sourceMarketValue.amount.value",
					    equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))))
			    .body(acctRoot + "details.suitabilityStatus", equalTo("SUITABLE"))
			    .body(acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							    + ".assetClass='TOTAL_EQUITY'}.netPercentage.value",
					    equalTo(0f))
			    .body(acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							    + ".assetClass='BOND'}.netPercentage.value",
					    equalTo(0f))
			    .body(acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							    + ".assetClass='CASH'}.netPercentage.value",
					    equalTo(0f))
			    .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name",
					    equalTo("Short Term"))
			    .body(acctRoot + "contributions.contributions[0].contribution.value",
					    equalTo(Float.valueOf(accountsCommonTestData.get("updatedContribAmount"))))
			    .body(acctRoot + "contributions.contributions[0].frequency",
					    equalTo(accountsCommonTestData.get("updatedContribFreq")))
			    .body(acctRoot + "withdrawals[0].amount.amount.value",
					    equalTo(Float.valueOf(accountsCommonTestData.get("updatedWithdrawAmount"))))
			    .body(acctRoot + "withdrawals[0].amount.frequency",
					    equalTo(accountsCommonTestData.get("updatedWithdrawFreq")))
			    .body("targetAccounts", not(empty()))
			    .body("targetAccounts[0].sourceMarketValue.amount.value",
					    equalTo(updatedFundingAccountAmount))
			    .body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
			    .body("targetAccounts[0].accountId.sourceSystem",
					    equalTo(accountsCommonTestData.getSourceSystem1()))
			    .body("targetAccounts[0].fundingAccounts[0].accountNumber",
					    equalTo(accountsCommonTestData.getAccountNumber1()))
			    .body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(updatedUnknownAmount))
			    .body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
			    .body("targetAccounts[0].isProductSuitable",
					    equalTo(Boolean.valueOf(isProductSuitableUpdate)))
			    .body("targetAccounts[0].suitabilityStatus", equalTo("UNSUITABLE"))
			    .body("targetAccounts[0].irrevocableTrust", equalTo(false))
			    .body("targetAccounts[0].trustType", equalTo(null))
			    .body("targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"))
				.body("targetAccounts[0].trusteeType", equalTo(TRUSTEE_TYPE_UPDATE));
    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterUpdate")
    public void deleteCompositeAccount()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

	// Make post request
	response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true))
			.body("accountList", empty());
    }

    /**
     * Call delete and confirm that no accounts come back in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void getCompositeAccountAfterDelete()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"accounts", empty());
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}