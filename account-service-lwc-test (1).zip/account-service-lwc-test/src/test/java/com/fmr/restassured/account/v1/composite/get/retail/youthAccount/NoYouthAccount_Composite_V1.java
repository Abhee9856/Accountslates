/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.get.retail.youthAccount;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.v1.dss.realtimedata.AccountCompositeV1;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Contains tests that validate that given account is not youth account.
 *
 * @author a631781
 */
public class NoYouthAccount_Composite_V1 extends PAPBaseServiceTest
{

    protected NoYouthAccount_Composite_V1()
    {
	super(Services.Account);
    }

    private String ssn;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = AccountCompositeV1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private final String oAuth = AccountUtil.getOauthToken();

    private TestDataUtil testDataUtil;

    private VelocityContext context;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
	// Data setup
	AccountsCommonTestData accountsCommonTestData = TestDataUtil
			.populateRegressionTestData("account_default_ssn", oAuth);

	String mid = accountsCommonTestData.getMid();
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


	ssn = accountsCommonTestData.getSsn();
	testDataUtil = new TestDataUtil();

	// Populate request context with user IDs
	context = new VelocityContext();
	context.put("source", AccountConstants.RETAIL);
	context.put("mid", mid);

    }

    /**
     * Tests for Youth Account.
     * <p>
     * Version V1
     */
    @Test
    public void getCompositeAccounts_V1()
    {
	this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	// Generate request body
	context.put("excludeExternalDataSources", "false");
	context.put("retailLid", ssn);
	context.put("pointOfEntry", "RETAIL");
	context.put("role", "FidCust");
	context.put("productCode", "IGE");
	context.put("categoryCode", "DEF");
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Call Account service
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().statusCode(200);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	response.then().log().ifValidationFails().body("accounts", not(emptyArray()))
			.body("accounts[0].account.accountId.accountNumber", notNullValue())
			.body("accounts[0].account.isYouthAccount", equalTo(false));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	this.testDataUtil.closeSQLiteConnection();
    }
}
