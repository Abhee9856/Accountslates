/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.crud.fullview;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.equalTo;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;

import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.Map;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.http.Header;

/**
 * Tests Account Details V2 for Fullview Account
 *
 * @author a653510
 */
@Test(groups = {Tags.FULLVIEW, Tags.CRUD, Tags.V2, Tags.REGRESSION})
public class FullviewDetailsV2CrudTest extends PAPBaseServiceTest
{

	Logger logger = LogManager.getLogger(this.getClass());

	protected FullviewDetailsV2CrudTest()
	{
		super(Services.Account);
	}

	/**
	 * Instance to the p2 test data utility class
	 */
	private TestDataUtil p2TestDataUtil;

	private AccountsCommonTestData accountsCommonTestData;

	private String ppid;

	// Test data
	private String accId;

	private String accountNum;

	private String sourceSystem = "FULLVIEW";

	private String displayName;

	private String mnemonic;

	private String asOfDate;

	private VelocityContext context;

	private float value = 818.89f;

	private final float updatedValue = 426.85f;

	private final Map<String, String> accIdRegCodeMap = new TreeMap<>();

	private final Map<String, String> accNumberRegCodeMap = new TreeMap<>();

	private final Map<String, String> accNumberAccIdMap = new TreeMap<>();

	private String accountId;

	private String ownerId;

	private String accNum;

	private String institutionName;

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private static final String TRUSTEE_TYPE = "FPTC";
	private static final String TRUSTEE_TYPE_UPDATE = "ABCD";

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
	 * for the test, and build the request body from Velocity.
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{
		this.p2TestDataUtil = new TestDataUtil();

		final String oAuth = AccountUtil.getOauthToken();
		this.accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_FV, oAuth);
		DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


		this.ppid = Identity.createHouseholdIdentity(this.accountsCommonTestData.getMid(), oAuth);
		this.logger.debug("New PpID created from Identity : " + this.ppid);
		// Data setup
		this.accountsCommonTestData.setPpid(this.ppid);

		this.logger.debug("OwnerID from Accounts : " + this.accountsCommonTestData.getPpid());
		// Endpoint setup
		this.setDefaultRequestHeaders(oAuth);
		this.request.given().header(new Header("user-poe", AccountConstants.RETAIL))
		        .header(new Header("user-mid", this.accountsCommonTestData.getMid()))
		        .header(new Header("user-sid", this.accountsCommonTestData.getSid()))
		        .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
		        .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
		// Populate request variables
		this.context = new VelocityContext();
		this.context.put("source", this.sourceSystem);

	}

	/**
	 * Tests that account details data is brought back for Fullview account.
	 * <p>
	 * Version V2
	 */
	@Test
	public void getFullviewAccountInfo()
	{

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
		// Call Account service v2
		this.response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);
		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("accountList", Matchers.notNullValue());
		final int size = this.response.getBody().jsonPath().getList("accountList").size();
		if (size > 0)
		{
			for (int i = 0; i < size; i++)
			{
				this.accountId = this.response.path("accountList[" + i + "].accountId.id");
				this.accountsCommonTestData.setAccountId1(this.accountId);
				this.accountNum = this.response.path("accountList[" + i + "].accountId.accountNumber");
				this.sourceSystem = this.response.path("accountList[" + i + "].accountId.sourceSystem");
				this.displayName = this.response.path("accountList[" + i + "].displayName");
				this.mnemonic = this.response.path("accountList[" + i + "].regCode.mnemonic");
				if (null != this.response.path("accountList[" + i + "].sourceMarketValue.amount.value"))
				{
					this.value = this.response.path("accountList[" + i + "].sourceMarketValue.amount.value");
				}
				this.accountsCommonTestData.setValue1(this.value);
				this.institutionName = this.response.path("accountList[" + i + "].institutionName");
				this.asOfDate = this.response.path("accountList[" + i + "].sourceMarketValue.asOfDate");
				this.ownerId = this.response.path("accountList[" + i + "].accountId.owner.id");

				if (null != this.accountId)
				{
					this.accIdRegCodeMap.put(this.mnemonic, this.accountId);
				}
				this.accNumberRegCodeMap.put(this.mnemonic, this.accountNum);
				this.accNumberAccIdMap.put(this.accountNum, this.accountId);

			}
		}

		this.logger.debug("Owner ID : " + this.ownerId);
		this.accountsCommonTestData.setPpid(this.ownerId);
		this.logger.debug("AccNumber_RegCode Map : " + this.accNumberRegCodeMap);
		this.logger.debug("AccID_RegCode Map : " + this.accIdRegCodeMap);
		this.logger.debug("AccNumber_AccID Map : " + this.accNumberAccIdMap);
	}

	/**
	 * Creates a new Fullview account
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "getFullviewAccountInfo")
	public void createFullviewAccount()
	{

		for (final Map.Entry<String, String> entry : this.accNumberRegCodeMap.entrySet())
		{
			this.logger.debug("Create FV A/c for RegCode - " + entry.getKey());
			this.context.put("ppid", this.accountsCommonTestData.getPpid());

			this.context.put("mnemonic", entry.getKey());
			this.context.put("value", this.value);
			this.context.put("source", this.sourceSystem);
			this.context.put("accountNumber", entry.getValue());
			this.context.put("displayName", this.displayName);
			this.context.put("institutionName", "BB&T");
			this.context.put("asOfDate", this.asOfDate);

			// Generate request body
			this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

			// Call Account service
			this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V2);
			// Assert on response
			this.response.then().log().ifValidationFails().statusCode(200);
			if (null != this.response.path("accountList")
			        && this.response.getBody().jsonPath().getList("accountList").size() > 0)
			{
				this.accId = this.response.path("accountList[0].accountId.id");
				this.accNum = this.response.path("accountList[0].accountId.accountNumber");

				this.logger.debug("New FV Account ID : " + this.accId);
				if (null != this.accId)
				{
					this.accNumberAccIdMap.put(this.accNum, this.accId);
				}
			}
		}
		this.logger.debug("AccountID Map : " + this.accNumberAccIdMap);
	}

	/**
	 * Create FV account Details Request.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "createFullviewAccount")
	public void createAccountDetails()
	{
		for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet())
		{

			if (null != entry.getValue())
			{
				this.context.put("ppid", this.accountsCommonTestData.getPpid());
				this.context.put("value", this.value);
				this.context.put("source", this.sourceSystem);
				this.context.put("accountNumber", entry.getKey());
				this.context.put("accId", entry.getValue());
				this.context.put("isInherited", true);
				this.context.put("isPreviousEmployersAccount", true);
				this.context.put("state", "NC");
				this.context.put("type", "fullviewAccountDetail");
				this.context.put("_type", "FullviewAccountDetails");
				context.put("trusteeType", TRUSTEE_TYPE);
				// Generate request body
				this.request.body(
						IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));
				// Call Account service
				this.response =
				        this.request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);
				// Assert on response
				this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
				        .body("accountDetails", notNullValue())
				        .body("accountDetails[0].fullviewAccountDetail.accountDetail", notNullValue());

			}
		}
	}

	/**
	 * Validate the FV account.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "createAccountDetails")
	public void getDetailsAfterCreate()
	{
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

		if (null != this.response.path("accountDetails[0].fullviewAccountDetail.accountDetail.accountId.id"))
		{
			this.response.then().body("accountDetails[0].fullviewAccountDetail.accountDetail.costBasis.value",
			        equalTo(this.value), "accountDetails[0].fullviewAccountDetail.isInherited", equalTo(true),
					"accountDetails[0].fullviewAccountDetail.accountDetail.trusteeType", equalTo(TRUSTEE_TYPE));
		}

	}

	/**
	 * Update the details for FV account.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "getDetailsAfterCreate")
	public void updateAccountDetails()
	{

		for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet())
		{
			if (null != entry.getValue())
			{

				this.context.put("ppid", this.accountsCommonTestData.getPpid());
				this.context.put("value", this.updatedValue);
				this.context.put("source", this.sourceSystem);
				this.context.put("accountNumber", entry.getKey());
				this.context.put("accId", entry.getValue());
				this.context.put("isInherited", false);
				this.context.put("isPreviousEmployersAccount", false);
				this.context.put("state", "NC");
				this.context.put("type", "fullviewAccountDetail");
				this.context.put("_type", "FullviewAccountDetails");
				context.put("trusteeType", TRUSTEE_TYPE_UPDATE);
				// Generate request body
				this.request.body(
				        IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE_V2));
				// Call Account service
				this.response =
				        this.request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);
				this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
				
			}
		}
	}

	/**
	 * Validate the updated FV account.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "updateAccountDetails")
	public void getDetailsAfterUpdate()
	{
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
		// Assert on response
		this.response.then().body("accountDetails", not(Matchers.emptyArray()))
		        .body("accountDetails[0].fullviewAccountDetail.accountDetail.accountId", notNullValue());
		if (null != this.response.path("accountDetails[0].fullviewAccountDetail.accountDetail.accountId.id"))
		{
			this.response.then().body("accountDetails[0].fullviewAccountDetail.accountDetail.costBasis.value",
			        equalTo(this.updatedValue), "accountDetails[0].fullviewAccountDetail.isInherited", equalTo(false),
					"accountDetails[0].fullviewAccountDetail.accountDetail.trusteeType", equalTo(TRUSTEE_TYPE_UPDATE));
		}

	}

	@AfterClass(alwaysRun = true)
	public void closeDBConnections()
	{
		this.p2TestDataUtil.closeSQLiteConnection();
	}
}
