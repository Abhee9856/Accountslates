/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.retirementDistribution;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.v2.retirementDistribution.FILI_RetirementDistributionV2;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Year;

import static com.fmr.restassured.account.helpers.AccountConstants.APP_ID;
import static com.fmr.restassured.account.helpers.AccountUtil.getoAuthTokenForRetirementDistribution;
import static com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.CALLING_APP_ID;
import static com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.FILI;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.hasSize;

/**
 * Contains tests that validate retirement distribution elements like rmdAmount, distributionReasonCode and YearEndBalance
 * for the FILI Account Details and Composite operation
 *
 * @author a783909
 */
@Test(groups = {Tags.FILI, Tags.ACCOUNT, Tags.V1})
public class FILI_RetirementDistributionV1 extends PAPBaseServiceTest {

    protected FILI_RetirementDistributionV1() {
        super(Services.Account);
    }

    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private static final String logTrackingId = FILI_RetirementDistributionV1.class.getSimpleName();

    private static final String fsreqid = logTrackingId;

    private String ssn;
    private String mid;
    private static final String LOG_TRACKING_ID = FILI_RetirementDistributionV1.class.getSimpleName();
    public static final String ACCOUNT_CATEGORY = "Annuity";
    private final String oAuth = AccountUtil.getOauthToken();
    private Response accountResponse;
    private TestDataUtil testDataUtil;

    private String accountNumber;
    private String rmdAmount;
    private String yearEndBalanceAmount;
    private static String distributionReasonCode;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN
     */
    @BeforeClass(alwaysRun = true)
    public void init() {

        // Data setup
        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_fili_retirement_distribution", oAuth);

        mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");

        ssn = accountsCommonTestData.getSsn();

        testDataUtil = new TestDataUtil();
    }

    /**
     * Test to validate  Retirement distribution details
     * <p>
     * Version V1
     */
    @Test()
    public void getRetirementDistribution_FILIAccount() {

        //Set RetirementDistribution Headers
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForRetirementDistribution();

        // Generate request body
        context = new VelocityContext();
        context.put("distributionYears", Year.now().getValue() - 1);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.RETIREMENT_DISTRIBUTION_TEMPLATE));

        request.baseUri(AccountConstants.APIGEE_BASE_URI_QA);
        response = request.post(AccountConstants.RETIREMENT_DISTRIBUTION_PATH_V1);

        // Assert on response
        response.then().statusCode(200);

        accountNumber = response.path("customerDetails[0].yearDetails[0].accountDetails[3].accountNumber");
        distributionReasonCode = response.path("customerDetails[0].yearDetails[0].accountDetails[3].distributionReasonCode");
        rmdAmount = response.path("customerDetails[0].yearDetails[0].accountDetails[3].distributionDetails.amount").toString();
        yearEndBalanceAmount = response.path("customerDetails[0].yearDetails[0].accountDetails[3].distributionDetails.yearEndBalanceAmount").toString();

    }

    /**
     * Tests that retirement distribution details data is brought back for Fili account in details get.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getRetirementDistribution_FILIAccount"})
    public void getFiliAccountDetails() {
        // Common Headers setup
        setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, logTrackingId, fsreqid, oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", mid);
        String sourceSystem = AccountConstants.FILI;
        context.put("source", sourceSystem);
        context.put("poe", "RETAIL");
        context.put("filiLid", ssn);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service v1
        accountResponse = request.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        accountResponse.then().log().ifValidationFails().statusCode(200)
                .body("accountDetails", not(hasSize(0)));

        Assert.assertEquals(accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.rmdAmount").toString(), rmdAmount);
        Assert.assertEquals(accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.yearEndBalanceAmount").toString(), yearEndBalanceAmount);
        Assert.assertEquals(accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.distributionReasonCode").toString(), distributionReasonCode);

    }

    /**
     * Tests that verify retirement distribution details data is brought back for Fili account in composite get.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getRetirementDistribution_FILIAccount"})
    public void getCompositeAccounts_V1() {
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        this.setDefaultRequestHeaders(CALLING_APP_ID, AccountConstants.APP_ID, logTrackingId, fsreqid, this.oAuth);
        context = new VelocityContext();
        // Generate request body
        context.put("excludeExternalDataSources", "false");
        context.put("filiLid", ssn);
        context.put("pointOfEntry", FILI);
        context.put("productCode", "IGE");
        context.put("categoryCode", "DEF");
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Call Account service
        accountResponse = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        accountResponse.then().log().ifValidationFails().statusCode(200).body("accounts", not(emptyArray()));
        Assert.assertEquals(accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
                + accountNumber + "'}.details.rmdAmount").toString(), rmdAmount);
        Assert.assertEquals(accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
                + accountNumber + "'}.details.yearEndBalanceAmount").toString(), yearEndBalanceAmount);
        Assert.assertEquals(accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
                + accountNumber + "'}.details.distributionReasonCode").toString(), distributionReasonCode);

    }

    private void setDefaultRequestHeadersForRetirementDistribution() {
        String oAuthRetDis = getoAuthTokenForRetirementDistribution();
        // Account headers setup
        this.request.given()
                .header(new Header("appid", APP_ID))
                .header(new Header("authorization", oAuthRetDis))
                .header(new Header("appname", "Planning Accounts"))
                .header(new Header("content-type", "application/json"))
                .header(new Header("facmc", "MID=" + mid))
                .header(new Header("facsc", "ROLE=FidCust"))
                .header(new Header("fsreqid", LOG_TRACKING_ID))
                .header(new Header("rtazallrealmslids", "FILI=" + ssn))
                .header(new Header("rtazlid", ssn));
    }


    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }
}