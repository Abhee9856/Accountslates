/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.get.fili;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.v1.details.crud.fili.Fili_Details_V1_Crud;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.is;

/**
 * Contains tests that validate additional data elements for the FILI Account Details operation
 *
 * @author a631781
 */
@Test(groups = {Tags.FILI, Tags.ACCOUNT, Tags.V1})
public class FILI_AdditionalAnnuityDataPointsV1 extends PAPBaseServiceTest {

    protected FILI_AdditionalAnnuityDataPointsV1() {
        super(Services.Account);
    }

    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Fili_Details_V1_Crud.class.getSimpleName();

    private static final String fsreqid = logTrackingId;

    private static final String APP_NAME = "Advice and Planning Platform";
    private String accountNumber;
    private String acctSubTypeDSSAccount = "Fixed Deferred Annuity";
    private String acctSubType = "Fixed Annuity";
    private String filiSystem = "OCI";
    private String ssn;
    public static final String ACCOUNT_CATEGORY = "Annuity";
    private final String oAuth = AccountUtil.getOauthToken();
    private Response accountResponse;
    private TestDataUtil testDataUtil;

    private String deferredAnnuityIndicator;
    private Boolean isTaxQualified;
    private String maturityDate;
    private String surrenderChargeFreeDate;
    private Float guaranteedInterestRate;
    private String guaranteePeriod;
    private String guaranteedInterestRateEndDate;
    private String productName;
    private String insuranceCompanyName;

    private String deferredAnnuityIndicatorDSS;
    private Boolean isTaxQualifiedDSS;
    private Long maturityDateDSS;
    private Integer surrenderChargeFreeDateDSS;
    private Float guaranteedInterestRateDSS;
    private String guaranteePeriodDSS;
    private Integer guaranteedInterestRateEndDateDSS;
    private String productNameDSS;
    private String insuranceCompanyNameDSS;


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        // Data setup
        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_get_FILI_Reg_Code_T_85", oAuth);

        String mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


       ssn = accountsCommonTestData.getSsn();
        accountsCommonTestData
                .setPpid(Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth));
        testDataUtil = new TestDataUtil();
        // Common Headers setup
        setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        String sourceSystem = AccountConstants.FILI;
        context.put("source", sourceSystem);
        context.put("poe", "RETAIL");
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("filiLid", accountsCommonTestData.getSsn());

    }

    /**
     * Tests that Additional Annuity details data is brought back for Fili account.
     * <p>
     * Version V1
     */
    @Test
    public void getFiliAccountDetails() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service v1
        accountResponse = request.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        accountResponse.then().log().ifValidationFails().statusCode(200)
                .body("accountDetails", not(hasSize(0)));

    }

    /**
     * Test to get the DSS FILI account
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getFiliAccountDetails"})
    public void getDSS_FILIAccount_V2() {
        // Reset headers
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        this.setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = this.request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);
        // Assert on response
        response.then().statusCode(anyOf(is(200), is(206)));
        accountNumber = response.path("acctDetails.find{it.acctSubType=='" + acctSubTypeDSSAccount + "'}.acctNum");

    }


    /**
     * Test to get the DSS FILI Details
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getDSS_FILIAccount_V2"})
    public void getDSS_FILIDetails_V2() {
        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);
        context.put("accountNumber", accountNumber);
        context.put("acctSubType", acctSubType);
        context.put("filiSystem", filiSystem);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_DETAILS_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_DETAILS_V2_PATH);
        // Assert on response
        response.then().statusCode(anyOf(is(200), is(206)));
        accountNumber = response.path("balances[0].acctNum");

        deferredAnnuityIndicatorDSS = response.path("balances[0].annuityContractDetail.fixedVarInd");
        isTaxQualifiedDSS = response.path("balances[0].annuityContractDetail.taxQualifiedInd");
        maturityDateDSS = response.path("balances[0].annuityContractDetail.maturityDate");
        surrenderChargeFreeDateDSS = response.path("balances[0].annuityContractDetail.spdaContractDetail.surrenderChargeEndDate");
        guaranteedInterestRateDSS = response.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteedInterestRate");
        guaranteePeriodDSS = response.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteePeriod");
        guaranteedInterestRateEndDateDSS = response.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteedinterestRateEndDate");
        productNameDSS = response.path("balances[0].annuityContractDetail.productName");
        insuranceCompanyNameDSS = response.path("balances[0].annuityContractDetail.insuranceCompanyName");
    }

    /**
     * Test to validate Account Details Annuity additional elements
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getDSS_FILIDetails_V2"})
    public void validateResponse() {
        //Account Composite Details elements
        deferredAnnuityIndicator = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.deferredAnnuityIndicator");
        isTaxQualified = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.isTaxQualified");
        maturityDate = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.maturityDate");
        surrenderChargeFreeDate = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.surrenderChargeFreeDate");
        guaranteedInterestRate = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.guaranteedInterestRate.value");
        guaranteePeriod = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.guaranteePeriod");
        guaranteedInterestRateEndDate = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.guaranteedInterestRateEndDate");
        productName = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.productName");
        insuranceCompanyName = accountResponse.path("accountDetails.find{it.accountId.accountNumber=='" + accountNumber + "'}.insuranceCompanyName");

        //Validating Account Details for additional Annuity elements
        Assert.assertEquals(productName, productNameDSS);
        Assert.assertEquals(deferredAnnuityIndicator, deferredAnnuityIndicatorDSS);
        Assert.assertEquals(isTaxQualified, isTaxQualifiedDSS);
        Assert.assertEquals(maturityDate, (AccountUtil.parseDSSDate(maturityDateDSS)));
        Assert.assertEquals(insuranceCompanyName, insuranceCompanyNameDSS);
        Assert.assertEquals(guaranteedInterestRate, (guaranteedInterestRateDSS / 100));
        Assert.assertEquals(guaranteePeriod, guaranteePeriodDSS);
        Assert.assertEquals(guaranteedInterestRateEndDate, AccountUtil.parseDSSDate(guaranteedInterestRateEndDateDSS.longValue()));
        Assert.assertEquals(surrenderChargeFreeDate, (AccountUtil.parseDSSDate(surrenderChargeFreeDateDSS.longValue())));
    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS() {
        this.request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", fsreqid))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", ssn))
                .header(new Header("rtazallrealmslids", "FILI=" + ssn))
                .header(new Header("FACSC", "ROLE=FidCust"))
                .header(new Header("Content-Type", "application/json"));
    }


    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }
}