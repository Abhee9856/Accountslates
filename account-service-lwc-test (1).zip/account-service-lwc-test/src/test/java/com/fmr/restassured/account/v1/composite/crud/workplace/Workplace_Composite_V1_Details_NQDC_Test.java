/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDateTime;

import static org.hamcrest.Matchers.*;

/**
 * Tests CRUD operations of account details V2 for Workplace Account for nqdcFixedRateOfReturn element
 * Story #PFCP-18759
 *
 * @author a631781
 */

@Test(groups = {
        Tags.WORKPLACE,
        Tags.COMPOSITE,
        Tags.V1})
public class Workplace_Composite_V1_Details_NQDC_Test extends PAPBaseServiceTest {

    protected Workplace_Composite_V1_Details_NQDC_Test() {
        super(Services.Account);
    }

    private AccountsCommonTestData accountsCommonTestData;
    private String mid;
    private String accNum;
    private String acctRoot;

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Workplace_Composite_V1_Details_NQDC_Test.class.getSimpleName()+ LocalDateTime.now();
    private static final String FSREQID = LOG_TRACKING_ID;

    //Context
    private VelocityContext context;
    TestDataUtil testDataUtil = new TestDataUtil();
    private float nqdcFixedRateOfReturn = 0.2f;
    private float updatedNqdcFixedRateOfReturn = 0.4f;

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init() {
        
        String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_workplace_nqdc_test", oAuth);
        mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(mid);

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        //Data setup
        accountsCommonTestData.set("updatedAmount", "15000");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("fescoLid", accountsCommonTestData.getSsn());
        context.put("mid", accountsCommonTestData.getMid());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", "WORKPLACE");
    }

    /**
     * Get retail account info from the backend. Save the account number.
     */
    @Test
    public void getWorkplaceAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void getCompositeAccount() {
        // Exclude external data
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());

    }

    /**
     * Create a new composite account with nqdcFixedRateOfReturn element. Save the account ID and account number.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getCompositeAccount"})
    public void createCompositeAccount() {
        // Generate request body
        accNum = accountsCommonTestData.getAccountNumber1();
        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accNum);
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("_type", AccountConstants.WORKPLACE_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.WORKPLACE_ACCOUNT_DETAILS);
        context.put("nqdcFixedRateOfReturn", nqdcFixedRateOfReturn);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        acctRoot + "details.nqdcFixedRateOfReturn", equalTo(nqdcFixedRateOfReturn));

        //Save account number and ID
        accountsCommonTestData.setAccountId1(response.path(acctRoot + "account.accountId.id"));
    }


    /**
     * Gets composite account and verifies there is nqdcFixedRateOfReturn in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void getCompositeAccountAfterCreate() {
        // Generate request body
        context.put("source", null);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        acctRoot + "account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()),
                        acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()),
                        acctRoot + "details.nqdcFixedRateOfReturn", equalTo(nqdcFixedRateOfReturn));
    }

    /**
     * Runs an update on the new account and verifies content in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterCreate")
    public void updateCompositeAccount() {
        // Generate request body
        context.remove("displayName");
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("nqdcFixedRateOfReturn", updatedNqdcFixedRateOfReturn);
        context.put("source", AccountConstants.WORKPLACE);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        acctRoot + "details.nqdcFixedRateOfReturn", equalTo(updatedNqdcFixedRateOfReturn));
    }

    /**
     * Gets the composite accounts and verifies that updated value is coming back for nqdcFixedRateOfReturn.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateCompositeAccount")
    public void getCompositeAccountAfterUpdate() {
        // Generate request body
        context.put("source", null);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        acctRoot + "account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()),
                        acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
                        acctRoot + "details.nqdcFixedRateOfReturn", equalTo(updatedNqdcFixedRateOfReturn));

    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterUpdate")
    public void deleteCompositeAccount() {
        // Generate request body
        context.put("source", AccountConstants.WORKPLACE);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accountList", empty());
    }
    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}