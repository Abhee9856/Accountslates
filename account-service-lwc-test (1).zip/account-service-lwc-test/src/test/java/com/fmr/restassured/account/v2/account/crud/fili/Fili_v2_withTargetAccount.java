package com.fmr.restassured.account.v2.account.crud.fili;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.http.Header;

/**
 * Tests account/get operation for a Fidelity Investments Life Insurance (FILI) account. Test will be run against
 * version V2. Created on 10/28/2020 to use the updated framework.
 *
 * @author a560878
 * Updated by a608077 on 10/13/2021 to include changes for 'scenario-id' header(PFCP-6168)
 * Updated by a608077 on 08/26/2022 to include unknown funding amount changes(PFCP-9908)
 */
@Test(groups = {Tags.FILI, Tags.ACCOUNT, Tags.V2, Tags.TARGET_ACCOUNT})
public class Fili_v2_withTargetAccount extends PAPBaseServiceTest {

    private AccountsCommonTestData accountsCommonTestData;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private String accId;

    private String accountNum;

    private String sourceSystem;

    private String displayName;

    private String mnemonic;

    private float value;

    private String institutionName;

    private String asOfDate;

    private final float fundingAccountAmount = 5.55f;

    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";
    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";
    private static final String TARGET_ACCOUNT_NAME = "NewTargetAccount";
    
    private final float unknownAmount = 20.0f;

    private final VelocityContext context = new VelocityContext();
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Fili_v2_withTargetAccount.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;


    /**
     * Generic constructor
     */
    protected Fili_v2_withTargetAccount() {
        super(Services.Account);
    }

    /**
     * Initialization method used to set up the endpoint for the test, and build the request body from the Velocity
     * Template
     */

    @BeforeClass(alwaysRun = true)
    public void init() {

        String oAuth = AccountUtil.getOauthToken();

        accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_fili", oAuth);

        String mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(mid);

        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");

        // Create Principal
        Identity.createPrincipal(accountsCommonTestData.getMid(), oAuth);
        String scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE, oAuth);
        //Insert Household
        this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", this.accountsCommonTestData.getMid(), oAuth));

        //Set default REST header with authorization token
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-fili-lid", this.accountsCommonTestData.getSsn()))
                .header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                //optional header scenario-id
                .header(new Header("scenario-id", scenarioId))
                .header(new Header("excludeExternalDataSources", "false"));

    }

    /**
     * Test to validate account data is returned for FILI accounts Version V2
     */
    @Test
    public void getFiliAccountInfo() {

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        this.response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList.accountId[0].sourceSystem", equalTo(AccountConstants.FILI));


        this.accountNum = this.response.path("accountList[0].accountId.accountNumber");
        this.sourceSystem = this.response.path("accountList[0].accountId.sourceSystem");
        this.displayName = this.response.path("accountList[0].displayName");
        this.mnemonic = this.response.path("accountList[0].regCode.mnemonic");
        this.value = this.response.path("accountList[0].sourceMarketValue.amount.value");
        this.institutionName = this.response.path("accountList[0].institutionName");
        this.asOfDate = this.response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Creates a new FILI account
     */
    @Test(dependsOnMethods = "getFiliAccountInfo")
    public void createFiliAccount() {

        this.context.put("accountNumber", this.accountNum);
        this.context.put("source", this.sourceSystem);
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("mnemonic", this.mnemonic);
        this.context.put("value", this.value);
        this.context.put("displayName", this.displayName);
        this.context.put("institutionName", this.institutionName);
        this.context.put("asOfDate", this.asOfDate);

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", equalTo(this.accountNum))
                .body("accountList[0].accountId.sourceSystem", equalTo(AccountConstants.FILI))
                .body("accountList[0].accountId.id", notNullValue());

        this.accId = this.response.path("accountList[0].accountId.id");
    }

    /**
     * Create target account
     */
    @Test(dependsOnMethods = "createFiliAccount")
    public void createTargetAccount() {

	context.remove("displayName");
        this.context.put("fundingAccountNumber", this.accountNum);
        this.context.put("fundingAccountAmount", String.valueOf(this.fundingAccountAmount));
        context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
        this.context.put("targetAccountSourceMarketValue", String.valueOf(this.fundingAccountAmount));
        this.context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        this.context.put("unknownAmount", String.valueOf(unknownAmount));

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

        // Call Account service
        this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(this.fundingAccountAmount))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(this.accountNum))
                .body("targetAccounts[0].fundingAccounts[0].amount.value", equalTo(this.fundingAccountAmount))
                .body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
                .body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"));

        this.accountsCommonTestData.set(TARGET_ACCOUNT_NUMBER_KEY, this.response.path("targetAccounts[0].accountId.accountNumber"));
        this.accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, this.response.path("targetAccounts[0].accountId.id"));
    }

    /**
     * Validates that the account was created
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void verifyFiliAccountAfterCreate() {


        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.TARGET_ACCOUNT_GET_V2_TEMPLATE));
        // Call Account service v2
        this.response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

        this.response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(empty()))
                .body("accountList[0].accountId.accountNumber", equalTo(this.accountNum))
                .body("accountList[0].accountId.id", equalTo(this.accId))
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(this.fundingAccountAmount))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(this.accountNum))
                .body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
                .body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
                .body("targetAccounts[0].fundingAccounts[0].amount.value", equalTo(this.fundingAccountAmount))
                .body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"));
    }

    /**
     * Updates the account with new mnemonic
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "verifyFiliAccountAfterCreate")
    public void updateFiliAccount() {

        this.context.put("id", this.accId);
        this.context.put("accountNumber", this.accountNum);
        this.context.put("value", "10000.0");
        this.context.put("source", this.sourceSystem);
        this.context.put("ppid", this.accountsCommonTestData.getPpid());

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

        // Set resource path
        this.response = this.request.post(AccountsPaths.UPDATE_ACCOUNT_V2);

        // Call service
        this.response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(empty()))
                .body("accountList[0].regCode.mnemonic", equalTo(mnemonic))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(10000f))
                .body("accountList[0].accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()));
    }

    /**
     * Validates that the account was updated correctly
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateFiliAccount")
    public void verifyFiliAccountAfterUpdate() {

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.TARGET_ACCOUNT_GET_V2_TEMPLATE));
        // Call Account service v2
        this.response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

        this.response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(empty()))
                .body("accountList[0].accountId.accountNumber", equalTo(this.accountNum))
                .body("accountList[0].accountId.id", equalTo(this.accId))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(this.value))
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(this.fundingAccountAmount))
                .body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(this.accountNum))
                .body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"));
    }

    /**
     * Deletes the account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "verifyFiliAccountAfterUpdate")
    public void deleteFiliAccount() {

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Set resource path
        this.response = this.request.post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(200)
                .body("isEmpty()", Matchers.is(true));
    }
}
