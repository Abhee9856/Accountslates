/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.workplace;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.equalTo;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.specification.FilterableRequestSpecification;

import java.util.Map;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operations of account details V1 for Workplace Accounts. First, retrieves workplace account, then loops
 * through all accounts and creates account details for each account.
 *
 * @author a560878
 * updated by a631781
 */
@Test(groups = {
        Tags.WORKPLACE,
        Tags.DETAILS,
        Tags.V1})

public class Workplace_Details_V1_Crud extends PAPBaseServiceTest {

    Logger logger = LogManager.getLogger(getClass());

    protected Workplace_Details_V1_Crud() {
        super(Services.Account);
    }

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private FilterableRequestSpecification frs;

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Workplace_Details_V1_Crud.class.getSimpleName();

    private static final String fsreqid = logTrackingId;

    private String ppid;

    // Test data
    private String mid;

    private String accId;

    private String accountNum;

    private String sourceSystem = AccountConstants.WORKPLACE;

    private String displayName;

    private String mnemonic;

    private String institutionName;

    private String asOfDate;

    private float value = 818.89f;

    private final float updatedValue = 426.85f;

    private final Map<String, String> accIdRegCodeMap = new TreeMap<>();

    private final Map<String, String> accNumberRegCodeMap = new TreeMap<>();

    private final Map<String, String> accNumberAccIdMap = new TreeMap<>();

    private String accountId;

    private String ownerId;

    private String accNum;

    private String assertAccId;

    private String assertAccNum;

    private String assertRegCode;

    private static final String TRUSTEE_TYPE = "FPTC";
    private static final String TRUSTEE_TYPE_UPDATE = "ABCD";

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        this.p2TestDataUtil = new TestDataUtil();

        final String oAuth = AccountUtil.getOauthToken();
        this.accountsCommonTestData =
                TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_WORKPLACE, oAuth);
        this.mid = Identity.getUserIdentifier("lid", this.accountsCommonTestData.getSsn(), oAuth).get("mid");
        this.accountsCommonTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


        this.ppid = Identity.createHouseholdIdentity(this.accountsCommonTestData.getMid(), oAuth);
        // Data setup
        this.accountsCommonTestData.setPpid(this.ppid);

        // Endpoint setup
        setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

        // Populate request variables
        this.context = new VelocityContext();
        this.context.put("mid", this.accountsCommonTestData.getMid());
        this.context.put("sid", this.accountsCommonTestData.getSid());
        this.context.put("source", this.sourceSystem);
        this.context.put("poe", "NETBENEFITS");
        this.context.put("fescoLid", accountsCommonTestData.getSsn());

        frs = (FilterableRequestSpecification) request;

    }

    /**
     * Tests that account data is brought back for Workplace account.
     * <p>
     * Version V1
     */
    @Test
    public void getWorkplaceAccountInfo() {

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service v1
        this.response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));
        final int size = this.response.getBody().jsonPath().getList("accountList").size();
        if (size > 0) {
            for (int i = 0; i < size; i++) {
                this.accountId = this.response.path("accountList[" + i + "].accountId.id");

                this.accountsCommonTestData.setAccountId1(this.accountId);
                this.accountNum = this.response.path("accountList[" + i + "].accountId.accountNumber");

                this.sourceSystem = this.response.path("accountList[" + i + "].accountId.sourceSystem");
                this.displayName = this.response.path("accountList[" + i + "].displayName");
                this.mnemonic = this.response.path("accountList[" + i + "].regCode.mnemonic");

                if (null != this.response.path("accountList[" + i + "].sourceMarketValue.amount.value")) {
                    this.value = this.response.path("accountList[" + i + "].sourceMarketValue.amount.value");
                }
                this.accountsCommonTestData.setValue1(this.value);
                this.institutionName = this.response.path("accountList[" + i + "].institutionName");
                this.asOfDate = this.response.path("accountList[" + i + "].sourceMarketValue.asOfDate");
                this.ownerId = this.response.path("accountList[" + i + "].accountId.owner.id");

                if (null != this.accountId) {
                    this.accIdRegCodeMap.put(this.mnemonic, this.accountId);
                }
                this.accNumberRegCodeMap.put(this.accountNum, this.mnemonic);
                this.accNumberAccIdMap.put(this.accountNum, this.accountId);
            }
        }

        this.accountsCommonTestData.setPpid(this.ownerId);
    }

    /**
     * Creates a new Workplace account
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount() {

        for (final Map.Entry<String, String> entry : this.accNumberRegCodeMap.entrySet()) {

            this.context.put("mid", this.accountsCommonTestData.getMid());
            this.context.put("sid", this.accountsCommonTestData.getSid());
            this.context.put("ppid", this.accountsCommonTestData.getPpid());
            this.context.put("mnemonic", entry.getValue());
            this.context.put("value", this.value);
            this.context.put("source", this.sourceSystem);
            this.context.put("accountNumber", entry.getKey());
            this.context.put("displayName", this.displayName);
            this.context.put("institutionName", this.institutionName);
            this.context.put("asOfDate", this.asOfDate);

            assertAccNum = entry.getKey();
            assertRegCode = entry.getValue();

            // Generate request body
            this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

            // Call Account service
            this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V1);

            // Assert on response
            final String path = "accountList.find{it.accountId.accountNumber=='" + assertAccNum + "'}";
            this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                    .body(path + ".accountId.accountNumber", equalTo(assertAccNum))
                    .body(path + ".regCode.mnemonic", equalTo(assertRegCode))
                    .body(path + ".displayName", equalTo(this.displayName))
                    .body(path + ".institutionName", equalTo(this.institutionName))
                    .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

            this.accId = this.response.path("accountList[0].accountId.id");
            this.accNum = this.response.path("accountList[0].accountId.accountNumber");

            this.logger.debug("New Workplace Account ID : " + this.accId);
            if (null != this.accId) {
                this.accNumberAccIdMap.put(this.accNum, this.accId);
            }
        }
    }

    /**
     * Create Workplace account Details Request.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void createAccountDetails() {
        for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet()) {
            if (null != entry.getValue()) {
                this.context.put("ppid", this.accountsCommonTestData.getPpid());
                this.context.put("value", this.value);
                this.context.put("source", this.sourceSystem);
                this.context.put("accountNumber", entry.getKey());
                this.context.put("accId", entry.getValue());
                this.context.put("isInherited", false);
                this.context.put("isPreviousEmployersAccount", false);
                this.context.put("state", "NC");
                this.context.put("type", "WorkplaceAccountDetails");
                this.context.put("_type", "WorkplaceAccountDetails");
                context.put("trusteeType", TRUSTEE_TYPE);

                assertAccId = entry.getValue();
                assertAccNum = entry.getKey();

                // Generate request body
                this.request.body(
                        IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

                // Call Account service
                this.response =
                        this.request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);

                // Assert on response
                this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                        .body("resultCode", equalTo(true))
                        .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.accountNumber", equalTo(assertAccNum))
                        .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.id", equalTo(assertAccId))
                        .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.owner.relationship", equalTo("PRINCIPAL"))
                        .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()))
                        .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.planId.planNumber", equalTo(assertAccNum))
                        .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.trusteeType", equalTo(TRUSTEE_TYPE))
                        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

            }
        }
    }

    /**
     * Validate the Workplace account details after create.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate() {
        for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet()) {
            this.context.put("ppid", this.accountsCommonTestData.getPpid());
            this.context.put("source", this.sourceSystem);
            this.context.put("accountNumber", entry.getKey());
            this.context.put("accId", entry.getValue());

            assertAccId = entry.getValue();
            if (null == assertAccId)
            {
                continue;
            }
            assertAccNum = entry.getKey();

            // Generate request body
            this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

            // Call Account service
            this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
            // Assert on response
            this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                    equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
                    "accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.accountNumber", equalTo(assertAccNum),
                    "accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.id", equalTo(assertAccId), "accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.sourceSystem",
                    equalTo("WORKPLACE"),
                    "accountDetails.find{it.accountId.id=='" + assertAccId + "'}.trusteeType", equalTo(TRUSTEE_TYPE));

        }
    }

    /**
     * Update the account details for Workplace account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails() {

        for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet()) {
            this.context.put("ppid", this.accountsCommonTestData.getPpid());
            this.context.put("value", this.updatedValue);
            this.context.put("source", this.sourceSystem);
            this.context.put("accountNumber", entry.getKey());
            this.context.put("accId", entry.getValue());
            this.context.put("isInherited", false);
            this.context.put("isPreviousEmployersAccount", false);
            this.context.put("state", "NC");
            this.context.put("type", "WorkplaceAccountDetails");
            this.context.put("_type", "WorkplaceAccountDetails");
            context.put("trusteeType", TRUSTEE_TYPE);

            assertAccId = entry.getValue();
            if (null == assertAccId)
            {
                continue;
            }
            assertAccNum = entry.getKey();

            // Generate request body
            this.request
                    .body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

            // Call Account service
            this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

            // Assert on response
            this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                    .body("resultCode", equalTo(true))
                    .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.accountNumber", equalTo(assertAccNum))
                    .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.id", equalTo(assertAccId))
                    .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.owner.relationship", equalTo("PRINCIPAL"))
                    .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()))
                    .body("accountDetails.find{it.accountId.id=='" + assertAccId + "'}.trusteeType", equalTo(TRUSTEE_TYPE))
                    .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

        }
    }

    /**
     * Validate the updated Workplace account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate() {

        for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet()) {
            this.context.put("ppid", this.accountsCommonTestData.getPpid());
            this.context.put("source", this.sourceSystem);
            this.context.put("accountNumber", entry.getKey());
            this.context.put("accId", entry.getValue());

            assertAccId = entry.getValue();
            if (null == assertAccId)
            {
                continue;
            }
            assertAccNum = entry.getKey();

            // Generate request body
            this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

            // Call Account service
            this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
            // Assert on response
            this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                    .body("resultCode", equalTo(true),
                            "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
                            "accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.accountNumber", equalTo(assertAccNum),
                            "accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.id", equalTo(assertAccId),
                            "accountDetails.find{it.accountId.id=='" + assertAccId + "'}.accountId.sourceSystem", equalTo("WORKPLACE"),
                            "accountDetails.find{it.accountId.id=='" + assertAccId + "'}.trusteeType", equalTo(TRUSTEE_TYPE));

        }

    }

    /**
     * Delete the Workplace account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteAccountDetails() {
        for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet()) {
            this.context.put("ppid", this.accountsCommonTestData.getPpid());
            this.context.put("value", this.updatedValue);
            this.context.put("source", this.sourceSystem);
            this.context.put("accountNumber", entry.getKey());
            this.context.put("accId", entry.getValue());
            this.context.put("isInherited", false);
            this.context.put("isPreviousEmployersAccount", false);
            this.context.put("state", "NC");
            this.context.put("type", "WorkplaceAccountDetails");
            this.context.put("_type", "WorkplaceAccountDetails");
            // Generate request body
            this.request
                    .body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
            // Call Account service
            this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);
            // Assert on response
            this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                    .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

        }
    }

    /**
     * Validate the workplace account was deleted.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccountDetails")
    public void getDetailsAfterDelete() {
        // context.put("externalDataSources", "true");
        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
                "accountDetails.find{it.accountId.id=='" + assertAccId + "'}.costBasis",
                nullValue());

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        this.p2TestDataUtil.closeSQLiteConnection();
    }

}
