/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.hft;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.notNullValue;

import com.fmr.ast.platform.account.domain.DestinationAccountType;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.hypofundtransfer.helpers.AccountHelper;
import com.fmr.restassured.hypofundtransfer.helpers.CreateAccount;
import com.fmr.restassured.hypofundtransfer.helpers.HypotheticalFundTransferConstants;
import com.fmr.restassured.hypofundtransfer.helpers.HypotheticalFundTransferPaths;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.commons.lang3.StringUtils;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;
import io.restassured.response.Response;

/**
 * Tests ScenarioId header implementation for Hypothetical Fund Transfer v1 CRUD operations for Retail To Retail
 * accounts.
 *
 * @author a631781
 * Updated by a608077 for removing the duplicate oauth header being sent in
 * Create HFT call as that is not supported by LWC framework.
 */
@Test(groups = {Tags.HYPO_FUND_TRANSFER, Tags.V2, "PFCP-6168"})
public class HypoFundTransferCRUDv1TestScenarioId extends PAPBaseServiceTest {

    protected HypoFundTransferCRUDv1TestScenarioId() {
        super(Services.Account);
    }

    private AccountsCommonTestData testData = null;

    private VelocityContext context;

    private String mid;

    private TestDataUtil testDataUtil;

    private static final String CALLING_APP_ID = "AP144949";

    private static final String APP_ID = "AP144949";

    private static final String LOG_TRACKING_ID = HypoFundTransferCRUDv1TestScenarioId.class.getSimpleName();

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String FSREQID = LOG_TRACKING_ID;

    private String ssn;
    private String accountNumber;

    private String accountNumber2;

    private String oAuth;

    private String scenarioId;

    Response allScenarioIDs;
    private FilterableRequestSpecification frs;
    private final String host = AccountHelper.getQATestEnvHost();
    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, and build the request
     * body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();

        testData = TestDataUtil.populateRegressionTestData("account_default_ssn", oAuth);

        ssn = testData.getSsn();
        mid = Identity.getUserIdentifier("lid", testData.getSsn(), oAuth).get("mid");
        testData.setMid(mid);
        String asOfDate1 = "2014-10-31";
        testData.setAsOfDate1(asOfDate1);

        DataCleanup.deleteCustomerDataFromCP("mid", testData.getMid(), oAuth, "true");
        testData.setPpid(Identity.createHouseholdIdentity("mid", testData.getMid(), oAuth));
        // Get/Create ScenarioId
        allScenarioIDs = Scenario.getAllScenarios(mid, oAuth);
        scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null) {
            scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE,
                    oAuth);
        }

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", testData.getSsn()))
                .header(new Header("user-mid", testData.getMid()))
                .header(new Header("scenario-id", scenarioId))
                .header(new Header("excludeExternalDataSources", "false"));

        // Populate request variables
        context = new VelocityContext();
        frs = (FilterableRequestSpecification) request;
    }

    /**
     * Create 2 Retail accounts in CFP for making Fund Transfer.
     */
    @Test
    public void createTwoRetailAccounts() {

        context.put("source", AccountConstants.RETAIL);
        context.put("mnemonicFilter", testData.getMnemonic1());
        request
                .body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(Matchers.empty()));

        String mnemonic = response.path("accountList[0].regCode.mnemonic").toString();
        accountNumber = response.path("accountList[0].accountId.accountNumber").toString();
        float srcMktValFundingAccount = response.path("accountList[0].sourceMarketValue.amount.value");

        String source = AccountConstants.RETAIL;
        String ppid = testData.getPpid();

        String mnemonic2 = response.path("accountList[1].regCode.mnemonic").toString();
        accountNumber2 = response.path("accountList[1].accountId.accountNumber").toString();
        float srcMktValDestAccount = response.path("accountList[1].sourceMarketValue.amount.value");

        String source2 = AccountConstants.RETAIL;
        frs.removeHeader("Authorization");
        final String accIds = CreateAccount.createAccounts(ssn, accountNumber, source, mnemonic, srcMktValFundingAccount,
                accountNumber2, source2, mnemonic2, srcMktValDestAccount, null, null, null, null, null, null, ppid,
                mid, request, oAuth);
        if (StringUtils.isNotBlank(accIds)) {
            final String[] arrAcc = accIds.split(",");
            String accId1 = arrAcc[0];
            String accId2 = arrAcc[1];
        }
    }

    /**
     * Create the Fund Transfer between 2 Retail accounts.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"createTwoRetailAccounts"})
    public void createFundTransfersRetail2Retail() {
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeader(CALLING_APP_ID);
        frs.removeHeader(APP_ID);
        frs.removeHeader(LOG_TRACKING_ID);
        frs.removeHeader(FSREQID);
        frs.removeHeader(oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", testData.getSsn()))
                .header(new Header("user-mid", testData.getMid()))
                .header(new Header("scenario-id", scenarioId))
                .header(new Header("excludeExternalDataSources", "false"));

        context.put("destAcct1", accountNumber2);
        context.put("destType1", DestinationAccountType.EXISTING_ACCOUNT.value());
        context.put("fundAcctNum1", accountNumber);
        context.put("transferType1", "FULL_BALANCE");
        context.put("totAmount1", "1550000");
        context.put("domEquityAmount1", "1550000");
        context.put("foreignEquityAmount1", "0");
        context.put("bondAmount1", "0");
        context.put("cashAmount1", "0");
        context.put("otherAmount1", "0");

        request.body(IOUtil.generateJsonRequest(context,
                HypotheticalFundTransferConstants.HYPOFUNDTRANSFER_CREATE_V1_TEMPLATE));

        response =
                request.baseUri(host).log().ifValidationFails().post(HypotheticalFundTransferPaths.HYPOFUNDTRNDFR_V1_PATH);

        validateResponse();
    }

    /**
     * Get details of Fund Transfer between Retail to Retail account after Create FT
     */
    @Test(dependsOnMethods = "createFundTransfersRetail2Retail")
    public void getFundTransfersRetail2Retail() {

        response =
                request.log().ifValidationFails().get(HypotheticalFundTransferPaths.HYPOFUNDTRNDFR_V1_PATH);
        validateResponse();

    }

    @Test(dependsOnMethods = "createFundTransfersRetail2Retail")
    public void getTransfersFromComposite() {

        // Exclude external data
        context.put("sourceBasedRegistrationFilter",
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.RETAIL);
        context.put("includeFundTransferDetails", true);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails()
                .given()
                .header(new Header("excludeExternalDataSources", "true"))
                .post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.HTTP_200)
                .body("accounts", not(Matchers.empty()));
        validateResponse();

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

    private void validateResponse() {

        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("transfers", not(Matchers.empty()), "transfers[0].fundingDetails[0].fundingAccountNumber",
                        notNullValue(), "transfers[0].fundingDetails[0].fundingAccountNumber",
                        equalTo(accountNumber), "transfers[0].destinationAccountNumber",
                        notNullValue(), "transfers[0].destinationAccountNumber",
                        equalTo(accountNumber2))
                .body("transfers[0].fundingDetails[0].domesticEquityAmount", notNullValue(),
                        "transfers[0].fundingDetails[0].foreignEquityAmount", notNullValue())
                .body("transfers[0].fundingDetails[0].transferType", equalTo("FULL_BALANCE"),
                        "transfers[0].fundingDetails[0].totalAmount", notNullValue());

    }
}