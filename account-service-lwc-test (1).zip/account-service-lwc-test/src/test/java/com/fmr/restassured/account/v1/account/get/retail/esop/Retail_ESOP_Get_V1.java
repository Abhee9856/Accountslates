/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.get.retail.esop;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.is;

/**
 * Tests for ESOP Retail Account V1
 *
 * @author a631781
 */

@Test(groups = {Tags.REGRESSION, Tags.RETAIL, Tags.V1})
public class Retail_ESOP_Get_V1 extends PAPBaseServiceTest
{

    protected Retail_ESOP_Get_V1()
    {
	super(Services.Account);
    }

    private static final String sourceSystem = "RETAIL";

    public static final String ACCOUNT_CATEGORY = "StockPlans";

    private String ssn;

    private String mid;

    private String sid;

    private String ppid;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_ESOP_Get_V1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String APP_NAME = "Advice and Planning Platform";

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private Response accountResponse;

    private String mnemonic = "ESOP";

    private Integer totalNumOfAcctDSS;

    private Integer totalNumOfAcct;

    List<String> accountESOPList;

    private final String oAuth = AccountUtil.getOauthToken();

    private TestDataUtil testDataUtil;

    private VelocityContext context;

    private FilterableRequestSpecification frs;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
	// Data setup
	AccountsCommonTestData accountsCommonTestData = TestDataUtil
			.populateRegressionTestData("retail_esop_account", oAuth);

	mid = accountsCommonTestData.getMid();
	sid = accountsCommonTestData.getSid().replace("-", "");
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


	ppid = Identity.createHouseholdIdentity(mid, oAuth);

	ssn = accountsCommonTestData.getSsn();
	testDataUtil = new TestDataUtil();

	// Populate request context with user IDs
	context = new VelocityContext();

	// Common headers setup
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Test to get the DSS StockPlans account
     * <p>
     * Version V2
     */
    @Test
    public void getDSS_V2()
    {
	//Set DSS Headers
	frs = (FilterableRequestSpecification) request;
	frs.removeHeaders();
	setDefaultRequestHeadersForDSS();

	// Generate request body
	context.put("acctCategory", ACCOUNT_CATEGORY);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

	request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
	response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)));
	totalNumOfAcctDSS = response.path("totalNumOfAcct");
	accountESOPList = response.path("acctDetails.parentBrokAcctNum");
    }

    /**
     * Tests that account data is brought back for ESOP account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void getRetailESOPAccountInfo()
    {
	// Set request headers
	frs = (FilterableRequestSpecification) request;
	frs.removeHeaders();
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
	// Generate request body
	context.put("source", sourceSystem);
	context.put("mid", mid);
	context.put("excludeExternalDataSources", "false");
	context.put("retailLid", ssn);
	context.put("pointOfEntry", "RETAIL");
	context.put("role", "FidCust");
	context.put("productCode", SCENARIO_PRODUCT_CODE);
	context.put("categoryCode", SCENARIO_CATEGORY_CODE);
	context.put("mnemonicFilter", mnemonic);
	request = request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	// Call Account service
	accountResponse = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	accountResponse.then().log().ifValidationFails().statusCode(200)
			.body("resultCode", equalTo(true));

	if (null != accountResponse.path("accountList"))
	{
	    ArrayList<String> accountList;
	    accountList = accountResponse.path("accountList.accountId.accountNumber");
	    totalNumOfAcct = accountList.size();
	    Assert.assertEquals(totalNumOfAcct, totalNumOfAcctDSS);
	    ArrayList<String> finalAccountList = new ArrayList<>();
	    for (String items : accountList)
	    {
		String[] acctNumbers = items.split("_", 2);
		finalAccountList.add(acctNumbers[0]);
	    }
	    Assert.assertEquals(finalAccountList, accountESOPList);

	}
    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS()
    {
	this.request.given().header(new Header("AppId", "AP106532"))
			.header(new Header("fsreqid", FSREQID))
			.header(new Header("Authorization", oAuth))
			.header(new Header("AppName", APP_NAME))
			.header(new Header("rtazlid", this.ssn))
			.header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
			.header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
			.header(new Header("FACMC", "MID=" + this.mid))
			.header(new Header("FACFC", "SESSION_KEY=1"))
			.header(new Header("Content-Type", "application/json"));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


	this.testDataUtil.closeSQLiteConnection();
    }

}
