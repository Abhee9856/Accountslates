/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.positions.get;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.is;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests account positions get for Fullview accounts. Starts by retrieving a Fili account, and then retrieving positions
 * from backend.
 *
 * @author a608077
 */
@Test(groups = {Tags.RETAIL, Tags.POSITIONS, Tags.V1})

public class Positions_Get_Retail_v1 extends PAPBaseServiceTest
{

	protected Positions_Get_Retail_v1()
	{
		super(Services.Account);
	}

	// Data setup
	private String mid;

	private String ppid;

	private String mnemonic;

	private String accountNumber;

	private String sourceSystem;

	private String displayName;

	private float value;

	private VelocityContext context;

	private static final String CALLING_APP_ID = "AP136091";

	private static final String APP_ID = "AP136091";

	private static final String LOG_TRACKING_ID = Positions_Get_Retail_v1.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private FilterableRequestSpecification frs;

	private static final String APP_NAME = "Advice and Planning Platform";

	private final String oAuth = AccountUtil.getOauthToken();

	private String ssn;

	private String sid;

	private String internalAccountNumberDSS;

	public static final String acctSubTypeDescInt = "Brokerage General Investing Person";

	public static final String acctSubTypeDescExt = "External Digital Currency";

	public static final String acctTypeDSS = "Brokerage";

	private Response dssPositionResponse;

	private int portfolioPositionCount;

	// Instance to the test data utility class
	TestDataUtil testDataUtil = new TestDataUtil();

	private String acctRoot;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();

		// Data setup
		AccountsCommonTestData accountsCommonTestData =
		                TestDataUtil.populateRegressionTestData("account_positions_get_Retail_100", oAuth);

		mid = accountsCommonTestData.getMid();
		ssn = accountsCommonTestData.getSsn();
		DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");
		ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
		                FSREQID, oAuth);

		// Populate request context with user IDs
		context = new VelocityContext();
		context.put("mid", mid);
		context.put("retailLid", accountsCommonTestData.getSsn());
		context.put("ppid", ppid);
		context.put("source", "RETAIL");

	}

	/**
	 * Get Retail account info from the backend. Save the account number.
	 */
	@Test
	public void getRetailAccountInfo()
	{
		// Set Account Headers
		frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
		                FSREQID, oAuth);
		setRequestHeadersForAccount();
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);
		Boolean resultCode = response.path("resultCode");
		Boolean dssResultCode = response.path(
		                "responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
		if (!resultCode)
		{
			Assert.assertEquals(dssResultCode, false);
		}
		response.then().log().ifValidationFails().body("accountList", Matchers.not(empty()));

		mnemonic = response.path("accountList[0].regCode.mnemonic");
		accountNumber = response.path("accountList[0].accountId.accountNumber");
		sourceSystem = response.path("accountList[0].accountId.sourceSystem");
		displayName = response.path("accountList[0].displayName");
		value = response.path("accountList[0].sourceMarketValue.amount.value");

	}

	/**
	 * Validate the positions.
	 */
	@Test(dependsOnMethods = {"getRetailAccountInfo", "getDSS_AccountPositions_V2"})
	public void getPositionsRetail()
	{
		// Set Account Headers
		frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
		                FSREQID, oAuth);
		setRequestHeadersForAccount();
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_POSITIONS_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
		Boolean resultCode = response.path("resultCode");
		Boolean dssResultCode = response.path(
		                "responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2'}.result");
		if (dssResultCode != null)
		{
			org.testng.Assert.assertEquals(resultCode, false);
		}
		else
		{
			org.testng.Assert.assertEquals(resultCode, true);
		}
		response.then().log().ifValidationFails().body("userIdentifier.mid", equalTo(mid))
		                .body("accountList[0].account.accountId.sourceSystem", equalTo(sourceSystem))
		                .body("accountList[0].account.accountId.accountNumber", equalTo(accountNumber))
		                .body("accountList[0].account.regCode.mnemonic", equalTo(mnemonic))
		                .body("accountList[0].account.displayName", equalTo(displayName))
		                .body("accountList[0].account.accountId.owner.id", equalTo(ppid))
		                .body("accountList[0].account.sourceMarketValue.amount.value", equalTo(value)).body(
		                                "accountList.account.accountId.find{it.accountNumber==\""
		                                                + accountNumber + "\"}.positions",
		                                Matchers.nullValue());
		// Validation
		acctRoot = "accountList.find{it.account.accountId.accountNumber=='" + internalAccountNumberDSS + "'}.";
		for (int i = 0; i < portfolioPositionCount; i++)
		{
			if (!(dssPositionResponse
			                .path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i
			                                + "].securityType")).toString().equals("Core"))
			{
				Float quantity = dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].quantity");
				Float endOfQuantity = dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].endOfDaySettledShareQuantity");
				Float unsettledQuantity = quantity - endOfQuantity;
				Assert.assertEquals(response
				                .path(acctRoot + "positions.position[" + i + "].unsettledQuantity"), unsettledQuantity);
			}
		}

	}

	/**
	 * Test to get the dss v2
	 * <p>
	 * Version V2
	 */
	@Test
	public void getDSS_V2()
	{
		// Set DSS Headers
		frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeadersForDSS();

		// Generate request body
		context.put("acctCategory", "Brokerage");

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

		request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
		response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)));
		internalAccountNumberDSS = response
		                .path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescInt + "'}.acctNum");
	}

	/**
	 * Test to get the dss account positions v2
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "getDSS_V2")
	public void getDSS_AccountPositions_V2()
	{
		// Set DSS Headers
		frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeadersForDSS();
		// Generate request body
		context.put("returnAvailabilityStatus", "true");
		context.put("returnAccountGainLossDetail", "true");
		context.put("returnPositionMarketValDetail", "true");
		context.put("accountNumber", internalAccountNumberDSS);
		context.put("acctType", acctTypeDSS);

		this.request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_POSITION_V2));

		dssPositionResponse = this.request.post(AccountConstants.DSS_ACCOUNT_POSITIONS_V2_PATH);
		portfolioPositionCount = dssPositionResponse.path("position.portfolioDetail.portfolioPositionCount");

		// Assert on response
		dssPositionResponse.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
		                .body("position.acctDetails.acctDetail", not(emptyArray()))
		                .body("position.acctDetails.acctDetail[0].acctNum", equalTo(internalAccountNumberDSS));

	}

	/**
	 * Setting default headers for DSS Services
	 */
	private void setDefaultRequestHeadersForDSS()
	{
		this.request.given().header(new Header("AppId", "AP106532")).header(new Header("fsreqid", FSREQID))
		                .header(new Header("Authorization", oAuth)).header(new Header("AppName", APP_NAME))
		                .header(new Header("rtazlid", this.ssn))
		                .header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
		                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
		                .header(new Header("FACMC", "MID=" + this.mid))
		                .header(new Header("FACFC", "SESSION_KEY=1"))
		                .header(new Header("Content-Type", "application/json"));

	}

	/**
	 * Setting headers for Account Service
	 */
	private void setRequestHeadersForAccount()
	{
		// Account headers setup
		this.request.given().header(new Header("user-poe", AccountConstants.RETAIL))
		                .header(new Header("user-mid", mid)).header(new Header("user-retail-lid", ssn))
		                .header(new Header("excludeExternalDataSources", "false"))
		                .header(new Header("realTimeData", "true")).header(new Header("mauiCache", "no"))
		                .header(new Header("user-digital-lid", ssn));
	}

	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}
}
