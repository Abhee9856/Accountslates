/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.retirementDistribution;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Year;

import static com.fmr.restassured.account.helpers.AccountUtil.getoAuthTokenForRetirementDistribution;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Contains tests that validate retirement distribution elements like rmdAmount, distributionReasonCode and yearEndBalanceAmount
 * for the FILI Details and composite operation
 *
 * @author a783909
 */
@Test(groups = {Tags.FILI, Tags.ACCOUNT, Tags.V2})
public class FILI_RetirementDistributionV2 extends PAPBaseServiceTest {

    protected FILI_RetirementDistributionV2() {
        super(Services.Account);
    }

    private String accountNumber;
    private String rmdAmount;
    private String yearEndBalanceAmount;
    private static String distributionReasonCode;
    private String ssn;
    private String mid;
    public static final String ACCOUNT_CATEGORY = "Annuity";
    private static final String LOG_TRACKING_ID = FILI_RetirementDistributionV2.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private static final String sourceSystem = "FILI";
    private Response accountResponse;
    private final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;

    private VelocityContext context;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_fili_retirement_distribution", oAuth);

        mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");

        ssn = accountsCommonTestData.getSsn();
        testDataUtil = new TestDataUtil();
    }

    /**
     * Test to validate  Retirement distribution details
     * <p>
     * Version V1
     */
    @Test()
    public void getRetirementDistribution_FILIAccount() {

        //Set RetirementDistribution Headers
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForRetirementDistribution();

        // Generate request body
        context = new VelocityContext();
        context.put("distributionYears", Year.now().getValue()-1);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.RETIREMENT_DISTRIBUTION_TEMPLATE));

        request.baseUri(AccountConstants.APIGEE_BASE_URI_QA);
        response = request.post(AccountConstants.RETIREMENT_DISTRIBUTION_PATH_V1);

        // Assert on response
        response.then().statusCode(200);

        accountNumber = response.path("customerDetails[0].yearDetails[0].accountDetails[3].accountNumber");
        distributionReasonCode = response.path("customerDetails[0].yearDetails[0].accountDetails[3].distributionReasonCode");
        rmdAmount = response.path("customerDetails[0].yearDetails[0].accountDetails[3].distributionDetails.amount").toString();
        yearEndBalanceAmount = response.path("customerDetails[0].yearDetails[0].accountDetails[3].distributionDetails.yearEndBalanceAmount").toString();
    }

    /**
     * Tests that retirement distribution details data is brought back for Fili account in details get.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getRetirementDistribution_FILIAccount"})
    public void getFiliAccountDetails() {
        //Set Account Headers
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();

        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        setRequestHeadersForAccount();
        // Generate request body
        context.put("accountNumber", accountNumber);
        context.put("source", sourceSystem);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

        // Call Account service
        accountResponse = request.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

        // Assert on response
        accountResponse.then().statusCode(200)
                .body("accountDetails", not(emptyArray()));

        Assert.assertEquals(accountResponse.path("accountDetails[0].annuityAccountDetail.rmdAmount").toString(), rmdAmount);
        Assert.assertEquals(accountResponse.path("accountDetails[0].annuityAccountDetail.yearEndBalanceAmount").toString(), yearEndBalanceAmount);
        Assert.assertEquals(accountResponse.path("accountDetails[0].annuityAccountDetail.distributionReasonCode").toString(), distributionReasonCode);
    }

    /**
     * Tests that verify retirement distribution details data is brought back for Fili account in composite get.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getRetirementDistribution_FILIAccount"})
    public void getFiliCompositeGet() {
        context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", sourceSystem);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request
                .header(new Header("user-mid", mid))
                .header(new Header("user-fili-lid", ssn))
                .header(new Header("excludeExternalDataSources", "false"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        accountResponse = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        // Assert on response
        accountResponse.then().statusCode(200)
                .body("accounts", not(emptyArray()));

        Assert.assertEquals(accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
                + accountNumber + "'}.details.annuityAccountDetail.rmdAmount").toString(), rmdAmount);
        Assert.assertEquals(accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
                + accountNumber + "'}.details.annuityAccountDetail.yearEndBalanceAmount").toString(), yearEndBalanceAmount);
        Assert.assertEquals(accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
                + accountNumber + "'}.details.annuityAccountDetail.distributionReasonCode").toString(), distributionReasonCode);
    }

    private void setRequestHeadersForAccount() {
        // Account headers setup
        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-fili-lid", ssn))
                .header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
    }

    private void setDefaultRequestHeadersForRetirementDistribution() {
        String oAuthRetDis = getoAuthTokenForRetirementDistribution();
        // Account headers setup
        this.request.given()
                .header(new Header("appid", AccountConstants.APP_ID))
                .header(new Header("authorization", oAuthRetDis))
                .header(new Header("appname", "Planning Accounts"))
                .header(new Header("content-type", "application/json"))
                .header(new Header("facmc", "MID=" + mid))
                .header(new Header("facsc", "ROLE=FidCust"))
                .header(new Header("fsreqid", LOG_TRACKING_ID))
                .header(new Header("rtazallrealmslids", "FILI=" + ssn))
                .header(new Header("rtazlid", ssn));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }
}
