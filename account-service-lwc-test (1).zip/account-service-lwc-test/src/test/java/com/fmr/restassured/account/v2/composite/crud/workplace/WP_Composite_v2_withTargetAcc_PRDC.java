package com.fmr.restassured.account.v2.composite.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

/**
 * Tests Account Composite operation for a Workplace account for PRDC account numbers. Test will create, update, and delete a composite
 * account and run get requests before and after each of those operations.
 *
 * @author a608077
 *
 */
@Test(groups = {
        Tags.REGRESSION,
        Tags.WORKPLACE,
        Tags.COMPOSITE,
        Tags.V2,
        Tags.TARGET_ACCOUNT,
        Tags.PRDC_DATA})
public class WP_Composite_v2_withTargetAcc_PRDC extends PAPBaseServiceTest {

        // Data setup
        private AccountsCommonTestData accountsCommonTestData;
        private static final float newFundingAmount = 6.66f;
        private final float updatedUnknownAmount = 23.5f;

        private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";
        private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";

        private static final String SCENARIO_CATEGORY_CODE = "DEF";
        private static final String SCENARIO_PRODUCT_CODE = "IGE";

        private TestDataUtil testDataUtil;
        private final String oAuth = AccountUtil.getOauthToken();
        //Context
        private final VelocityContext context = new VelocityContext();

        //Financial Instrument IDs and their symbols
        private FinancialInstrumentIds finstIds;
        private float fundingAccountAmount = 5.55f;
        private float unknownAmount = 25.0f;
        private static final String CALLING_APP_ID = "AP136091";
        private static final String APP_ID = "AP136091";
        private static final String LOG_TRACKING_ID = WP_Composite_v2_withTargetAcc_PRDC.class.getSimpleName();
        private static final String FSREQID = LOG_TRACKING_ID;

        protected WP_Composite_v2_withTargetAcc_PRDC()
        {
            super(Services.Account);
        }

        /**
         * Initialization method used to:
         * </br>1. Get the default SSN and use it to retrieve the MID.
         * </br>2. Set the Base URI
         * </br>3. Get the account service operation paths.
         * </br>4. Build the request header (with OAuth token).
         */
        @BeforeClass(alwaysRun = true)
        public void init()
        {
            testDataUtil= new TestDataUtil();

            accountsCommonTestData =
                    TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Workplace 2",oAuth);
            //Data setup
            accountsCommonTestData.set("detailValue", "42619.85");
            accountsCommonTestData.set("contribAmount", "6000.0");
            accountsCommonTestData.set("contribFreq", "YEARLY");
            accountsCommonTestData.set("withdrawAmount", "500.0");
            accountsCommonTestData.set("withdrawFreq", "YEARLY");
            accountsCommonTestData.set("updatedDetailValue", "81819.89");
            accountsCommonTestData.set("updatedAmount", "15000.0");
            accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
            accountsCommonTestData.set("updatedContribAmount", "500.0");
            accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
            accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");

            this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

            DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


            accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));


            //Resolve finstIds
            finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK","GCASH", "GDSTOCK");

            this.request.given()
                    .header(new Header("user-poe", AccountConstants.RETAIL))
                    .header(new Header("user-mid", accountsCommonTestData.getMid()))
                    .header(new Header("user-sid", accountsCommonTestData.getSid()))
                    .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                    .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                    .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                    .header(new Header("return-prdc-accounts","true"));

        }

        /**
         * Get Workplace account info from the backend. Save the account number.
         */
        @Test
        public void getWorkplaceAccountInfo()
        {
            // Generate request body
            context.put("source", AccountConstants.WORKPLACE);
            request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

            // Call Account service
            response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

            // Assert on response
            response.then().log().ifValidationFails()
                    .statusCode(AccountConstants.HTTP_200)
                    .body("accountList", not(anyOf(nullValue(),empty())));

            accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
            accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
            accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
            accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
            accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
            accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
            accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
        }

        /**
         * Create a new composite account. Save the account ID and account number.
         *
         * Version V2
         */
        @Test(dependsOnMethods="getWorkplaceAccountInfo")
        public void createCompositeAccount()
        {
            // Generate request body
            context.put("ppid", accountsCommonTestData.getPpid());
            context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
            context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
            context.put("GBOND", finstIds.getFinstId("GBOND"));
            context.put("GCASH", finstIds.getFinstId("GCASH"));
            context.put("mnemonic", accountsCommonTestData.getMnemonic1());
            context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
            context.put("value", accountsCommonTestData.getValue1());
            context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
            context.put("displayName", accountsCommonTestData.getDisplayName1());
            context.put("institutionName", accountsCommonTestData.getInstitutionName1());
            context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
            context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
            context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
            context.put("detailValue", accountsCommonTestData.get("detailValue"));

            request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

            // Make post request
            response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

			// Assert on response
			response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
					.body("accounts", not(empty())).body("accounts[0].account.accountId.id", notNullValue())
					.body("accounts[0].account.accountId.accountNumber",
							equalTo(accountsCommonTestData.getAccountNumber1()))
					.body("accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
					.body("accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
					.body("accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
					.body("accounts[0].account.regCode.sourceSystem",
							equalTo(accountsCommonTestData.getSourceSystem1()))
					.body("accounts[0].account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()))
					.body("accounts[0].account.sourceMarketValue.amount.value",
							equalTo(accountsCommonTestData.getValue1()))
					// Assertion specifically for PRDC account number
					.body("accounts[0].details.workplaceAccountDetail.accountDetail.accountId.accountNumber",
							equalTo(accountsCommonTestData.getAccountNumber1()))
					.body("accounts[0].suitability.accountId.accountNumber",
							equalTo(accountsCommonTestData.getAccountNumber1()))
					.body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
							equalTo(0f))
					.body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value",
							equalTo(0f))
					.body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value",
							equalTo(0f))
					.body("accounts[0].suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
					.body("accounts[0].withdrawals[0].amount.amount.value",
							equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))))
					.body("accounts[0].withdrawals[0].amount.frequency",
							equalTo(accountsCommonTestData.get("withdrawFreq")));

            //Save account number and ID
            accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
        }
        /**
         * Create a new composite account. Save the account ID and account number.
         *
         * Version V2
         */
        @Test(dependsOnMethods="createCompositeAccount")
        public void createTargetAccount()
        {
            //Target account fields

            context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
            context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
            context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
            context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
            context.put("category", "INVESTOR_SELECTED_STRATEGY");

            context.put("unknownAmount", String.valueOf(unknownAmount));

			request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

			// Make post request
			response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

			// Assert on response
			response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("accounts", empty())
					.body("targetAccounts", not(empty()))
					.body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
					.body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
					.body("targetAccounts[0].fundingAccounts[0].accountNumber",
							equalTo(accountsCommonTestData.getAccountNumber1()))
					.body("targetAccounts[0].fundingAccounts[0].amount.value", equalTo(fundingAccountAmount))
					.body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
					.body("targetAccounts[0].complementaryAdjustmentOption",
							equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"));

			// Save target account number and ID
			accountsCommonTestData.set(TARGET_ACCOUNT_NUMBER_KEY,
					response.path("targetAccounts[0].accountId.accountNumber"));
			accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
		}
    /**
     * Gets composite account and verifies there is content in the response.
     *
     * Version V2
     */
    @Test(dependsOnMethods="createTargetAccount")
    public void getCompositeAccountAfterCreate() {
        context.put("source", null);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body("accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
                .body("accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body("accounts[0].account.regCode.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()))
                .body("accounts[0].account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(accountsCommonTestData.getValue1()))
                // Assertion specifically for PRDC account number
                .body("accounts[0].details.workplaceAccountDetail.accountDetail.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accounts[0].suitability.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value",
                        equalTo(0f))
                .body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value",
                        equalTo(0f))
                .body("accounts[0].suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body("accounts[0].withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))))
                .body("accounts[0].withdrawals[0].amount.frequency",
                        equalTo(accountsCommonTestData.get("withdrawFreq")))
                .body("targetAccounts", not(anyOf(nullValue(),empty())))
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("targetAccounts[0].fundingAccounts[0].amount.value", equalTo(fundingAccountAmount))
                .body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
                .body("targetAccounts[0].complementaryAdjustmentOption",
                        equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"));
    }

        /**
         * Runs an update on the new account and verifies content in the response.
         *
         * Version V2
         */
        @Test(dependsOnMethods="createTargetAccount")
        public void updateCompositeAccount()
        {
            context.put("source", AccountConstants.WORKPLACE);
            // Populate variables for tests into context
            context.put("value", accountsCommonTestData.get("updatedAmount"));
            context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
            context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
            context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
            context.put("accId", accountsCommonTestData.getAccountId1());

            // Generate request body
            request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));

            // Make post request
            response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

            // Assert on response
            response.then().log().ifValidationFails()
                    .statusCode(AccountConstants.HTTP_200)
                    .body("accounts", not(empty()));
        }

        /**
         * Runs an update on the new account and verifies content in the response.
         *
         * Version V2
         */
        @Test(dependsOnMethods="updateCompositeAccount")
        public void updateTargetAccount()
        {
            //Target account fields
            context.put("targetAccountId", accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
            context.put("targetAccountNumber", accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
            context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
            context.put("fundingAccountAmount", String.valueOf(newFundingAmount));
            context.put("targetAccountSourceMarketValue", String.valueOf(newFundingAmount));
            context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
            context.put("unknownAmount",String.valueOf(updatedUnknownAmount));

            // Generate request body
            request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_UPDATE_V2_TEMPLATE));

            // Make post request
            response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

            // Assert on response
            response.then().log().ifValidationFails()
                    .statusCode(AccountConstants.HTTP_200)
                    .body("accounts", empty(),
                            "targetAccounts", not(empty()));
        }

        /**
         * Gets the composite accounts and verifies that content is still coming back.
         *
         * Version V2
         */
        @Test(dependsOnMethods="updateTargetAccount")
        public void getCompositeAccountAfterUpdate()
        {
            // Generate request body
            context.put("source", null);
            request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

            // Make post request
            response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

            // Assert on response
            response.then().log().ifValidationFails()
                    .statusCode(AccountConstants.HTTP_200)
                    .body("accounts", not(empty()))
                    .body("accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                    .body("accounts[0].account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                    .body("accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                    .body("accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
                    .body("accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                    .body("accounts[0].account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()))
                    .body("accounts[0].account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()))
                    .body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value", equalTo(0f))
                    .body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value", equalTo(0f))
                    .body("accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value", equalTo(0f))
                    .body("accounts[0].suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                    .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(Float.valueOf(accountsCommonTestData.get("updatedWithdrawAmount"))))
                    .body("accounts[0].withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("updatedWithdrawFreq")))
                    .body("targetAccounts", not(anyOf(nullValue(),empty())))
                    .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(newFundingAmount))
                    .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                    .body("targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                    .body("targetAccounts[0].fundingAccounts[0].amount.value", equalTo(newFundingAmount))
                    .body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(updatedUnknownAmount))
                    .body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"));
        }

        /**
         * Delete the composite account that we created. Verify the account list is empty.
         *
         * Version V2
         */
	@Test(dependsOnMethods="getCompositeAccountAfterUpdate")
	public void deleteCompositeAccount()
	{
		// Generate request body
		context.put("source", AccountConstants.WORKPLACE);
		context.put("id", accountsCommonTestData.getAccountId1());
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

		// Make post request
		response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("isEmpty()", Matchers.is(true));
	}

	/**
	 * Call delete and confirm that no accounts come back in the response.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods="deleteCompositeAccount")
	public void getCompositeAccountAfterDelete()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Make post request
		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
                .body("accounts[0].account.accountId.id", nullValue());
	}
        @AfterClass(alwaysRun = true)
        public void closeDBConnections() {
            testDataUtil.closeSQLiteConnection();
        }
    }

