/*
 * Copyright 2018, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.manual;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.nullValue;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.response.Response;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operation for manual details against V1.
 *
 * @author a601767
 * Updated by a608077 on 10/13/2021 to include changes for 'scenario-id' header(PFCP-6168)
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.DETAILS,
        Tags.V1})
public class Manual_Details_V1_CRUD extends PAPBaseServiceTest {
    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private final float value = 818.89f;

    private final float updatedValue = 426.85f;

    // Velocity Keys
    private static final String IS_TRANSFER_TO_SURVIVOR_IND = "isTransferToSurvivorIndicator";

    private static final String VESTED_VALUE = "vestedValue";

    private static final String UNVESTED_VALUE = "unvestedValue";

    private static final String YEARS_REMAINING = "yearsRemaining";

    private static final String BENEFICIARY_AVAILABLE = "beneficiaryAvailable";

    private static final String COMPLEMENTARY_ADJUSTMENT_OPT = "complementaryAdjustmentOption";

    private static final String EQUITY_PERCENT = "equityPercent";

    private static final String WITHDRAWAL_START_DATE = "withdrawalEligibilityStartDate";

    private static final String WITHDRAWAL_END_DATE = "withdrawalEligibilityEndDate";

    private TestDataUtil testDataUtil;

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Manual_Details_V1_CRUD.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private String mid;

    private static final String TRUSTEE_TYPE = "FPTC";
    private static final String TRUSTEE_TYPE_UPDATE = "ABCD";


    /**
     * Constructor.
     */
    protected Manual_Details_V1_CRUD() {
        super(Services.Account);
    }


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {

        final String oAuth = AccountUtil.getOauthToken();

        //Data Setup
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("manual_details_crud", oAuth);

        mid = accountsCommonTestData.getMid();

        //Set default REST header with authorization token
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        testDataUtil = new TestDataUtil();
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


        //Set ppid
        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth));
        // Get/Create ScenarioId
        Response allScenarioIDs = Scenario.getAllScenarios(mid, oAuth);
        String scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null) {
            scenarioId = Scenario.createScenarioWithProductCode(mid, "IGE", "DEF",
                    oAuth);
        }

        //Set the regCode for this test
        accountsCommonTestData.setMnemonic1("IRA");
        accountsCommonTestData.set("isInherited", "false");
        accountsCommonTestData.set("isPreviousEmployersAccount", "false");
        accountsCommonTestData.set("state", "AK");
        accountsCommonTestData.setSourceSystem1("MANUAL");
        String asOfDate = "2014-10-31";
        accountsCommonTestData.setAsOfDate1(asOfDate);

        accountsCommonTestData.set(IS_TRANSFER_TO_SURVIVOR_IND, "true");
        accountsCommonTestData.set(VESTED_VALUE, "100.0");
        accountsCommonTestData.set(UNVESTED_VALUE, "200.0");
        accountsCommonTestData.set(YEARS_REMAINING, "10");
        accountsCommonTestData.set(BENEFICIARY_AVAILABLE, "true");
        accountsCommonTestData.set(COMPLEMENTARY_ADJUSTMENT_OPT, "MANAGED_LOCK_CURRENT_ALLOCATION");
        accountsCommonTestData.set(EQUITY_PERCENT, "0.8");
        accountsCommonTestData.set(WITHDRAWAL_START_DATE, "2020-01-01T00:00:00.000+0000");
        accountsCommonTestData.set(WITHDRAWAL_END_DATE, "2020-01-01T00:00:00.000+0000");


        // Populate request variables
        context = new VelocityContext();
        context.put("scenarioId", scenarioId);
        context.put("mid", accountsCommonTestData.getMid());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", String.valueOf(value));
        context.put("isInherited", accountsCommonTestData.get("isInherited"));
        context.put("isPreviousEmployersAccount", accountsCommonTestData.get("isPreviousEmployersAccount"));
        context.put("state", accountsCommonTestData.get("state"));
        context.put(IS_TRANSFER_TO_SURVIVOR_IND, accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND));
        context.put(VESTED_VALUE, accountsCommonTestData.get(VESTED_VALUE));
        context.put(UNVESTED_VALUE, accountsCommonTestData.get(UNVESTED_VALUE));
        context.put(YEARS_REMAINING, accountsCommonTestData.get(YEARS_REMAINING));
        context.put(BENEFICIARY_AVAILABLE, accountsCommonTestData.get(BENEFICIARY_AVAILABLE));
        context.put(COMPLEMENTARY_ADJUSTMENT_OPT, accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT));
        context.put(EQUITY_PERCENT, accountsCommonTestData.get(EQUITY_PERCENT));
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put(WITHDRAWAL_START_DATE, accountsCommonTestData.get(WITHDRAWAL_START_DATE));
        context.put(WITHDRAWAL_END_DATE, accountsCommonTestData.get(WITHDRAWAL_END_DATE));
        context.put("trusteeType", TRUSTEE_TYPE);
    }

    /**
     * Create the manual account.
     * <p>
     * Version V1
     */
    @Test
    public void createManualAccount() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_WITH_SCENARIO_ID_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()));

        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("accId", accountsCommonTestData.getAccountNumber1());
    }

    /**
     * Validate the manual account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void getDetailsAfterCreateAccount() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()));

    }

    /**
     * Update the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreateAccount")
    public void createAccountDetails() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.costBasis.value", equalTo(value),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isInherited", equalTo(false),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isPreviousEmployersAccount", equalTo(false),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.state", equalTo(accountsCommonTestData.get("state")),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.withdrawalEligibilityStartDate", equalTo(accountsCommonTestData.get("withdrawalEligibilityStartDate")),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.withdrawalEligibilityEndDate", equalTo(accountsCommonTestData.get("withdrawalEligibilityEndDate")),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.trusteeType", equalTo(TRUSTEE_TYPE));

    }

    /**
     * Validate the updated manual account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.costBasis.value", equalTo(value),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isInherited", equalTo(false),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isPreviousEmployersAccount", equalTo(false),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isTransferToSurvivorIndicator",
                        equalTo(Boolean.parseBoolean(accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.vestedValue.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get(VESTED_VALUE))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.unvestedValue.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get(UNVESTED_VALUE))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.yearsRemaining",
                        equalTo(Integer.valueOf(accountsCommonTestData.get(YEARS_REMAINING))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.beneficiaryAvailable",
                        equalTo(Boolean.parseBoolean(accountsCommonTestData.get(BENEFICIARY_AVAILABLE))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.complementaryAdjustmentOption",
                        equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.equityPercent",
                        equalTo(Float.valueOf(accountsCommonTestData.get(EQUITY_PERCENT))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.state", equalTo(accountsCommonTestData.get("state")),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.withdrawalEligibilityStartDate", equalTo(accountsCommonTestData.get("withdrawalEligibilityStartDate")),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.withdrawalEligibilityEndDate", equalTo(accountsCommonTestData.get("withdrawalEligibilityEndDate")),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.trusteeType", equalTo(TRUSTEE_TYPE));

    }

    /**
     * Update account Details
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails() {
        // Generate request body
        accountsCommonTestData.set("isInherited", "true");
        accountsCommonTestData.set("isPreviousEmployersAccount", "true");
        accountsCommonTestData.set("state", "NC");
        accountsCommonTestData.set(IS_TRANSFER_TO_SURVIVOR_IND, "false");
        accountsCommonTestData.set(VESTED_VALUE, "1000.0");
        accountsCommonTestData.set(UNVESTED_VALUE, "2000.0");
        accountsCommonTestData.set(YEARS_REMAINING, "5");
        accountsCommonTestData.set(BENEFICIARY_AVAILABLE, "false");
        accountsCommonTestData.set(COMPLEMENTARY_ADJUSTMENT_OPT, "MOVE_TO_MANAGED_ACCOUNT");
        accountsCommonTestData.set(EQUITY_PERCENT, "0.7");
        accountsCommonTestData.set(WITHDRAWAL_START_DATE, "2030-01-01T00:00:00.000+0000");
        accountsCommonTestData.set(WITHDRAWAL_END_DATE, "2030-01-01T00:00:00.000+0000");

        //Set new fields in Velocity
        context.put("isInherited", accountsCommonTestData.get("isInherited"));
        context.put("isPreviousEmployersAccount", accountsCommonTestData.get("isPreviousEmployersAccount"));
        context.put("state", accountsCommonTestData.get("state"));
        context.put("value", updatedValue);
        context.put(IS_TRANSFER_TO_SURVIVOR_IND, accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND));
        context.put(VESTED_VALUE, accountsCommonTestData.get(VESTED_VALUE));
        context.put(UNVESTED_VALUE, accountsCommonTestData.get(UNVESTED_VALUE));
        context.put(YEARS_REMAINING, accountsCommonTestData.get(YEARS_REMAINING));
        context.put(BENEFICIARY_AVAILABLE, accountsCommonTestData.get(BENEFICIARY_AVAILABLE));
        context.put(COMPLEMENTARY_ADJUSTMENT_OPT, accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT));
        context.put(EQUITY_PERCENT, accountsCommonTestData.get(EQUITY_PERCENT));
        context.put(WITHDRAWAL_START_DATE, accountsCommonTestData.get(WITHDRAWAL_START_DATE));
        context.put(WITHDRAWAL_END_DATE, accountsCommonTestData.get(WITHDRAWAL_END_DATE));
        context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_UPDATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.costBasis.value", equalTo(updatedValue),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isInherited", equalTo(true),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isPreviousEmployersAccount", equalTo(true),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isTransferToSurvivorIndicator",
                        equalTo(Boolean.parseBoolean(accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.vestedValue.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get(VESTED_VALUE))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.unvestedValue.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get(UNVESTED_VALUE))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.yearsRemaining",
                        equalTo(Integer.valueOf(accountsCommonTestData.get(YEARS_REMAINING))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.beneficiaryAvailable",
                        equalTo(Boolean.parseBoolean(accountsCommonTestData.get(BENEFICIARY_AVAILABLE))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.complementaryAdjustmentOption",
                        equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.equityPercent",
                        equalTo(Float.valueOf(accountsCommonTestData.get(EQUITY_PERCENT))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.state", equalTo(accountsCommonTestData.get("state")),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.withdrawalEligibilityStartDate", equalTo("2030-01-01T00:00:00.000+0000"),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.withdrawalEligibilityEndDate", equalTo("2030-01-01T00:00:00.000+0000"),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.trusteeType", equalTo(TRUSTEE_TYPE_UPDATE));
    }


    /**
     * Update account Details
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetailsWithNull() {
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_UPDATE_NULL_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

        // Assert on response
        response.then().log().everything()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.withdrawalEligibilityStartDate", nullValue(),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.withdrawalEligibilityEndDate", nullValue(),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.trusteeType", equalTo(TRUSTEE_TYPE_UPDATE));
    }

    /**
     * Validate the manual account was updated.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.costBasis.value", equalTo(updatedValue),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isInherited", equalTo(true),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isPreviousEmployersAccount", equalTo(true),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.isTransferToSurvivorIndicator",
                        equalTo(Boolean.parseBoolean(accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.vestedValue.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get(VESTED_VALUE))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.unvestedValue.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get(UNVESTED_VALUE))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.yearsRemaining",
                        equalTo(Integer.valueOf(accountsCommonTestData.get(YEARS_REMAINING))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.beneficiaryAvailable",
                        equalTo(Boolean.parseBoolean(accountsCommonTestData.get(BENEFICIARY_AVAILABLE))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.complementaryAdjustmentOption",
                        equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.equityPercent",
                        equalTo(Float.valueOf(accountsCommonTestData.get(EQUITY_PERCENT))),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.state", equalTo(accountsCommonTestData.get("state")),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.trusteeType", equalTo(TRUSTEE_TYPE_UPDATE));

    }

    /**
     * Validate the manual account was updated.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteAccountDetails() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()));
    }

    /**
     * Validate the manual account was updated.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccountDetails")
    public void getDetailsAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountDetails.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()));

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }
}
