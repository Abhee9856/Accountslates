/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.get.fullview.regcode;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.commons.collections.CollectionUtils;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.is;

/**
 * Tests for v2/account/get operation for FullView accounts using DSS Account V2.
 *
 * @author a783909
 */
@Test(groups = {Tags.PIPELINE, Tags.ASYNCHRONOUS, Tags.FULLVIEW, Tags.ACCOUNT, Tags.V2, Tags.GET})
public class FullViewDisplayNameGetV2 extends PAPBaseServiceTest {
    protected FullViewDisplayNameGetV2() {
        super(Services.Account);
    }

    private VelocityContext context;

    private static final String sourceSystem = "FULLVIEW";

    private Response accountResponse;

    /**
     * Instance to the test data utility class
     */

    private String accNumber;

    private String displayName;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private final String oAuth = AccountUtil.getOauthToken();

    private static final String APP_NAME = "Advice and Planning Platform";

    private FilterableRequestSpecification frs;

    private String ssn;

    private String mid;

    private String sid;

    private static final String LOG_TRACKING_ID = FullViewDisplayNameGetV2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */

    @BeforeClass
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_CRUD_Fullview_131", oAuth);

        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ssn = accountsCommonTestData.getSsn();

        context = new VelocityContext();
        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Test for getting Fullview Accounts using data provider.
     * <p>
     * Version V2
     */

    @Test
    public void getDSS_V2() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", "ExternalManual");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)));

        accNumber = response.path("acctDetails[0].acctNum");
        displayName = response.path("acctDetails[0].externalAcctDetail.acctName") != null ?
                response.path("acctDetails[0].externalAcctDetail.acctName") :
                response.path("acctDetails[0].preferenceDetail.name");
        displayName = displayName + " (FV)";

    }

    @Test(dependsOnMethods = {"getDSS_V2"})
    public void getAccountInfo_v2() {
        // Set request headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        setRequestHeadersForAccount();
        // Generate request body
        context.put("source", sourceSystem);
        context.put("mid", mid);
        context.put("excludeExternalDataSources", "false");
        context.put("retailLid", ssn);
        context.put("pointOfEntry", "RETAIL");
        context.put("role", "FidCust");
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service v2
        accountResponse = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        accountResponse.then().log().ifValidationFails().statusCode(200);

        Assert.assertEquals(accountResponse.path("accountList.find{it.accountId.accountNumber == '" + accNumber + "'}.displayName"), displayName);

    }

    private void setRequestHeadersForAccount() {
        // Account headers setup
        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-retail-lid", ssn))
                .header(new Header("exclude-external-data-sources", "false"))
                .header(new Header("realTimeData", "false"))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("Content-Type", "application/json"));

    }

    private void setDefaultRequestHeadersForDSS() {
        this.request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", this.ssn))
                .header(new Header("rtazallrealmslids", "Fullview=" + this.ssn))
                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
                .header(new Header("FACMC", "MID=" + this.mid))
                .header(new Header("FACFC", "SESSION_KEY=1"))
                .header(new Header("Content-Type", "application/json"));
    }

}
