/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDateTime;

import static org.hamcrest.Matchers.equalTo;

/**
 * Tests CRUD operations of account details V2 for Workplace Account for nqdcFixedRateOfReturn element
 * Story #PFCP-18759
 *
 * @author a631781
 */
@Test(groups = {Tags.WORKPLACE,
        Tags.DETAILS})
public class Workplace_Details_NQDC_V2_Crud_Test extends PAPBaseServiceTest {

    protected Workplace_Details_NQDC_V2_Crud_Test() {
        super(Services.Account);
    }

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private String ppid;

    private VelocityContext context;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Workplace_Details_NQDC_V2_Crud_Test.class.getSimpleName()+ LocalDateTime.now();

    private static final String fsreqid = logTrackingId;

    // Test data
    private String mid;

    private String accId;

    private String sourceSystem = AccountConstants.WORKPLACE;

    private String displayName;

    private String mnemonic;

    private String institutionName;

    private String asOfDate;

    private float value = 818.89f;

    private final float updatedValue = 426.85f;

    FilterableRequestSpecification frs = null;

    private String accNum;
    private float nqdcFixedRateOfReturn = 0.1f;
    private float updatedNqdcFixedRateOfReturn = 0.5f;
    private String acctRoot;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        p2TestDataUtil = new TestDataUtil();

        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_workplace_nqdc_test", oAuth);

        mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(mid);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");
        ppid = Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth);
        // Data setup
        accountsCommonTestData.setPpid(ppid);
        // Endpoint setup
        setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

        request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("excludeExternalDataSources", "false"));

        // Populate request variables
        context = new VelocityContext();
        context.put("source", sourceSystem);
        frs = (FilterableRequestSpecification) request;
    }

    /**
     * Tests that account data is brought back for Workplace account.
     * <p>
     * Version V2
     */
    @Test
    public void getWorkplaceAccountInfo() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service v2
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(200).body("accountList[0].accountId.sourceSystem",
                equalTo(sourceSystem));
        accNum = response.path("accountList[0].accountId.accountNumber");
        displayName = response.path("accountList.find{it.accountId.accountNumber=='" + accNum + "'}.displayName");
        institutionName =
                response.path("accountList.find{it.accountId.accountNumber=='" + accNum + "'}.institutionName");
        asOfDate = response.path("accountList.find{it.accountId.accountNumber=='" + accNum
                + "'}.sourceMarketValue.asOfDate");
        mnemonic = response.path("accountList.find{it.accountId.accountNumber=='" + accNum + "'}.regCode.mnemonic");

    }

    /**
     * Creates a new Workplace account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount() {
        //Setting Exclude external data sources flag
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "true"));
        // Generate request body
        context.put("accountNumber", accNum);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);
        acctRoot = "accountList.find{it.accountId.accountNumber=='" + accNum + "'}.";

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                acctRoot + "accountId.accountNumber", equalTo(accNum),
                acctRoot + "accountId.sourceSystem", equalTo("WORKPLACE"));

        accId = response.path( acctRoot + "accountId.id");

    }

    /**
     * Create Workplace account Details Request.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void createAccountDetails() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accNum);
        context.put("accId", accId);
        context.put("isInherited", false);
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "workplaceAccountDetail");
        context.put("nqdcFixedRateOfReturn", nqdcFixedRateOfReturn);
        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));

        // Call Account service
        response =
                request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
                                + accNum + "'}.workplaceAccountDetail.accountDetail.fidelityAccount",
                        equalTo(true),
                        "accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
                                + accNum
                                + "'}.workplaceAccountDetail.accountDetail.accountId.sourceSystem",
                        equalTo("WORKPLACE"),
                        "accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
                                + accId
                                + "'}.workplaceAccountDetail.nqdcFixedRateOfReturn",
                        equalTo(nqdcFixedRateOfReturn));

    }

    /**
     * Validate the Workplace account details after create.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", sourceSystem);
        context.put("accountNumber", accNum);
        context.put("accId", accId);

        request
                .body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
                                + accNum + "'}.workplaceAccountDetail.accountDetail.fidelityAccount",
                        equalTo(true),
                        "accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
                                + accNum
                                + "'}.workplaceAccountDetail.accountDetail.accountId.sourceSystem",
                        equalTo("WORKPLACE"),
                        "accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
                                + accId
                                + "'}.workplaceAccountDetail.nqdcFixedRateOfReturn",
                        equalTo(nqdcFixedRateOfReturn));

    }

    /**
     * Update the account details for Workplace account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails() {
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", updatedValue);
        context.put("source", sourceSystem);
        context.put("accountNumber", accNum);
        context.put("accId", accId);
        context.put("isInherited", false);
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "workplaceAccountDetail");
        context.put("nqdcFixedRateOfReturn", updatedNqdcFixedRateOfReturn);
        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_UPDATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
                                + accNum + "'}.workplaceAccountDetail.accountDetail.fidelityAccount",
                        equalTo(true),
                        "accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
                                + accNum
                                + "'}.workplaceAccountDetail.accountDetail.accountId.sourceSystem",
                        equalTo("WORKPLACE"),
                        "accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
                                + accId
                                + "'}.workplaceAccountDetail.nqdcFixedRateOfReturn",
                        equalTo(updatedNqdcFixedRateOfReturn));
    }

    /**
     * Validate the updated Workplace account details.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate() {
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", sourceSystem);
        context.put("accountNumber", accNum);
        context.put("accId", accId);

        // Generate request body
        request
                .body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
                                + accNum + "'}.workplaceAccountDetail.accountDetail.fidelityAccount",
                        equalTo(true),
                        "accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
                                + accNum
                                + "'}.workplaceAccountDetail.accountDetail.accountId.sourceSystem",
                        equalTo("WORKPLACE"),
                        "accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
                                + accId
                                + "'}.workplaceAccountDetail.nqdcFixedRateOfReturn",
                        equalTo(updatedNqdcFixedRateOfReturn));
    }

    /**
     * Delete the Workplace account details.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteAccountDetails() {
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", updatedValue);
        context.put("source", sourceSystem);
        context.put("accountNumber", accNum);
        context.put("accId", accId);
        context.put("isInherited", false);
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "WorkplaceAccountDetails");
        context.put("_type", "WorkplaceAccountDetails");
        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_DELETE_V2_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.sourceSystem",
                equalTo("WORKPLACE"), "accountDetails[0].workplaceAccountDetail.accountDetail.fidelityAccount",
                equalTo(true), "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.id",
                Matchers.notNullValue());

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        p2TestDataUtil.closeSQLiteConnection();
    }

}