/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.fullview;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;

/**
 * Tests Account Details V1 for Fullview Account
 * 
 * Updated by a608077 on 10/09/2023 to include 3 new asset classes: Private Equity, Private Credit,
 *  and Real Assets(PFCP-13826)
 *
 * @author a631781
 */
@Test(groups = {Tags.CRITICAL, Tags.FULLVIEW, Tags.CRUD, Tags.V1, Tags.TAM})
public class Fullview_Detail_CriticalTests_V1 extends PAPBaseServiceTest
{

    protected Fullview_Detail_CriticalTests_V1()
    {
	super(Services.Account);
    }

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private String ppid;

    // Test data
    private String accId;

    private String accountNum;

    private String sourceSystem = AccountConstants.FULLVIEW;

    private String displayName;

    private String mnemonic;

    private String institutionName;

    private String asOfDate;

    private VelocityContext context;

    private final float value = 818.89f;

    private final float updatedValue = 426.85f;

    private String accNum;

    private String originalOwnerBirthDate = "1960-11-30T00:00:00.000+0000";

    private String originalOwnerDeceasedDate = "2022-12-30T00:00:00.000+0000";

    private String tamName = "Short Term";

    private String originalOwnerSpouse = "false";

    private String withdrawalEligibilityStartDate = "2020-01-01T00:00:00.000+0000";

    private String withdrawalEligibilityEndDate = "2020-01-01T00:00:00.000+0000";

    private String federalTaxWithholding = "0.7";

    private String stateTaxWithholding = "0.5";

    private String equityPercent = "0.5";

    private String complementaryAdjustmentOption = "NONE";

    private String tamAssetClass = "TOTAL_EQUITY";

    // AssetAllocation
    private String assetClass = "CASH";

    private float netPercentageValue = 1.0f;

    private float netPercentageUpdatedValue = 0.7f;

    private String assetClass_T_Equity = "TOTAL_EQUITY";

    private String foreignEquity = "FOREIGN_EQUITY";

    private String domesticEquity = "DOMESTIC_EQUITY";

    private float netPercentage_T_Equity = 0.8f;

    private float netPercentage_FE = 0.3f;

    private float netPercentage_DE = 0.5f;

    private String assetClass3 = "BOND";

    private String assetClass4 = "OTHER";

    private float netPercentage3 = 0.3f;

    private float netPercentage4 = 0.2f;

    private float netPercentageUpdated3 = 0.5f;

    private float netPercentageUpdated4 = 0.7f;
    
    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";

    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";

    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";

    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";

    private final float netPercentage_T_ALTERNATIVE = 0.8f;

    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;

    private final float netPercentage_PEA = 0.4f;

    private final float netPercentage_Updated_PEA = 0.2f;

    private final float netPercentage_PCA = 0.2f;

    private final float netPercentage_Updated_PCA = 0.3f;

    private final float netPercentage_PRAA = 0.2f;

    private final float netPercentage_Updated_PRAA = 0.1f;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	p2TestDataUtil = new TestDataUtil();

	final String oAuth = AccountUtil.getOauthToken();
	accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_FV, oAuth);
	DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


	ppid = Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth);
	// Data setup
	accountsCommonTestData.setPpid(ppid);

	// Endpoint setup
	setDefaultRequestHeaders(oAuth);

	// Populate request variables
	context = new VelocityContext();
	context.put("mid", accountsCommonTestData.getMid());
	context.put("sid", accountsCommonTestData.getSid());
	context.put("source", sourceSystem);

    }

    /**
     * Tests that account data is brought back for Fullview account.
     * <p>
     * Version V1
     */
    @Test
    public void getFullviewAccountInfo()
    {

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
	// Call Account service v1
	response = request.post(AccountsPaths.GET_ACCOUNT_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

	accountNum = response.path("accountList[0].accountId.accountNumber");
	sourceSystem = response.path("accountList[0].accountId.sourceSystem");
	displayName = response.path("accountList[0].displayName");
	mnemonic = response.path("accountList[0].regCode.mnemonic");

	accountsCommonTestData.setValue1(value);
	institutionName = response.path("accountList[0].institutionName");
	asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");

    }

    /**
     * Creates a new Fullview account
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void createFullviewAccount()
    {
	// Generate request body
	context.put("mid", accountsCommonTestData.getMid());
	context.put("sid", accountsCommonTestData.getSid());
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("mnemonic", mnemonic);
	context.put("value", value);
	context.put("source", sourceSystem);
	context.put("accountNumber", accountNum);
	context.put("displayName", displayName);
	context.put("institutionName", institutionName);
	context.put("asOfDate", asOfDate);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);
	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("accountList", not(empty()));
	accId = response.path("accountList[0].accountId.id");
	accNum = response.path("accountList[0].accountId.accountNumber");
    }

    /**
     * Create FV account Details Request.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createFullviewAccount")
    public void createAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", value);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "FullViewAccountDetails");
	context.put("_type", "FullviewAccountDetails");
	context.put("tamAssetClass", tamAssetClass);
	context.put("assetClass", assetClass);
	context.put("netPercentageValue", netPercentageValue);
	context.put("originalOwnerBirthDate", originalOwnerBirthDate);
	context.put("originalOwnerSpouse", originalOwnerSpouse);
	context.put("originalOwnerDeceasedDate", originalOwnerDeceasedDate);
	context.put("withdrawalEligibilityStartDate", withdrawalEligibilityStartDate);
	context.put("withdrawalEligibilityEndDate", withdrawalEligibilityEndDate);
	context.put("federalTaxWithholding", federalTaxWithholding);
	context.put("stateTaxWithholding", stateTaxWithholding);
	context.put("equityPercent", equityPercent);
	context.put("complementaryAdjustmentOption", complementaryAdjustmentOption);
	context.put("assetClass", assetClass);
	context.put("netPercentageValue", netPercentageValue);
	context.put("assetClass_T_Equity", assetClass_T_Equity);
	context.put("netPercentage_T_Equity", netPercentage_T_Equity);
	context.put("assetClass_FOREIGN_EQUITY", foreignEquity);
	context.put("netPercentage_FE", netPercentage_FE);
	context.put("assetClass_DOMESTIC_EQUITY", domesticEquity);
	context.put("netPercentage_DE", netPercentage_DE);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentage3);
	context.put("assetClass4", assetClass4);
	context.put("netPercentage4", netPercentage4);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE",netPercentage_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA",netPercentage_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA",netPercentage_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA",netPercentage_PRAA);
	context.put("externalDataSources", true);

	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("accountDetails[0].isInherited", equalTo(false))
			.body("accountDetails[0].isPreviousEmployersAccount", equalTo(false))
			.body("accountDetails[0].state", equalTo("NC"))
			.body("accountDetails", notNullValue())
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.targetAssetMixes.targetAssetMix[0].allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.costBasis.value", equalTo(value))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.equityPercent",
					equalTo(Float.valueOf(equityPercent)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerSpouse",
					equalTo(false))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentage3))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentage4))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
							equalTo(netPercentage_FE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_T_ALTERNATIVE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PCA))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PEA))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PRAA));

    }

    /**
     * Validate the FV account details after create.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("accountDetails[0].isInherited", equalTo(false))
			.body("accountDetails[0].isPreviousEmployersAccount", equalTo(false))
			.body("accountDetails[0].state", equalTo("NC"))
			.body("accountDetails", notNullValue())
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.targetAssetMixes.targetAssetMix[0].allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.costBasis.value", equalTo(value))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.equityPercent",
					equalTo(Float.valueOf(equityPercent)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerSpouse",
					equalTo(false))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentage3))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentage4))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
							equalTo(netPercentage_FE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_T_ALTERNATIVE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PCA))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PEA))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_PRAA));
    }

    /**
     * Update the account details for FV account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", updatedValue);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "FullViewAccountDetails");
	context.put("_type", "FullviewAccountDetails");
	context.put("assetClass", assetClass);
	context.put("netPercentageValue", netPercentageValue);
	context.put("assetClass_T_Equity", assetClass_T_Equity);
	context.put("netPercentage_T_Equity", netPercentage_T_Equity);
	context.put("assetClass_FOREIGN_EQUITY", foreignEquity);
	context.put("netPercentage_FE", netPercentage_FE);
	context.put("assetClass_DOMESTIC_EQUITY", domesticEquity);
	context.put("netPercentage_DE", netPercentage_DE);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentageUpdated3);
	context.put("assetClass4", assetClass4);
	context.put("netPercentage4", netPercentageUpdated4);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE",netPercentage_Updated_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA",netPercentage_Updated_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA",netPercentage_Updated_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA",netPercentage_Updated_PRAA);
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("accountDetails[0].isInherited", equalTo(false))
			.body("accountDetails[0].isPreviousEmployersAccount", equalTo(false))
			.body("accountDetails[0].state", equalTo("NC"))
			.body("accountDetails", notNullValue())
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.costBasis.value",
					equalTo(updatedValue))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.equityPercent",
					equalTo(Float.valueOf(equityPercent)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerSpouse",
					equalTo(false))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated3))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated4))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
							equalTo(netPercentage_FE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_T_ALTERNATIVE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PCA))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PEA))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PRAA));

    }

    /**
     * Validate the updated FV account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("accountDetails[0].isInherited", equalTo(false))
			.body("accountDetails[0].isPreviousEmployersAccount", equalTo(false))
			.body("accountDetails[0].state", equalTo("NC"))
			.body("accountDetails", notNullValue())
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.costBasis.value",
					equalTo(updatedValue))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.equityPercent",
					equalTo(Float.valueOf(equityPercent)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.federalTaxWithholding.value",
					equalTo(Float.valueOf(federalTaxWithholding)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.stateTaxWithholding.value",
					equalTo(Float.valueOf(stateTaxWithholding)))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.originalOwnerSpouse",
					equalTo(false))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated3))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated4))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
							equalTo(netPercentage_FE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_T_ALTERNATIVE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PCA))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PEA))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
					equalTo(netPercentage_Updated_PRAA));

    }

    /**
     * Delete the FV account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", updatedValue);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "FullViewAccountDetails");
	context.put("_type", "FullviewAccountDetails");
	// Generate request body
	request
			.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

    }

    /**
     * Validate the manual account was deleted.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccountDetails")
    public void getDetailsAfterDelete()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
			equalTo(true), "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
			"accountDetails[0].costBasis",
			nullValue());

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	p2TestDataUtil.closeSQLiteConnection();
    }
}

