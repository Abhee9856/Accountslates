/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.accountsInGroup.withdrawals;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsWithdrawalsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.GroupsUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDateTime;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;

/**
 * Tests when group call is made to account service: i.e. if there is group id and group type in the request after the call to household identity if we identity that the mid in the request is the partners mid. park all accounts by default under the partner.
 *
 * @author a631781, Story# PFCP-18785
 */
@Test(groups = {
        Tags.REGRESSION,
        Tags.RETAIL,
        Tags.WITHDRAWALS,
        Tags.GROUP,
        Tags.V2})
public class Retail_Withdrawals_Partner_GroupAccount_V2 extends PAPBaseServiceTest {
    protected Retail_Withdrawals_Partner_GroupAccount_V2() {
        super(Services.Account);
    }

    private AccountsCommonTestData accountsCommonTestData;

    //Test data
    private TestDataUtil testDataUtil;
    private String principalMid, partnerMid;
    private String principalSsn, partnerSsn;
    private String product = "WM";
    private String poe = "RETAIL";
    private String groupId;
    private String groupType = "APO_WM";
    private String groupName = "FullviewGroupPartnerTest" + GroupsUtil.generateRandomNumber();
    private int principalId, partnerId;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "WM";
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Fullview_Withdrawals_Partner_GroupAccount_V2.class.getSimpleName() + LocalDateTime.now();
    private static final String FSREQID = LOG_TRACKING_ID;
    //Velocity Context
    private final VelocityContext context = new VelocityContext();
    private String oAuth;
    private String mnemonic;

    private String accountNumber;

    private String accountId;

    private String sourceSystem = "RETAIL";

    private String displayName;

    private float value;

    private String institutionName;

    private String asOfDate;
    private String withdrawalType = "Regular";
    private float withdrawalValue = 30f;
    private String valueType = "MONEY";
    private String frequency = "DAILY";
    FilterableRequestSpecification frs;

    /**
     * Initialization method used to populate the UserIdentifiers object
     * based on the default SSN, set up the endpoint for the test, and
     * build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);
        testDataUtil = new TestDataUtil();
        principalMid = accountsCommonTestData.getMid();
        principalSsn = accountsCommonTestData.getSsn();
        //Partner
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_get_Retail_Reg_Code_I_1", oAuth);
        partnerMid = accountsCommonTestData.getMid();
        partnerSsn = accountsCommonTestData.getSsn();
        //Set default REST header with authorization token
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");

        // Call GET APO and delete any existing groupID
        response = GroupsUtil.getGroupId(oAuth, principalMid, poe, product);
        int getGroupStatus = response.statusCode();
        if (200 == getGroupStatus) {
            String existingGroupId = response.path("groups.find{it.type=='" + groupType + "'}.id");
            GroupsUtil.deleteGroup(existingGroupId, groupType, oAuth, poe);
        }
        //Create group
        response = GroupsUtil.createGroup(oAuth, groupName, principalSsn, partnerSsn, principalMid, partnerMid, poe, product);
        groupId = response.path("groups[0].id");
        // Create Group Household with Partner
        response = GroupsUtil.createHouseholdIdentityWithGroupId(oAuth, principalMid, groupId, groupType, partnerMid, poe, product);
        principalId = response.path("identities.find{it.relationship=='PRINCIPAL'}.planningPartyId");
        partnerId = response.path("identities.find{it.relationship=='PARTNER'}.planningPartyId");
        // Set request header
        request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", partnerSsn))
                .header(new Header("user-mid", partnerMid))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("user-group-type", groupType))
                .header(new Header("user-group-id", groupId))
                .header(new Header("excludeExternalDataSources", "false"));
        frs = (FilterableRequestSpecification) request;
    }

    /**
     * Get account info from the backend. Save the account number.
     */
    @Test
    public void getAccountInfo() {
        // Generate request body
        context.put("source", sourceSystem);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Create a Account in FPPD
     */
    @Test(dependsOnMethods = "getAccountInfo")
    public void createRetailAccount() {
        frs.removeHeader("excludeExternalDataSources");
        request.given().header(new Header("excludeExternalDataSources", "true"));
        // Generate request body
        context.put("relationShip", "PARTNER");
        context.put("ppid", partnerId);
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList[0].regCode.mnemonic",
                equalTo(mnemonic), "accountList[0].accountId.accountNumber", equalTo(accountNumber));

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        context.put("accId", accountId);
    }

    /**
     * Create the account withdrawals.
     */
    @Test(dependsOnMethods = "createRetailAccount")
    public void createAccountWithdrawals() {
        // Generate request body
        context.put("relationship", "PARTNER");
        context.put("withdrawalType", withdrawalType);
        context.put("withdrawalValue", withdrawalValue);
        context.put("valueType", valueType);
        context.put("frequency", frequency);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_V2_TEMPLATE))
                .log().ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()))
                .body("accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.withdrawalType", equalTo(withdrawalType),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.amount.amount.value", equalTo(withdrawalValue),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.amount.frequency", equalTo(frequency),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.accountId.owner.relationship", equalTo("PARTNER"),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.accountId.owner.id", equalTo(String.valueOf(partnerId)));

    }

    /**
     * Validate the withdrawals.
     */
    @Test(dependsOnMethods = "createAccountWithdrawals")
    public void getWithdrawalsAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.withdrawalType", equalTo(withdrawalType),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.amount.amount.value", equalTo(withdrawalValue),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.amount.frequency", equalTo(frequency),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.accountId.owner.relationship", equalTo("PARTNER"),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.accountId.owner.id", equalTo(String.valueOf(partnerId)));

    }

    /**
     * Delete GroupID
     */
    @AfterClass(alwaysRun = true)
    public void deleteGroupId() {
        GroupsUtil.deleteGroup(groupId, groupType, oAuth, poe);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
