/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.retail;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.equalTo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.constants.TestDataConstants;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

/**
 * Tests for v1 CRUD operations for Retail accounts using DataProvider (for
 * handling multiple regCodes).
 *
 * @author a601767
 */
@Test(groups = {
		Tags.PIPELINE,
		Tags.ASYNCHRONOUS,
		Tags.RETAIL,
		Tags.ACCOUNT,
		Tags.V1})
public class Retail_CRUD_V1RegCodesWithNBPoe extends PAPBaseServiceTest
{

    Logger logger = LogManager.getLogger(getClass());

    protected Retail_CRUD_V1RegCodesWithNBPoe()
    {
	super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private final float updatedValue = 426.85f;

    private String mid;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private final Map<String, String> accIdRegCodeMap = new HashMap<>();

    private final Map<String, String> accNumberRegCodeMap = new HashMap<>();

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();
	accountsCommonTestData =
			TestDataUtil.populateRegressionTestData("retail_critical_regcode", oAuth);
	testDataUtil = new TestDataUtil();

	this.mid = this.accountsCommonTestData.getMid();
	this.accountsCommonTestData.setMid(this.mid);
	String asOfDate1 = "2014-10-31";
	accountsCommonTestData.setAsOfDate1(asOfDate1);
	float value = 120.0F;
	accountsCommonTestData.setValue1(value);
	DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


	accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

	setDefaultRequestHeaders(oAuth);

	// Populate request variables
	context = new VelocityContext();
	context.put("mid", accountsCommonTestData.getMid());
	context.put("retailLid", accountsCommonTestData.getSsn());
	context.put("poe", TestDataConstants.POE_NB);
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", String.valueOf(value));

    }

    /**
     * Get account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo()
    {
	String source = "RETAIL";
	context.put("source", source);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
	response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	response.then().log().ifValidationFails()
			.body("userIdentifier.pointOfEntry", equalTo(TestDataConstants.POE_NB));
	accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));

	List<Map<String, String>> acctResponse = response.jsonPath().getList("accountList");
	for (int i = 0; i < acctResponse.size(); i++)
	{
	    String accRegCode = response.path("accountList[" + i + "].regCode.mnemonic").toString();
	    String accNumber = response.path("accountList[" + i + "].accountId.accountNumber");
	    accNumberRegCodeMap.put(accRegCode, accNumber);
	}

	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
	accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));

	if (null != (response.path("accountList[0].sourceMarketValue")))
	{
	    accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
	    accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
	}

	accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));

    }

    /**
     * Create the account.
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getRetailAccountRegCode", dataProviderClass = AccountsRegCodesDataProviderUtil.class,
		    dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount(final AccountRegCodeTestData data)
    {
	context.put("mnemonic", data.getRegCode1());
	context.put("source", data.getSrcFilter());
	if (null != accNumberRegCodeMap.get(data.getRegCode1()))
	{
	    context.put("accountNumber", accNumberRegCodeMap.get(data.getRegCode1()));
	}
	else
	{
	    context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	}
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("userIdentifier.pointOfEntry", equalTo(TestDataConstants.POE_NB));

	// Gets and saves the CFP account ID
	accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
	String accId = response.path("accountList[0].accountId.id");
	if (null != accId)
	{
	    accIdRegCodeMap.put(data.getRegCode1(), accId);
	}
	logger.info("AccountID Map : " + accIdRegCodeMap.toString());
    }

    /**
     * Validate the account.
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getRetailAccountRegCode", dataProviderClass = AccountsRegCodesDataProviderUtil.class,
		    dependsOnMethods = "createRetailAccount")
    public void getRetailAccountAfterCreate(final AccountRegCodeTestData data)
    {
	// Exclude external data sources
	context.put("mnemonicFilter", data.getRegCode1());
	context.put("externalDataSources", "true");
	context.put("source", data.getSrcFilter());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
			equalTo(true),
			"userIdentifier.pointOfEntry", equalTo(TestDataConstants.POE_NB));

	if (CollectionUtils.isNotEmpty(response.path("accountList"))
			&& (response.jsonPath().getList("accountList").size() > 0))
	{

	    if (null != response.path("accountList[0].accountId.id"))
	    {
		response.then().body("accountList[0].accountId", notNullValue())
				.body("accountList[0].accountId.owner.id", notNullValue())
				.body("accountList[0].accountId.accountNumber", notNullValue(),
						"accountList[0].accountId.accountNumber",
						equalTo(accNumberRegCodeMap.get(data.getRegCode1())),
						"accountList[0].accountId.id", notNullValue())
				.body("accountList[0].regCode.mnemonic", Matchers
						.isOneOf(data.getRegCode1(), data.getRegCode2(), data.getRegCode3()));
	    }
	}

    }

    /**
     * Update the account
     */
    @Test(dataProvider = "getRetailAccountRegCode", dataProviderClass = AccountsRegCodesDataProviderUtil.class,
		    dependsOnMethods = "getRetailAccountAfterCreate")
    public void updateRetailAccount(final AccountRegCodeTestData data)
    {
	// Change the amount of the account
	context.put("source", data.getSrcFilter());
	context.put("accId", accIdRegCodeMap.get(data.getRegCode1()));
	context.put("value", updatedValue);

	context.put("mnemonic", data.getRegCode1());
	if (null != accNumberRegCodeMap.get(data.getRegCode1()))
	{
	    context.put("accountNumber", accNumberRegCodeMap.get(data.getRegCode1()));
	}
	else
	{
	    context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	}
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("userIdentifier.pointOfEntry", equalTo(TestDataConstants.POE_NB));

    }

    /**
     * Validate the updated account.
     */
    @Test(dataProvider = "getRetailAccountRegCode", dataProviderClass = AccountsRegCodesDataProviderUtil.class,
		    dependsOnMethods = "updateRetailAccount")
    public void getRetailAccountAfterUpdate(final AccountRegCodeTestData data)
    {
	// We don't want to filter by source here
	context.put("mnemonicFilter", data.getRegCode1());
	context.put("externalDataSources", "true");
	context.put("source", data.getSrcFilter());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
			equalTo(true),
			"userIdentifier.pointOfEntry", equalTo(TestDataConstants.POE_NB));
	if (CollectionUtils.isNotEmpty(response.path("accountList"))
			&& (response.jsonPath().getList("accountList").size() > 0))
	{
	    response.then().body("accountList[0].accountId", notNullValue())
			    .body("accountList[0].accountId.owner.id", notNullValue())
			    .body("accountList[0].accountId.accountNumber", notNullValue(),
					    "accountList[0].accountId.accountNumber",
					    equalTo(accNumberRegCodeMap.get(data.getRegCode1())),
					    "accountList[0].accountId.id",
					    equalTo(accIdRegCodeMap.get(data.getRegCode1())))
			    .body("accountList[0].regCode.mnemonic", Matchers
					    .isOneOf(data.getRegCode1(), data.getRegCode2(), data.getRegCode3()));
	}

    }

    /**
     * Delete the account.
     */

    @Test(dataProvider = "getRetailAccountRegCode", dataProviderClass = AccountsRegCodesDataProviderUtil.class,
		    dependsOnMethods = "getRetailAccountAfterUpdate")

    public void deleteRetailAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("source", data.getSrcFilter());
	context.put("value", updatedValue);

	context.put("mnemonic", data.getRegCode1());
	context.put("accId", accIdRegCodeMap.get(data.getRegCode1()));
	if (null != accNumberRegCodeMap.get(data.getRegCode1()))
	{
	    context.put("accountNumber", accNumberRegCodeMap.get(data.getRegCode1()));
	}
	else
	{
	    context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	}
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

	// Call Account service response =
	request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.pointOfEntry", equalTo(TestDataConstants.POE_NB));

    }

    /**
     * Validate the account was deleted.
     * <p>
     * Version V1
     */

    @Test(dataProvider = "getRetailAccountRegCode", dataProviderClass = AccountsRegCodesDataProviderUtil.class, dependsOnMethods = "deleteRetailAccount")
    public void getRetailAccountAfterDelete(final AccountRegCodeTestData data)
    {

	context.put("mnemonicFilter", data.getRegCode1());
	context.put("source", data.getSrcFilter());
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	// Call Account service response =
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
			equalTo(true), "accountList", Matchers.empty(),
			"userIdentifier.pointOfEntry", equalTo(TestDataConstants.POE_NB));

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}
