/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;

import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.Matchers.*;

/**
 * Tests for transferType for v1 CRUD operations for Composite Retail Target accounts using DataProvider
 * @author a631781
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.TARGET_ACCOUNT,
		Tags.COMPOSITE,
		Tags.V1})
public class Retail_Composite_TargetAccount_TransferType_V1 extends PAPBaseServiceTest
{

    protected Retail_Composite_TargetAccount_TransferType_V1()
    {
	super(Services.Account);
    }

    //Context
    private VelocityContext context;

    int startYear = ZonedDateTime.now().plusYears(1).getYear();

    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    private final float fundingAccountAmount = 5.55f;

    private final float updatedFundingAccountAmount = 6.78f;

    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";

    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";

    private static final String isProductSuitable = "true";

    private static final String isProductSuitableUpdate = "false";

    private AccountsCommonTestData accountsCommonTestData;

    private TestDataUtil testDataUtil;

    private static String mid;

    private String acctRoot;

    private static final String LOG_TRACKING_ID = Retail_Composite_withTargetAccount.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private final float unknownAmount = 20.0f;

    private final float updatedUnknownAmount = 26.0f;


    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init()
    {
	String oAuth = AccountUtil.getOauthToken();
	testDataUtil = new TestDataUtil();

	accountsCommonTestData =
			TestDataUtil.populateRegressionTestData("retail_critical_regcode", oAuth);
	mid = accountsCommonTestData.getMid();

        //Data setup
	accountsCommonTestData.set("updatedAmount", "15000.0");
	accountsCommonTestData.set("contribFreq", "YEARLY");
	accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
	accountsCommonTestData.set("contribAmount", "6000.0");
	accountsCommonTestData.set("updatedContribAmount", "500.0");
	accountsCommonTestData.set("withdrawAmount", "500.0");
	accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
	accountsCommonTestData.set("withdrawFreq", "YEARLY");
	accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
	accountsCommonTestData.set("detailValue", "42619.85");
	accountsCommonTestData.set("updatedDetailValue", "81819.89");

	DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


	accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	// Populate common variables for tests into context
	context = new VelocityContext();
	context.put("retailLid", accountsCommonTestData.getSsn());
	context.put("mid", accountsCommonTestData.getMid());
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("source", "RETAIL");
    }

    /**
     * Create Retail account with different combination of Regcodes from DataProvider.
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getRetailAccountData",
		    dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data)
    {
	this.getRetailAccountInfo(data);
	this.getCompositeAccount(data);
	this.createCompositeAccount(data);
	this.createTargetAccount(data);
	this.getCompositeAccountAfterCreate(data);
	this.updateTargetAccount(data);
	this.updateCompositeAccount(data);
	this.getCompositeAccountAfterUpdate(data);
	this.deleteCompositeAccount(data);
	this.deleteTargetAccount(data);
	this.getCompositeAccountAfterDelete(data);
    }

    /**
     * Get retail account info from the backend. Save the account number.
     */
    private void getRetailAccountInfo(final AccountRegCodeTestData data)
    {	// Exclude external data
        context.put("externalDataSources", "false");
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountList", not(empty()));

	accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
	accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
	accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
	accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
	accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V1
     */
    private void getCompositeAccount(final AccountRegCodeTestData data)
    {
	// Exclude external data
	context.put("externalDataSources", "true");

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", empty());

    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V1
     */
    private void createCompositeAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
        context.put("accId", "");
        String accNum = accountsCommonTestData.getAccountNumber1();
	acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accountNumber", accNum);
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
	context.put("contribValue", accountsCommonTestData.get("contribAmount"));
	context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
	context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
	context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
	context.put("detailValue", accountsCommonTestData.get("detailValue"));
	context.put("_type", AccountConstants.RETAIL_ACCOUNT_DETAILS_TYPE);
	context.put("type", AccountConstants.RETAIL_ACCOUNT_DETAILS);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

	// Make post request
	response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("userIdentifier.mid", equalTo(mid));

	//Save account number and ID
	accountsCommonTestData.setAccountId1(response.path(acctRoot + "account.accountId.id"));
    }

    /**
     * Create target account
     */
    private void createTargetAccount(final AccountRegCodeTestData data)
    {
	context.remove("displayName");
	context.put("targetAccountNumber", "");
	context.put("targetAccountId", "");
	context.put("targetAccountSourceSystem", accountsCommonTestData.getSourceSystem1());
	context.put("targetAccountPpid", accountsCommonTestData.getPpid());
	context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("fundingAccountValue", String.valueOf(fundingAccountAmount));
	context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
	context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
	context.put("category", "INVESTOR_SELECTED_STRATEGY");
	context.put("withdrawalStartYear", startYear);
	context.put("withdrawalEndYear", endYear);
	context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
	context.put("riskTolerance", "8");
	context.put("withdrawalNeeds", "TIME_TO_TIME_WITHDRAWAL_LESS_THAN_EQUAL_TO_6");
	context.put("isProductSuitable", isProductSuitable);
	context.put("unknownAmount", String.valueOf(unknownAmount));
	context.put("transferType", data.getTransferType());
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("targetAccounts", not(empty()),
					"targetAccounts[0].sourceMarketValue.amount.value",
					equalTo(fundingAccountAmount),
					"targetAccounts[0].displayName", equalTo("NewTargetAccount"),
					"targetAccounts[0].accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"targetAccounts[0].fundingAccounts[0].transferType",
					equalTo(data.getTransferType()),
					"targetAccounts[0].complementaryAdjustmentOption",
					equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"),
					"targetAccounts[0].isProductSuitable",
					equalTo(Boolean.valueOf(isProductSuitable)),
					"targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount),
					"targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
					equalTo("TIME_TO_TIME_WITHDRAWAL_LESS_THAN_EQUAL_TO_6"),
					"targetAccounts[0].targetAssetMixes[0].category",
					equalTo("INVESTOR_SELECTED_STRATEGY"));

	accountsCommonTestData
			.set(TARGET_ACCOUNT_NUMBER_KEY, response.path("targetAccounts[0].accountId.accountNumber"));
	accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V1
     */
    private void getCompositeAccountAfterCreate(final AccountRegCodeTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body(acctRoot + "account.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()),
					acctRoot + "account.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					acctRoot + "account.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()),
					acctRoot + "account.displayName",
					equalTo(accountsCommonTestData.getDisplayName1()),
					acctRoot + "account.regCode.mnemonic",
					equalTo(accountsCommonTestData.getMnemonic1()),
					acctRoot + "account.regCode.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					acctRoot + "account.institutionName",
					equalTo(accountsCommonTestData.getInstitutionName1()),
					acctRoot + "account.sourceMarketValue.amount.value",
					equalTo(accountsCommonTestData.getValue1()),
					acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							+ ".assetClass='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(0f),
					acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							+ ".assetClass='BOND'}.netPercentage.value",
					equalTo(0f),
					acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							+ ".assetClass='CASH'}.netPercentage.value",
					equalTo(0f),
					acctRoot + "suitability.investmentObjective.targetAssetMix.name",
					equalTo("Short Term"),
					acctRoot + "contributions.contributions[0].contribution.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("contribAmount"))),
					acctRoot + "contributions.contributions[0].frequency",
					equalTo(accountsCommonTestData.get("contribFreq")),
					acctRoot + "withdrawals[0].amount.amount.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
					acctRoot + "withdrawals[0].amount.frequency",
					equalTo(accountsCommonTestData.get("withdrawFreq")),
					"targetAccounts", not(empty()),
					"targetAccounts[0].sourceMarketValue.amount.value",
					equalTo(fundingAccountAmount),
					"targetAccounts[0].displayName", equalTo("NewTargetAccount"),
					"targetAccounts[0].accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount),
					"targetAccounts[0].fundingAccounts[0].transferType",
					equalTo(data.getTransferType()),
					"targetAccounts[0].complementaryAdjustmentOption",
					equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"),
					"targetAccounts[0].isProductSuitable",
					equalTo(Boolean.valueOf(isProductSuitable)),
					"targetAccounts[0].targetAssetMixes[0].category",
					equalTo("INVESTOR_SELECTED_STRATEGY"));
    }

    /**
     * Update target account
     */
    private void updateTargetAccount(final AccountRegCodeTestData data)
    {
	context.put("fundingAccountValue", String.valueOf(updatedFundingAccountAmount));
	context.put("targetAccountSourceMarketValue", String.valueOf(updatedFundingAccountAmount));
	context.put(TARGET_ACCOUNT_NUMBER_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
	context.put(TARGET_ACCOUNT_ID_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
	context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
	context.put("category", "FINAL");
	context.put("isProductSuitable", isProductSuitableUpdate);
	context.put("unknownAmount", String.valueOf(updatedUnknownAmount));
	context.put("transferType", data.getTransferType());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("targetAccounts", not(empty()),
					"targetAccounts[0].sourceMarketValue.amount.value",
					equalTo(updatedFundingAccountAmount),
					"targetAccounts[0].displayName", equalTo("NewTargetAccount"),
					"targetAccounts[0].accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"targetAccounts[0].fundingAccounts[0].transferType",
					equalTo(data.getTransferType()),
					"targetAccounts[0].complementaryAdjustmentOption",
					equalTo("MOVE_TO_MANAGED_ACCOUNT"),
					"targetAccounts[0].isProductSuitable",
					equalTo(Boolean.valueOf(isProductSuitableUpdate)),
					"targetAccounts[0].fundingAccounts[0].unknownAmount",
					equalTo(updatedUnknownAmount),
					"targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"));

    }

    /**
     * Runs an update on the new account and verifies content in the response.
     * <p>
     * Version V1
     */
    private void updateCompositeAccount(final AccountRegCodeTestData data)
    {
	// Populate variables for tests into context
	context.remove("displayName");
	context.put("value", accountsCommonTestData.get("updatedAmount"));
	context.put("contribFreq", accountsCommonTestData.get("updatedContribFreq"));
	context.put("contribValue", accountsCommonTestData.get("updatedContribAmount"));
	context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
	context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
	context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("accId", accountsCommonTestData.getAccountId1());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE));

	// Make post request
	response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("userIdentifier.mid", equalTo(mid));
    }

    /**
     * Gets the composite accounts and verifies that content is still coming back.
     * <p>
     * Version V1
     */
    private void getCompositeAccountAfterUpdate(final AccountRegCodeTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body(acctRoot + "account.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()),
					acctRoot + "account.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					acctRoot + "account.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()),
					acctRoot + "account.displayName",
					equalTo(accountsCommonTestData.getDisplayName1()),
					acctRoot + "account.regCode.mnemonic",
					equalTo(accountsCommonTestData.getMnemonic1()),
					acctRoot + "account.regCode.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					acctRoot + "account.institutionName",
					equalTo(accountsCommonTestData.getInstitutionName1()),
					acctRoot + "account.sourceMarketValue.amount.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
					acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							+ ".assetClass='TOTAL_EQUITY'}.netPercentage.value",
					equalTo(0f),
					acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							+ ".assetClass='BOND'}.netPercentage.value",
					equalTo(0f),
					acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
							+ ".assetClass='CASH'}.netPercentage.value",
					equalTo(0f),
					acctRoot + "suitability.investmentObjective.targetAssetMix.name",
					equalTo("Short Term"),
					acctRoot + "contributions.contributions[0].contribution.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("updatedContribAmount"))),
					acctRoot + "contributions.contributions[0].frequency",
					equalTo(accountsCommonTestData.get("updatedContribFreq")),
					acctRoot + "withdrawals[0].amount.amount.value",
					equalTo(Float.valueOf(accountsCommonTestData.get("updatedWithdrawAmount"))),
					acctRoot + "withdrawals[0].amount.frequency",
					equalTo(accountsCommonTestData.get("updatedWithdrawFreq")),
					"targetAccounts", not(empty()),
					"targetAccounts[0].sourceMarketValue.amount.value",
					equalTo(updatedFundingAccountAmount),
					"targetAccounts[0].displayName", equalTo("NewTargetAccount"),
					"targetAccounts[0].accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"targetAccounts[0].fundingAccounts[0].unknownAmount",
					equalTo(updatedUnknownAmount),
					"targetAccounts[0].fundingAccounts[0].transferType",
					equalTo(data.getTransferType()),
					"targetAccounts[0].complementaryAdjustmentOption",
					equalTo("MOVE_TO_MANAGED_ACCOUNT"),
					"targetAccounts[0].isProductSuitable",
					equalTo(Boolean.valueOf(isProductSuitableUpdate)),
					"targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"));
    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V1
     */
    private void deleteCompositeAccount(final AccountRegCodeTestData data)
    {  // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
		        .statusCode(AccountConstants.HTTP_200)
		        .body("targetAccounts", empty());
    }

    /**
     * Delete target account
     */
    private void deleteTargetAccount(final AccountRegCodeTestData data)
    {

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("targetAccounts", empty());
    }

    /**
     * Call delete and confirm that no accounts come back in the response.
     * <p>
     * Version V1
     */
    private void getCompositeAccountAfterDelete(final AccountRegCodeTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", empty());
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}
