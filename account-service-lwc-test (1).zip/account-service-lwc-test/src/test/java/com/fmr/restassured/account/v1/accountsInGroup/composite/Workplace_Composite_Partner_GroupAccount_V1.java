/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.v1.accountsInGroup.composite;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.GroupsUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;

/**
 * Tests when group call is made to account service: i.e. if there is group id and group type in the request after the call to household identity if we identity that the mid in the request is the partners mid. park all accounts by default under the partner.
 *
 * @author a631781, Story# PFCP-18785
 */
@Test(groups = {
        Tags.REGRESSION,
        Tags.WORKPLACE,
        Tags.COMPOSITE,
        Tags.GROUP,
        Tags.V1})
public class Workplace_Composite_Partner_GroupAccount_V1 extends PAPBaseServiceTest {

    protected Workplace_Composite_Partner_GroupAccount_V1() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private TestDataUtil testDataUtil;
    private String principalMid, partnerMid;
    private String principalSsn, partnerSsn;
    private String product = "WM";
    private String poe = "RETAIL";
    private String groupId;
    private String groupType = "APO_WM";
    private String groupName = "WorkplaceCompositeGroupPartnerTest" + GroupsUtil.generateRandomNumber();
    private int principalId, partnerId;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "WM";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    //Velocity Context
    private final VelocityContext context = new VelocityContext();
    private String oAuth;

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID for principal and Partner.
     * </br>2. Set the Group and Group Household
     * </br>3. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init() {
        oAuth = AccountUtil.getOauthToken();
        // Get Principal's Mid
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_get_Workplace_Reg_Code_457F_80", oAuth);
        testDataUtil = new TestDataUtil();
        principalMid = accountsCommonTestData.getMid();
        principalSsn = accountsCommonTestData.getSsn();
        // Get Partner's Mid
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Workplace_69", oAuth);
        partnerMid = accountsCommonTestData.getMid();
        partnerSsn = accountsCommonTestData.getSsn();

        //Set default REST header with authorization token
        setDefaultRequestHeaders(oAuth);
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", principalMid, oAuth, "true");

        //Get APO call and Delete existing groupId for the user
        response = GroupsUtil.getGroupId(oAuth, principalMid, poe, product);
        int getGroupStatus = response.statusCode();
        if (200 == getGroupStatus) {
            String existingGroupId = response.path("groups.find{it.type=='" + groupType + "'}.id");
            GroupsUtil.deleteGroup(existingGroupId, groupType, oAuth, poe);
        }
        //Crate group
        response = GroupsUtil.createGroup(oAuth, groupName, principalSsn, partnerSsn, principalMid, partnerMid, poe, product);
        groupId = response.path("groups[0].id");
        // Create Group Household with Partner
        response = GroupsUtil.createHouseholdIdentityWithGroupId(oAuth, principalMid, groupId, groupType, partnerMid, poe, product);
        principalId = response.path("identities.find{it.relationship=='PRINCIPAL'}.planningPartyId");
        partnerId = response.path("identities.find{it.relationship=='PARTNER'}.planningPartyId");
    }

    /**
     * Get composite Workplace account info for Partner and validate owner relationship and ID are of partner.
     */
    @Test
    public void getWorkplaceCompositePartnerAccount() {
        // Populate request variables
        context.put("mid", partnerMid);
        context.put("fescoLid", partnerSsn);
        context.put("source", AccountConstants.WORKPLACE);
        context.put("groupId", groupId);
        context.put("groupType", groupType);
        context.put("externalDataSources", false);
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts[0].account.accountId.owner.relationship",
                        equalTo("PARTNER"),
                        "accounts[0].account.accountId.owner.id",
                        equalTo(String.valueOf(partnerId)),
                        "accounts[0].details.accountId.owner.relationship",
                        equalTo("PARTNER"),
                        "accounts[0].details.accountId.owner.id",
                        equalTo(String.valueOf(partnerId)));
    }

    /**
     * Delete GroupID
     */
    @Test(dependsOnMethods = "getWorkplaceCompositePartnerAccount")
    public void deleteGroupId() {
        GroupsUtil.deleteGroup(groupId, groupType, oAuth, poe);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
