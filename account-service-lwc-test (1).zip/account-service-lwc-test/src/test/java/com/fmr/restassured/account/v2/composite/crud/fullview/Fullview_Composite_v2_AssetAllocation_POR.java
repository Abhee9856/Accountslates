/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.fullview;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;

/**
 * Tests Account Composite operation for a Fullview account with asset allocation in details.
 * Test will create, update, and delete a composite account and
 * run get requests before and after each of those operations.
 *
 * Updated by a608077 on 10/24/2023 to include 3 new asset classes: Private Equity, Private Credit,
 *  and Real Assets for POR/WM scenario with EEDS=true(PFCP-13827)
 *
 * @author a608077
 */
@Test(groups = {Tags.REGRESSION, Tags.FULLVIEW, Tags.COMPOSITE, Tags.V2})
public class Fullview_Composite_v2_AssetAllocation_POR extends PAPBaseServiceTest {
    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Fullview_Composite_v2_AssetAllocation_POR.class);

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;
    private VelocityContext context;
    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountsCommonTestData;
    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;
    /**
     * Financial Instrument IDs and their symbols
     */
    private FinancialInstrumentIds finstIds;

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Fullview_Composite_v2_AssetAllocation_POR.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String SCENARIO_PRODUCT_CODE="WM";
    private static final String SCENARIO_CATEGORY_CODE="POR";

    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
    private final float netPercentage_T_ALTERNATIVE = 0.8f;
    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
    private final float netPercentage_PEA = 0.4f;
    private final float netPercentage_Updated_PEA = 0.2f;
    private final float netPercentage_PCA = 0.2f;
    private final float netPercentage_Updated_PCA = 0.3f;
    private final float netPercentage_PRAA = 0.2f;
    private final float netPercentage_Updated_PRAA = 0.1f;
    private String acctRoot, scenarioId;
    private final String details = "details.fullviewAccountDetail.";
    
    protected Fullview_Composite_v2_AssetAllocation_POR() {
        super(Services.Account);
    }

    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {
        /*
          Global variable holding the oAuth token generated in the initClass method
         */
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();

        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Fullview", oAuth);

        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");

        
     // Create Principal
        Identity.createPrincipal(accountsCommonTestData.getMid(), oAuth);
        //Create Scenario
        scenarioId = Scenario.createScenarioWithProductCode(this.accountsCommonTestData.getMid(),
                SCENARIO_PRODUCT_CODE,SCENARIO_CATEGORY_CODE,oAuth);

        //Insert Household Identity
        this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentityWithProductCode(accountsCommonTestData.getMid(),
                oAuth,SCENARIO_PRODUCT_CODE,SCENARIO_CATEGORY_CODE));
     
        // Resolve finstIds
        this.finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

        this.request.header(new Header("user-poe", "RETAIL"))
        	.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
        	.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
        	.header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("user-sid", this.accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()))
                .header(new Header("scenario-id", scenarioId));

        context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", "FULLVIEW");

        this.accountsCommonTestData.set("updatedAmount", "15000.0");
        this.accountsCommonTestData.set("contribFreq", "YEARLY");
        this.accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        this.accountsCommonTestData.set("contribAmount", "6000");
        this.accountsCommonTestData.set("updatedContribAmount", "500");
        this.accountsCommonTestData.set("withdrawAmount", "500");
        this.accountsCommonTestData.set("updatedWithdrawAmount", "1000");
        this.accountsCommonTestData.set("withdrawFreq", "YEARLY");
        this.accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
        this.accountsCommonTestData.set("detailValue", "42619.85");
        this.accountsCommonTestData.set("updatedDetailValue", "81819.89");
        this.accountsCommonTestData.set("emergencyFundAmountValue", "111111.11");
        this.accountsCommonTestData.set("updatedEmergencyFundAmountValue", "211111.11");

    }

    @Test
    public void getCompositeAccountFullviewV2BeforeCreate() {
        // Retrieve fullview test data
        this.accountsCommonTestData = getFullviewAccountInformationV2(this.accountsCommonTestData, this.oAuth);

        assert this.accountsCommonTestData != null;

        this.request.header(new Header("excludeExternalDataSources", "true"));

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        this.response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts", hasSize(0));

    }

    @Test(dependsOnMethods = "getCompositeAccountFullviewV2BeforeCreate")
    public void createCompositeAccountFullviewV2() {
	    
	String accNum = accountsCommonTestData.getAccountNumber1();
	    
        // Generate request body
        context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
        context.put("source", this.accountsCommonTestData.getSourceSystem1());
        context.put("ppid", this.accountsCommonTestData.getPpid());
        context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", this.accountsCommonTestData.getSourceSystem1());
        context.put("value", this.accountsCommonTestData.getValue1());
        context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        context.put("contribValue", this.accountsCommonTestData.get("contribAmount"));
        context.put("withdrawAmount", this.accountsCommonTestData.get("withdrawAmount"));
        context.put("contribFreq", this.accountsCommonTestData.get("contribFreq"));
        context.put("withdrawFreq", this.accountsCommonTestData.get("withdrawFreq"));
        context.put("detailValue", this.accountsCommonTestData.get("detailValue"));
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.177);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.0f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_PRAA);
        context.put("emergencyFundAmountValue", this.accountsCommonTestData.get("emergencyFundAmountValue"));
        context.put("GDSTOCK", this.finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", this.finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", this.finstIds.getFinstId("GBOND"));
        context.put("GCASH", this.finstIds.getFinstId("GCASH"));


        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
        
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));
        // Make post request
        this.response = this.request.log().ifValidationFails()
                .post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", notNullValue())
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(this.accountsCommonTestData.getAccountNumber1()))
                .body("accounts[0].account.accountId.sourceSystem",
                        equalTo(this.accountsCommonTestData.getSourceSystem1()))
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()))
                .body("accounts[0].account.regCode.mnemonic",
                        equalTo(this.accountsCommonTestData.getMnemonic1()))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(this.accountsCommonTestData.getValue1()))
                .body("accounts[0].details", notNullValue())
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.emergencyFundAmount.value",
                        equalTo(Float.valueOf(
                                this.accountsCommonTestData.get("emergencyFundAmountValue"))))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PRAA))
                .body("accounts[0].contributions", notNullValue())
                .body("accounts[0].contributions.contributions[0].contribution.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("contribAmount"))))
                .body("accounts[0].contributions.contributions[0].frequency",
                        equalTo(this.accountsCommonTestData.get("contribFreq")))
                .body("accounts[0].suitability", notNullValue())
                .body("accounts[0].withdrawals", notNullValue())
                .body("accounts[0].withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("withdrawAmount"))))
                .body("accounts[0].withdrawals[0].amount.frequency",
                        equalTo(this.accountsCommonTestData.get("withdrawFreq")));

        this.accountsCommonTestData.setAccountId1(this.response.jsonPath().getString("accounts[0].account.accountId.id"));
    }

    @Test(dependsOnMethods = "createCompositeAccountFullviewV2")
    public void getCompositeAccountFullviewV2AfterCreate() {
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", notNullValue())
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(this.accountsCommonTestData.getAccountNumber1()))
                .body("accounts[0].account.accountId.sourceSystem",
                        equalTo(this.accountsCommonTestData.getSourceSystem1()))
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()))
                .body("accounts[0].account.regCode.mnemonic",
                        equalTo(this.accountsCommonTestData.getMnemonic1()))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(this.accountsCommonTestData.getValue1()))
                .body("accounts[0].details", notNullValue())
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.emergencyFundAmount.value",
                        equalTo(Float.valueOf(
                                this.accountsCommonTestData.get("emergencyFundAmountValue"))))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PRAA))
                .body("accounts[0].contributions", notNullValue())
                .body("accounts[0].contributions.contributions[0].contribution.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("contribAmount"))))
                .body("accounts[0].contributions.contributions[0].frequency",
                        equalTo(this.accountsCommonTestData.get("contribFreq")))
                .body("accounts[0].suitability", notNullValue())
                .body("accounts[0].withdrawals", notNullValue())
                .body("accounts[0].withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("withdrawAmount"))))
                .body("accounts[0].withdrawals[0].amount.frequency",
                        equalTo(this.accountsCommonTestData.get("withdrawFreq")));
    }

    @Test(dependsOnMethods = "getCompositeAccountFullviewV2AfterCreate")
    public void updateCompositeAccountFullviewV2() {
        // Generate request body
        context.put("accId", this.accountsCommonTestData.getAccountId1());
        context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
        context.put("source", this.accountsCommonTestData.getSourceSystem1());
        context.put("ppid", this.accountsCommonTestData.getPpid());
        context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", this.accountsCommonTestData.getSourceSystem1());
        context.put("value", this.accountsCommonTestData.get("updatedAmount"));
        context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        context.put("contribValue", this.accountsCommonTestData.get("updatedContribAmount"));
        context.put("withdrawAmount", this.accountsCommonTestData.get("updatedWithdrawAmount"));
        context.put("contribFreq", this.accountsCommonTestData.get("updatedContribFreq"));
        context.put("withdrawFreq", this.accountsCommonTestData.get("updatedWithdrawFreq"));
        context.put("detailValue", this.accountsCommonTestData.get("updatedDetailValue"));
        context.put("emergencyFundAmountValue", this.accountsCommonTestData.get("updatedEmergencyFundAmountValue"));
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.4f);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 1.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.70f);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.30f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_Updated_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_Updated_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));

        // Make post request
        this.response = this.request.log().ifValidationFails()
                .post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", equalTo(this.accountsCommonTestData.getAccountId1()))
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(this.accountsCommonTestData.getAccountNumber1()))
                .body("accounts[0].account.accountId.sourceSystem",
                        equalTo(this.accountsCommonTestData.getSourceSystem1()))
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()))
                .body("accounts[0].account.regCode.mnemonic",
                        equalTo(this.accountsCommonTestData.getMnemonic1()))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedAmount"))))
                .body("accounts[0].details", notNullValue())
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.emergencyFundAmount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData
                                .get("updatedEmergencyFundAmountValue"))))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PRAA))
                .body("accounts[0].contributions", notNullValue())
                .body("accounts[0].contributions.contributions[0].contribution.value",
                        equalTo(Float.valueOf(
                                this.accountsCommonTestData.get("updatedContribAmount"))))
                .body("accounts[0].contributions.contributions[0].frequency",
                        equalTo(this.accountsCommonTestData.get("updatedContribFreq")))
                .body("accounts[0].suitability", notNullValue())
                .body("accounts[0].withdrawals", notNullValue())
                .body("accounts[0].withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(
                                this.accountsCommonTestData.get("updatedWithdrawAmount"))))
                .body("accounts[0].withdrawals[0].amount.frequency",
                        equalTo(this.accountsCommonTestData.get("updatedWithdrawFreq")));
    }

    @Test(dependsOnMethods = "updateCompositeAccountFullviewV2")
    public void getCompositeAccountFullviewV2AfterUpdate() {

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", equalTo(this.accountsCommonTestData.getAccountId1()))
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(this.accountsCommonTestData.getAccountNumber1()))
                .body("accounts[0].account.accountId.sourceSystem",
                        equalTo(this.accountsCommonTestData.getSourceSystem1()))
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()))
                .body("accounts[0].account.regCode.mnemonic",
                        equalTo(this.accountsCommonTestData.getMnemonic1()))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedAmount"))))
                .body("accounts[0].details", notNullValue())
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.emergencyFundAmount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData
                                .get("updatedEmergencyFundAmountValue"))))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body("accounts[0].details.fullviewAccountDetail.accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PRAA))
                .body("accounts[0].contributions", notNullValue())
                .body("accounts[0].contributions.contributions[0].contribution.value",
                        equalTo(Float.valueOf(
                                this.accountsCommonTestData.get("updatedContribAmount"))))
                .body("accounts[0].contributions.contributions[0].frequency",
                        equalTo(this.accountsCommonTestData.get("updatedContribFreq")))
                .body("accounts[0].suitability", notNullValue())
                .body("accounts[0].withdrawals", notNullValue())
                .body("accounts[0].withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(
                                this.accountsCommonTestData.get("updatedWithdrawAmount"))))
                .body("accounts[0].withdrawals[0].amount.frequency",
                        equalTo(this.accountsCommonTestData.get("updatedWithdrawFreq")));
    }

    @Test(dependsOnMethods = "getCompositeAccountFullviewV2AfterUpdate")
    public void deleteCompositeAccountFullviewV2() {
        context.put("accId", this.accountsCommonTestData.getAccountId1());
        context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
        context.put("source", this.accountsCommonTestData.getSourceSystem1());
        context.put("ppid", this.accountsCommonTestData.getPpid());
        context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
        context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        context.put("value", this.accountsCommonTestData.get("updatedAmount"));
        context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        this.response = this.request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = this.response.jsonPath().getString("$");
        assertThat(emptyResponse, equalTo("[:]"));
    }

    @Test(dependsOnMethods = "deleteCompositeAccountFullviewV2")
    public void getCompositeAccountFullviewV2AfterDelete() {
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts", hasSize(0));
    }

    /**
     * Returns the response of retrieving a fullview account
     *
     * @param accountsCommonTestData the test data
     * @param oAuth                  the oauth token
     */
    private static AccountsCommonTestData getFullviewAccountInformationV2(
            final AccountsCommonTestData accountsCommonTestData, final String oAuth) {
        final VelocityContext context = new VelocityContext();
        context.put("source", "FULLVIEW");

        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();

        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        final Response response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        if (response.statusCode() != HTTPStatusCodes.STATUS_200) {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));

            return null;
        }
        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));

        return accountsCommonTestData;
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown() {
        this.testDataUtil.closeSQLiteConnection();
    }
}