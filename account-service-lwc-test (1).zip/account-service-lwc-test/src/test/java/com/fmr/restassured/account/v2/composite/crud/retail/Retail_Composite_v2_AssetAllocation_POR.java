/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.retail;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.HashMap;

import io.restassured.RestAssured;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.MatcherAssert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import org.testng.annotations.Test;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * Tests Account Composite operation for a Retail account with asset allocation in details.
 * @author a608077
 * Updated by a608077 on 10/24/2023 to include 3 new asset classes: Private Equity, Private Credit,
 *  and Real Assets for POR/WM scenario with EEDS=true(PFCP-13827)
 */
@Test(groups = {Tags.REGRESSION, Tags.RETAIL, Tags.COMPOSITE, Tags.V2})
public class Retail_Composite_v2_AssetAllocation_POR extends PAPBaseServiceTest
{
    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Retail_Composite_v2_AssetAllocation_POR.class);

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;
    private VelocityContext context ;
    /**
     * Global variable holding retailAccount information
     */
    private HashMap<String, String> retailAccountMap;

    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountTestData;

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Retail_Composite_v2_AssetAllocation_POR.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String SCENARIO_PRODUCT_CODE="WM";
    private static final String SCENARIO_CATEGORY_CODE="POR";

    private String acctRoot;
    private final String details = "details.retailAccountDetail.";
    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
    private final float netPercentage_T_ALTERNATIVE = 0.8f;
    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
    private final float netPercentage_PEA = 0.4f;
    private final float netPercentage_Updated_PEA = 0.2f;
    private final float netPercentage_PCA = 0.2f;
    private final float netPercentage_Updated_PCA = 0.3f;
    private final float netPercentage_PRAA = 0.2f;
    private final float netPercentage_Updated_PRAA = 0.1f;


    protected Retail_Composite_v2_AssetAllocation_POR()
    {
        super(Services.Account);
    }

    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
        /*
          Global variable holding the oAuth token generated in the initClass method
         */
        String oAuth = AccountUtil.getOauthToken();
        this.testDataUtil = new TestDataUtil();
        this.retailAccountMap = new HashMap<>();

        this.accountTestData = TestDataUtil.populateRegressionTestData("account_default_ssn", oAuth);

        this.retailAccountMap = getRetailAccountInformationV2(this.accountTestData, oAuth);

        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountTestData.getMid(), oAuth, "true");

        // Create Principal
        Identity.createPrincipal(accountTestData.getMid(), oAuth);
        //Create Scenario
        String scenarioId = Scenario.createScenarioWithProductCode(this.accountTestData.getMid(),
                SCENARIO_PRODUCT_CODE,SCENARIO_CATEGORY_CODE,oAuth);

        //Insert Household Identity
        this.accountTestData.setPpid(Identity.createHouseholdIdentityWithProductCode(accountTestData.getMid(),
                oAuth,SCENARIO_PRODUCT_CODE,SCENARIO_CATEGORY_CODE));

        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("user-mid", this.accountTestData.getMid()))
                .header(new Header("scenario-id", scenarioId))
                .header(new Header("user-retail-lid", this.accountTestData.getSsn()));

        context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter","RETAIL");

    }
    /**
     * Description: Validates an empty account list when calling get account composite retail before creation of an
     * account (v2)
     */
    @Test
    public void getCompositeAccountRetailV2BeforeCreate()
    {
        this.request.header(new Header("excludeExternalDataSources", "true"));

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        this.response = this.request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        this.response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts", hasSize(0));
    }

    @Test(dependsOnMethods = "getCompositeAccountRetailV2BeforeCreate")
    public void createCompositeAccountRetailV2()
    {
        String accNum = retailAccountMap.get("accountNumber");
        context.put("accountNumber", this.retailAccountMap.get("accountNumber"));
        context.put("source", this.retailAccountMap.get("sourceSystem"));
        context.put("ppid", this.accountTestData.getPpid());
        context.put("displayName", this.retailAccountMap.get("displayName"));
        context.put("mnemonic", this.retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", this.retailAccountMap.get("sourceSystem"));
        context.put("institutionName", this.retailAccountMap.get("institutionName"));
        context.put("value", this.retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", this.retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "111111.11");
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.177);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.0f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_PRAA);
        context.put("asdr", false);
        context.put("isProductSuitable", "false");
        context.put("emergencyFundAmountValue", "111111.11");
        context.put("contribFreq", "MONTHLY");
        context.put("contribValue", "500");
        context.put("withdrawAmount", "500");
        context.put("withdrawFreq", "HOURLY");

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        this.response = this.request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";

        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(retailAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "accountDetail.emergencyFundAmount.value",
                        equalTo(111111.11f))
                .body(acctRoot + details + "isProductSuitable", equalTo(false))
                .body(acctRoot + details + "accountDetail.emergencyFundAmount.value", equalTo(111111.11f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PRAA))
                .body(acctRoot +"contributions", notNullValue())
                .body(acctRoot +"contributions.contributions[0].contribution.value", equalTo(500.0f))
                .body(acctRoot +"contributions.contributions[0].frequency", equalTo("MONTHLY"))
                .body(acctRoot +"suitability", notNullValue())
                .body(acctRoot +"withdrawals", notNullValue())
                .body(acctRoot +"withdrawals[0].amount.amount.value", equalTo(500.0f))
                .body(acctRoot +"withdrawals[0].amount.frequency", equalTo("HOURLY"));

        this.accountTestData
                .setAccountId1(this.response.jsonPath().getString("accounts[0].account.accountId.id"));
    }

    @Test(dependsOnMethods = "createCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterCreate()
    {

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        this.response = this.request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(retailAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "accountDetail.emergencyFundAmount.value",
                        equalTo(111111.11f))
                .body(acctRoot + details + "isProductSuitable", equalTo(false))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PRAA))
                .body(acctRoot +"contributions", notNullValue())
                .body(acctRoot +"contributions.contributions[0].contribution.value", equalTo(500.0f))
                .body(acctRoot +"contributions.contributions[0].frequency", equalTo("MONTHLY"))
                .body(acctRoot +"suitability", notNullValue())
                .body(acctRoot +"withdrawals", notNullValue())
                .body(acctRoot +"withdrawals[0].amount.amount.value", equalTo(500.0f))
                .body(acctRoot +"withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }

    @Test(dependsOnMethods = "getCompositeAccountRetailV2AfterCreate")
    public void updateCompositeAccountRetailV2()
    {

        context.put("accId", this.accountTestData.getAccountId1());
        context.put("accountNumber", this.retailAccountMap.get("accountNumber"));
        context.put("source", this.retailAccountMap.get("sourceSystem"));
        context.put("ppid", this.accountTestData.getPpid());
        context.put("displayName", this.retailAccountMap.get("displayName"));
        context.put("mnemonic", this.retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", this.retailAccountMap.get("sourceSystem"));
        context.put("institutionName", this.retailAccountMap.get("institutionName"));
        context.put("value", this.retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", this.retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "211111.11");
        context.put("emergencyFundAmountValue", "211111.11");
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.4f);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 1.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.70f);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.30f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_Updated_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_Updated_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
        context.put("contribFreq", "MONTHLY");
        context.put("contribValue", "600");
        context.put("withdrawAmount", "800");
        context.put("withdrawFreq", "HOURLY");
        context.put("isProductSuitable", "true");

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));

        this.response = this.request.log().ifValidationFails().post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", equalTo(this.accountTestData.getAccountId1()))
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(this.retailAccountMap.get("accountNumber")))
                .body("accounts[0].account.accountId.sourceSystem",
                        equalTo(this.retailAccountMap.get("sourceSystem")))
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountTestData.getPpid()))
                .body("accounts[0].account.displayName",
                        equalTo(this.retailAccountMap.get("displayName")))
                .body("accounts[0].account.regCode.mnemonic",
                        equalTo(this.retailAccountMap.get("mnemonic")))
                .body("accounts[0].account.institutionName",
                        equalTo(this.retailAccountMap.get("institutionName")))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(
                                this.retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "accountDetail.emergencyFundAmount.value",
                        equalTo(211111.11f))
                .body(acctRoot + details + "isProductSuitable", equalTo(true))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PRAA))
                .body(acctRoot +"contributions", notNullValue())
                .body(acctRoot +"contributions.contributions[0].contribution.value", equalTo(600.0f))
                .body(acctRoot +"contributions.contributions[0].frequency", equalTo("MONTHLY"))
                .body(acctRoot +"suitability", notNullValue())
                .body(acctRoot +"withdrawals", notNullValue())
                .body(acctRoot +"withdrawals[0].amount.amount.value", equalTo(800.0f))
                .body(acctRoot +"withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }

    @Test(dependsOnMethods = "updateCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterUpdate()
    {

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        this.response = this.request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", equalTo(this.accountTestData.getAccountId1()))
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(this.retailAccountMap.get("accountNumber")))
                .body("accounts[0].account.accountId.sourceSystem",
                        equalTo(this.retailAccountMap.get("sourceSystem")))
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountTestData.getPpid()))
                .body("accounts[0].account.displayName",
                        equalTo(this.retailAccountMap.get("displayName")))
                .body("accounts[0].account.regCode.mnemonic",
                        equalTo(this.retailAccountMap.get("mnemonic")))
                .body("accounts[0].account.institutionName",
                        equalTo(this.retailAccountMap.get("institutionName")))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(
                                this.retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "accountDetail.emergencyFundAmount.value",
                        equalTo(211111.11f))
                .body(acctRoot + details + "isProductSuitable", equalTo(true))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PRAA))
                .body(acctRoot +"contributions", notNullValue())
                .body(acctRoot +"contributions.contributions[0].contribution.value", equalTo(600.0f))
                .body(acctRoot +"contributions.contributions[0].frequency", equalTo("MONTHLY"))
                .body(acctRoot +"suitability", notNullValue())
                .body(acctRoot +"withdrawals", notNullValue())
                .body(acctRoot +"withdrawals[0].amount.amount.value", equalTo(800.0f))
                .body(acctRoot +"withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }

    @Test(dependsOnMethods = "getCompositeAccountRetailV2AfterUpdate")
    public void deleteCompositeAccountRetailV2()
    {

        context.put("accId", this.accountTestData.getAccountId1());
        context.put("accountNumber", this.retailAccountMap.get("accountNumber"));
        context.put("source", this.retailAccountMap.get("sourceSystem"));
        context.put("ppid", this.accountTestData.getPpid());
        context.put("displayName", this.retailAccountMap.get("displayName"));
        context.put("mnemonic", this.retailAccountMap.get("mnemonic"));
        context.put("institutionName", this.retailAccountMap.get("institutionName"));
        context.put("value", this.retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", this.retailAccountMap.get("sourceMarketAsOfDate"));

        this.request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        this.response = this.request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        this.response.then().log().ifValidationFails().
                statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = this.response.jsonPath().getString("$");
        MatcherAssert.assertThat(emptyResponse, equalTo("[:]"));
    }


    @Test(dependsOnMethods = "deleteCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterDelete()
    {
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        this.response = this.request.log().ifValidationFails()
                .post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        this.response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts", hasSize(0));
    }

    /**
     * Returns the response of retrieving a retail account from backend
     *
     * @param accountsCommonTestData test data for accounts
     */
    private static HashMap<String, String> getRetailAccountInformationV2(
            final AccountsCommonTestData accountsCommonTestData, final String oAuth)
    {

        final VelocityContext context = new VelocityContext();
        context.put("source", "RETAIL");

        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();

        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        final Response response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        if (response.statusCode() != HTTPStatusCodes.STATUS_200)
        {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));

            return null;
        }

        final JsonPath retailAccountJP = response.jsonPath();

        final HashMap<String, String> retailAccountMap = new HashMap<>();
        retailAccountMap.put("accountNumber",
                retailAccountJP.getString("accountList[0].accountId.accountNumber"));
        retailAccountMap.put("sourceSystem",
                retailAccountJP.getString("accountList[0].accountId.sourceSystem"));
        retailAccountMap.put("displayName", retailAccountJP.getString("accountList[0].displayName"));
        retailAccountMap.put("mnemonic", retailAccountJP.getString("accountList[0].regCode.mnemonic"));
        retailAccountMap.put("institutionName", retailAccountJP.getString("accountList[0].institutionName"));
        retailAccountMap.put("sourceMarketAmountValue",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
        retailAccountMap.put("sourceMarketAmountValueType",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        retailAccountMap.put("sourceMarketAmountCurrency",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        retailAccountMap.put("sourceMarketAsOfDate",
                retailAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));

        return retailAccountMap;
    }
    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown()
    {
        this.testDataUtil.closeSQLiteConnection();
    }
}