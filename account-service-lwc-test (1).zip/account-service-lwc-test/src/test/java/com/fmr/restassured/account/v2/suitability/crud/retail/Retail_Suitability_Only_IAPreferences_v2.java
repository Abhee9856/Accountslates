/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.suitability.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsSuitabilityPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;

/**
 * Tests CRUD operation for suitability against V2 for Retail accounts,
 * only with account level preferences and not other suitability questions (PFCP-6920)
 *
 * @author a608077
 * Updated by @author a631781 for story PFCP-10346
 */
@Test(groups = {Tags.RETAIL, Tags.SUITABILITY, Tags.V2, Tags.CRITICAL})
public class Retail_Suitability_Only_IAPreferences_v2 extends PAPBaseServiceTest {

    protected Retail_Suitability_Only_IAPreferences_v2() {
        super(Services.Account);
    }
    
    private String mid;// = "SuitabilityAccountV2TestMid";

    private String mnemonic;
    private String ppid;
    private String accountId;

    private String accountNumber;

    private String sourceSystem;

    private String displayName;

    private float value;

    private String institutionName;

    private String asOfDate;

    private VelocityContext context; 

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String LOG_TRACKING_ID = Retail_Suitability_Only_IAPreferences_v2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    //Start and End years for accountPreferencesIA - both should be greater than the current year.
    int startYear = ZonedDateTime.now().plusYears(1).getYear();
    int endYear = ZonedDateTime.now().plusYears(2).getYear();
    //investmentObjectiveIA, withdrawalNeeds, anticipatedExpenses and annualWithdrawalPercent for accountPreferencesIA
    private static String investmentObjectiveIA = "NONE";
    private static String withdrawalNeeds = "NO_WITHDRAWAL";
    private static String anticipatedExpenses = "LIKELY";
    private static float annualWithdrawalPercent = 0.02f;
    private static String updatedInvestmentObjectiveIA = "CONSERVATIVE";
    private static String updatedWithdrawalNeeds = "CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5";
    private static String updatedAnticipatedExpenses = "SOMEWHAT_LIKELY";
    private static float updatedAnnualWithdrawalPercent = 0.05f;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();

        testDataUtil = new TestDataUtil();
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil.populateRegressionTestData("accountCRUD_Retail", oAuth);

       this.mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(this.mid);

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.given().header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("excludeExternalDataSources", "false"));

        // Populate request context with user IDs
        context = new VelocityContext();
        context.put("ppid", ppid);

    }

    /**
     * Get Retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }


    /**
     * Create the Retail account. Save the account id.
     * <p>
     * Version V2
     */

    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount() {
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList[0].regCode.mnemonic", equalTo(mnemonic),
                        "accountList[0].accountId.accountNumber", equalTo(accountNumber));

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        context.put("accId", accountId);
    }

    /**
     * Validate the account was created correctly.
     */
    @Test(dependsOnMethods = "createRetailAccount")
    public void getRetailAccountAfterCreate() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList[0].regCode.mnemonic", equalTo(mnemonic),
                        "accountList[0].accountId.accountNumber", equalTo(accountNumber));

    }

    /**
     * Create the account suitability.
     */
    @Test(dependsOnMethods = "getRetailAccountAfterCreate")
    public void createAccountSuitability() {

        // Generate request body
        context.put("riskTolerance", 1);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("investmentObjectiveIA", investmentObjectiveIA);
        context.put("withdrawalNeeds", withdrawalNeeds);
        context.put("anticipatedExpenses", anticipatedExpenses);
        context.put("annualWithdrawalPercent", annualWithdrawalPercent);


        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V2))
                .log().ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.CREATE_ACCOUNTS_SUITABILITY_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", not(empty()))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA", not(empty()))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.riskTolerance", equalTo(1))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.withdrawalStartYear", equalTo(startYear))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.investmentObjectiveIA", equalTo(investmentObjectiveIA))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.withdrawalNeeds", equalTo(withdrawalNeeds))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.anticipatedExpenses", equalTo(anticipatedExpenses))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.annualWithdrawalPercent", equalTo(annualWithdrawalPercent));

    }

    /**
     * Validate the suitability information just created.
     */
    @Test(dependsOnMethods = "createAccountSuitability")
    public void getSuitabilityAfterCreate() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", not(empty()))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA", not(empty()))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.riskTolerance", equalTo(1))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.withdrawalStartYear", equalTo(startYear))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.investmentObjectiveIA", equalTo(investmentObjectiveIA))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.withdrawalNeeds", equalTo(withdrawalNeeds))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.anticipatedExpenses", equalTo(anticipatedExpenses))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.annualWithdrawalPercent", equalTo(annualWithdrawalPercent));
    }

    /**
     * Update the suitability just created.
     */
    @Test(dependsOnMethods = "getSuitabilityAfterCreate")
    public void updateAccountSuitability() {
        // Generate request body
        context.put("riskTolerance", 2);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("investmentObjectiveIA", updatedInvestmentObjectiveIA);
        context.put("withdrawalNeeds", updatedWithdrawalNeeds);
        context.put("anticipatedExpenses", updatedAnticipatedExpenses);
        context.put("annualWithdrawalPercent", updatedAnnualWithdrawalPercent);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.UPDATE_ACCOUNTS_SUITABILITY_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", not(empty()))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA", not(empty()))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.riskTolerance", equalTo(2))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.withdrawalStartYear", equalTo(startYear))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.investmentObjectiveIA", equalTo(updatedInvestmentObjectiveIA))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.withdrawalNeeds", equalTo(updatedWithdrawalNeeds))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.anticipatedExpenses", equalTo(updatedAnticipatedExpenses))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.annualWithdrawalPercent", equalTo(updatedAnnualWithdrawalPercent));

    }

    /**
     * Validate the suitability was updated.
     */
    @Test(dependsOnMethods = "updateAccountSuitability")
    public void getSuitabilityAfterUpdate() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", not(empty()))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.investmentObjectiveIA", equalTo(updatedInvestmentObjectiveIA))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.withdrawalNeeds", equalTo(updatedWithdrawalNeeds))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.anticipatedExpenses", equalTo(updatedAnticipatedExpenses))
                .body("accountSuitability.find{it.accountId.id == '" + accountId + "'}.accountPreferencesIA.annualWithdrawalPercent", equalTo(updatedAnnualWithdrawalPercent));
    }

    /**
     * Delete the account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getSuitabilityAfterUpdate")
    public void deleteAccountSuitability() {
        context.put("ppid", ppid);
        context.put("source", "RETAIL");
        context.put("id", accountId);
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", equalTo(null));
    }

    /**
     * Validate no suitability is returned.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteAccountSuitability")
    public void getSuitabilityAfterDelete() {

        FilterableRequestSpecification frs = (FilterableRequestSpecification) this.request;
        frs.removeHeader("excludeExternalDataSources");

        this.request.given().header(new Header("excludeExternalDataSources", "true"));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", empty());

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
