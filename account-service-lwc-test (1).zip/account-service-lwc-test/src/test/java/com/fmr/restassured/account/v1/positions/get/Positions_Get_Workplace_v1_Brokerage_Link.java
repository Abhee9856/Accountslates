/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.positions.get;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.testng.AssertJUnit.assertFalse;

/**
 * Tests positions/get for Workplace accounts v1 specifically for brokerage linked accounts and their positions.
 * PFCP-11737
 *
 * @author a608077
 * Updted by a631781. Added header "calculate-balances"
 */
@Test(groups = {Tags.WORKPLACE, Tags.POSITIONS, Tags.V1})
public class Positions_Get_Workplace_v1_Brokerage_Link extends PAPBaseServiceTest
{

	protected Positions_Get_Workplace_v1_Brokerage_Link()
	{
		super(Services.Account);
	}

	private Boolean containsIsBrokerageLinkPosition;
	private VelocityContext context;

	// Instance to the test data utility class
	TestDataUtil testDataUtil = new TestDataUtil();

	private static final String CALLING_APP_ID = "AP136091";
	private static final String APP_ID = "AP136091";
	private static final String LOG_TRACKING_ID = Positions_Get_Workplace_v1_Brokerage_Link.class.getSimpleName();
	private static final String FSREQID = LOG_TRACKING_ID;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
		// Data setup
		AccountsCommonTestData accountsCommonTestData = TestDataUtil
		                .populateRegressionTestData("account_get_positions_brokerage_account", oAuth);

		String mid = accountsCommonTestData.getMid();
		DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


		String ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

		// Populate request context with user IDs
		context = new VelocityContext();
		context.put("mid", mid);
		context.put("fescoLid", accountsCommonTestData.getSsn());
		context.put("ppid", ppid);
		String sourceSystem = "WORKPLACE";
		context.put("source", sourceSystem);
	}

	/**
	 * Validate the positions.
	 */
	@Test
	public void getPositions() throws JSONException
	{
		request.given().header(new Header("calculate-balances", "brokerage-link"));
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
		                .body("resultCode", equalTo(true)).body("accountList", notNullValue());

		// Logic for validation of brokerage linked accounts
		JSONArray accountList = new JSONObject(response.getBody().asString()).getJSONArray("accountList");
		for (int i = 0; i < accountList.length(); i++)
		{
			JSONArray allPositions = accountList.getJSONObject(i).getJSONObject("positions")
			                .getJSONArray("position");
			for (int j = 0; j < allPositions.length(); j++)
			{
				JSONObject workplacePosition = allPositions.getJSONObject(j);
				if (workplacePosition.optString("isBrokerageLink").equals("true"))
				{
					containsIsBrokerageLinkPosition = true;
					break;
				}
				else
				{
					containsIsBrokerageLinkPosition = false;
				}
			}
		}
		// Brokerage-linked positions should not exist
		assertFalse("Brokerage linked positions found!", containsIsBrokerageLinkPosition);
	}

	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}

}
