/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.crud.fullview;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;


import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.equalTo;

/**
 * Tests Account Details V2 for Fullview Account
 *
 * @author a631781
 *  Updated by a608077 on 10/11/2023 to include 3 new asset classes: Private Equity, Private Credit,
 *  and Real Assets(PFCP-13826)
 */
@Test(groups = {Tags.CRITICAL, Tags.FULLVIEW, Tags.CRUD, Tags.V2, Tags.REGRESSION, Tags.TAM})
public class Fullview_Detail_CriticalTest_v2 extends PAPBaseServiceTest
{

    protected Fullview_Detail_CriticalTest_v2()
    {
	super(Services.Account);
    }

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

	// Test data
    private String accId;

    private String accountNum;

    private String sourceSystem = "FULLVIEW";

    private String displayName;

    private String mnemonic;

    private String asOfDate;

    private VelocityContext context;

    private final float value = 818.89f;

    private final float updatedValue = 426.85f;

	private String accNum;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String FEDERAL_TAX_WITHHOLDING_PCT = "federalTaxWithholdingPercent";

    private static final String STATE_TAX_WITHHOLDING_PCT = "stateTaxWithholdingPercent";

    private final String originalOwnerBirthDate = "1960-11-30T00:00:00.000+0000";

    private final String originalOwnerDeceasedDate = "2022-12-30T00:00:00.000+0000";

	private final String withdrawalEligibilityStartDate = "2020-01-01T00:00:00.000+0000";

    private final String withdrawalEligibilityEndDate = "2020-01-01T00:00:00.000+0000";

    private final String equityPercent = "0.1";

    private final String tamAssetClass = "TOTAL_EQUITY";

    private final String assetClass = "TOTAL_EQUITY";

    private final float netPercentage = 1.0f;

    private final float netPercentageUpdated = 0.9f;

    private final String assetClass1 = "BOND";

    private final float netPercentage1 = 0.5f;

    private final float netPercentageUpdated1 = 0.2f;

    private final String assetClass2 = "CASH";

    private final float netPercentage2 = 0.3f;

    private final float netPercentageUpdated2 = 0.8f;

    private final String assetClass3 = "OTHER";

    private final float netPercentage3 = 0.4f;

	private final float netPercentageUpdated3 = 0.7f;
	private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
	private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
	private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
	private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
	private final float netPercentage_T_ALTERNATIVE = 0.8f;
	private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
	private final float netPercentage_PEA = 0.4f;
	private final float netPercentage_Updated_PEA = 0.2f;
	private final float netPercentage_PCA = 0.2f;
	private final float netPercentage_Updated_PCA = 0.3f;
	private final float netPercentage_PRAA = 0.2f;
	private final float netPercentage_Updated_PRAA = 0.1f;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	p2TestDataUtil = new TestDataUtil();

	final String oAuth = AccountUtil.getOauthToken();
	accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_FV, oAuth);
	DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


		String ppid = Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth);
	// Data setup
	accountsCommonTestData.setPpid(ppid);

	accountsCommonTestData.set(FEDERAL_TAX_WITHHOLDING_PCT, "0.8");
	accountsCommonTestData.set(STATE_TAX_WITHHOLDING_PCT, "0.8");

	// Endpoint setup
	setDefaultRequestHeaders(oAuth);
	request.given().header(new Header("user-poe", AccountConstants.RETAIL))
			.header(new Header("user-mid", accountsCommonTestData.getMid()))
			.header(new Header("user-sid", accountsCommonTestData.getSid()))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
	// Populate request variables
	context = new VelocityContext();
	context.put("source", sourceSystem);

    }

    /**
     * Tests that account details data is brought back for Fullview account.
     * <p>
     * Version V2
     */
    @Test
    public void getFullviewAccountInfo()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
	// Call Account service v2
	response = request.post(AccountsPaths.GET_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(200).body("accountList", Matchers.notNullValue());

	String accountId = response.path("accountList[0].accountId.id");
	accountsCommonTestData.setAccountId1(accountId);
	accountNum = response.path("accountList[0].accountId.accountNumber");
	sourceSystem = response.path("accountList[0].accountId.sourceSystem");
	displayName = response.path("accountList[0].displayName");
	mnemonic = response.path("accountList[0].regCode.mnemonic");
	asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");

    }

    /**
     * Creates a new Fullview account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void createFullviewAccount()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("mnemonic", mnemonic);
	context.put("value", value);
	context.put("source", sourceSystem);
	context.put("accountNumber", accountNum);
	context.put("displayName", displayName);
	context.put("institutionName", "BB&T");
	context.put("asOfDate", asOfDate);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

	// Call Account service
	response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(200);
	accId = response.path("accountList[0].accountId.id");
	accNum = response.path("accountList[0].accountId.accountNumber");
    }

    /**
     * Create FV account Details Request.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createFullviewAccount")
    public void createAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", value);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", true);
	context.put("isPreviousEmployersAccount", true);
	context.put("state", "NC");
	context.put("type", "fullviewAccountDetail");
	context.put("_type", "FullviewAccountDetails");
	context.put("tamAssetClass", tamAssetClass);
	context.put("originalOwnerBirthDate", originalOwnerBirthDate);
		String originalOwnerSpouse = "false";
	context.put("originalOwnerSpouse", originalOwnerSpouse);
	context.put("originalOwnerDeceasedDate", originalOwnerDeceasedDate);
	context.put("withdrawalEligibilityStartDate", withdrawalEligibilityStartDate);
	context.put("withdrawalEligibilityEndDate", withdrawalEligibilityEndDate);
	context.put("federalTaxWithholdingPercent", accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT));
	context.put("stateTaxWithholdingPercent", accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT));
	context.put("equityPercent", equityPercent);
	context.put("assetClass", assetClass);
	context.put("netPercentage", netPercentage);
	context.put("assetClass1", assetClass1);
	context.put("netPercentage1", netPercentage1);
	context.put("assetClass2", assetClass2);
	context.put("netPercentage2", netPercentage2);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentage3);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA", netPercentage_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA", netPercentage_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA", netPercentage_PRAA);

	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));

	// Call Account service
	response =
			request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountDetails", notNullValue())
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
					+ "'}.fullviewAccountDetail.accountDetail.costBasis.value", equalTo(value))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.equityPercent",
					equalTo(Float.valueOf(equityPercent)))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
					+ "'}.fullviewAccountDetail.accountDetail.originalOwnerSpouse", equalTo(false))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					CoreMatchers.equalTo(assetClass))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass1))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage1))

			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass2))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage2))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass3))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage3))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_T_ALTERNATIVE))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PCA))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PEA))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PRAA));
    }

    /**
     * Validate the FV account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountDetails", notNullValue())
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
					+ "'}.fullviewAccountDetail.accountDetail.costBasis.value", equalTo(value))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.equityPercent",
					equalTo(Float.valueOf(equityPercent)))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
					+ "'}.fullviewAccountDetail.accountDetail.originalOwnerSpouse", equalTo(false))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					CoreMatchers.equalTo(assetClass))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass1))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage1))

			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass2))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage2))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass3))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage3))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_T_ALTERNATIVE))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PCA))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PEA))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PRAA));
    }

    /**
     * Update the details for FV account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", updatedValue);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "fullviewAccountDetail");
	context.put("_type", "FullviewAccountDetails");
	context.put("assetClass", assetClass);
	context.put("netPercentage", netPercentageUpdated);
	context.put("assetClass1", assetClass1);
	context.put("netPercentage1", netPercentageUpdated1);
	context.put("assetClass2", assetClass2);
	context.put("netPercentage2", netPercentageUpdated2);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentageUpdated3);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA", netPercentage_Updated_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA", netPercentage_Updated_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);

	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_UPDATE_V2_TEMPLATE));
	// Call Account service
	response =
			request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);

	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountDetails", notNullValue())
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.costBasis.value",
					equalTo(updatedValue))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.equityPercent",
					equalTo(Float.valueOf(equityPercent)))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
					+ "'}.fullviewAccountDetail.accountDetail.originalOwnerSpouse", equalTo(false))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					CoreMatchers.equalTo(assetClass))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass1))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated1))

			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass2))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated2))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass3))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated3))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_T_ALTERNATIVE))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PCA))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PEA))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PRAA));

    }

    /**
     * Validate the updated FV account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountDetails", notNullValue())
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.costBasis.value",
					equalTo(updatedValue))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.equityPercent",
					equalTo(Float.valueOf(equityPercent)))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.withdrawalEligibilityStartDate",
					equalTo(withdrawalEligibilityStartDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.withdrawalEligibilityEndDate",
					equalTo(withdrawalEligibilityEndDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
					+ "'}.fullviewAccountDetail.accountDetail.originalOwnerSpouse", equalTo(false))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					CoreMatchers.equalTo(assetClass))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass1))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated1))

			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass2))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated2))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass3))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated3))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_T_ALTERNATIVE))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PCA))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PEA))
			.body("accountDetails.find{it.fullviewAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.fullviewAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PRAA));

    }

    /**
     * Delete the Fullview account Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteFiliAccount()
    {
	context.put("id", accId);
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("mnemonic", mnemonic);
	context.put("value", value);
	context.put("source", sourceSystem);
	context.put("accountNumber", accountNum);
	context.put("displayName", displayName);
	context.put("institutionName", "BB&T");
	context.put("asOfDate", asOfDate);

	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200).body("isEmpty()", Matchers.is(true));
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	p2TestDataUtil.closeSQLiteConnection();
    }
}
