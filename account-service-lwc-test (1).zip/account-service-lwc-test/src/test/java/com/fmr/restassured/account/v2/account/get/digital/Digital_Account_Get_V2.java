/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.get.digital;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.hamcrest.Matchers.*;

/**
 * Tests for Digital Account
 *
 * @author a631781
 */

@Test(groups = {Tags.DIGITAL, Tags.ACCOUNT, Tags.V2, Tags.GET})
public class Digital_Account_Get_V2 extends PAPBaseServiceTest {

    protected Digital_Account_Get_V2() {
        super(Services.Account);
    }

    private static final String sourceSystem = "DIGITAL";

    public static final String ACCOUNT_CATEGORY = "InternalDigital, ExternalDigital";
    public static final String acctSubTypeDescInt = "Internal Digital Currency";
    public static final String acctSubTypeDescExt = "External Digital Currency";

    private String ssn;
    private String mid;
    private String sid;
    private String internalAccountNumber;
    private String externalAccountNumber;
    private String internalAccountNumberDSS;
    private String externalAccountNumberDSS;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Digital_Account_Get_V2.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String APP_NAME = "Advice and Planning Platform";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private Response accountResponse;
    private final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;
    private VelocityContext context;
    private FilterableRequestSpecification frs;

    private String sourceSystemInt;
    private String mnemonicInt;
    private String regCodeSourceSystemInt;
    private Boolean externalDigitalAccountInt;

    private String sourceSystemExt;
    private String mnemonicExt;
    private String regCodeSourceSystemExt;
    private Boolean externalDigitalAccountExt;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_digital", oAuth);

        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid().replace("-", "");

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ssn = accountsCommonTestData.getSsn();
        testDataUtil = new TestDataUtil();

        // Populate request context with user IDs
        context = new VelocityContext();

        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Tests that account data is brought back for Digital account.
     * <p>
     * Version V2
     */
    @Test
    public void getDigitalAccountInfo() {
        // Generate request body
        setRequestHeadersForAccount();
        context.put("source", sourceSystem);
        context.put("returnPortfolioGainLossBalanceDetail", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service v2
        accountResponse = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        accountResponse.then().log().ifValidationFails().statusCode(200)
                .body("accountList[0].accountId.sourceSystem", equalTo(sourceSystem))
                .body("accountList", Matchers.not(Matchers.hasSize(0)));

    }

    /**
     * Test to get the DSS digital account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDigitalAccountInfo"})
    public void getDSS_V2() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)));
        internalAccountNumberDSS = response.path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescInt + "'}.acctNum");
        externalAccountNumberDSS = response.path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescExt + "'}.acctNum");

    }

    /**
     * Test to validate Digital Account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void validateResponse() {
        //Digital Account elements
        internalAccountNumber = accountResponse.path("accountList.find{it.accountId.accountNumber=='" + internalAccountNumberDSS + "'}.accountId.accountNumber");
        sourceSystemInt = accountResponse.path("accountList.find{it.accountId.accountNumber=='" + internalAccountNumber + "'}.accountId.sourceSystem");
        mnemonicInt = accountResponse.path("accountList.find{it.accountId.accountNumber=='" + internalAccountNumber + "'}.regCode.mnemonic");
        regCodeSourceSystemInt = accountResponse.path("accountList.find{it.accountId.accountNumber=='" + internalAccountNumber + "'}.regCode.sourceSystem");
        externalDigitalAccountInt = accountResponse.path("accountList.find{it.accountId.accountNumber=='" + internalAccountNumber + "'}.externalDigitalAccount");

        externalAccountNumber = accountResponse.path("accountList.find{it.accountId.accountNumber=='" + externalAccountNumberDSS + "'}.accountId.accountNumber");
        sourceSystemExt = accountResponse.path("accountList.find{it.accountId.accountNumber=='" + externalAccountNumber + "'}.accountId.sourceSystem");
        mnemonicExt = accountResponse.path("accountList.find{it.accountId.accountNumber=='" + externalAccountNumber + "'}.regCode.mnemonic");
        regCodeSourceSystemExt = accountResponse.path("accountList.find{it.accountId.accountNumber=='" + externalAccountNumber + "'}.regCode.sourceSystem");
        externalDigitalAccountExt = accountResponse.path("accountList.find{it.accountId.accountNumber=='" + externalAccountNumber + "'}.externalDigitalAccount");

        //Validating Account Digital elements
        Assert.assertEquals(internalAccountNumber, internalAccountNumberDSS);
        Assert.assertEquals(sourceSystemInt, sourceSystem);
        Assert.assertEquals(mnemonicInt, "I");
        Assert.assertEquals(regCodeSourceSystemInt, sourceSystem);
        Assert.assertEquals(externalDigitalAccountInt, false);
        if (externalAccountNumberDSS != null) {
            Assert.assertEquals(externalAccountNumber, externalAccountNumberDSS);
            Assert.assertEquals(sourceSystemExt, sourceSystem);
            Assert.assertEquals(mnemonicExt, "UNKN");
            Assert.assertEquals(regCodeSourceSystemExt, sourceSystem);
            Assert.assertEquals(externalDigitalAccountExt, true);
        }
    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS() {
        this.request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", this.ssn))
                .header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
                .header(new Header("FACMC", "MID=" + this.mid))
                .header(new Header("FACFC", "SESSION_KEY=1"))
                .header(new Header("Content-Type", "application/json"));

    }

    /**
     * Setting headers for Account Service
     */
    private void setRequestHeadersForAccount() {
        // Account headers setup
        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-retail-lid", ssn))
                .header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("realTimeData", "true"))
                .header(new Header("mauiCache", "no"))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("user-digital-lid", ssn));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        this.testDataUtil.closeSQLiteConnection();
    }
}