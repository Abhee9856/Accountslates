/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDateTime;

import static org.hamcrest.Matchers.*;

/**
 * Tests CRUD operations of account details V2 for Workplace Account for nqdcFixedRateOfReturn element
 * Story #PFCP-18759
 *
 * @author a631781
 */

@Test(groups = {
        Tags.REGRESSION,
        Tags.WORKPLACE,
        Tags.COMPOSITE,
        Tags.V2,
})
public class Workplace_Composite_v2_Details_NQDC_Test extends PAPBaseServiceTest {
    protected Workplace_Composite_v2_Details_NQDC_Test() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;
    private static final float newFundingAmount = 6.66f;
    private final float updatedUnknownAmount = 23.5f;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private TestDataUtil testDataUtil;
    //Context
    private final VelocityContext context = new VelocityContext();

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Workplace_Composite_v2_Details_NQDC_Test.class.getSimpleName() + LocalDateTime.now();
    private static final String FSREQID = LOG_TRACKING_ID;
    private String acctRoot;
    private float nqdcFixedRateOfReturn = 0.2f;
    private float updatedNqdcFixedRateOfReturn = 0.4f;

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        String oAuth = AccountUtil.getOauthToken();

        testDataUtil = new TestDataUtil();

        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_workplace_nqdc_test", oAuth);
        //Data setup
        accountsCommonTestData.set("detailValue", "42619.85");

        accountsCommonTestData.set("updatedDetailValue", "81819.89");
        accountsCommonTestData.set("updatedAmount", "15000.0");

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(oAuth);

        request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));

    }

    /**
     * Get Workplace account info from the backend. Save the account number.
     */
    @Test
    public void getWorkplaceAccountInfo() {
        // Generate request body
        context.put("source", AccountConstants.WORKPLACE);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(empty()));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void getCompositeAccount() {
        // Exclude external data
        context.put("sourceBasedRegistrationFilter", AccountConstants.WORKPLACE);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails()
                .given()
                .header(new Header("excludeExternalDataSources", "true"))
                .post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", empty());

    }

    /**
     * Create a new composite account with nqdcFixedRateOfReturn. Save the account ID and account number.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccount")
    public void createCompositeAccount() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("nqdcFixedRateOfReturn", nqdcFixedRateOfReturn);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        // Make post request
        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", not(empty()),
                        "accounts[0].details.workplaceAccountDetail.nqdcFixedRateOfReturn", equalTo(nqdcFixedRateOfReturn));

        //Save account number and ID
        accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
        accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
    }


    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void getCompositeAccountAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accountsCommonTestData.getAccountNumber1() + "'}.";

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        acctRoot + "account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()),
                        acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()),
                        acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()),
                        acctRoot + "details.workplaceAccountDetail.nqdcFixedRateOfReturn", equalTo(nqdcFixedRateOfReturn));
    }

    /**
     * Update account details with nqdcFixedRateOfReturn and verifies content in the response.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterCreate")
    public void updateCompositeAccount() {
        // Populate variables for tests into context
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("contribFreq", accountsCommonTestData.get("updatedContribFreq"));
        context.put("contribValue", accountsCommonTestData.get("updatedContribAmount"));
        context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
        context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("nqdcFixedRateOfReturn", updatedNqdcFixedRateOfReturn);


        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));

        // Make post request
        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", not(empty()),
                        acctRoot + "details.workplaceAccountDetail.nqdcFixedRateOfReturn", equalTo(updatedNqdcFixedRateOfReturn));
    }

    /**
     * Gets the composite accounts and verifies that content is still coming back.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateCompositeAccount")
    public void getCompositeAccountAfterUpdate() {
        // Generate request body
        context.put("source", null);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", not(empty()),
                        acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        acctRoot + "account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()),
                        acctRoot + "details.workplaceAccountDetail.nqdcFixedRateOfReturn", equalTo(updatedNqdcFixedRateOfReturn));
    }


    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterUpdate")
    public void deleteCompositeAccount() {
        // Generate request body
        context.put("source", AccountConstants.WORKPLACE);
        context.put("id", accountsCommonTestData.getAccountId1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Make post request
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("isEmpty()", Matchers.is(true));
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
