package com.fmr.restassured.account.v2.composite.crud.fili;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.MatcherAssert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * Contains tests that validate the Account Composite operation for FILI Accounts - includes CRUD validations
 *
 * @author a623549
 * Updated by a608077 on 08/26/2022 to include asset allocation changes(PFCP-9501)
 * Updated by a608077 on 10/11/2023 to include 3 new asset classes: Private Equity, Private Credit,
 * and Real Assets(PFCP-13826)
 */
@Test(groups = {Tags.FILI, Tags.ACCOUNT, Tags.V2, Tags.CRITICAL, "PFCP-3074"})
public class FILI_Composite_v2_AllDetails extends PAPBaseServiceTest
{
    
    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(FILI_Composite_v2_AllDetails.class);
    
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;
    
    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;
    
    /**
     * Global variable holding filiAccount information
     */
    private HashMap<String, String> filiAccountMap;
    
    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountsCommonTestData;

    private String accNum;

    private String acctRoot;

    private final String catchupPath = ".contributions.find{it.contributionType=='CATCHUP'}";
    private final String regularPath = ".contributions.find{it.contributionType=='REGULAR'}";

    private final String details = "details.annuityAccountDetail.accountDetail.";
    
    private static final String CALLING_APP_ID = "AP136091";
    
    private static final String APP_ID = "AP136091";
    
    private static final String LOG_TRACKING_ID = FILI_Composite_v2_AllDetails.class.getSimpleName();
    
    private static final String FSREQID = LOG_TRACKING_ID;

    private VelocityContext context;
    
    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
  
    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
    
    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
    
    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
    
    private final float netPercentage_T_ALTERNATIVE = 0.8f;
    
    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
    
    private final float netPercentage_PEA = 0.4f;
    
    private final float netPercentage_Updated_PEA = 0.2f;
    
    private final float netPercentage_PCA = 0.2f;
    
    private final float netPercentage_Updated_PCA = 0.3f;
    
    private final float netPercentage_PRAA = 0.2f;
    
    private final float netPercentage_Updated_PRAA = 0.1f;
    
    /**
     * Constructor
     */
    protected FILI_Composite_v2_AllDetails()
    {
        super(Services.Account);
    }
    
    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass()
    {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        filiAccountMap = new HashMap<>();
        
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("fili_crud", oAuth);
        accountsCommonTestData.setMid("FiliCompositeV2TestMid");
        filiAccountMap = getFiliAccountInformationV2(accountsCommonTestData, oAuth);
        
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");

        final String ppid = Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth);
        accountsCommonTestData.setPpid(ppid);

        context = new VelocityContext();
    }
    
    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init()
    {
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"));
    }
    
    /**
     * Description: Validates an empty account list when calling get account composite FILI before creation of an
     * account (v2)
     */
    @Test
    public void getCompositeAccountFILIV2BeforeCreate()
    {
        if (filiAccountMap.isEmpty())
        {
            throw new SkipException(
                    "'getCompositeAccountFILIBeforeCreate' test scenario cannot run due to failure to retrieve fili "
                            + "account information!");
        }
        
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", filiAccountMap.get("sourceSystem"));
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }
    
    /**
     * Description: Creates composite account
     */
    @Test(dependsOnMethods = "getCompositeAccountFILIV2BeforeCreate")
    public void createCompositeAccountFILIV2()
    {
        accNum = filiAccountMap.get("accountNumber");
        context.put("accountNumber", accNum);
        context.put("source", filiAccountMap.get("sourceSystem"));
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", filiAccountMap.get("displayName"));
        context.put("mnemonic", filiAccountMap.get("mnemonic"));
        context.put("sourceSystem2", filiAccountMap.get("sourceSystem"));
        context.put("institutionName", filiAccountMap.get("institutionName"));
        context.put("value", filiAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", filiAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "111111.11");
        context.put("emergencyFundAmountValue", "111111.11");
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.177);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.0f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_PRAA);
        context.put("contribFreq", "YEARLY");
        context.put("contribValue", "500");
        context.put("contributionTaxType", "POST_TAX");
        context.put("contributionType", "CATCHUP");
        context.put("contributor", "EMPLOYER");
        context.put("contribBasisTypeCd", "BASE");
        context.put("contribFreq2", "BIMONTHLY");
        context.put("contribValue2", "900");
        context.put("contributionTaxType2", "AGGREGATE");
        context.put("contributionType2", "REGULAR");
        context.put("contributor2", "INDIVIDUAL");
        context.put("contribBasisTypeCd2", "BASEBONUS");
        context.put("withdrawAmount", "500");
        context.put("withdrawFreq", "HOURLY");
        context.put("riskTolerance", 2);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", 2055);
        context.put("withdrawalEndYear", 2085);
        context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
        context.put("equityPercent", 0.35);
        context.put("federalTaxWithholding", 0.15);
        context.put("stateTaxWithholding", 0.05);
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        request.log().ifValidationFails().body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(filiAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(filiAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(filiAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(filiAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(filiAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                                filiAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PCA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PEA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PRAA))
                .body(acctRoot + details + "complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
                .body(acctRoot + details + "emergencyFundAmount.value", equalTo(111111.11f))
                .body(acctRoot + details + "equityPercent", equalTo(0.35f))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "contributions" + catchupPath + ".contribBasisTypeCd", equalTo("BASE"))
                .body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
                .body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "contributions" + regularPath + ".contribBasisTypeCd", equalTo("BASEBONUS"))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(500.0f))
                .body(acctRoot + "withdrawals[0].amount.frequency", equalTo("HOURLY"));
        
        accountsCommonTestData
                .setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
    }
    
    /**
     * Description: Validates the account composite response after create
     */
    @Test(dependsOnMethods = "createCompositeAccountFILIV2")
    public void getCompositeAccountFILIV2AfterCreate()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", filiAccountMap.get("sourceSystem"));
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(filiAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(filiAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(filiAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(filiAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(filiAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                                filiAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details", notNullValue())
                .body(acctRoot + details + "emergencyFundAmount.value",
                        equalTo(111111.11f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PCA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PEA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PRAA))
                .body(acctRoot + details + "complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
                .body(acctRoot + details + "emergencyFundAmount.value", equalTo(111111.11f))
                .body(acctRoot + details + "equityPercent", equalTo(0.35f))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "contributions" + catchupPath + ".contribBasisTypeCd", equalTo("BASE"))
                .body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
                .body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "contributions" + regularPath + ".contribBasisTypeCd", equalTo("BASEBONUS"))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(500.0f))
                .body(acctRoot + "withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }
    
    /**
     * Description: Updates account composite
     */
    @Test(dependsOnMethods = "getCompositeAccountFILIV2AfterCreate")
    public void updateCompositeAccountFILIV2()
    {
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", filiAccountMap.get("accountNumber"));
        context.put("source", filiAccountMap.get("sourceSystem"));
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", filiAccountMap.get("displayName"));
        context.put("mnemonic", filiAccountMap.get("mnemonic"));
        context.put("sourceSystem2", filiAccountMap.get("sourceSystem"));
        context.put("institutionName", filiAccountMap.get("institutionName"));
        context.put("value", filiAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", filiAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "211111.11");
        context.put("emergencyFundAmountValue", "211111.11");
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.4f);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 1.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.70f);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.30f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_Updated_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_Updated_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
        context.put("contribValue", "600");
        context.put("contribFreq", "YEARLY");
        context.put("contribValue2", "700");
        context.put("contribFreq2", "BIMONTHLY");
        context.put("withdrawAmount", "1000");
        context.put("withdrawFreq", "HOURLY");
        context.put("riskTolerance", 3);
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_25_AND_50");
        context.put("withdrawalStartYear", 2056);
        context.put("withdrawalEndYear", 2086);
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("equityPercent", 0.25);
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        request.log().ifValidationFails().body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));
        
        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(filiAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(filiAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(filiAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(filiAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(filiAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                                filiAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "equityPercent", equalTo(0.25f))
                .body(acctRoot + details + "emergencyFundAmount.value", equalTo(211111.11f))
                .body(acctRoot + details + "complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PRAA))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(700.0f))
                .body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(3))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(1000.0f))
                .body(acctRoot + "withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }
    
    /**
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "updateCompositeAccountFILIV2")
    public void getCompositeAccountFILIV2AfterUpdate()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", filiAccountMap.get("sourceSystem"));
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(filiAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(filiAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(filiAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(filiAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(filiAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                                filiAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "equityPercent", equalTo(0.25f))
                .body(acctRoot + details + "complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body(acctRoot + details + "emergencyFundAmount.value", equalTo(211111.11f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                                equalTo(0.30f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PRAA))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(700.0f))
                .body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(3))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(1000.0f))
                .body(acctRoot + "withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }
    
    /**
     * Description: Delete the account
     */
    @Test(dependsOnMethods = "getCompositeAccountFILIV2AfterUpdate")
    public void deleteCompositeAccountFILIV2()
    {
        final VelocityContext context = new VelocityContext();
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", filiAccountMap.get("accountNumber"));
        context.put("source", filiAccountMap.get("sourceSystem"));
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", filiAccountMap.get("displayName"));
        context.put("mnemonic", filiAccountMap.get("mnemonic"));
        context.put("institutionName", filiAccountMap.get("institutionName"));
        context.put("value", filiAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", filiAccountMap.get("sourceMarketAsOfDate"));
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()));
        
        request.log().ifValidationFails().body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));
        
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);
        
        final String emptyResponse = response.jsonPath().getString("$");
        MatcherAssert.assertThat(emptyResponse, equalTo("[:]"));
    }
    
    /**
     * Description: Validates an empty account list when calling get account composite FILI after delete
     */
    @Test(dependsOnMethods = "deleteCompositeAccountFILIV2")
    public void getCompositeAccountFILIV2AfterDelete()
    {
        context.put("sourceBasedRegistrationFilter", filiAccountMap.get("sourceSystem"));
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Returns the response of retrieving a fili account
     *
     * @param accountsCommonTestData the test data
     * @return filiAccountMap
     */
    private static HashMap<String, String> getFiliAccountInformationV2(
            final AccountsCommonTestData accountsCommonTestData, final String oAuth)
    {
        final VelocityContext context = new VelocityContext();
        context.put("source", "FILI");
        
        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();
        
        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()));
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        
        final Response response = request.post(AccountsPaths.GET_ACCOUNT_V2);
        
        if (response.statusCode() != HTTPStatusCodes.STATUS_200)
        {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));
            
            return null;
        }
        
        final JsonPath filiAccountJP = response.jsonPath();
        
        final HashMap<String, String> filiAccountMap = new HashMap<>();
        filiAccountMap.put("accountNumber", filiAccountJP.getString("accountList[0].accountId.accountNumber"));
        filiAccountMap.put("sourceSystem", filiAccountJP.getString("accountList[0].accountId.sourceSystem"));
        filiAccountMap.put("displayName", filiAccountJP.getString("accountList[0].displayName"));
        filiAccountMap.put("mnemonic", filiAccountJP.getString("accountList[0].regCode.mnemonic"));
        filiAccountMap.put("institutionName", filiAccountJP.getString("accountList[0].institutionName"));
        filiAccountMap.put("sourceMarketAmountValue",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
        filiAccountMap.put("sourceMarketAmountValueType",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        filiAccountMap.put("sourceMarketAmountCurrency",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        filiAccountMap.put("sourceMarketAsOfDate",
                filiAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));
        
        return filiAccountMap;
    }
    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown()
    {
        testDataUtil.closeSQLiteConnection();
    }

}
