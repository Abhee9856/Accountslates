/*
 * Copyright 2024 FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.MatcherAssert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

/**
 * Class to test TAM is created successfully via UPDATE method.
 *
 * @author a631781
 */
@Test(groups = {Tags.MANUAL, Tags.COMPOSITE, Tags.V2})
public class Manual_Composite_V2_Update_TAM_Test extends PAPBaseServiceTest {
    /**
     * Constructor
     */
    protected Manual_Composite_V2_Update_TAM_Test() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    // Paths
    private String accountCompositeGetPath;

    private String accountCompositeCreatePath;

    private String accountCompositeUpdatePath;

    private String accountDeletePath;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Manual_Composite_V2_Update_TAM_Test.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;
    private static String tamName = "Balanced";
    private static float tamTotalEquity = 0.50F;
    private static float tamDomesticEquity = 0.35F;
    private static float tamForeignEquity = 0.15F;
    private static float tamBond = 0.40F;
    private static float tamCash = 0.10F;

    private static String tamCategory = "INVESTOR_SELECTED_STRATEGY";
    private static Integer tamRepositoryTamId = 178;
    private static Integer tamAssetAllocationId = 50;
    private final String details = "accounts[0].details.manualAccountDetail.";
    private VelocityContext context;

    /**
     * Initialization method used to: </br>
     * 1. Retrieve the oAuth token </br>
     * 2. Retrieve the test data from SQLite DB & set up any other test data </br>
     * 3. Set operation paths </br>
     * 4. Build partial contents of the velocity context
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();

        accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN, oAuth);
        accountsCommonTestData.setMid("ManualCompositeV2TestMid");
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        // Data setup
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");
        accountsCommonTestData.set("value", "52619.85");
        accountsCommonTestData.set("updatedValue", "62619.85");
        accountsCommonTestData.setMnemonic1("IRA");
        accountsCommonTestData.setDisplayName1("Manual Composite CRUD RestAssured");
        accountsCommonTestData.setInstitutionName1("RETAIL");
        accountsCommonTestData.setSourceSystem1("MANUAL");
        accountsCommonTestData.setPpid(
                String.valueOf(Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth)));

        // Set operation paths
        accountCompositeGetPath = AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2;
        accountCompositeCreatePath = AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2;
        accountCompositeUpdatePath = AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2;
        accountDeletePath = AccountsPaths.DELETE_ACCOUNT_V2;

        context = new VelocityContext();
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));

    }

    // Get Composite account before create
    @Test
    public void getCompositeAccountManualV2BeforeCreate() {
        // Generate request body
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts", hasSize(0));

    }

    //Create composite account
    @Test(dependsOnMethods = {"getCompositeAccountManualV2BeforeCreate"})
    public void createCompositeAccountManualV2() {
        // Generate request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.get("value"));
        context.put("detailValue", accountsCommonTestData.get("detailValue"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeCreatePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body(
                "accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                "accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                "accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                "accounts[0].account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                "accounts[0].account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()),
                "accounts[0].account.sourceMarketValue.amount.value", equalTo(Float.valueOf(accountsCommonTestData.get("value"))),
                details, notNullValue());

        // Save account number and ID
        accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
        accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
        accountsCommonTestData.set("asOfDate", response.path("accounts[0].account.sourceMarketValue.asOfDate"));
    }

    //Get composite account after create
    @Test(dependsOnMethods = "createCompositeAccountManualV2")
    public void getCompositeAccountManualV2AfterCreate() {
        //Generate request body
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeader("return-current-asset-allocation");
        frs.removeHeader("excludeExternalDataSources");

        this.request.header(new Header("excludeExternalDataSources", "true"));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                "accounts[0].account.accountId.accountNumber",
                equalTo(accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                equalTo(accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                equalTo(accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                equalTo(accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                equalTo(accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                equalTo(accountsCommonTestData.getInstitutionName1()),
                "accounts[0].account.sourceMarketValue.amount.value",
                equalTo(Float.valueOf(accountsCommonTestData.get("value"))),
                details + "state", equalTo("AK"));
    }

    //Create TAM via update call
    @Test(dependsOnMethods = "getCompositeAccountManualV2AfterCreate")
    public void updateCompositeAccountManualV2() {
        // Generate request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.get("updatedValue"));
        context.put("id", accountsCommonTestData.getAccountId1());
        context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
        context.put("TAM_name", tamName);
        context.put("TAM_total_equity", tamTotalEquity);
        context.put("TAM_domestic_equity", tamDomesticEquity);
        context.put("TAM_foreign_equity", tamForeignEquity);
        context.put("TAM_bond", tamBond);
        context.put("TAM_cash", tamCash);
        context.put("TAM_category", tamCategory);
        context.put("TAM_repositoryTamId", tamRepositoryTamId);
        context.put("TAM_assetAllocationId", tamAssetAllocationId);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeUpdatePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body(
                        "accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accounts[0].account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                        equalTo(accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedValue"))),
                        details + "accountDetail.costBasis.value", equalTo(Float.valueOf(accountsCommonTestData.get(
                                "updatedDetailValue"))),
                        details + "state", equalTo("AK"))
                .body(details + "accountDetail.targetAssetMixes[0].name", equalTo(tamName))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage", equalTo(tamTotalEquity))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage", equalTo(tamDomesticEquity))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage", equalTo(tamForeignEquity))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage", equalTo(tamBond))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage", equalTo(tamCash));

    }

    //Get composite account after update
    @Test(dependsOnMethods = "updateCompositeAccountManualV2")
    public void getCompositeAccountManualV2AfterUpdate() {
        //Generate request body
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                        "accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accounts[0].account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                        equalTo(accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedValue"))),
                        details + "accountDetail.costBasis.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedDetailValue"))),
                        details + "state", equalTo("AK"))
                .body(details + "accountDetail.targetAssetMixes[0].name", equalTo(tamName))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage", equalTo(tamTotalEquity))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage", equalTo(tamDomesticEquity))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage", equalTo(tamForeignEquity))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage", equalTo(tamBond))
                .body(details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage", equalTo(tamCash));

    }

    //Delete composite account
    @Test(dependsOnMethods = "getCompositeAccountManualV2AfterUpdate")
    public void deleteCompositeAccountManualV2() {
        //Generate request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("value", accountsCommonTestData.get("updatedValue"));
        context.put("asOfDate", accountsCommonTestData.get("asOfDate"));

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        // Make post request
        response = request.post(accountDeletePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = response.jsonPath().getString("$");
        MatcherAssert.assertThat(emptyResponse, equalTo("[:]"));
    }

    //Get composite account after delete
    @Test(dependsOnMethods = "deleteCompositeAccountManualV2")
    public void getCompositeAccountManualV2AfterDelete() {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.get("sourceSystem"));

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts", hasSize(0));
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}