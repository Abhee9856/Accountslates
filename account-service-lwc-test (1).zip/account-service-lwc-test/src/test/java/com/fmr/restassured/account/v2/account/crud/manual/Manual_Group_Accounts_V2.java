/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.crud.manual;

import static org.hamcrest.CoreMatchers.equalTo;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.GroupAccountsUtil;
import com.fmr.restassured.account.helpers.HouseholdGroupUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.HashMap;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;

/**
 * The class Account Manual_Group_Accounts_V2.
 *
 * @author a651454
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.ACCOUNT,
        Tags.V2,
        Tags.GROUP})
public class Manual_Group_Accounts_V2 extends PAPBaseServiceTest
{
    
    /** The accountsCommonTestData */
    private AccountsCommonTestData accountsCommonTestData;
    
    /** The testDataUtil */
    private TestDataUtil testDataUtil;
    
    /* The constant SCENARIO_CATEGORY_CODE */
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    
    /* The constant SCENARIO_PRODUCT_CODE */
    private static final String SCENARIO_PRODUCT_CODE = "WM";
    
    /* The constant LOG_TRACKING_ID */
    private static final String LOG_TRACKING_ID = Manual_Group_Accounts_V2.class.getSimpleName();
    
    /* The constant FSREQID */
    private static final String FSREQID = LOG_TRACKING_ID;
    
    /** The oAuth */
    private String oAuth;
    
    /** The ssn */
    private String ssn;
    
    /** The mid */
    private String mid;
    
    /** The grouId */
    private String groupId;
    
    /** The groupType */
    private String groupType = "APO_WM";
    
    /** The accountInfo */
    private HashMap<String, String> accountInfo = new HashMap<>();
    
    /** The context */
    private final VelocityContext context = new VelocityContext();
    
    /** The accountId */
    private String accountId;
    
    /** The constructor */
    protected Manual_Group_Accounts_V2()
    {
        super(Services.Account);
    }
    
    /**
     * Initialized data for each run.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);
        mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(mid);
        ssn = accountsCommonTestData.getSsn();
        
        //Set default REST header with authorization token
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");

        
        // Delete any existing groups for this user
        HouseholdGroupUtil.deleteExistingGroups(oAuth, ssn);
        
        // Create a new group
        response = HouseholdGroupUtil.createHouseholdGroup(oAuth, ssn, null, accountInfo);
        groupId = response.path("householdParties[0].household.groupId");
        
        //Create Principal with groupID
        HouseholdGroupUtil.createPrincipalWithGroupId(mid, groupId, groupType, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE, oAuth);
        
        //Create scenarioID with GroupID
        String scenarioId = (HouseholdGroupUtil.createScenarioWithGroupIdandType(mid, groupId, groupType, oAuth));
        
        //Set ppid
        accountsCommonTestData.setPpid(HouseholdGroupUtil.createHouseholdIdentityWithGroupIdandType(mid, groupId, groupType, scenarioId, oAuth));
        
        request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("scenario-id", scenarioId))
                .header(new Header("user-group-type", groupType))
                .header(new Header("user-group-id", groupId))
                .header(new Header("excludeExternalDataSources", "true"));
    
        request.filters(new RequestLoggingFilter(), new ResponseLoggingFilter());
    }
    
    /**
     * Create Manual Account V2
     */
    @Test
    private void createManualAccount()
    {
        context.put("id", null);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "IRA");
        context.put("value", 818.89f);
        context.put("asOfDate", "2014-10-31");
        context.put("source", "MANUAL");
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));
        
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);
        
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(818.89f));
        
        accountId = response.path("accountList[0].accountId.id");
    }
    
    /**
     * Validates if the manual account created has been added to the group in UCP.
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void validateAccountAddedToTheGroup()
    {
        Assert.assertTrue(GroupAccountsUtil.accountExistsInGroup(oAuth, groupId, groupType, accountId));
    }
    
    /**
     * Deletes the manual account.
     */
    @Test(dependsOnMethods = "validateAccountAddedToTheGroup")
    private void deleteManualAccount()
    {
        context.put("id", accountId);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "IRA");
        context.put("value", 818.89f);
        context.put("asOfDate", "2014-10-31");
        context.put("source", "MANUAL");
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));
        
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("isEmpty()", Matchers.is(true));
    }
    
    /**
     * Validates if the manual account created has been removed from the group in UCP.
     */
    @Test(dependsOnMethods = "deleteManualAccount")
    public void validateAccountRemovedFromTheGroup()
    {
        Assert.assertFalse(GroupAccountsUtil.accountExistsInGroup(oAuth, groupId, groupType, accountId));
    }
    
    /**
     * Close resources. Clean up data.
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
        HouseholdGroupUtil.deleteHouseholdGroup(groupId, oAuth);
        testDataUtil.closeSQLiteConnection();
    }
}
