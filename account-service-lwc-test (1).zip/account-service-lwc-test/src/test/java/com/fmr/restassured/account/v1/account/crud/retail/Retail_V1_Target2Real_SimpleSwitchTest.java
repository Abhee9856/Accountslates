/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDateTime;

import static org.hamcrest.Matchers.*;

/**
 * We convert retail account to real account as part of target account create when we have targetAccountIndicator as false and scenario category code POR. In this sceanrio, we are not currently returning the created account back as part of create response. We need to return the newly created account back as part of create response for Simple Switch Case sceanrio.
 * PFCP-18208
 *
 * @author a631781
 */
@Test(groups = {
        Tags.RETAIL,
        Tags.ACCOUNT,
        Tags.V1})
public class Retail_V1_Target2Real_SimpleSwitchTest extends PAPBaseServiceTest {

    protected Retail_V1_Target2Real_SimpleSwitchTest() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private final float fundingAccountAmount = 5.55f;

    private static final String displayNameTargetAct = "Simple Switch TargetAccount DisplayName V1";

    private static String targetAccountId;

    private final float unknownAmount = 20.0f;

    private String mid;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Retail_V1_Target2Real_SimpleSwitchTest.class.getSimpleName() + LocalDateTime.now();
    ;
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String SCENARIO_CATEGORY_CODE = "POR";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
     * endpoint for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();

        //Data Setup
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("retail_critical_regcode", oAuth);
        this.testDataUtil = new TestDataUtil();

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);

        //Set default REST header with authorization token
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");

        String ppid = Identity.createPrincipalWithScenario("mid", accountsCommonTestData.getMid(), SCENARIO_PRODUCT_CODE,
                SCENARIO_CATEGORY_CODE, oAuth);

        accountsCommonTestData.setPpid(ppid);

        String scenarioId = Scenario
                .createScenarioWithProductCode(accountsCommonTestData.getMid(), SCENARIO_PRODUCT_CODE,
                        SCENARIO_CATEGORY_CODE, oAuth);

        Identity.createHouseholdIdentityWithProductCode(accountsCommonTestData.getMid(), oAuth, SCENARIO_PRODUCT_CODE,
                SCENARIO_CATEGORY_CODE);
        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("source", AccountConstants.RETAIL);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);
    }

    /**
     * Get retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
                response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode) {
            Assert.assertEquals(dssResultCode, false);
        }

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
        accountsCommonTestData.setMnemonic2(response.path("accountList[1].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber2(response.path("accountList[1].accountId.accountNumber"));

    }

    /**
     * Create the retail account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount() {
        // Generate request body
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()),
                        "accountList[0].accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountList[0].accountId.owner.relationship", equalTo("PRINCIPAL"),
                        "accountList[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accountList[0].regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        "accountList[0].institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()));

        // Gets and saves the CFP account ID
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
    }

    /**
     * Create target account with targetAccountIndicator as false. Target account should return as real account.
     */
    @Test(dependsOnMethods = "createRetailAccount")
    public void createTargetAccount() {
        // Generate request body
        context.put("targetAccountNumber", accountsCommonTestData.getAccountNumber2());
        context.put("targetAccountSourceSystem", accountsCommonTestData.getSourceSystem1());
        context.put("targetAccountPpid", accountsCommonTestData.getPpid());
        context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("fundingAccountValue", String.valueOf(fundingAccountAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("category", "INVESTOR_SELECTED_STRATEGY");
        context.put("riskTolerance", "8");
        context.put("unknownAmount", String.valueOf(unknownAmount));
        context.put("targetAccountIndicator", "false");
        context.put("targetDisplayName", displayNameTargetAct);
        context.put("assetAllocation", "0.05");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()),
                        "accountList.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber2() + "'}.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber2()),
                        "accountList.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber2() + "'}.displayName", equalTo(displayNameTargetAct));
        targetAccountId = response.path("accountList.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber2() + "'}.accountId.id");
    }

    /**
     * Delete the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void deleteRetailAccount() {
        // Generate request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("accId", accountsCommonTestData.getAccountId1());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));
    }

    /**
     * Delete target account
     */
    @Test(dependsOnMethods = "deleteRetailAccount")
    public void deleteTargetAccount() {
        // Generate request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber2());
        context.put("accId", targetAccountId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }
}