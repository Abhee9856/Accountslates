/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasSize;

/**
 * Tests CRUD operations for Composite Account Suitability V1 for Retail accounts when riskTolerance is provided in the investment objective for Create and Update then service should return TAM(not RiskTolerance) based on the riskTolerance mapping.
 *
 * @author a631781
 * <p>
 * Test flow:
 * 1. Create Principal
 * 2. Search for Retail accounts owned by the Principal
 * 3. Get Composite account to validate composite retail account does not exist.
 * 4. Create then get Composite account suitability for the account created
 * 5. Update then get Composite account suitability created in step 4
 * 6. Delete the Compoiste account then get composite account to validate Retail account and
 * suitabililty were deleted
 */
@Test(groups = {Tags.RETAIL, Tags.ACCOUNT, Tags.V1})
public class Retail_Composite_InvestObjRiskTolerance_V1 extends PAPBaseServiceTest {
    /**
     * Constructor
     */
    protected Retail_Composite_InvestObjRiskTolerance_V1() {
        super(Services.Account);
    }

    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Retail_Composite_InvestObjRiskTolerance_V1.class);

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accNum;

    private String acctRoot;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    /**
     * Global variable holding retailAccount information
     */
    private HashMap<String, String> retailAccountMap;

    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountTestData;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Composite_InvestObjRiskTolerance_V1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String source = "RETAIL";
    private static final String investObjId = "26";
    private static final Integer investObjRiskTolerance = 8;
    private static final String tamName = "Aggressive Growth";
    private static final Integer investObjRiskToleranceUpdate = 9;
    private static final String tamNameUpdated = "Aggressive Growth";
    private String scenarioId;

    private VelocityContext context;


    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        retailAccountMap = new HashMap<>();

        accountTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);
        accountTestData.setMid("RetailCompositeV1TestMid");

        retailAccountMap = getRetailAccountInformation(accountTestData, oAuth);

        DataCleanup.deleteCustomerDataFromCP("mid", accountTestData.getMid(), oAuth, "true");

        final String ppid = Identity.createHouseholdIdentity(accountTestData.getMid(), oAuth);
        accountTestData.setPpid(ppid);
        // Get/Create ScenarioId
        Response allScenarioIDs = Scenario.getAllScenarios(accountTestData.getMid(), oAuth);
        scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null) {
            scenarioId = Scenario.createScenarioWithProductCode(accountTestData.getMid(), "IGE", "DEF",
                    oAuth);
        }
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
    }


    //Validates an empty account list when calling get account composite retail before creation of an account
    @Test
    public void getCompositeAccountRetailBeforeCreate() {
        if (retailAccountMap.isEmpty()) {
            throw new SkipException(
                    "'getCompositeAccountRetailBeforeCreate' test scenario cannot run due to failure to retrieve "
                            + "retail account information!");
        }

        context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", true);
        context.put("source", source);
        context.put("scenarioId", scenarioId);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    // Create the composite account suitability with investmentObjective riskTolerance.
    @Test(dependsOnMethods = "getCompositeAccountRetailBeforeCreate")
    public void createCompositeAccountRetail() {
        //Generate Request body
        accNum = retailAccountMap.get("accountNumber");
        context.put("externalDataSources", false);
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("accountNumber", accNum);
        context.put("source", source);
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", source);
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("investObj_riskTolerance", investObjRiskTolerance);
        context.put("investObj_Id", investObjId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_UPDATE_TEMPLATE_V1));

        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))));


        accountTestData.setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
    }

    //Validate Suitability TAM is saved in ICS.
    @Test(dependsOnMethods = "createCompositeAccountRetail")
    public void getCompositeAccountRetailAfterCreate() {
        //Generate Request body
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", false);
        context.put("source", source);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix", not(empty()))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name",
                        equalTo(tamName))
                .body(acctRoot + "suitability.investmentObjective.id", equalTo(investObjId));
    }

    // Update the suitability investmentObjective riskTolerance.
    @Test(dependsOnMethods = "getCompositeAccountRetailAfterCreate")
    public void updateCompositeAccountRetail() {
        //Generate Request body
        context.put("externalDataSources", false);
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", retailAccountMap.get("accountNumber"));
        context.put("source", source);
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", source);
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("investObj_riskTolerance", investObjRiskToleranceUpdate);
        context.put("investObj_Id", investObjId);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_UPDATE_TEMPLATE_V1));

        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);
        response.prettyPrint();
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix", not(empty()))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name",
                        equalTo(tamNameUpdated))
                .body(acctRoot + "suitability.investmentObjective.id", equalTo(investObjId));
    }

    //Validate updated Suitability TAM is saved in ICS.
    @Test(dependsOnMethods = "updateCompositeAccountRetail")
    public void getCompositeAccountRetailAfterUpdate() {
        //Generate Request body
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", false);
        context.put("source", source);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix", not(empty()))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name",
                        equalTo(tamNameUpdated))
                .body(acctRoot + "suitability.investmentObjective.id", equalTo(investObjId));
    }

    //Validates the account composite response after delete
    @Test(dependsOnMethods = "getCompositeAccountRetailAfterUpdate")
    public void deleteCompositeAccountRetail() {
        //Generate Request body
        context.put("externalDataSources", true);
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", retailAccountMap.get("accountNumber"));
        context.put("source", source);
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", source);
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accountList",
                hasSize(0));
    }

    //Get Call after Delete to validates an empty account list when calling get account composite retail after delete
    @Test(dependsOnMethods = "deleteCompositeAccountRetail")
    public void getCompositeAccountRetailAfterDelete() {
        //Generate Request body
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", true);
        context.put("source", source);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Returns the response of retrieving a retail account
     *
     * @param accountsCommonTestData the test data
     * @return retailAccountMap
     */
    private static HashMap<String, String> getRetailAccountInformation(
            final AccountsCommonTestData accountsCommonTestData, final String oAuth) {
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("source", "RETAIL");

        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();

        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        request.given().log().all();
        final Response response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        response.then().log().all();
        if (response.statusCode() != HTTPStatusCodes.STATUS_200) {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));

            return null;
        }

        final JsonPath retailAccountJP = response.jsonPath();

        final HashMap<String, String> retailAccountMap = new HashMap<>();
        retailAccountMap.put("accountNumber",
                retailAccountJP.getString("accountList[0].accountId.accountNumber"));
        retailAccountMap.put("sourceSystem",
                retailAccountJP.getString("accountList[0].accountId.sourceSystem"));
        retailAccountMap.put("displayName", retailAccountJP.getString("accountList[0].displayName"));
        retailAccountMap.put("mnemonic", retailAccountJP.getString("accountList[0].regCode.mnemonic"));
        retailAccountMap.put("institutionName", retailAccountJP.getString("accountList[0].institutionName"));
        retailAccountMap.put("sourceMarketAmountType",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount._type"));
        retailAccountMap.put("sourceMarketAmountValue",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
        retailAccountMap.put("sourceMarketAmountValueType",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        retailAccountMap.put("sourceMarketAmountCurrency",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        retailAccountMap.put("sourceMarketAsOfDate",
                retailAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));

        return retailAccountMap;
    }

    // Tear down method
    @AfterClass(alwaysRun = true)
    public void tearDown() {
        testDataUtil.closeSQLiteConnection();
    }
}