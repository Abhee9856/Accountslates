/*
 * Copyright 2018, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.crud.manual;

import static org.hamcrest.Matchers.equalTo;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.velocity.VelocityContext;
import org.hamcrest.CoreMatchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.http.Header;

/**
 * Tests CRUD operation for manual details against V2.
 *
 * @author a601767
 * Updated by a608077 on 10/13/2021 to include changes for 'scenario-id' header(PFCP-6168)
 * Updated by a631781 on 12/05/2022
 * Updated by a608077 on 10/11/2023 to include 3 new asset classes: Private Equity, Private Credit,
 *  and Real Assets(PFCP-13826)
 */
@Test(groups = {
		Tags.CRITICAL,
		Tags.MANUAL,
		Tags.DETAILS,
		Tags.V2, Tags.TAM})
public class Manual_Details_CRUD_V2 extends PAPBaseServiceTest
{

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private VelocityContext context;

    private final float value = 818.89f;

    private final float updatedValue = 426.85f;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private final Header eeds = new Header("excludeExternalDataSources", "true");

    // Velocity Keys
    private static final String IS_TRANSFER_TO_SURVIVOR_IND = "isTransferToSurvivorIndicator";

    private static final String VESTED_VALUE = "vestedValue";

    private static final String UNVESTED_VALUE = "unvestedValue";

    private static final String YEARS_REMAINING = "yearsRemaining";

    private static final String BENEFICIARY_AVAILABLE = "beneficiaryAvailable";

    private static final String COMPLEMENTARY_ADJUSTMENT_OPT = "complementaryAdjustmentOption";

    private static final String EQUITY_PERCENT = "equityPercent";

    private static final String FEDERAL_TAX_WITHHOLDING_PCT = "federalTaxWithholdingPercent";

    private static final String STATE_TAX_WITHHOLDING_PCT = "stateTaxWithholdingPercent";

    private static final String WITHDRAWAL_START_DATE = "withdrawalEligibilityStartDate";

    private static final String WITHDRAWAL_END_DATE = "withdrawalEligibilityEndDate";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Manual_Details_CRUD_V2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

	private final String originalOwnerBirthDate = "1960-11-30T00:00:00.000+0000";

    private final String originalOwnerDeceasedDate = "2022-12-30T00:00:00.000+0000";

	private final String tamAssetClass = "TOTAL_EQUITY";

	private final String assetClass = "TOTAL_EQUITY";

	private final float netPercentage = 1.0f;

	private final float netPercentageUpdated = 0.9f;

	private final String assetClass1 = "BOND";

	private final float netPercentage1 = 0.5f;

	private final float netPercentageUpdated1 = 0.2f;

	private final String assetClass2 = "CASH";

	private final float netPercentage2 = 0.3f;

	private final float netPercentageUpdated2 = 0.8f;

	private final String assetClass3 = "OTHER";

	private final float netPercentage3 = 0.4f;

	private final float netPercentageUpdated3 = 0.7f;
	private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
	private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
	private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
	private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
	private final float netPercentage_T_ALTERNATIVE = 0.8f;
	private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
	private final float netPercentage_PEA = 0.4f;
	private final float netPercentage_Updated_PEA = 0.2f;
	private final float netPercentage_PCA = 0.2f;
	private final float netPercentage_Updated_PCA = 0.3f;
	private final float netPercentage_PRAA = 0.2f;
	private final float netPercentage_Updated_PRAA = 0.1f;

	private static final String TRUSTEE_TYPE = "FPTC";
	private static final String TRUSTEE_TYPE_UPDATE = "ABCD";

	/**
     * Constructor.
     */
    protected Manual_Details_CRUD_V2()
    {
	super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
	String oAuthToken = AccountUtil.getOauthToken();

	accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_manual", oAuthToken);

	//Set default request headers
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);

	testDataUtil = new TestDataUtil();

		//= "ManualDetailsV2TestMid";
		String mid = accountsCommonTestData.getMid();
	accountsCommonTestData.setMid(mid);

	//Data cleanup
	DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuthToken);

	//Set ppid
	accountsCommonTestData.setPpid(Identity
			.createPrincipalWithScenario(AccountConstants.MID, mid, SCENARIO_PRODUCT_CODE,
					SCENARIO_CATEGORY_CODE, oAuthToken));

	String scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE,
			oAuthToken);

	Identity.createHouseholdIdentityWithProductCode(mid, oAuthToken, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE);

	//Set the regCode for this test
	accountsCommonTestData.setMnemonic1("IRA");
	accountsCommonTestData.set("isInherited", "false");
	accountsCommonTestData.set("isPreviousEmployersAccount", "false");
	accountsCommonTestData.set("state", "AK");
	accountsCommonTestData.setSourceSystem1("MANUAL");
	accountsCommonTestData.set(IS_TRANSFER_TO_SURVIVOR_IND, "true");
	accountsCommonTestData.set(VESTED_VALUE, "100.0");
	accountsCommonTestData.set(UNVESTED_VALUE, "200.0");
	accountsCommonTestData.set(YEARS_REMAINING, "10");
	accountsCommonTestData.set(BENEFICIARY_AVAILABLE, "true");
	accountsCommonTestData.set(COMPLEMENTARY_ADJUSTMENT_OPT, "MANAGED_LOCK_CURRENT_ALLOCATION");
	accountsCommonTestData.set(EQUITY_PERCENT, "0.8");
	accountsCommonTestData.set(FEDERAL_TAX_WITHHOLDING_PCT, "0.8");
	accountsCommonTestData.set(STATE_TAX_WITHHOLDING_PCT, "0.8");
	accountsCommonTestData.set(WITHDRAWAL_START_DATE, "2020-01-01T00:00:00.000+0000");
	accountsCommonTestData.set(WITHDRAWAL_END_DATE, "2020-01-01T00:00:00.000+0000");

	// Populate request variables
	context = new VelocityContext();
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("source", accountsCommonTestData.getSourceSystem1());
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", String.valueOf(value));
	context.put("isInherited", accountsCommonTestData.get("isInherited"));
	context.put("isPreviousEmployersAccount", accountsCommonTestData.get("isPreviousEmployersAccount"));
	context.put("state", accountsCommonTestData.get("state"));
	context.put(IS_TRANSFER_TO_SURVIVOR_IND, accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND));
	context.put(VESTED_VALUE, accountsCommonTestData.get(VESTED_VALUE));
	context.put(UNVESTED_VALUE, accountsCommonTestData.get(UNVESTED_VALUE));
	context.put(YEARS_REMAINING, accountsCommonTestData.get(YEARS_REMAINING));
	context.put(BENEFICIARY_AVAILABLE, accountsCommonTestData.get(BENEFICIARY_AVAILABLE));
	context.put(COMPLEMENTARY_ADJUSTMENT_OPT, accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT));
	context.put(EQUITY_PERCENT, accountsCommonTestData.get(EQUITY_PERCENT));
	context.put(FEDERAL_TAX_WITHHOLDING_PCT, accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT));
	context.put(STATE_TAX_WITHHOLDING_PCT, accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT));
	context.put(WITHDRAWAL_START_DATE, accountsCommonTestData.get(WITHDRAWAL_START_DATE));
	context.put(WITHDRAWAL_END_DATE, accountsCommonTestData.get(WITHDRAWAL_END_DATE));

	context.put("originalOwnerBirthDate", originalOwnerBirthDate);
		String originalOwnerSpouse = "false";
	context.put("originalOwnerSpouse", originalOwnerSpouse);
	context.put("originalOwnerDeceasedDate", originalOwnerDeceasedDate);
	context.put("tam_assetClass", assetClass);
		String tamName = "Short Term";
	context.put("tam_name", tamName);
	context.put("tamAssetClass", tamAssetClass);

	request.given()
			.header(new Header("user-poe", AccountConstants.RETAIL))
			.header(new Header("user-mid", accountsCommonTestData.getMid()))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
			//optional header scenario-id
			.header(new Header("scenario-id", scenarioId))
			.header(eeds);

    }

    /**
     * Create the manual account.
     * <p>
     * Version V2
     */
    @Test
    public void createManualAccount()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()));

	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("accId", accountsCommonTestData.getAccountNumber1());
    }

    /**
     * Validate the manual account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void getDetailsAfterCreateAccount()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()));
    }

    /**
     * Create the Account Details.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterCreateAccount")
    public void createAccountDetails()
    {
	// Generate request body
	context.put("assetClass", assetClass);
	context.put("netPercentage", netPercentage);
	context.put("assetClass1", assetClass1);
	context.put("netPercentage1", netPercentage1);
	context.put("assetClass2", assetClass2);
	context.put("netPercentage2", netPercentage2);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentage3);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA", netPercentage_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA", netPercentage_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA", netPercentage_PRAA);
		context.put("trusteeType", TRUSTEE_TYPE);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.costBasis.value",
					equalTo(value))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.manualAccountDetail.isInherited", equalTo(false))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.isTransferToSurvivorIndicator",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.vestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(VESTED_VALUE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.unvestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(UNVESTED_VALUE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.yearsRemaining",
					equalTo(Integer.valueOf(accountsCommonTestData.get(YEARS_REMAINING))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.beneficiaryAvailable",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(BENEFICIARY_AVAILABLE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.complementaryAdjustmentOption",
					equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.manualAccountDetail.accountDetail.trusteeType",
					equalTo(TRUSTEE_TYPE))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.equityPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(EQUITY_PERCENT))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.originalOwnerSpouse",
					equalTo(false))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					equalTo(assetClass))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					equalTo(netPercentage))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					equalTo(assetClass1))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					equalTo(netPercentage1))

			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					equalTo(assetClass2))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					equalTo(netPercentage2))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					equalTo(assetClass3))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					equalTo(netPercentage3))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" + accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_T_ALTERNATIVE))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PCA))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PEA))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PRAA));

    }

    /**
     * Validate the created manual account details.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.costBasis.value",
					equalTo(value))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.isInherited", equalTo(false))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.isTransferToSurvivorIndicator",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.vestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(VESTED_VALUE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.unvestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(UNVESTED_VALUE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.yearsRemaining",
					equalTo(Integer.valueOf(accountsCommonTestData.get(YEARS_REMAINING))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.beneficiaryAvailable",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(BENEFICIARY_AVAILABLE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.complementaryAdjustmentOption",
					equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.equityPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(EQUITY_PERCENT))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.originalOwnerBirthDate",
					equalTo(originalOwnerBirthDate))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.originalOwnerDeceasedDate",
					equalTo(originalOwnerDeceasedDate))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.originalOwnerSpouse",
					equalTo(false))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.trusteeType",
					equalTo(TRUSTEE_TYPE))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					equalTo(assetClass))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					equalTo(netPercentage))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					equalTo(assetClass1))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					equalTo(netPercentage1))

			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					equalTo(assetClass2))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					equalTo(netPercentage2))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					equalTo(assetClass3))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					equalTo(netPercentage3))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" + accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_T_ALTERNATIVE))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PCA))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PEA))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PRAA));
    }

    /**
     * Update the Account Details
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails()
    {
	// Update fields
	accountsCommonTestData.set("isInherited", "true");
	accountsCommonTestData.set("isPreviousEmployersAccount", "true");
	accountsCommonTestData.set("state", "NC");
	accountsCommonTestData.set(IS_TRANSFER_TO_SURVIVOR_IND, "false");
	accountsCommonTestData.set(VESTED_VALUE, "1000.0");
	accountsCommonTestData.set(UNVESTED_VALUE, "2000.0");
	accountsCommonTestData.set(YEARS_REMAINING, "5");
	accountsCommonTestData.set(BENEFICIARY_AVAILABLE, "false");
	accountsCommonTestData.set(COMPLEMENTARY_ADJUSTMENT_OPT, "MOVE_TO_MANAGED_ACCOUNT");
	accountsCommonTestData.set(EQUITY_PERCENT, "0.7");
	accountsCommonTestData.set(WITHDRAWAL_START_DATE, "2030-01-01T00:00:00.000+0000");
	accountsCommonTestData.set(WITHDRAWAL_END_DATE, "2030-01-01T00:00:00.000+0000");

	//Set new fields in Velocity
	context.put("isInherited", accountsCommonTestData.get("isInherited"));
	context.put("isPreviousEmployersAccount", accountsCommonTestData.get("isPreviousEmployersAccount"));
	context.put("state", accountsCommonTestData.get("state"));
	context.put("value", updatedValue);
	context.put(IS_TRANSFER_TO_SURVIVOR_IND, accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND));
	context.put(VESTED_VALUE, accountsCommonTestData.get(VESTED_VALUE));
	context.put(UNVESTED_VALUE, accountsCommonTestData.get(UNVESTED_VALUE));
	context.put(YEARS_REMAINING, accountsCommonTestData.get(YEARS_REMAINING));
	context.put(BENEFICIARY_AVAILABLE, accountsCommonTestData.get(BENEFICIARY_AVAILABLE));
	context.put(COMPLEMENTARY_ADJUSTMENT_OPT, accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT));
	context.put(EQUITY_PERCENT, accountsCommonTestData.get(EQUITY_PERCENT));
	context.put(WITHDRAWAL_START_DATE, accountsCommonTestData.get(WITHDRAWAL_START_DATE));
	context.put(WITHDRAWAL_END_DATE, accountsCommonTestData.get(WITHDRAWAL_END_DATE));
	context.put("assetClass", assetClass);
	context.put("netPercentage", netPercentageUpdated);
	context.put("assetClass1", assetClass1);
	context.put("netPercentage1", netPercentageUpdated1);
	context.put("assetClass2", assetClass2);
	context.put("netPercentage2", netPercentageUpdated2);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentageUpdated3);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA", netPercentage_Updated_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA", netPercentage_Updated_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
		context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_UPDATE_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.costBasis.value",
					equalTo(updatedValue))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.manualAccountDetail.isInherited", equalTo(true))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.isTransferToSurvivorIndicator",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.vestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(VESTED_VALUE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.unvestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(UNVESTED_VALUE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.yearsRemaining",
					equalTo(Integer.valueOf(accountsCommonTestData.get(YEARS_REMAINING))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.beneficiaryAvailable",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(BENEFICIARY_AVAILABLE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.complementaryAdjustmentOption",
					equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.equityPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(EQUITY_PERCENT))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.trusteeType",
					equalTo(TRUSTEE_TYPE_UPDATE))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					equalTo(assetClass))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					equalTo(netPercentageUpdated))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					equalTo(assetClass1))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					equalTo(netPercentageUpdated1))

			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					equalTo(assetClass2))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					equalTo(netPercentageUpdated2))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					equalTo(assetClass3))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					equalTo(netPercentageUpdated3))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" + accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_T_ALTERNATIVE))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PCA))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PEA))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PRAA));
    }

    /**
     * Update account Details with null
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetailsWithNull()
    {
	// Generate request body
	accountsCommonTestData.set("isInherited", "true");
	accountsCommonTestData.set("isPreviousEmployersAccount", "true");
	accountsCommonTestData.set("state", "NC");
	accountsCommonTestData.set(IS_TRANSFER_TO_SURVIVOR_IND, "false");
	accountsCommonTestData.set(VESTED_VALUE, "1000.0");
	accountsCommonTestData.set(UNVESTED_VALUE, "2000.0");
	accountsCommonTestData.set(YEARS_REMAINING, "5");
	accountsCommonTestData.set(BENEFICIARY_AVAILABLE, "false");
	accountsCommonTestData.set(COMPLEMENTARY_ADJUSTMENT_OPT, "MOVE_TO_MANAGED_ACCOUNT");
	accountsCommonTestData.set(EQUITY_PERCENT, "0.7");

	//Set new fields in Velocity
	context.put("isInherited", accountsCommonTestData.get("isInherited"));
	context.put("isPreviousEmployersAccount", accountsCommonTestData.get("isPreviousEmployersAccount"));
	context.put("state", accountsCommonTestData.get("state"));
	context.put("value", updatedValue);
	context.put(IS_TRANSFER_TO_SURVIVOR_IND, accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND));
	context.put(VESTED_VALUE, accountsCommonTestData.get(VESTED_VALUE));
	context.put(UNVESTED_VALUE, accountsCommonTestData.get(UNVESTED_VALUE));
	context.put(YEARS_REMAINING, accountsCommonTestData.get(YEARS_REMAINING));
	context.put(BENEFICIARY_AVAILABLE, accountsCommonTestData.get(BENEFICIARY_AVAILABLE));
	context.put(COMPLEMENTARY_ADJUSTMENT_OPT, accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT));
	context.put(EQUITY_PERCENT, accountsCommonTestData.get(EQUITY_PERCENT));

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_UPDATE_V2_NULL_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()),
					"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.withdrawalEligibilityStartDate",
					equalTo(accountsCommonTestData.get(WITHDRAWAL_START_DATE)),
					"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.withdrawalEligibilityEndDate",
					equalTo(accountsCommonTestData.get(WITHDRAWAL_END_DATE)))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.trusteeType",
					equalTo(TRUSTEE_TYPE_UPDATE));
    }

    /**
     * Validate the manual account was updated.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.costBasis.value",
					equalTo(updatedValue))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.isInherited", equalTo(true))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.isTransferToSurvivorIndicator",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.vestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(VESTED_VALUE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.unvestedValue.value",
					equalTo(Float.valueOf(accountsCommonTestData.get(UNVESTED_VALUE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.yearsRemaining",
					equalTo(Integer.valueOf(accountsCommonTestData.get(YEARS_REMAINING))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.beneficiaryAvailable",
					equalTo(Boolean.parseBoolean(
							accountsCommonTestData.get(BENEFICIARY_AVAILABLE))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.complementaryAdjustmentOption",
					equalTo(accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT)))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.equityPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(EQUITY_PERCENT))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))))
			.body(		"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.trusteeType",
					equalTo(TRUSTEE_TYPE_UPDATE))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
				+ accountsCommonTestData.getAccountNumber1()
				+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
				+ assetClass + "'}.assetClass",
				equalTo(assetClass))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
						+ accountsCommonTestData.getAccountNumber1()
						+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
						+ assetClass + "'}.netPercentage",
				equalTo(netPercentageUpdated))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
						+ accountsCommonTestData.getAccountNumber1()
						+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
						+ assetClass1 + "'}.assetClass",
				equalTo(assetClass1))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
						+ accountsCommonTestData.getAccountNumber1()
						+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
						+ assetClass1 + "'}.netPercentage",
				equalTo(netPercentageUpdated1))

			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
						+ accountsCommonTestData.getAccountNumber1()
						+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
						+ assetClass2 + "'}.assetClass",
				equalTo(assetClass2))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
						+ accountsCommonTestData.getAccountNumber1()
						+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
						+ assetClass2 + "'}.netPercentage",
				equalTo(netPercentageUpdated2))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
						+ accountsCommonTestData.getAccountNumber1()
						+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
						+ assetClass3 + "'}.assetClass",
				equalTo(assetClass3))
			.body(	"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
						+ accountsCommonTestData.getAccountNumber1()
						+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
						+ assetClass3 + "'}.netPercentage",
				equalTo(netPercentageUpdated3))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" + accountsCommonTestData.getAccountNumber1()
					+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
			CoreMatchers.equalTo(netPercentage_Updated_T_ALTERNATIVE))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PCA))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PEA))
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.id=='" +  accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PRAA));

    }

    /**
     * Delete the manual account.
     * Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteAccountDetails()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_DELETE_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()));

    }

    /**
     * Validate the manual account was deleted.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteAccountDetails")
    public void getDetailsAfterDelete()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountDetails.find{it.manualAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.manualAccountDetail.accountDetail.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}