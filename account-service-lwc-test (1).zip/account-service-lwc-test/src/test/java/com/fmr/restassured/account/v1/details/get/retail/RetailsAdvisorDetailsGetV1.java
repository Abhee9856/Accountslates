/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.get.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;

/**
 * Tests IOM-DASSNPRW for Advisor Account details against V1.
 *
 * @author a631781
 */
@Test(groups = {Tags.REGRESSION, Tags.RETAIL, Tags.DETAILS, Tags.V1})
public class RetailsAdvisorDetailsGetV1 extends PAPBaseServiceTest
{

    protected RetailsAdvisorDetailsGetV1()
    {
	super(Services.Account);
    }

    private final TestDataUtil testDataUtil = new TestDataUtil();

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private final String source = "RETAIL";

    private String mid;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();
	this.accountsCommonTestData =
			TestDataUtil.populateRegressionTestData("account_get_details_advisorDetails", oAuth);
	this.mid = Identity.getUserIdentifier("lid", this.accountsCommonTestData.getSsn(), oAuth).get("mid");
	this.accountsCommonTestData.setMid(this.mid);

	DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


	this.accountsCommonTestData
			.setPpid(Identity.createHouseholdIdentity("mid", this.accountsCommonTestData.getMid(), oAuth));

	this.setDefaultRequestHeaders(oAuth);

	// Populate request variables
	this.context = new VelocityContext();
	this.context.put("mid", this.accountsCommonTestData.getMid());
	this.context.put("retailLid", this.accountsCommonTestData.getSsn());
	this.context.put("source", this.source);
	this.context.put("ppid", this.accountsCommonTestData.getPpid());

    }

    /**
     * Validate analyticOptout and advisorRetailAccountDetail elements in the Get response
     * <p>
     * Version V1
     */
    @Test
    public void getAdvisorRetailAccountDetail()
    {
	// Generate request body
	this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
	// Assert on response
	this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	List<Boolean> analyticOptout =
			response.body().jsonPath().get("accountDetails.advisorRetailAccountDetail.analyticOptout");
	assertThat(analyticOptout, notNullValue());

    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	this.testDataUtil.closeSQLiteConnection();
    }
}