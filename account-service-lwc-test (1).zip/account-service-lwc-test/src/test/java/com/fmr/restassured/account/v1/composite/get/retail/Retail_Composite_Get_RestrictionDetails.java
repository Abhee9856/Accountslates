/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.get.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

/**
 * Tests Account Composite get operation for a retail account with restriction details.
 *
 * @author a608077
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.COMPOSITE,
		Tags.V1})
public class Retail_Composite_Get_RestrictionDetails extends PAPBaseServiceTest
{

    protected Retail_Composite_Get_RestrictionDetails()
    {
	super(Services.Account);
    }

    //Velocity Context
    private VelocityContext context;

    //Instance to the test data utility class
    private TestDataUtil testDataUtil;

    private String mid;// = "RetailCompositeV1TestMid";

    //Logging Details
    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Composite_Get_RestrictionDetails.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {

	final String oAuth = AccountUtil.getOauthToken();

	testDataUtil = new TestDataUtil();

	// Data setup
	final AccountsCommonTestData accountsCommonTestData = TestDataUtil
            .populateRegressionTestData("account_restrictionDetails_composite", oAuth);
	this.mid = accountsCommonTestData.getMid();
	accountsCommonTestData.setMid(this.mid);
	//Set default REST header with authorization token
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	//Data cleanup
	DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuth,"true");

	accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

	// Populate common variables for tests into context
	context = new VelocityContext();
	context.put("retailLid", accountsCommonTestData.getSsn());
	context.put("mid", accountsCommonTestData.getMid());
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("source", "RETAIL");
    }

    /**
     * Get retail account info from the backend. Save the account number.
     */
    @Test
    public void getCompositeAccountInfo()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	response.then().log().ifValidationFails().body("accounts[0].details.restrictionDetails", not(empty()))
			.body("accounts[0].details.restrictionDetails.find{it.code=='P1'}", notNullValue());

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}
