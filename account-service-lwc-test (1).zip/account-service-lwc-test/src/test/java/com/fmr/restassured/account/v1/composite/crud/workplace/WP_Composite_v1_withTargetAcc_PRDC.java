/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

/**
 * Tests Account Composite operation for a workplace account for PRDC Account numbers. Test will create,
 * update, and delete a composite account and run get requests before and after
 * each of those operations.
 *
 * @author a608077
 */
@Test(groups = { Tags.WORKPLACE, Tags.COMPOSITE, Tags.V1, Tags.TARGET_ACCOUNT,Tags.PRDC_DATA })
public class WP_Composite_v1_withTargetAcc_PRDC extends PAPBaseServiceTest {

	protected WP_Composite_v1_withTargetAcc_PRDC() {
		super(Services.Account);
	}

	private final float fundingAccountAmount = 5.55f;
	private final float updatedFundingAccountAmount = 6.78f;

	private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";
	private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";
	private static final String TARGET_ACCOUNT_NAME = "NewTargetAccount";

	private AccountsCommonTestData accountsCommonTestData;
    private String acctRoot;

	private static final String CALLING_APP_ID = "AP136091";
	private static final String APP_ID = "AP136091";
	private static final String LOG_TRACKING_ID = WP_Composite_v1_withTargetAcc_PRDC.class.getSimpleName();
	private static final String FSREQID = LOG_TRACKING_ID;

	private final float unknownAmount = 20.0f;
	private final float updatedUnknownAmount = 26.0f;

	// Context
	private VelocityContext context;

	// Financial Instrument IDs and their symbols
	private FinancialInstrumentIds finstIds;

	/**
	 * Initialization method used to: </br>
	 * 1. Get the default SSN and use it to retrieve the MID. </br>
	 * 2. Set the Base URI </br>
	 * 3. Get the account service operation paths. </br>
	 * 4. Build the request header (with OAuth token).
	 */
	@BeforeClass
	public void init() {
		String oAuth = AccountUtil.getOauthToken();
		accountsCommonTestData = TestDataUtil
				.populateRegressionTestData("account_composite_CRUD_allDetails_Workplace 2", oAuth);
        String mid = accountsCommonTestData.getMid();
		accountsCommonTestData.setMid(mid);

		// Data setup
		accountsCommonTestData.set("updatedAmount", "15000");
		accountsCommonTestData.set("withdrawAmount", "500");
		accountsCommonTestData.set("updatedWithdrawAmount", "1000");
		accountsCommonTestData.set("withdrawFreq", "YEARLY");
		accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
		accountsCommonTestData.set("detailValue", "42619.85");
		accountsCommonTestData.set("updatedDetailValue", "81819.89");

		// Resolve finstIds
		finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

		DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


		accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

		// Populate common variables for tests into context
		context = new VelocityContext();
		context.put("fescoLid", accountsCommonTestData.getSsn());
		context.put("mid", accountsCommonTestData.getMid());
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("source", "WORKPLACE");

		this.request.given().
                header(new Header("return-prdc-accounts", "true"));
	}

	/**
	 * Get retail account info from the backend. Save the account number.
	 */
	@Test
	public void getWorkplaceAccountInfo() {
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
				equalTo(true));

		accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
		accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
		accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
		accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
		accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
		accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
		accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
	}

	/**
	 * Get composite accounts for user.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "getWorkplaceAccountInfo")
	public void getCompositeAccount() {
		// Exclude external data
		context.put("externalDataSources", "true");

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Make post request
		response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true)).body("accounts", empty());

	}

	/**
	 * Create a new composite account. Save the account ID and account number.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = { "getCompositeAccount" })
	public void createCompositeAccount() {
		context.remove("externalDataSources");
		// Generate request body
        String accNum = accountsCommonTestData.getAccountNumber1();
		acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
		context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
		context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
		context.put("GBOND", finstIds.getFinstId("GBOND"));
		context.put("GCASH", finstIds.getFinstId("GCASH"));
		context.put("mnemonic", accountsCommonTestData.getMnemonic1());
		context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
		context.put("value", accountsCommonTestData.getValue1());
		context.put("accountNumber", accNum);
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		context.put("institutionName", accountsCommonTestData.getInstitutionName1());
		context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
		context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
		context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
		context.put("_type", AccountConstants.WORKPLACE_ACCOUNT_DETAILS_TYPE);
		context.put("type", AccountConstants.WORKPLACE_ACCOUNT_DETAILS);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

		// Make post request
		response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
				equalTo(true));

		// Save account number and ID
		accountsCommonTestData.setAccountId1(response.path(acctRoot + "account.accountId.id"));
	}

	/**
	 * Create target account
	 */
	@Test(dependsOnMethods = "createCompositeAccount")
	public void createTargetAccount() {
		context.remove("displayName");
		context.put("targetAccountSourceSystem", AccountConstants.RETAIL);
		context.put("targetAccountPpid", accountsCommonTestData.getPpid());
		context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
		context.put("fundingAccountValue", String.valueOf(fundingAccountAmount));
		context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
		context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
		context.put("category", "INVESTOR_SELECTED_STRATEGY");
		context.put("unknownAmount", String.valueOf(unknownAmount));

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount", Matchers.equalTo(unknownAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
				.body("targetAccounts[0].targetAssetMixes[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"));

		accountsCommonTestData.set(TARGET_ACCOUNT_NUMBER_KEY,
				response.path("targetAccounts[0].accountId.accountNumber"));
		accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
	}

	/**
	 * Gets composite account and verifies there is content in the response.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "createTargetAccount")
	public void getCompositeAccountAfterCreate() {
		// Generate request body
		context.put("source", null);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Make post request
		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true))
				.body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
				.body(acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
				.body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
				.body(acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
				.body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
				.body(acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()))
				.body(acctRoot + "account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()))
				.body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()))
				.body(acctRoot
						+ "suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
						equalTo(0f))
				.body(acctRoot
						+ "suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='BOND'}.netPercentage.value",
						equalTo(0f))
				.body(acctRoot
						+ "suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='CASH'}.netPercentage.value",
						equalTo(0f))
				.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
				.body(acctRoot + "withdrawals[0].amount.amount.value",
						equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))))
				.body(acctRoot + "withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("withdrawFreq")))
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount", Matchers.equalTo(unknownAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
				.body("targetAccounts[0].targetAssetMixes[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"));
	}

	/**
	 * Update target account
	 */
	@Test(dependsOnMethods = "getCompositeAccountAfterCreate")
	public void updateTargetAccount() {
		context.put("fundingAccountValue", String.valueOf(updatedFundingAccountAmount));
		context.put("targetAccountSourceMarketValue", String.valueOf(updatedFundingAccountAmount));
		context.put(TARGET_ACCOUNT_NUMBER_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
		context.put(TARGET_ACCOUNT_ID_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
		context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
		context.put("category", "FINAL");
		context.put("unknownAmount", String.valueOf(updatedUnknownAmount));

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(updatedFundingAccountAmount))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount", Matchers.equalTo(updatedUnknownAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
				.body("targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"));

	}

	/**
	 * Runs an update on the new account and verifies content in the response.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "updateTargetAccount")
	public void updateCompositeAccount() {
		context.remove("displayName");
		// Populate variables for tests into context
		context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
		context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
		context.put("accId", accountsCommonTestData.getAccountId1());

		// Generate request body
		context.put("source", AccountConstants.WORKPLACE);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE));

		// Make post request
		response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));
	}

	/**
	 * Gets the composite accounts and verifies that content is still coming back.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "updateCompositeAccount")
	public void getCompositeAccountAfterUpdate() {
		// Generate request body
		context.put("source", null);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Make post request
		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true))
				.body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
				.body(acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
				.body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
				.body(acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
				.body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
				.body(acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()))
				.body(acctRoot + "account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()))
				.body(acctRoot
						+ "suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
						equalTo(0f))
				.body(acctRoot
						+ "suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='BOND'}.netPercentage.value",
						equalTo(0f))
				.body(acctRoot
						+ "suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='CASH'}.netPercentage.value",
						equalTo(0f))
				.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
				.body(acctRoot + "withdrawals[0].amount.amount.value",
						equalTo(Float.valueOf(accountsCommonTestData.get("updatedWithdrawAmount"))))
				.body(acctRoot + "withdrawals[0].amount.frequency",
						equalTo(accountsCommonTestData.get("updatedWithdrawFreq")))
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(updatedFundingAccountAmount))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount", Matchers.equalTo(updatedUnknownAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
				.body("targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"));
	}

	/**
	 * Delete the composite account that we created. Verify the account list is
	 * empty.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "getCompositeAccountAfterUpdate")
	public void deleteCompositeAccount() {
		// Generate request body
		context.put("source", AccountConstants.WORKPLACE);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

		// Make post request
		response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true)).body("accountList", empty());
	}

	/**
	 * Call delete and confirm that no accounts come back in the response.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "deleteCompositeAccount")
	public void getCompositeAccountAfterDelete() {
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Make post request
		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accounts[0].account.accountId.id", nullValue());
	}

}
