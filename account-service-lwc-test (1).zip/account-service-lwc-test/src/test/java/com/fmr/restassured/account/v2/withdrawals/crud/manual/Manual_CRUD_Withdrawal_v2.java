/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.withdrawals.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsWithdrawalsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.WithdrawalsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountWithdrawalsTestData;

import io.restassured.http.Header;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Tests CRUD operation for manual withdrawals against V2.
 *
 * @author a608077
 * updated by a631781
 */
@Test(groups = {
        Tags.CRITICAL,
        Tags.MANUAL,
        Tags.WITHDRAWALS,
        Tags.V2,
        "PFCP-3071"})

public class Manual_CRUD_Withdrawal_v2 extends PAPBaseServiceTest {


    // Data setup
    private AccountsCommonTestData accountsCommonTestData ;

    private String accountNumber;
    private String accountId;

    private VelocityContext context;

    private static final String LOG_TRACKING_ID = Manual_CRUD_Withdrawal_v2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private TestDataUtil testDataUtil;

    protected Manual_CRUD_Withdrawal_v2() {
        super(Services.Account);
    }


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("accountCRUD_Manual",oAuth);
        String mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");

        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth));

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", mid))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("scenario-category-code", "DEF"));

        context = new VelocityContext();
        context.put("source", "MANUAL");

    }

    /**
     * Create a manual account
     */
    @Test
    public void createManualAccount() {
        float value = 818.89f;
        context.put("pointOfEntry", "RETAIL");
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "IRA");
        context.put("value", value);
        String asOfDate1 = "2014-10-31";
        context.put("asOfDate", asOfDate1);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        context.put("accId", accountId);
        context.put("accountNumber", accountNumber);

    }

    /**
     * Tests that account data is brought back for manual account.
     * Version V2
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void verifyAfterCreate() {

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Set URL to V2 before running again
        response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        String sourceSystem = "MANUAL";
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", Matchers.not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", Matchers.equalTo(sourceSystem));


    }


    /**
     * The is the test flow. It iterates through the data provider, performing CRUD operations for each use case.
     *
     * @param data the test cases
     */
    @Test(dependsOnMethods = "createManualAccount", dataProvider = "getManualWithdrawalData",
            dataProviderClass = WithdrawalsDataProviderUtil.class)

    public void performCrudOperations(final AccountWithdrawalsTestData data) {
        this.createAccountWithdrawals(data);
        this.getWithdrawalsAfterCreate(data);
        this.updateAccountWithdrawals(data);
        this.getWithdrawalsAfterUpdate(data);
        this.deleteAccountWithdrawals(data);
        this.getWithdrawalsAfterDelete();
    }

    /**
     * Create the account withdrawals.
     */
    private void createAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("accountNumber", accountNumber);
        context.put("withdrawalType", data.getType());
        context.put("withdrawalValue", data.getAmountValue());
        context.put("valueType", data.getAmountValueType());
        context.put("frequency", data.getFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_V2_TEMPLATE))
                .log().ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()))
                .body("accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.withdrawalType", equalTo(data.getType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.frequency", equalTo(data.getFrequency()));

    }

    /**
     * Validate the withdrawals.
     */
    private void getWithdrawalsAfterCreate(final AccountWithdrawalsTestData data) {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.withdrawalType", equalTo(data.getType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.frequency", equalTo(data.getFrequency()));

    }

    /**
     * Update the withdrawal.
     */
    private void updateAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("withdrawalType", data.getUpdatedType());
        context.put("withdrawalValue", data.getUpdatedAmountValue());
        context.put("valueType", data.getUpdatedAmountValueType());
        context.put("frequency", data.getUpdatedFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_UPDATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.UPDATE_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.withdrawalType", equalTo(data.getUpdatedType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getUpdatedAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.frequency", equalTo(data.getUpdatedFrequency()));
    }

    /**
     * Validate the withdrawal was updated.
     */
    private void getWithdrawalsAfterUpdate(final AccountWithdrawalsTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.withdrawalType", equalTo(data.getUpdatedType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.value", equalTo(Float.valueOf(data.getUpdatedAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.frequency", equalTo(data.getUpdatedFrequency()));

    }

    /**
     * Delete the withdrawal
     */
    private void deleteAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("withdrawalType", data.getUpdatedType());
        context.put("withdrawalValue", data.getUpdatedAmountValue());
        context.put("valueType", data.getUpdatedAmountValueType());
        context.put("frequency", data.getUpdatedFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_DELETE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.DELETE_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                // No accounts are returned
                .body("isEmpty()", Matchers.is(true));

    }

    /**
     * Validate the withdrawals were deleted.
     */
    private void getWithdrawalsAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                // No accounts are returned
                .body("isEmpty()", Matchers.is(true));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
