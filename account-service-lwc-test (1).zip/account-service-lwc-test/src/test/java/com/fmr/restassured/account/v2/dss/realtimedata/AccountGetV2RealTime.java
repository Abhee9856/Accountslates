/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.dss.realtimedata;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.MatcherAssert;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Test Account Get operation with real time data from DSS Accounts API
 *
 * @author a631781
 * <p>
 * Updated by a608077 on 09/13/2022 to include changes for clear-retail-cache flag(PFCP-10001)
 * <p>
 * Updated by a608077 on 05/08/2023 to remove unsettled balances when RealTimeData flag is not true(PFCP-12703)
 */

@Test(groups = {Tags.REAL_TIME_DATA, Tags.V2})
public class AccountGetV2RealTime extends PAPBaseServiceTest
{

    protected AccountGetV2RealTime()
    {
	super(Services.Account);
    }

    private VelocityContext context;

    public String mid;

    public String ssn;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String APP_NAME = "Advice and Planning Platform";

    private static final String LOG_TRACKING_ID = AccountGetV2RealTime.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private FilterableRequestSpecification frs;

    private final String oAuth = AccountUtil.getOauthToken();

    private String accNumber;

    private float value;

    public static final String ACCOUNT_CATEGORY = "Brokerage";

    private String accountAsOfDateTime;

    private Integer dssAsOFDate;

    private TestDataUtil testDataUtil;

    @BeforeTest
    public void init()
    {
	AccountsCommonTestData accountsCommonTestData = TestDataUtil
			.populateRegressionTestData("account_get_Retail_DSS_gainlossbalancedetail", oAuth);

	this.ssn = accountsCommonTestData.getSsn();
	mid = accountsCommonTestData.getMid();

	this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);
	DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


	frs = (FilterableRequestSpecification) request;

	testDataUtil = new TestDataUtil();

	this.request.given().header(new Header("user-poe", "RETAIL"))
			.header(new Header("user-retail-lid", this.ssn));

	context = new VelocityContext();
	context.put("source", AccountConstants.RETAIL);

    }

    /**
     * Tests that DSS service data is brought back for all account.
     */
    @Test
    public void getAccounts_V2_DSS()
    {

	frs.removeHeaders();
	this.setDefaultRequestHeadersForDSS();

	context.put("acctCategory", ACCOUNT_CATEGORY);
	context.put("returnAccountGainLossBalanceDetail", "true");

	this.request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DSS_BALANCE_V2_TEMPLATE));

	response = this.request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
			.body("acctDetails", not(emptyArray()))
			.body("acctDetails[0].acctNum", notNullValue())
			.body("acctDetails[0].gainLossBalanceDetail.totalMarketVal", notNullValue())
			.body("acctDetails[0].acctType", equalTo(ACCOUNT_CATEGORY));

	accNumber = this.response.path("acctDetails[0].acctNum");
	value = this.response.path("acctDetails[0].gainLossBalanceDetail.totalMarketVal");
	dssAsOFDate = this.response.path("acctDetails[0].gainLossBalanceDetail.asOfDateTime");

    }

    /**
     * Get account call with realTimeData=true Version V2
     */
    @Test(dependsOnMethods = "getAccounts_V2_DSS")
    public void getAccounts_V2RealTimeDataTrue()
    {

	frs.removeHeaders();
	this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

	this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);

	this.request.header(new Header("user-poe", "RETAIL"))
			.header(new Header("scenario-category-code", "DEF"))
			.header(new Header("scenario-product-code", "IGE"))
			.header(new Header("user-retail-lid", this.ssn))
			.header(new Header("realTimeData", "true"))
			.header(new Header("clear-retail-cache", "true"));

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200).body("accountList", not(emptyArray()))
			.body("accountList[0].accountId.accountNumber", not(emptyArray()))
			.body("accountList.find{it.accountId.accountNumber=='" + accNumber
					+ "'}.accountId.accountNumber", equalTo(accNumber))
			.body("accountList.find{it.accountId.accountNumber=='" + accNumber
					+ "'}.accountId.sourceSystem", equalTo(AccountConstants.RETAIL));
	Float dssTotalMarketValue = response.path("accountList.find{it.accountId.accountNumber=='" + accNumber
			+ "'}.sourceMarketValue.amount.value");
	assertThat(dssTotalMarketValue).isCloseTo(value, within(value * 0.01f));
	accountAsOfDateTime = this.response.path("accountList.find{it.accountId.accountNumber=='" + accNumber
			+ "'}.sourceMarketValue.asOfDate");
	validateDate();
    }

    /*
     * Get account call with realTimeData=false
     */
    @Test(dependsOnMethods = "getAccounts_V2_DSS")
    public void getAccounts_V2RealTimeDataFalse()
    {

	frs.removeHeaders();
	this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

	this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);

	this.request.header(new Header("user-poe", "RETAIL"))
			.header(new Header("scenario-category-code", "DEF"))
			.header(new Header("scenario-product-code", "IGE"))
			.header(new Header("user-retail-lid", this.ssn))
			.header(new Header("realTimeData", "false"))
			.header(new Header("clear-retail-cache", "true"));

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200).body("accountList", not(emptyArray()))
			.body("accountList[0].accountId.accountNumber", not(emptyArray()))
			.body("accountList.find{it.accountId.accountNumber=='" + accNumber
					+ "'}.accountId.accountNumber", equalTo(accNumber))
			.body("accountList.find{it.accountId.accountNumber=='" + accNumber
					+ "'}.accountId.sourceSystem", equalTo(AccountConstants.RETAIL));
    }

    private void validateDate()
    {

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.ENGLISH);

	String dssAsOfDateTime = AccountUtil.parseDSSDate(dssAsOFDate.longValue());

	ZonedDateTime formattedDateDSS = ZonedDateTime.parse(dssAsOfDateTime, formatter);

	String DSSDateValue = dssAsOfDateTime.substring(0, 10);
	String AccountDateValue = accountAsOfDateTime.substring(0, 10);

	ZonedDateTime formattedDateAccount = ZonedDateTime.parse(accountAsOfDateTime, formatter);

	/*
	 * Validations on Date and Time
	 */
	Assert.assertEquals(accountAsOfDateTime.length() - 15, dssAsOfDateTime.length() - 15);

	// Validates the date
	Assert.assertEquals(DSSDateValue, AccountDateValue);

	// Validates the second of time is within a range of 60second of DSS(Added for clear-cache-retail flag)
	MatcherAssert.assertThat(formattedDateAccount.getSecond(),
			is(both(greaterThan(formattedDateDSS.getSecond() - 60))
					.and(lessThan(formattedDateDSS.getSecond() + 60))));

    }

    private void setDefaultRequestHeadersForDSS()
    {
	this.request.given().header(new Header("AppId", "AP106532")).header(new Header("fsreqid", FSREQID))
			.header(new Header("Authorization", oAuth)).header(new Header("AppName", APP_NAME))
			.header(new Header("rtazlid", this.ssn))
			.header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
			.header(new Header("FACSC", "ROLE=FidCust"))
			.header(new Header("Content-Type", "application/json"));
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown()
    {
	this.testDataUtil.closeSQLiteConnection();
    }
}
