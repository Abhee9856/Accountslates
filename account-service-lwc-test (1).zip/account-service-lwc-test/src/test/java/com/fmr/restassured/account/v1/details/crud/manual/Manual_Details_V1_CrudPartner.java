/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.manual;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.equalTo;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.constants.TestDataConstants;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.Map;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operations of account details V1 for Manual Accounts owned by Partner.
 *
 * @author a560878
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.DETAILS,
        Tags.V1})

public class Manual_Details_V1_CrudPartner extends PAPBaseServiceTest {

    Logger logger = LogManager.getLogger(getClass());

    protected Manual_Details_V1_CrudPartner() {
        super(Services.Account);
    }

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private String ppid;

    private String partPid;

    private VelocityContext context;

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Manual_Details_V1_CrudPartner.class.getSimpleName();

    private static final String fsreqid = logTrackingId;

    // Test data
    private String mid;

    private String accId;

    private String sourceSystem = "MANUAL";

    private String nickName = "RA";

    private String displayName = "Rest Assured Partner Manual Account";

    private String asOfDate;

    private float value = 818.89f;

    private final float updatedValue = 426.85f;

    private final Map<String, String> accNumberAccIdMap = new TreeMap<>();

    private String accNum;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        this.p2TestDataUtil = new TestDataUtil();

        final String oAuth = AccountUtil.getOauthToken();
        this.accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_FILI, oAuth);
        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


        this.ppid = Identity.createHouseholdIdentity(this.accountsCommonTestData.getMid(), oAuth);
        // Data setup
        this.partPid = Identity.createHouseholdIdentity(this.accountsCommonTestData.getMid(), this.ppid, TestDataConstants.HH_PARTNER,
                oAuth);
        this.accountsCommonTestData.setPpid(this.partPid);

        // Endpoint setup
        setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("source", sourceSystem);
        context.put("poe", "RETAIL");

    }

    /**
     * Creates a new Manual account
     * <p>
     * Version V1
     */
    @Test
    public void createManualAccount() {

        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("mnemonic", "ANNDEF");
        this.context.put("value", this.value);
        this.context.put("nickName", this.nickName);
        this.context.put("displayName", this.displayName);
        this.context.put("asOfDate", this.asOfDate);
        this.context.put("relationship", TestDataConstants.HH_PARTNER);

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("accountList[0].accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()))
                .body("accountList[0].accountId.owner.relationship", equalTo(TestDataConstants.HH_PARTNER))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

        this.accId = this.response.path("accountList[0].accountId.id");
        this.accNum = this.response.path("accountList[0].accountId.accountNumber");

        if (null != this.accId) {
            this.accNumberAccIdMap.put(this.accNum, this.accId);
        }

    }

    /**
     * Create Manual account Details Request.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void createAccountDetails() {
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("relationship", TestDataConstants.HH_PARTNER);
        this.context.put("value", this.value);
        this.context.put("accountNumber", this.accNum);
        this.context.put("accId", this.accId);
        this.context.put("isInherited", false);
        this.context.put("isPreviousEmployersAccount", false);
        this.context.put("state", "NC");
        this.context.put("type", "ManualAccountDetails");
        this.context.put("_type", "ManualAccountDetails");

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.id", equalTo(this.accId))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.accountNumber", equalTo(this.accNum))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.owner.relationship", equalTo(TestDataConstants.HH_PARTNER))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

    }

    /**
     * Validate the Manual account details after create.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate() {
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("accountNumber", this.accNum);
        this.context.put("accId", this.accId);
        this.context.put("relationship", TestDataConstants.HH_PARTNER);

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
                "accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.accountNumber", equalTo(accNum), "accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.id",
                equalTo(accId), "accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.sourceSystem", equalTo("MANUAL"));

    }

    /**
     * Update the account details for Manual account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails() {

        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("relationship", TestDataConstants.HH_PARTNER);
        this.context.put("value", this.updatedValue);
        this.context.put("accountNumber", this.accNum);
        this.context.put("accId", this.accId);
        this.context.put("isInherited", true);
        this.context.put("isPreviousEmployersAccount", true);
        this.context.put("state", "NC");
        this.context.put("type", "ManualAccountDetails");
        this.context.put("_type", "ManualAccountDetails");

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.id", equalTo(this.accId))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.accountNumber", equalTo(this.accNum))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()))
                .body("accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.owner.relationship", equalTo(TestDataConstants.HH_PARTNER))
                .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

    }

    /**
     * Validate the updated Manual account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate() {
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("accountNumber", this.accNum);
        this.context.put("accId", this.accId);
        this.context.put("relationship", TestDataConstants.HH_PARTNER);

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
                "accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.accountNumber", equalTo(accNum), "accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.id",
                equalTo(accId), "accountDetails.find{it.accountId.id=='" + this.accId + "'}.accountId.sourceSystem", equalTo("MANUAL"));

    }

    /**
     * Delete the Manual account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteAccountDetails() {
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("accountNumber", this.accNum);
        this.context.put("accId", this.accId);

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("userIdentifier.mid",
                equalTo(this.accountsCommonTestData.getMid()));

    }

    /**
     * Validate the Manual account was deleted.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccountDetails")
    public void getDetailsAfterDelete() {
        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()), "accountDetails.find{it.accountId.id=='" + this.accId + "'}.costBasis",
                nullValue());

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        this.p2TestDataUtil.closeSQLiteConnection();
    }

}
