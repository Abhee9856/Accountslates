package com.fmr.restassured.account.v1.composite.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.empty;

@Test(groups = {Tags.MANUAL, Tags.COMPOSITE, Tags.V1, Tags.TAM})
public class Manual_Composite_v1_AssetAllocation_POR extends PAPBaseServiceTest {
    private AccountsCommonTestData accountsCommonTestData;
    private String oAuth;

    // Paths
    private String accountCompositeGetPath;

    private String accountCompositeCreatePath;

    private String accountCompositeUpdatePath;

    private String accountDeletePath;
    private static String scenarioId;

    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
    private final float netPercentage_T_ALTERNATIVE = 0.8f;
    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
    private final float netPercentage_PEA = 0.4f;
    private final float netPercentage_Updated_PEA = 0.2f;
    private final float netPercentage_PCA = 0.2f;
    private final float netPercentage_Updated_PCA = 0.3f;
    private final float netPercentage_PRAA = 0.2f;
    private final float netPercentage_Updated_PRAA = 0.1f;
    private static final String SCENARIO_PRODUCT_CODE="WM";
    private static final String SCENARIO_CATEGORY_CODE="POR";

    // Context
    private VelocityContext context;
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    // Financial Instrument IDs and their symbols
    private FinancialInstrumentIds finstIds;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Manual_Composite_v1_AssetAllocation_POR.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    //Start and End years for accountPreferencesIA - both should be greater than the current year.
    int startYear = ZonedDateTime.now().plusYears(1).getYear();
    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    final String catchupPath = ".contributions.find{it.contributionType=='CATCHUP'}";
    final String regularPath = ".contributions.find{it.contributionType=='REGULAR'}";
    /**
     * Constructor
     */
    protected Manual_Composite_v1_AssetAllocation_POR() {
        super(Services.Account);
    }

    /**
     * Initialization method used to: </br>
     * 1. Retrieve the oAuth token </br>
     * 2. Retrieve the test data from SQLite DB & set up any other test data </br>
     * 3. Set operation paths </br>
     * 4. Build partial contents of the velocity context
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {

        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();

        accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN, oAuth);
        accountsCommonTestData.setMid("ManualCompositeV1TestMid");
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


        // Create Principal
        Identity.createPrincipal(accountsCommonTestData.getMid(), oAuth);
        //Create Scenario
        scenarioId = Scenario.createScenarioWithProductCode(this.accountsCommonTestData.getMid(),
                SCENARIO_PRODUCT_CODE,SCENARIO_CATEGORY_CODE,oAuth);

        //Insert Household Identity
        this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentityWithProductCode(accountsCommonTestData.getMid(),
                oAuth,SCENARIO_PRODUCT_CODE,SCENARIO_CATEGORY_CODE));

        // Data setup
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("contribFreq", "YEARLY");
        accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        accountsCommonTestData.set("contribValue", "6000.0");
        accountsCommonTestData.set("updatedContribAmount", "500.0");
        accountsCommonTestData.set("withdrawAmount", "500.0");
        accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
        accountsCommonTestData.set("withdrawFreq", "YEARLY");
        accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");
        accountsCommonTestData.setMnemonic1("IRA");
        accountsCommonTestData.setDisplayName1("Manual Composite CRUD RestAssured");
        accountsCommonTestData.setInstitutionName1("Manual Institution");
        accountsCommonTestData.setSourceSystem1("MANUAL");
        accountsCommonTestData.setPpid(
                String.valueOf(Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth)));

        // Resolve finstIds
        finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

        // Set operation paths
        accountCompositeGetPath = AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1;
        accountCompositeCreatePath = AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1;
        accountCompositeUpdatePath = AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1;
        accountDeletePath = AccountsPaths.DELETE_ACCOUNT_V1;

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", "MANUAL");
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
    }

    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates an empty account list when calling get account composite manual before creation of an
     * account (v1)
     */
    @Test
    public void getCompositeAccountManualBeforeCreate() {
        // Exclude external data
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "accounts", empty());

    }

    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after create
     */
    @Test(dependsOnMethods = {"getCompositeAccountManualBeforeCreate"})
    public void createCompositeAccountManual() {
        // Generate request body
        context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", finstIds.getFinstId("GBOND"));
        context.put("GCASH", finstIds.getFinstId("GCASH"));
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("withdrawAmount", "2000");
        context.put("withdrawFreq", "BIMONTHLY");
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.177);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.0f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_PRAA);
        context.put("_type", AccountConstants.MANUAL_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.MANUAL_ACCOUNT_DETAILS);
        context.put("riskTolerance", 1);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
        context.put("equityPercent", 0.35);
        context.put("originalOwnerBirthDate", "1958-11-09");
        context.put("originalOwnerDeceasedDate", "2022-11-09");
        context.put("withdrawalEligibilityStartDate", "2022-11-09");
        context.put("withdrawalEligibilityEndDate", "2052-11-09");
        context.put("originalOwnerSpouse", "false");
        context.put("federalTaxWithholding", 0.15);
        context.put("stateTaxWithholding", 0.05);
        context.put("emergencyFundAmount", "111111.11");
        context.put("contribFreq", "YEARLY");
        context.put("contribValue", "500");
        context.put("contributionTaxType", "POST_TAX");
        context.put("contributionType", "CATCHUP");
        context.put("contributor", "EMPLOYER");
        context.put("contribFreq2", "BIMONTHLY");
        context.put("contribValue2", "900");
        context.put("contributionTaxType2", "AGGREGATE");
        context.put("contributionType2", "REGULAR");
        context.put("contributor2", "INDIVIDUAL");
        context.put("isBackdoorRoth", "true");
        context.put("TAM_name", "Short Term");

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeCreatePath);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                        equalTo(true), "accounts[0].account.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                        equalTo(accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(accountsCommonTestData.getValue1()),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GDSTOCK")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GFSTOCK")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GBOND")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GCASH")), "accounts[0].details.costBasis.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))), "accounts[0].details.state",
                        equalTo("AK"),
                        "accounts[0].details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f),
                        "accounts[0].details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f),
                        "accounts[0].details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body("accounts[0].details.assetAllocation.allocation.find{it.assetClass=='"
                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_T_ALTERNATIVE))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PCA))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PEA))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PRAA),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='TOTAL_EQUITY'}" +
                                ".netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='BOND'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='CASH'}.netPercentage.value",
                        equalTo(0f), "accounts[0].suitability.investmentObjective.targetAssetMix.name",
                        equalTo("Short Term"),
                        "accounts[0].suitability.investmentPurpose.values[0].value", equalTo("Save for education"),
                        "accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"),
                        "accounts[0].suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"),
                        "accounts[0].suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"),
                        "accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"),
                        "accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"),
                        "accounts[0].suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"),
                        "accounts[0].suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"),
                        "accounts[0].suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"),
                        "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(1),
                        "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                        "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                        "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(endYear))
                .body("accounts[0].contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
                .body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body("accounts[0].contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body("accounts[0].contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body("accounts[0].contributions" + regularPath + ".contribution.value", equalTo(900.0f))
                .body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body("accounts[0].contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body("accounts[0].contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body("accounts[0].contributions" +".isBackdoorRoth", equalTo(true))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.42f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.18f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.35f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.05f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].category", equalTo("FINAL"))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].name", equalTo("Growth with Income"))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(179))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(60))
                .body("accounts[0].details.complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
                .body("accounts[0].details.equityPercent", equalTo(0.35f))
                .body("accounts[0].details.originalOwnerBirthDate", equalTo("1958-11-09T00:00:00.000+0000"))
                .body("accounts[0].details.originalOwnerDeceasedDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body("accounts[0].details.withdrawalEligibilityStartDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body("accounts[0].details.withdrawalEligibilityEndDate", equalTo("2052-11-09T00:00:00.000+0000"))
                .body("accounts[0].details.originalOwnerSpouse", equalTo(false))
                .body("accounts[0].details.federalTaxWithholding.value", equalTo(0.15f))
                .body("accounts[0].details.stateTaxWithholding.value", equalTo(0.05f))
                .body("accounts[0].details.emergencyFundAmount.value", equalTo(111111.11f))
                .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(2000.0f))
                .body("accounts[0].withdrawals[0].amount.frequency", equalTo("BIMONTHLY"));

        // Save account number and ID
        accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
        accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
    }

    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after a create
     */
    @Test(dependsOnMethods = "createCompositeAccountManual")
    public void getCompositeAccountManualAfterCreate() {

        this.request.given()
                .header(new Header("include-suitability-details", "true"));
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                        equalTo(true), "accounts[0].account.accountId.id",
                        equalTo(accountsCommonTestData.getAccountId1()), "accounts[0].account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                        equalTo(accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(accountsCommonTestData.getValue1()),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GDSTOCK")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GFSTOCK")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GBOND")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GCASH")), "accounts[0].details.costBasis.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))), "accounts[0].details.state",
                        equalTo("AK"),
                        "accounts[0].details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f),
                        "accounts[0].details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f),
                        "accounts[0].details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body("accounts[0].details.assetAllocation.allocation.find{it.assetClass=='"
                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_T_ALTERNATIVE))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PCA))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PEA))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PRAA),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='BOND'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='CASH'}.netPercentage.value",
                        equalTo(0f), "accounts[0].suitability.investmentObjective.targetAssetMix.name",
                        equalTo("Short Term"),
                        "accounts[0].suitability.investmentPurpose.values[0].value", equalTo("Save for education"),
                        "accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"),
                        "accounts[0].suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"),
                        "accounts[0].suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"),
                        "accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"),
                        "accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"),
                        "accounts[0].suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"),
                        "accounts[0].suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"),
                        "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(1),
                        "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                        "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                        "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(endYear))
                .body("accounts[0].contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
                .body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body("accounts[0].contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body("accounts[0].contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body("accounts[0].contributions" + regularPath + ".contribution.value", equalTo(900.0f))
                .body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body("accounts[0].contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body("accounts[0].contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body("accounts[0].contributions" + ".isBackdoorRoth ", equalTo(true))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.42f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.18f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.35f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.05f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].category", equalTo("FINAL"))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].name", equalTo("Growth with Income"))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(179))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(60))
                .body("accounts[0].details.complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
                .body("accounts[0].details.equityPercent", equalTo(0.35f))
                .body("accounts[0].details.originalOwnerBirthDate", equalTo("1958-11-09T00:00:00.000+0000"))
                .body("accounts[0].details.originalOwnerDeceasedDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body("accounts[0].details.withdrawalEligibilityStartDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body("accounts[0].details.withdrawalEligibilityEndDate", equalTo("2052-11-09T00:00:00.000+0000"))
                .body("accounts[0].details.originalOwnerSpouse", equalTo(false))
                .body("accounts[0].details.federalTaxWithholding.value", equalTo(0.15f))
                .body("accounts[0].details.stateTaxWithholding.value", equalTo(0.05f))
                .body("accounts[0].details.emergencyFundAmount.value", equalTo(111111.11f))
                .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(2000.0f))
                .body("accounts[0].withdrawals[0].amount.frequency", equalTo("BIMONTHLY"));
    }

    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "getCompositeAccountManualAfterCreate")
    public void updateCompositeAccountManual() {
        // Populate updated variables for tests into context
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("riskTolerance", 2);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.4f);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 1.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.70f);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.30f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_Updated_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_Updated_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
        context.put("riskTolerance", 3);
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_25_AND_50");
        context.put("withdrawalStartYear", 2056);
        context.put("withdrawalEndYear", 2086);
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("equityPercent", 0.25);
        context.put("originalOwnerBirthDate", "1958-12-09");
        context.put("originalOwnerDeceasedDate", "2022-12-09");
        context.put("withdrawalEligibilityStartDate", "2022-12-09");
        context.put("withdrawalEligibilityEndDate", "2052-12-09");
        context.put("originalOwnerSpouse", true);
        context.put("federalTaxWithholding", 0.16);
        context.put("stateTaxWithholding", 0.06);
        context.put("TAM_total_equity", 0.5);
        context.put("TAM_domestic_equity", 0.4);
        context.put("TAM_foreign_equity", 0.1);
        context.put("TAM_bond", 0.5);
        context.put("TAM_cash", 0.0);
        context.put("TAM_category", "INVESTOR_SELECTED_STRATEGY");
        context.put("TAM_name", "Aggressive Growth");
        context.put("TAM_repositoryTamId", 181);
        context.put("TAM_assetAllocationId", 85);
        context.put("emergencyFundAmount", "211111.11");
        context.put("contribFreq", "YEARLY");
        context.put("contribValue", "600");
        context.put("contributionTaxType", "POST_TAX");
        context.put("contributionType", "CATCHUP");
        context.put("contributor", "EMPLOYER");
        context.put("contribFreq2", "BIMONTHLY");
        context.put("contribValue2", "700");
        context.put("contributionTaxType2", "AGGREGATE");
        context.put("contributionType2", "REGULAR");
        context.put("contributor2", "INDIVIDUAL");
        context.put("withdrawAmount", "2500");
        context.put("withdrawFreq", "QUARTERLY");
        context.put("isBackdoorRoth", "false");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.post(accountCompositeUpdatePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                        equalTo(true), "accounts[0].account.accountId.id",
                        equalTo(accountsCommonTestData.getAccountId1()), "accounts[0].account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                        equalTo(accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GDSTOCK")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GFSTOCK")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GBOND")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GCASH")), "accounts[0].details.costBasis.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedDetailValue"))),
                        "accounts[0].details.state", equalTo("AK"),
                        "accounts[0].details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f),
                        "accounts[0].details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f),
                        "accounts[0].details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f),
                        "accounts[0].details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body("accounts[0].details.assetAllocation.allocation.find{it.assetClass=='"
                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PCA))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PEA))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PRAA),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='BOND'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='CASH'}.netPercentage.value",
                        equalTo(0f), "accounts[0].suitability.investmentObjective.targetAssetMix.name",
                        equalTo("Short Term"),
                        "accounts[0].suitability.investmentPurpose.values[0].value", equalTo("Save for education"),
                        "accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"),
                        "accounts[0].suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"),
                        "accounts[0].suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"),
                        "accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"),
                        "accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"),
                        "accounts[0].suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"),
                        "accounts[0].suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"),
                        "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(3),
                        "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"),
                        "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056),
                        "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
                .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(2500.0f))
                .body("accounts[0].withdrawals[0].amount.frequency", equalTo("QUARTERLY"))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.85f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.25f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.15f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.0f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].name", equalTo("Aggressive Growth"))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(181))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(85))
                .body("accounts[0].details.complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body("accounts[0].details.equityPercent", equalTo(0.25f))
                .body("accounts[0].details.originalOwnerBirthDate", equalTo("1958-12-09T00:00:00.000+0000"))
                .body("accounts[0].details.originalOwnerDeceasedDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body("accounts[0].details.withdrawalEligibilityStartDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body("accounts[0].details.withdrawalEligibilityEndDate", equalTo("2052-12-09T00:00:00.000+0000"))
                .body("accounts[0].details.originalOwnerSpouse", equalTo(true))
                .body("accounts[0].details.federalTaxWithholding.value", equalTo(0.16f))
                .body("accounts[0].details.stateTaxWithholding.value", equalTo(0.06f))
                .body("accounts[0].contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
                .body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body("accounts[0].contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body("accounts[0].contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body("accounts[0].contributions" + regularPath + ".contribution.value", equalTo(700.0f))
                .body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body("accounts[0].contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body("accounts[0].contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body("accounts[0].contributions" + ".isBackdoorRoth ", equalTo(false));
    }

    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "updateCompositeAccountManual")
    public void getCompositeAccountManualAfterUpdate() {

        this.request.given()
                .header(new Header("include-suitability-details", "true"));
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(accountCompositeGetPath);

        // Assert on response

        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                        equalTo(true), "accounts[0].account.accountId.id",
                        equalTo(accountsCommonTestData.getAccountId1()), "accounts[0].account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                        equalTo(accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GDSTOCK")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GFSTOCK")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GBOND")),
                        "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId",
                        equalTo(finstIds.getFinstId("GCASH")), "accounts[0].details.costBasis.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedDetailValue"))),
                        "accounts[0].details.state", equalTo("AK"),
                        "accounts[0].details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f),
                        "accounts[0].details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f),
                        "accounts[0].details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f),
                        "accounts[0].details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body("accounts[0].details.assetAllocation.allocation.find{it.assetClass=='"
                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PCA))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PEA))
                .body("accounts[0].details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PRAA),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation" +
                                ".find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='BOND'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='CASH'}.netPercentage.value",
                        equalTo(0f), "accounts[0].suitability.investmentObjective.targetAssetMix.name",
                        equalTo("Short Term"),
                        "accounts[0].suitability.investmentPurpose.values[0].value", equalTo("Save for education"),
                        "accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"),
                        "accounts[0].suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"),
                        "accounts[0].suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"),
                        "accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"),
                        "accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"),
                        "accounts[0].suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"),
                        "accounts[0].suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"),
                        "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(3),
                        "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"),
                        "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056),
                        "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.85f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.25f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.15f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.0f))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].name", equalTo("Aggressive Growth"))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(181))
                .body("accounts[0].details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(85))
                .body("accounts[0].details.complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body("accounts[0].details.equityPercent", equalTo(0.25f))
                .body("accounts[0].details.originalOwnerBirthDate", equalTo("1958-12-09T00:00:00.000+0000"))
                .body("accounts[0].details.originalOwnerDeceasedDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body("accounts[0].details.withdrawalEligibilityStartDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body("accounts[0].details.withdrawalEligibilityEndDate", equalTo("2052-12-09T00:00:00.000+0000"))
                .body("accounts[0].details.originalOwnerSpouse", equalTo(true))
                .body("accounts[0].details.federalTaxWithholding.value", equalTo(0.16f))
                .body("accounts[0].details.stateTaxWithholding.value", equalTo(0.06f))
                .body("accounts[0].contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
                .body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body("accounts[0].contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body("accounts[0].contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body("accounts[0].contributions" + regularPath + ".contribution.value", equalTo(700.0f))
                .body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body("accounts[0].contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body("accounts[0].contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body("accounts[0].contributions" + ".isBackdoorRoth", equalTo(false))
                .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(2500.0f))
                .body("accounts[0].withdrawals[0].amount.frequency", equalTo("QUARTERLY"));
    }

    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after delete
     */
    @Test(dependsOnMethods = "getCompositeAccountManualAfterUpdate")
    public void deleteCompositeAccountManual() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(accountDeletePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true)).body("accountList", empty());
    }

    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates an empty account list when calling get account composite manual after delete
     */
    @Test(dependsOnMethods = "deleteCompositeAccountManual")
    public void getCompositeAccountManualAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "accounts", empty());
    }
    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown()
    {
        testDataUtil.closeSQLiteConnection();
    }
}
