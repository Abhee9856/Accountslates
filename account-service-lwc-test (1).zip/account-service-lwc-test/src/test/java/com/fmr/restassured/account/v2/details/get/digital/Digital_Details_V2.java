/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.get.digital;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.is;

import com.fmr.restassured.account.helpers.Tags;


/**
 * Tests for Digital Details Account
 *
 * @author a631781
 */

@Test(groups = {Tags.REGRESSION, Tags.DIGITAL, Tags.DETAILS, Tags.V2})
public class Digital_Details_V2 extends PAPBaseServiceTest {

    protected Digital_Details_V2() {
        super(Services.Account);
    }

    private static final String sourceSystem = "DIGITAL";

    public static final String ACCOUNT_CATEGORY = "InternalDigital, ExternalDigital";
    public static final String acctSubTypeDescInt = "Internal Digital Currency";
    public static final String acctSubTypeDescExt = "External Digital Currency";

    private String ssn;
    private String mid;
    private String sid;
    private String ppid;
    private String internalAccountNumberDSS;
    private String externalAccountNumberDSS;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Digital_Details_V2.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String APP_NAME = "Advice and Planning Platform";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private Response accountResponse;
    private final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;
    private VelocityContext context;
    private FilterableRequestSpecification frs;
    private String linkedAccountsIntDSS;
    private String linkedAccountsExtDSS;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_digital", oAuth);

        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid().replace("-", "");

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity(mid, oAuth);

        ssn = accountsCommonTestData.getSsn();
        testDataUtil = new TestDataUtil();

        // Populate request context with user IDs
        context = new VelocityContext();

        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Test to get the DSS digital account
     * <p>
     * Version V2
     */
    @Test
    public void getDSS_V2() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().statusCode(anyOf(is(200), is(206)));
        internalAccountNumberDSS = response.path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescInt + "'}.acctNum");
        externalAccountNumberDSS = response.path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescExt + "'}.acctNum");
        linkedAccountsIntDSS = response.path("acctDetails.find{it.acctNum=='" + internalAccountNumberDSS + "'}.linkedAcctDetails[0].acctNum");
        linkedAccountsExtDSS = response.path("acctDetails.find{it.acctNum=='" + externalAccountNumberDSS + "'}.linkedAcctDetails[0].acctNum");

    }

    /**
     * Tests that account data is brought back for Digital account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void getDigitalAccountInfo() {
        //Set Account Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        setRequestHeadersForAccount();
        // Generate request body
        context.put("accountNumber", internalAccountNumberDSS);
        context.put("source", sourceSystem);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

        // Call Account service
        accountResponse = request.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

        // Assert on response
        accountResponse.then().statusCode(200)
                .body("accountDetails", not(emptyArray()))
                .body("accountDetails[0].digitalAccountDetail.accountDetail.accountId.accountNumber", Matchers.equalTo(internalAccountNumberDSS))
                .body("accountDetails[0].digitalAccountDetail.accountDetail.accountId.sourceSystem", Matchers.equalTo(sourceSystem))
                .body("accountDetails[0].digitalAccountDetail.linkedAccounts[0].accountNumber", Matchers.equalTo(linkedAccountsIntDSS));
    }

    /**
     * Tests that account data is brought back for External Digital account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void getDigitalExternalAccountInfo() {
        if (externalAccountNumberDSS != null) {
            //Set Account Headers
            frs = (FilterableRequestSpecification) request;
            frs.removeHeaders();
            setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
            setRequestHeadersForAccount();
            // Generate request body
            context.put("accountNumber", externalAccountNumberDSS);
            context.put("source", sourceSystem);

            request.body(IOUtil.generateJsonRequest(context,
                    AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

            // Call Account service
            accountResponse = request.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
            // Assert on response
            accountResponse.then().statusCode(200)
                    .body("accountDetails", not(emptyArray()))
                    .body("accountDetails[0].digitalAccountDetail.accountDetail.accountId.accountNumber", Matchers.equalTo(externalAccountNumberDSS))
                    .body("accountDetails[0].digitalAccountDetail.accountDetail.accountId.sourceSystem", Matchers.equalTo(sourceSystem))
                    .body("accountDetails[0].digitalAccountDetail.linkedAccounts[0].accountNumber", Matchers.equalTo(linkedAccountsExtDSS));
        } else {
            System.out.println("External Digital Account does not exist");
        }
    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS() {
        this.request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", this.ssn))
                .header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
                .header(new Header("FACMC", "MID=" + this.mid))
                .header(new Header("FACFC", "SESSION_KEY=1"))
                .header(new Header("Content-Type", "application/json"));

    }

    /**
     * Setting headers for Account Service
     */
    private void setRequestHeadersForAccount() {
        // Account headers setup
        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-retail-lid", ssn))
                .header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("realTimeData", "true"))
                .header(new Header("mauiCache", "no"))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("user-digital-lid", ssn));;
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        this.testDataUtil.closeSQLiteConnection();
    }

}