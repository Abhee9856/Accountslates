/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;
import org.hamcrest.Matchers;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.*;


/**
 * Tests for Preserving displayName when a Target Account converts to Real Account
 *
 * @author a631781
 * Updated by @631781 to validate irrevocableTrust and trustType.
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.ACCOUNT,
		Tags.V2})
public class Retail_V2_TargetAccount_to_RealAccount extends PAPBaseServiceTest
{
    protected Retail_V2_TargetAccount_to_RealAccount()
    {
	super(Services.Account);
    }
    private AccountsCommonTestData accountsCommonTestData;

    //Test data
    private final float fundingAccountAmount = 5.55f;

    private TestDataUtil testDataUtil;

    private String mid;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String displayNameTargetAct = "TargetAccount_DisplayName_V2";

    private static String targetAccountId;

    private final float unknownAmount = 20.0f;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_V2_TargetAccount_to_RealAccount.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private FilterableRequestSpecification frs;

    //Velocity Context
    private final VelocityContext context = new VelocityContext();
    private static final String TRUA = "Trust Under Will";


    /**
     * Initialization method used to populate the UserIdentifiers object
     * based on the default SSN, set up the endpoint for the test, and
     * build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();
	accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);

	//Set default request headers
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	testDataUtil = new TestDataUtil();

	this.mid = this.accountsCommonTestData.getMid();
	this.accountsCommonTestData.setMid(this.mid);

	DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");

	String scenarioId = Scenario
			.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE, oAuth);
	this.accountsCommonTestData.setPpid(
			Identity.createHouseholdIdentity("mid", this.accountsCommonTestData.getMid(), oAuth));

	this.request.given()
			.header(new Header("user-poe", AccountConstants.RETAIL))
			.header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
			.header(new Header("user-mid", accountsCommonTestData.getMid()))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));

	frs = (FilterableRequestSpecification) request;

    }

    /**
     * Get retail account info from the backend.
     */
    @Test
    public void getRetailAccountInfo()
    {
	this.request.given()
			.header(new Header("excludeExternalDataSources", "false"));
	// Generate request body
	context.put("source", AccountConstants.RETAIL);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	// Call Account service v2
	response = request.post(AccountsPaths.GET_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200)
			.body("accountList", not(emptyArray()))
			.body("accountList[0].accountId.accountNumber", notNullValue())
			.body("accountList[0].accountId", notNullValue());

	// use the values below to populate create request
	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
	accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
	accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
	accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
	accountsCommonTestData.setAccountNumber2(response.path("accountList[1].accountId.accountNumber"));

    }

    /**
     * Create the account
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount()
    {     //Exclude external data sources
	this.frs.removeHeader("excludeExternalDataSources");
	this.request.given()
			.header(new Header("excludeExternalDataSources", "true"));

	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

	response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200)
			.body("accountList[0].sourceMarketValue.amount.value",
					equalTo(accountsCommonTestData.getValue1()),
					"accountList[0].accountId.id", not(nullValue()),
					"accountList[0].accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountList[0].accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountList[0].regCode.mnemonic",
					equalTo(accountsCommonTestData.getMnemonic1()),
					"accountList[0].sourceMarketValue", not(nullValue()));

	accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
    }

    /**
     * Create target account
     */
    @Test(dependsOnMethods = "createRetailAccount")
    public void createTargetAccount() {
        // Generate request body
        context.put("targetAccountNumber", accountsCommonTestData.getAccountNumber2());
        context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("targetDisplayName", displayNameTargetAct);
        context.put("unknownAmount", String.valueOf(unknownAmount));
        context.put("irrevocableTrust", "true");
        context.put("trustType", TRUA);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

	// Call Account service
	response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()),
                        "targetAccounts[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber2()),
                        "targetAccounts[0].accountId.id", notNullValue(),
                        "targetAccounts[0].displayName", equalTo(displayNameTargetAct),
                        "targetAccounts[0].irrevocableTrust", equalTo(true),
                        "targetAccounts[0].trustType", equalTo(TRUA),
                        "targetAccounts[0].sourceMarketValue.amount.value",
                        equalTo(fundingAccountAmount),
                        "targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].fundingAccounts[0].accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        "targetAccounts[0].fundingAccounts[0].amount.value",
                        equalTo(fundingAccountAmount));

	targetAccountId = response.path("targetAccounts[0].accountId.id");

    }

    /**
     * Verify retail account info is being returned
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void verifyRetailAccountInfoAfterCreate()
    {  //Exclude external data sources
	this.frs.removeHeader("excludeExternalDataSources");
	this.request.given()
			.header(new Header("excludeExternalDataSources", "true"));

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        //Assert on response
        response.then().statusCode(200)
                .body("targetAccounts", not(empty()),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber2()),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.accountId.id", equalTo(targetAccountId),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.displayName", equalTo(displayNameTargetAct),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.irrevocableTrust", equalTo(true),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.trustType", equalTo(TRUA),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.sourceMarketValue.amount.value",
                        equalTo(fundingAccountAmount),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.fundingAccounts[0].accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        "targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.fundingAccounts[0].amount.value",
                        equalTo(fundingAccountAmount));

    }

    /**
     * Verify retail account info is being returned
     */
    @Test(dependsOnMethods = "verifyRetailAccountInfoAfterCreate")
    public void verifyTargetAccountWithEDSasFalse()
    {
	//Exclude external data sources
	this.frs.removeHeader("excludeExternalDataSources");
	this.request.given()
			.header(new Header("excludeExternalDataSources", "false"));

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        //Assert on response
        response.then().log().ifValidationFails().statusCode(200)
                .body("accountList.find{it.accountId.id=='" + targetAccountId + "'}.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber2()),
                        "accountList.find{it.accountId.id=='" + targetAccountId + "'}.displayName", equalTo(displayNameTargetAct));
    }
    /**
     * Validate irrevocableTrust and trustType in account details when EEDS is false.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "verifyTargetAccountWithEDSasFalse")
    public void verifyAccountDetailsWithEEDSFalse() {
        frs.removeHeader("excludeExternalDataSources");
        this.request.given()
                .header(new Header("excludeExternalDataSources", "false"));
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + targetAccountId + "'}.retailAccountDetail.accountDetail.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber2()),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + targetAccountId + "'}.retailAccountDetail.accountDetail.accountId.id", equalTo(targetAccountId),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + targetAccountId + "'}.retailAccountDetail.accountDetail.irrevocableTrust", equalTo(true),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + targetAccountId + "'}.retailAccountDetail.accountDetail.trustType", equalTo(TRUA));

    }

    /**
     * Delete the retail account.
     */
    @Test(dependsOnMethods = "verifyAccountDetailsWithEEDSFalse")
    public void deleteRetailAccount() {
        //Exclude external data sources
        this.frs.removeHeader("excludeExternalDataSources");
        this.request.given()
		        .header(new Header("excludeExternalDataSources", "true"));
        // Generate new request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("id", accountsCommonTestData.getAccountId1());
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

	response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("isEmpty()", Matchers.is(true));
    }

    /**
     * Delete the retail account.
     */
    @Test(dependsOnMethods = "deleteRetailAccount")
    public void deleteSecondRetailAccount()
    {
	//Exclude external data sources
	this.frs.removeHeader("excludeExternalDataSources");
	this.request.given()
			.header(new Header("excludeExternalDataSources", "true"));
	// Generate new request body
	context.put("accountNumber", accountsCommonTestData.getAccountNumber2());
	context.put("id", targetAccountId);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

	response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("isEmpty()", Matchers.is(true));
    }

    /**
     * Validate the retail account was deleted.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteSecondRetailAccount")
    public void getRetailAccountAfterDelete()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("isEmpty()", Matchers.is(true));
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
	this.testDataUtil.closeSQLiteConnection();
    }
}
