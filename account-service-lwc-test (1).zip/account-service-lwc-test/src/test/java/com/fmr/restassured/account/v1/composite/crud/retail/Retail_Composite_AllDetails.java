/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.HashMap;

import io.restassured.http.Header;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;

import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * Contains tests that validate the Account Composite operation for Retail Accounts - includes CRUD validations
 *
 * @author a623549
 * Updated by a608077 on 08/18/2022 to include asset allocation changes(PFCP-9501).
 * Updated by a608077 on 05/22/2023 to include backdoor IRA changes(PFCP-12448).
 * Updated by a608077 on 08/30/2023 for include-suitability-details header(PFCP-12115).
 * Updated by a608077 on 10/10/2023 to include 3 new asset
 *   classes: Private Equity, Private Credit, and Real Assets(PFCP-13826)
 * Updated by a608077 on 02/28/2024 to include suitabilityStatus changes(PFCP-15267)
 * Updated by a608077 on 09/23/2024 to include isManaged flag(PFCP-17274)
 */
@Test(groups = {Tags.RETAIL, Tags.ACCOUNT, Tags.V1, Tags.CRITICAL, Tags.TAM})
public class Retail_Composite_AllDetails extends PAPBaseServiceTest
{

	/**
	 * Logger to print appropriate error, warning, or info messages
	 **/
	private static final Logger LOGGER = LogManager.getLogger(Retail_Composite_AllDetails.class);

	/**
	 * Instance to the test data utility class
	 */
	private TestDataUtil testDataUtil;

	private String accNum;

	private String acctRoot;

	private final String catchupPath = ".contributions.find{it.contributionType=='CATCHUP'}";

	private final String regularPath = ".contributions.find{it.contributionType=='REGULAR'}";

	/**
	 * Global variable holding the oAuth token generated in the initClass method
	 */
	private String oAuth;

	/**
	 * Global variable holding retailAccount information
	 */
	private HashMap<String, String> retailAccountMap;

	/**
	 * Global variable holding account test data from sqlite
	 */
	private AccountsCommonTestData accountTestData;

	private static final String LOG_TRACKING_ID = Retail_Composite_AllDetails.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private static final String source = "RETAIL";

	private String scenarioId;

	private VelocityContext context;

	private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";

	private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";

	private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";

	private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";

	private final float netPercentage_T_ALTERNATIVE = 0.8f;

	private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;

	private final float netPercentage_PEA = 0.4f;

	private final float netPercentage_Updated_PEA = 0.2f;

	private final float netPercentage_PCA = 0.2f;

	private final float netPercentage_Updated_PCA = 0.3f;

	private final float netPercentage_PRAA = 0.2f;

	private final float netPercentage_Updated_PRAA = 0.1f;

	/**
	 * Constructor
	 */
	protected Retail_Composite_AllDetails()
	{
		super(Services.Account);
	}

	/**
	 * Instantiates TestDataUtil & retrieves oAuth token
	 */
	@BeforeClass(alwaysRun = true)
	public void initClass()
	{

		oAuth = AccountUtil.getOauthToken();
		testDataUtil = new TestDataUtil();
		retailAccountMap = new HashMap<>();

		accountTestData = TestDataUtil.populateRegressionTestData("accountCRUD_Retail", oAuth);

		retailAccountMap = getRetailAccountInformation(accountTestData, oAuth);

		DataCleanup.deleteCustomerDataFromCP("mid", accountTestData.getMid(), oAuth, "true");
		final String ppid = Identity.createHouseholdIdentity(accountTestData.getMid(), oAuth);
		accountTestData.setPpid(ppid);
		// Get/Create ScenarioId
		Response allScenarioIDs = Scenario.getAllScenarios(accountTestData.getMid(), oAuth);
		scenarioId = allScenarioIDs.path("scenario[0].id").toString();
		if (scenarioId == null)
		{
			scenarioId = Scenario.createScenarioWithProductCode(accountTestData.getMid(), "IGE", "DEF",
					oAuth);
		}
	}

	/**
	 * Test setup method.
	 */
	@BeforeMethod(alwaysRun = true)
	public void init()
	{
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
	}

	/**
	 * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
	 * <p>
	 * Description: Validates an empty account list when calling get account composite retail before creation of an
	 * account
	 */
	@Test
	public void getCompositeAccountRetailBeforeCreate()
	{
		if (retailAccountMap.isEmpty())
		{
			throw new SkipException(
					"'getCompositeAccountRetailBeforeCreate' test scenario cannot run due to failure to retrieve "
							+ "retail account information!");
		}

		context = new VelocityContext();
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("poe", source);
		context.put("externalDataSources", true);
		context.put("source", source);
		context.put("scenarioId", scenarioId);

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
				hasSize(0));
	}

	/**
	 * Description: Validates the account composite response after a create
	 */
	@Test(dependsOnMethods = "getCompositeAccountRetailBeforeCreate")
	public void createCompositeAccountRetail()
	{
		accNum = retailAccountMap.get("accountNumber");
		context.put("externalDataSources", true);
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("accountNumber", accNum);
		context.put("source", source);
		context.put("ppid", accountTestData.getPpid());
		context.put("displayName", retailAccountMap.get("displayName"));
		context.put("mnemonic", retailAccountMap.get("mnemonic"));
		context.put("sourceSystem2", source);
		context.put("institutionName", retailAccountMap.get("institutionName"));
		context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
		context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
		context.put("detailValue", "111111.11");
		context.put("emergencyFundAmount", "111111.11");
		context.put("assetClass1", "UNKNOWN");
		context.put("netPercentage1", 0.177);
		context.put("assetClass_T_Equity", "TOTAL_EQUITY");
		context.put("netPercentage_T_Equity", 0);
		context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
		context.put("netPercentage_FE", 0.0f);
		context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
		context.put("netPercentage_DE", 0.0f);
		context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
		context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
		context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
		context.put("netPercentage_PEA", netPercentage_PEA);
		context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
		context.put("netPercentage_PCA", netPercentage_PCA);
		context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
		context.put("netPercentage_PRAA", netPercentage_PRAA);
		context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
		context.put("type", "RetailAccountDetails");
		context.put("contribFreq", "YEARLY");
		context.put("contribValue", "500");
		context.put("contributionTaxType", "POST_TAX");
		context.put("contributionType", "CATCHUP");
		context.put("contributor", "EMPLOYER");
		context.put("contribBasisTypeCd", "BASE");
		context.put("contribFreq2", "BIMONTHLY");
		context.put("contribValue2", "900");
		context.put("contributionTaxType2", "AGGREGATE");
		context.put("contributionType2", "REGULAR");
		context.put("contributor2", "INDIVIDUAL");
		context.put("contribBasisTypeCd2", "BASEBONUS");
		context.put("withdrawAmount", "1000");
		context.put("withdrawFreq", "DAILY");
		context.put("scenarioId", scenarioId);
		context.put("isProductSuitable", "false");
		context.put("suitabilityStatus", "SUITABLE");
		context.put("riskTolerance", 2);
		context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
		context.put("withdrawalStartYear", 2055);
		context.put("withdrawalEndYear", 2085);
		context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
		context.put("equityPercent", 0.35);
		context.put("originalOwnerBirthDate", "1958-11-09");
		context.put("originalOwnerDeceasedDate", "2022-11-09");
		context.put("withdrawalEligibilityStartDate", "2022-11-09");
		context.put("withdrawalEligibilityEndDate", "2052-11-09");
		context.put("originalOwnerSpouse", "false");
		context.put("federalTaxWithholding", 0.15);
		context.put("stateTaxWithholding", 0.05);
		context.put("isBackdoorRoth", "true");
		context.put("isManaged", false);
		context.put("TAM_name", "Growth with Income");

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

		response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

		acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
		.body("resultCode", equalTo(true))
		.body(acctRoot + "account.accountId.id", notNullValue())
		.body(acctRoot + "account.accountId.accountNumber", equalTo(accNum))
		.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
		.body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
		.body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
		.body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
		.body(acctRoot + "account.institutionName",
				equalTo(retailAccountMap.get("institutionName")))
		.body(acctRoot + "account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))))
		.body(acctRoot + "details.complementaryAdjustmentOption",
				equalTo("MOVE_TO_MANAGED_ACCOUNT"))
		.body(acctRoot + "details.equityPercent", equalTo(0.35f))
		.body(acctRoot + "details.originalOwnerBirthDate",
				equalTo("1958-11-09T00:00:00.000+0000"))
		.body(acctRoot + "details.originalOwnerDeceasedDate",
				equalTo("2022-11-09T00:00:00.000+0000"))
		.body(acctRoot + "details.withdrawalEligibilityStartDate",
				equalTo("2022-11-09T00:00:00.000+0000"))
		.body(acctRoot + "details.withdrawalEligibilityEndDate",
				equalTo("2052-11-09T00:00:00.000+0000"))
		.body(acctRoot + "details.originalOwnerSpouse", equalTo(false))
		.body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.15f))
		.body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.05f))
		.body(acctRoot + "details.emergencyFundAmount.value", equalTo(111111.11f))
		.body(acctRoot + "details.isProductSuitable", equalTo(true))
		.body(acctRoot + "details.isManaged", equalTo(false))
		.body(acctRoot + "details.suitabilityStatus", equalTo("SUITABLE"))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
				equalTo(0.177f))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(0f))
		.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
				equalTo(0.0f))
		.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
				equalTo(0.0f))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
				+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_T_ALTERNATIVE))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PCA))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PEA))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PRAA))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
				+ ".netPercentage.value", equalTo(0.6f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
				+ ".allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
				equalTo(0.42f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
				+ ".allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
				equalTo(0.18f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}"
				+ ".netPercentage.value", equalTo(0.35f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}"
				+ ".netPercentage.value", equalTo(0.05f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category",
				equalTo("FINAL"))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name",
				equalTo("Growth with Income"))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId",
				equalTo(179))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId",
				equalTo(60))
		.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
		.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType",
				equalTo("POST_TAX"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionType",
				equalTo("CATCHUP"))
		.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body(acctRoot + "contributions" + catchupPath + ".contribBasisTypeCd", equalTo("BASE"))
		.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
		.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body(acctRoot + "contributions" + regularPath + ".contributionTaxType",
				equalTo("AGGREGATE"))
		.body(acctRoot + "contributions" + regularPath + ".contributionType",
				equalTo("REGULAR"))
		.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
		.body(acctRoot + "contributions" + regularPath + ".contribBasisTypeCd",
				equalTo("BASEBONUS"))
		.body(acctRoot + "contributions" + ".isBackdoorRoth", equalTo(true))
		.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name",
				equalTo("Short Term"))
		.body(acctRoot + "suitability.investmentPurpose.values[0].value",
				equalTo("Save for education"))
		.body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
		.body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
		.body(acctRoot + "suitability.liquidNetworthRange.values[0].value",
				equalTo("$0 to $50K"))
		.body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
		.body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
		.body(acctRoot + "suitability.essentialExpensesRange.values[0].value",
				equalTo("Under 25%"))
		.body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value",
				equalTo("Not Likely"))
		.body(acctRoot + "suitability.investmentTimeHorizon.values[0].value",
				equalTo("Near Term (0-1 year)"))
		.body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
		.body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent",
				equalTo("SELL_LESS_THAN_25"))
		.body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
		.body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
		.body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
		.body(acctRoot + "withdrawals", notNullValue())
		.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(1000.0f))
		.body(acctRoot + "withdrawals[0].amount.frequency", equalTo("DAILY"));

		accountTestData.setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
	}

	/**
	 * Description: Validates the account composite response after a create (get)
	 */
	@Test(dependsOnMethods = "createCompositeAccountRetail")
	public void getCompositeAccountRetailAfterCreate()
	{
		this.request.given().header(new Header("include-suitability-details", "true"));
		VelocityContext context = new VelocityContext();
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("poe", source);
		context.put("externalDataSources", true);
		context.put("source", source);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
		.body("resultCode", equalTo(true))
		.body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
		.body(acctRoot + "account.accountId.accountNumber",
				equalTo(retailAccountMap.get("accountNumber")))
		.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
		.body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
		.body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
		.body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
		.body(acctRoot + "account.institutionName",
				equalTo(retailAccountMap.get("institutionName")))
		.body(acctRoot + "account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))))
		.body(acctRoot + "details.isProductSuitable", equalTo(true))
		.body(acctRoot + "details.isManaged", equalTo(false))
		.body(acctRoot + "details.suitabilityStatus", equalTo("SUITABLE"))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
				equalTo(0.177f))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(0f))
		.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
				equalTo(0.0f))
		.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
				equalTo(0.0f))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
				+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_T_ALTERNATIVE))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PCA))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PEA))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_PRAA))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(0.6f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
				equalTo(0.42f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
				equalTo(0.18f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
				equalTo(0.35f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
				equalTo(0.05f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category",
				equalTo("FINAL"))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name",
				equalTo("Growth with Income"))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId",
				equalTo(179))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId",
				equalTo(60))
		.body(acctRoot + "details.emergencyFundAmount.value", equalTo(111111.11f))
		.body(acctRoot + "details.complementaryAdjustmentOption",
				equalTo("MOVE_TO_MANAGED_ACCOUNT"))
		.body(acctRoot + "details.equityPercent", equalTo(0.35f))
		.body(acctRoot + "details.originalOwnerBirthDate",
				equalTo("1958-11-09T00:00:00.000+0000"))
		.body(acctRoot + "details.originalOwnerDeceasedDate",
				equalTo("2022-11-09T00:00:00.000+0000"))
		.body(acctRoot + "details.withdrawalEligibilityStartDate",
				equalTo("2022-11-09T00:00:00.000+0000"))
		.body(acctRoot + "details.withdrawalEligibilityEndDate",
				equalTo("2052-11-09T00:00:00.000+0000"))
		.body(acctRoot + "details.originalOwnerSpouse", equalTo(false))
		.body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.15f))
		.body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.05f))
		.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
		.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType",
				equalTo("POST_TAX"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionType",
				equalTo("CATCHUP"))
		.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body(acctRoot + "contributions" + catchupPath + ".contribBasisTypeCd", equalTo("BASE"))
		.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
		.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body(acctRoot + "contributions" + regularPath + ".contributionTaxType",
				equalTo("AGGREGATE"))
		.body(acctRoot + "contributions" + regularPath + ".contributionType",
				equalTo("REGULAR"))
		.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
		.body(acctRoot + "contributions" + regularPath + ".contribBasisTypeCd",
				equalTo("BASEBONUS"))
		.body(acctRoot + "contributions" + ".isBackdoorRoth", equalTo(true))
		.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name",
				equalTo("Short Term"))
		.body(acctRoot + "suitability.investmentPurpose.values[0].value",
				equalTo("Save for education"))
		.body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
		.body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
		.body(acctRoot + "suitability.liquidNetworthRange.values[0].value",
				equalTo("$0 to $50K"))
		.body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
		.body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
		.body(acctRoot + "suitability.essentialExpensesRange.values[0].value",
				equalTo("Under 25%"))
		.body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value",
				equalTo("Not Likely"))
		.body(acctRoot + "suitability.investmentTimeHorizon.values[0].value",
				equalTo("Near Term (0-1 year)"))
		.body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
		.body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent",
				equalTo("SELL_LESS_THAN_25"))
		.body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
		.body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
		.body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
		.body(acctRoot + "withdrawals", notNullValue())
		.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(1000.0f))
		.body(acctRoot + "withdrawals[0].amount.frequency", equalTo("DAILY"));
	}

	/**
	 * Description:
	 * The isManaged flag should be saved and the DB value returned when EEDS=true.
	 * In this case, when EEDS=false the backend (DSS) data should have precedent.
	 */
	@Test(dependsOnMethods = "createCompositeAccountRetail")
	public void isManagedIsComingFromBackendWhenEEDSIsFalse()
	{
		context.put("externalDataSources", false);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
				.body("resultCode", equalTo(true))
				// Even though isManaged was saved as false, true should be returned from the backend.
				.body(acctRoot + "details.isManaged", equalTo(true));

	}


	/**
	 * Description: Validates the account composite response after an update
	 */
	@Test(dependsOnMethods = "isManagedIsComingFromBackendWhenEEDSIsFalse")
	public void updateCompositeAccountRetail()
	{
		context.put("externalDataSources", true);
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("accId", accountTestData.getAccountId1());
		context.put("accountNumber", retailAccountMap.get("accountNumber"));
		context.put("source", source);
		context.put("ppid", accountTestData.getPpid());
		context.put("displayName", retailAccountMap.get("displayName"));
		context.put("mnemonic", retailAccountMap.get("mnemonic"));
		context.put("sourceSystem2", source);
		context.put("institutionName", retailAccountMap.get("institutionName"));
		context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
		context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
		context.put("detailValue", "211111.11");
		context.put("emergencyFundAmount", "211111.11");
		context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
		context.put("type", "RetailAccountDetails");
		context.put("contribFreq", "MONTHLY");
		context.put("contribValue", "600");
		context.put("contribFreq2", "WEEKLY");
		context.put("contribValue2", "700");
		context.put("withdrawAmount", "1500");
		context.put("withdrawFreq", "MONTHLY");
		context.put("isProductSuitable", "true");
		context.put("suitabilityStatus", "UNSUITABLE");
		context.put("assetClass1", "UNKNOWN");
		context.put("netPercentage1", 0.4f);
		context.put("assetClass_T_Equity", "TOTAL_EQUITY");
		context.put("netPercentage_T_Equity", 1.0f);
		context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
		context.put("netPercentage_DE", 0.70f);
		context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
		context.put("netPercentage_FE", 0.30f);
		context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
		context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
		context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
		context.put("netPercentage_PEA", netPercentage_Updated_PEA);
		context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
		context.put("netPercentage_PCA", netPercentage_Updated_PCA);
		context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
		context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
		context.put("riskTolerance", 3);
		context.put("stockMarketDeclinePercent", "SELL_BETWEEN_25_AND_50");
		context.put("withdrawalStartYear", 2056);
		context.put("withdrawalEndYear", 2086);
		context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
		context.put("equityPercent", 0.25);
		context.put("originalOwnerBirthDate", "1958-12-09");
		context.put("originalOwnerDeceasedDate", "2022-12-09");
		context.put("withdrawalEligibilityStartDate", "2022-12-09");
		context.put("withdrawalEligibilityEndDate", "2052-12-09");
		context.put("originalOwnerSpouse", true);
		context.put("federalTaxWithholding", 0.16);
		context.put("stateTaxWithholding", 0.06);
		context.put("TAM_total_equity", 0.5);
		context.put("TAM_domestic_equity", 0.4);
		context.put("TAM_foreign_equity", 0.1);
		context.put("TAM_bond", 0.5);
		context.put("TAM_cash", 0.0);
		context.put("TAM_category", "INVESTOR_SELECTED_STRATEGY");
		context.put("TAM_name", "Aggressive Growth");
		context.put("TAM_repositoryTamId", 181);
		context.put("TAM_assetAllocationId", 85);
		context.put("isBackdoorRoth", "false");
		context.put("isManaged", true);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

		response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
		.body("resultCode", equalTo(true))
		.body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
		.body(acctRoot + "account.accountId.accountNumber",
				equalTo(retailAccountMap.get("accountNumber")))
		.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
		.body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
		.body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
		.body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
		.body(acctRoot + "account.institutionName",
				equalTo(retailAccountMap.get("institutionName")))
		.body(acctRoot + "account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))))
		.body(acctRoot + "details.emergencyFundAmount.value", equalTo(211111.11f))
		.body(acctRoot + "details.isProductSuitable", equalTo(false))
				.body(acctRoot + "details.isManaged", equalTo(true))
		.body(acctRoot + "details.suitabilityStatus", equalTo("UNSUITABLE"))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
				equalTo(0.4f))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(1.0f))
		.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
				equalTo(0.70f))
		.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
				equalTo(0.30f))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
				+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_T_ALTERNATIVE))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PCA))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PEA))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PRAA))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(0.85f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
				equalTo(0.6f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
				equalTo(0.25f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
				equalTo(0.15f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
				equalTo(0.0f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category",
				equalTo("INVESTOR_SELECTED_STRATEGY"))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name",
				equalTo("Aggressive Growth"))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId",
				equalTo(181))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId",
				equalTo(85))
		.body(acctRoot + "details.complementaryAdjustmentOption",
				equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
		.body(acctRoot + "details.equityPercent", equalTo(0.25f))
		.body(acctRoot + "details.originalOwnerBirthDate",
				equalTo("1958-12-09T00:00:00.000+0000"))
		.body(acctRoot + "details.originalOwnerDeceasedDate",
				equalTo("2022-12-09T00:00:00.000+0000"))
		.body(acctRoot + "details.withdrawalEligibilityStartDate",
				equalTo("2022-12-09T00:00:00.000+0000"))
		.body(acctRoot + "details.withdrawalEligibilityEndDate",
				equalTo("2052-12-09T00:00:00.000+0000"))
		.body(acctRoot + "details.originalOwnerSpouse", equalTo(true))
		.body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.16f))
		.body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.06f))
		.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
		.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("MONTHLY"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType",
				equalTo("POST_TAX"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionType",
				equalTo("CATCHUP"))
		.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body(acctRoot + "contributions" + catchupPath + ".contribBasisTypeCd", equalTo("BASE"))
		.body(acctRoot + "contributions" + regularPath + ".contributionTaxType",
				equalTo("AGGREGATE"))
		.body(acctRoot + "contributions" + regularPath + ".contributionType",
				equalTo("REGULAR"))
		.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
		.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(700.0f))
		.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("WEEKLY"))
		.body(acctRoot + "contributions" + ".isBackdoorRoth", equalTo(false))
		.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name",
				equalTo("Short Term"))
		.body(acctRoot + "suitability.investmentPurpose.values[0].value",
				equalTo("Save for education"))
		.body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
		.body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
		.body(acctRoot + "suitability.liquidNetworthRange.values[0].value",
				equalTo("$0 to $50K"))
		.body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
		.body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
		.body(acctRoot + "suitability.essentialExpensesRange.values[0].value",
				equalTo("Under 25%"))
		.body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value",
				equalTo("Not Likely"))
		.body(acctRoot + "suitability.investmentTimeHorizon.values[0].value",
				equalTo("Near Term (0-1 year)"))
		.body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(3))
		.body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent",
				equalTo("SELL_BETWEEN_25_AND_50"))
		.body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056))
		.body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
		.body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
		.body(acctRoot + "withdrawals", notNullValue())
		.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(1500.0f))
		.body(acctRoot + "withdrawals[0].amount.frequency", equalTo("MONTHLY"));
	}

	/**
	 * Description: Validates the account composite response after an update (get)
	 */
	@Test(dependsOnMethods = "updateCompositeAccountRetail")
	public void getCompositeAccountRetailAfterUpdate()
	{
		this.request.given().header(new Header("include-suitability-details", "true"));
		final VelocityContext context = new VelocityContext();
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("poe", source);
		context.put("externalDataSources", true);
		context.put("source", source);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
		.body("resultCode", equalTo(true))
		.body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
		.body(acctRoot + "account.accountId.accountNumber",
				equalTo(retailAccountMap.get("accountNumber")))
		.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
		.body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
		.body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
		.body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
		.body(acctRoot + "account.institutionName",
				equalTo(retailAccountMap.get("institutionName")))
		.body(acctRoot + "account.sourceMarketValue.amount.value",
				equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))))
		.body(acctRoot + "details.complementaryAdjustmentOption",
				equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
		.body(acctRoot + "details.equityPercent", equalTo(0.25f))
		.body(acctRoot + "details.originalOwnerBirthDate",
				equalTo("1958-12-09T00:00:00.000+0000"))
		.body(acctRoot + "details.originalOwnerDeceasedDate",
				equalTo("2022-12-09T00:00:00.000+0000"))
		.body(acctRoot + "details.withdrawalEligibilityStartDate",
				equalTo("2022-12-09T00:00:00.000+0000"))
		.body(acctRoot + "details.withdrawalEligibilityEndDate",
				equalTo("2052-12-09T00:00:00.000+0000"))
		.body(acctRoot + "details.originalOwnerSpouse", equalTo(true))
		.body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.16f))
		.body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.06f))
		.body(acctRoot + "details.isProductSuitable", equalTo(false))
				.body(acctRoot + "details.isManaged", equalTo(true))
		.body(acctRoot + "details.suitabilityStatus", equalTo("UNSUITABLE"))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
				equalTo(0.4f))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(1.0f))
		.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
				equalTo(0.70f))
		.body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
				equalTo(0.30f))
		.body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
				+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_T_ALTERNATIVE))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PCA))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PEA))
		.body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
				+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
				equalTo(netPercentage_Updated_PRAA))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
				equalTo(0.85f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
				equalTo(0.6f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
				equalTo(0.25f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
				equalTo(0.15f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
				equalTo(0.0f))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category",
				equalTo("INVESTOR_SELECTED_STRATEGY"))
		.body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name",
				equalTo("Aggressive Growth"))
		.body(acctRoot + "details.emergencyFundAmount.value", equalTo(211111.11f))
		.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
		.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("MONTHLY"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType",
				equalTo("POST_TAX"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionType",
				equalTo("CATCHUP"))
		.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body(acctRoot + "contributions" + catchupPath + ".contribBasisTypeCd", equalTo("BASE"))
		.body(acctRoot + "contributions" + regularPath + ".contributionTaxType",
				equalTo("AGGREGATE"))
		.body(acctRoot + "contributions" + regularPath + ".contributionType",
				equalTo("REGULAR"))
		.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
		.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(700.0f))
		.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("WEEKLY"))
		.body(acctRoot + "contributions" + ".isBackdoorRoth", equalTo(false))
		.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name",
				equalTo("Short Term"))
		.body(acctRoot + "suitability.investmentPurpose.values[0].value",
				equalTo("Save for education"))
		.body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
		.body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
		.body(acctRoot + "suitability.liquidNetworthRange.values[0].value",
				equalTo("$0 to $50K"))
		.body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
		.body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
		.body(acctRoot + "suitability.essentialExpensesRange.values[0].value",
				equalTo("Under 25%"))
		.body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value",
				equalTo("Not Likely"))
		.body(acctRoot + "suitability.investmentTimeHorizon.values[0].value",
				equalTo("Near Term (0-1 year)"))
		.body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(3))
		.body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent",
				equalTo("SELL_BETWEEN_25_AND_50"))
		.body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056))
		.body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
		.body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
		.body(acctRoot + "withdrawals", notNullValue())
		.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(1500.0f))
		.body(acctRoot + "withdrawals[0].amount.frequency", equalTo("MONTHLY"));
	}

	/**
	 * Description: Validates the account composite response after a delete
	 */
	@Test(dependsOnMethods = "getCompositeAccountRetailAfterUpdate")
	public void deleteCompositeAccountRetail()
	{
		final VelocityContext context = new VelocityContext();

		context.put("externalDataSources", true);
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("accId", accountTestData.getAccountId1());
		context.put("accountNumber", retailAccountMap.get("accountNumber"));
		context.put("source", source);
		context.put("ppid", accountTestData.getPpid());
		context.put("displayName", retailAccountMap.get("displayName"));
		context.put("mnemonic", retailAccountMap.get("mnemonic"));
		context.put("sourceSystem2", source);
		context.put("institutionName", retailAccountMap.get("institutionName"));
		context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
		context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

		response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accountList",
				hasSize(0));
	}

	/**
	 * Description: Validates an empty account list when calling get account composite retail after delete
	 */
	@Test(dependsOnMethods = "deleteCompositeAccountRetail")
	public void getCompositeAccountRetailAfterDelete()
	{
		final VelocityContext context = new VelocityContext();
		context.put("mid", accountTestData.getMid());
		context.put("retailLid", accountTestData.getSsn());
		context.put("poe", source);
		context.put("externalDataSources", true);
		context.put("source", source);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
		response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
				hasSize(0));
	}

	/**
	 * Returns the response of retrieving a retail account
	 *
	 * @param accountsCommonTestData
	 *                the test data
	 * @return retailAccountMap
	 */
	private static HashMap<String, String> getRetailAccountInformation(
			final AccountsCommonTestData accountsCommonTestData, final String oAuth)
	{
		final VelocityContext context = new VelocityContext();
		context.put("mid", accountsCommonTestData.getMid());
		context.put("retailLid", accountsCommonTestData.getSsn());
		context.put("source", "RETAIL");

		RestAssured.reset();
		RestAssured.baseURI = currentHost;
		RestAssured.useRelaxedHTTPSValidation();

		final RequestSpecification request =
				OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		request.given().log().all();
		final Response response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		response.then().log().all();
		if (response.statusCode() != HTTPStatusCodes.STATUS_200)
		{
			LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
					accountsCommonTestData.getSsn()));

			return null;
		}

		final JsonPath retailAccountJP = response.jsonPath();

		final HashMap<String, String> retailAccountMap = new HashMap<>();
		retailAccountMap.put("accountNumber",
				retailAccountJP.getString("accountList[0].accountId.accountNumber"));
		retailAccountMap.put("sourceSystem",
				retailAccountJP.getString("accountList[0].accountId.sourceSystem"));
		retailAccountMap.put("displayName", retailAccountJP.getString("accountList[0].displayName"));
		retailAccountMap.put("mnemonic", retailAccountJP.getString("accountList[0].regCode.mnemonic"));
		retailAccountMap.put("institutionName", retailAccountJP.getString("accountList[0].institutionName"));
		retailAccountMap.put("sourceMarketAmountType",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount._type"));
		retailAccountMap.put("sourceMarketAmountValue",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
		retailAccountMap.put("sourceMarketAmountValueType",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
		retailAccountMap.put("sourceMarketAmountCurrency",
				retailAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
		retailAccountMap.put("sourceMarketAsOfDate",
				retailAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));

		return retailAccountMap;
	}

	/**
	 * Tear down method
	 */
	@AfterClass(alwaysRun = true)
	public void tearDown()
	{
		testDataUtil.closeSQLiteConnection();
	}
}