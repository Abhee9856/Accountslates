/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.fullview;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.assertj.core.api.Assertions;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests Composite Details V1 for isFullviewDetailOverridden for Fullview Account
 *
 * @author a631781
 */
@Test(groups = {Tags.FULLVIEW, Tags.COMPOSITE, Tags.V1, Tags.TARGET_ACCOUNT, Tags.CRITICAL})
public class Fullview_Composite_isFullviewDetailOverridden_v1 extends PAPBaseServiceTest {

    protected Fullview_Composite_isFullviewDetailOverridden_v1() {
        super(Services.Account);
    }

    //Context
    private VelocityContext context;

    private AccountsCommonTestData accountsCommonTestData;
    private String accountNumber;
    private String acctRoot;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Fullview_Composite_AllDetails.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    private String mnemonic;

    private String accountId;

    private String displayName;
    private String source;

    private float value;

    private String institutionName;

    private String asOfDate;
    private float historicMarketValue = 6666f;
    private float historicMarketValueResponse;
    private Boolean isFullviewDetailOverridden;
    private Boolean isFullviewDetailOverriddenReq;
    private float detailValue = 1111f;

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init() {
        String oAuth = AccountUtil.getOauthToken();

        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Fullview", oAuth);

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", AccountConstants.FULLVIEW);
    }


    /**
     * Create Fullview Composite account Details with different combination of isFullviewDetailOverridden from DataProvider.
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getFullViewData",
            dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data) {
        getFullviewAccountInfo();
        getCompositeAccount();
        createCompositeAccount();
        getCompositeAccountAfterCreate();
        updateCompositeAccount(data);
        getCompositeAccountAfterUpdate(data);
        deleteCompositeAccount();
        getCompositeAccountAfterDelete();
    }

    /**
     * Get Fullview account info from the backend. Save the account number.
     */
    private void getFullviewAccountInfo() {
        // Generate request body
        context.put("externalDataSources", "false");
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        source = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V1
     */
    private void getCompositeAccount() {
        // Exclude external data
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());

    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V1
     */
    private void createCompositeAccount() {
        // Generate request body
        context.put("mnemonic", mnemonic);
        context.put("sourceSystem2", source);
        context.put("value", value);
        context.put("accountNumber", accountNumber);
        context.put("accId", "");
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);
        context.put("_type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS);
        context.put("detailValue", detailValue);
        context.put("externalDataSources", "false");
        context.put("isFullviewDetailOverridden", "");
        context.put("historicMarketValue", "");


        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accountNumber + "'}.";
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(mnemonic))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(value))
                .body(acctRoot + "details", notNullValue());


        accountId = response.path("accounts[0].account.accountId.id");
    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V1
     */
    private void getCompositeAccountAfterCreate() {
        // Generate request body
        context.put("source", source);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountId))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(mnemonic))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(value))
                .body(acctRoot + "details.historicMarketValue.amount.value", equalTo(value));
    }

    /**
     * Runs an update on the new account and verifies content in the response.
     * <p>
     * Version V1
     */
    private void updateCompositeAccount(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("mnemonic", mnemonic);
        context.put("sourceSystem2", source);
        context.put("value", value);
        context.put("accountNumber", accountNumber);
        context.put("accId", accountId);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);
        context.put("_type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS);
        context.put("source", AccountConstants.FULLVIEW);
        context.put("historicMarketValue", historicMarketValue);
        context.put("detailValue", detailValue);
        context.put("externalDataSources", "false");
        if (data.getIsFullviewDetailOverridden().equals("Y")) {
            isFullviewDetailOverriddenReq = true;
            isFullviewDetailOverridden = true;

        } else if (data.getIsFullviewDetailOverridden().equals("N")) {
            isFullviewDetailOverriddenReq = false;
            isFullviewDetailOverridden = false;
        } else {
            isFullviewDetailOverriddenReq = null;
            isFullviewDetailOverridden = false;
        }

        context.put("isFullviewDetailOverridden", isFullviewDetailOverriddenReq);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(mnemonic))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(value));
        historicMarketValueResponse = response.path(acctRoot + "details.historicMarketValue.amount.value");
        if (isFullviewDetailOverridden) {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(historicMarketValue);
        } else {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(value);
        }
    }

    /**
     * Gets the composite accounts and verifies that content is still coming back.
     * <p>
     * Version V1
     */
    private void getCompositeAccountAfterUpdate(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("source", source);
        context.put("externalDataSources", "false");
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountId))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(mnemonic))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(value));
        if (isFullviewDetailOverridden) {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(historicMarketValue);
        } else {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(value);
        }
    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V1
     */
    private void deleteCompositeAccount() {
        context.put("accId", accountId);
        context.put("accountNumber", accountNumber);
        context.put("source", source);
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accountList", empty());
    }

    /**
     * Call delete and confirm that no accounts come back in the response.
     * <p>
     * Version V1
     */
    private void getCompositeAccountAfterDelete() {
        // Generate request body
        context.put("externalDataSources", "true");
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());
    }

}