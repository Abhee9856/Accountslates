/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.fullview;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.not;

/**
 * Class to test TAM is created successfully via UPDATE method.
 *
 * @author a631781
 */
@Test(groups = {Tags.FULLVIEW, Tags.COMPOSITE})
public class Fullview_Composite_V1_Update_TAM_Test extends PAPBaseServiceTest {

    protected Fullview_Composite_V1_Update_TAM_Test() {
        super(Services.Account);
    }

    //Context
    private VelocityContext context;

    private final float fundingAccountAmount = 5.55f;

    private AccountsCommonTestData accountsCommonTestData;
    private String accNum;
    private String acctRoot;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Fullview_Composite_V1_Update_TAM_Test.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    private final float updatedUnknownAmount = 26.0f;
    private static String tamName = "Aggressive Growth";
    private static float tamTotalEquity = 0.85F;
    private static float tamDomesticEquity = 0.6F;
    private static float tamForeignEquity = 0.25F;
    private static float tamBond = 0.15F;
    private static float tamCash = 0.0F;

    private static String tamCategory = "INVESTOR_SELECTED_STRATEGY";
    private static Integer tamRepositoryTamId = 181;
    private static Integer tamAssetAllocationId = 85;

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init() {
        String oAuth = AccountUtil.getOauthToken();

        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Fullview", oAuth);
        //Data setup
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", AccountConstants.FULLVIEW);
    }

    /**
     * Get Fullview account info from the backend. Save the account number.
     */
    @Test
    public void getFullviewAccountInfo() {
        context.put("mnemonicFilter", "IRA");
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    // Get composite accounts for user.
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void getCompositeAccount() {
        // Exclude external data
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());

    }

    // Create a new composite account. Save the account ID and account number.
    @Test(dependsOnMethods = "getCompositeAccount")
    public void createCompositeAccount() {
        // Generate request body
        accNum = accountsCommonTestData.getAccountNumber1();
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accNum);
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("_type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS);


        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        acctRoot + "account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()),
                        acctRoot + "details.costBasis.value", equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))),
                        acctRoot + "details.state", equalTo("AK"));

        //Save account number and ID
        accountsCommonTestData.setAccountId1(response.path(acctRoot + "account.accountId.id"));
        accountsCommonTestData.setAccountNumber1(response.path(acctRoot + "account.accountId.accountNumber"));
    }

    //Gets composite account and verifies there is content in the response.
    @Test(dependsOnMethods = "createCompositeAccount")
    public void getCompositeAccountAfterCreate() {
        // Generate request body
        context.put("source", null);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        acctRoot + "account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()),
                        acctRoot + "details.costBasis.value", equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))),
                        acctRoot + "details.state", equalTo("AK"));
    }

    //Create TAM via update call
    @Test(dependsOnMethods = "getCompositeAccountAfterCreate")
    public void updateCompositeAccount() {
        // Populate variables for tests into context
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("_type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS);
        context.put("TAM_name", tamName);
        context.put("TAM_total_equity", tamTotalEquity);
        context.put("TAM_domestic_equity", tamDomesticEquity);
        context.put("TAM_foreign_equity", tamForeignEquity);
        context.put("TAM_bond", tamBond);
        context.put("TAM_cash", tamCash);
        context.put("TAM_category", tamCategory);
        context.put("TAM_repositoryTamId", tamRepositoryTamId);
        context.put("TAM_assetAllocationId", tamAssetAllocationId);

        // Generate request body
        context.put("source", AccountConstants.FULLVIEW);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo(tamName))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".netPercentage.value", equalTo(tamTotalEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(tamDomesticEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(tamForeignEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}"
                        + ".netPercentage.value", equalTo(tamBond))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}"
                        + ".netPercentage.value", equalTo(tamCash));
    }


    //Get composite account after update
    @Test(dependsOnMethods = "updateCompositeAccount")
    public void getCompositeAccountAfterUpdate() {
        // Generate request body
        context.put("source", null);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        acctRoot + "account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
                        acctRoot + "positions.marketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
                        acctRoot + "details.costBasis.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedDetailValue"))),
                        acctRoot + "details.state", equalTo("AK"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo(tamName))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".netPercentage.value", equalTo(tamTotalEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(tamDomesticEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(tamForeignEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}"
                        + ".netPercentage.value", equalTo(tamBond))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}"
                        + ".netPercentage.value", equalTo(tamCash));  }

    // Delete the composite account that we created. Verify the account list is empty.
    @Test(dependsOnMethods = "getCompositeAccountAfterUpdate")
    public void deleteCompositeAccount() {
        // Generate request body
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("source", accountsCommonTestData.getSourceSystem1());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accountList", empty());
    }

    // Call delete and confirm that no accounts come back in the response.
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void getCompositeAccountAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());
    }
}