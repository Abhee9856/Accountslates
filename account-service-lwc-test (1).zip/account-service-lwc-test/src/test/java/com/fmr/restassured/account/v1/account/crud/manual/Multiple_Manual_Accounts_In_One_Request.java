/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Tests account/CRUD operation for manual account with multiple accounts in one request. Tests will run against V1.
 *
 * @author a608077
 */
@Test(groups = {
        Tags.PIPELINE,
        Tags.ASYNCHRONOUS,
        Tags.MANUAL,
        Tags.ACCOUNT,
        Tags.V1,
        Tags.CRUD})
public class Multiple_Manual_Accounts_In_One_Request extends PAPBaseServiceTest {

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private String accId_1;
    private String accId_2;
    private String accId_3;
    private final String asOfDate = "2014-10-31";
    private final String displayName1 = "SOA Test Manual Account 1";
    private final String displayName2 = "SOA Test Manual Account 2";
    private final String displayName3 = "SOA Test Manual Account 3";
    private final float updatedValue = 426.85f;
    String source = "MANUAL";
    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Multiple_Manual_Accounts_In_One_Request.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;
    private String mid;// = "ManualAccountV1TestMid";

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;


    protected Multiple_Manual_Accounts_In_One_Request() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        String oAuthToken = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("Multiple_Manual_Accounts_In_One_Request",oAuthToken);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuthToken, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuthToken));

        // Populate request variables
        context = new VelocityContext();

        context.put("mid", accountsCommonTestData.getMid());
        context.put("source", source);
    }

    /**
     * Create a manual account
     */
    @Test
    public void createManualAccount() {

        float value = 818.89f;
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "401K");
        context.put("displayName", displayName1);
        context.put("value", value);
        context.put("asOfDate", asOfDate);
        context.put("ppid2", accountsCommonTestData.getPpid());
        context.put("mnemonic2", "IRA");
        context.put("displayName2", displayName2);
        context.put("source2", source);
        context.put("value2", value);
        context.put("asOfDate2", asOfDate);
        context.put("ppid3", accountsCommonTestData.getPpid());
        context.put("mnemonic3", "403B");
        context.put("displayName3", displayName3);
        context.put("source3", source);
        context.put("value3", value);
        context.put("asOfDate3", asOfDate);


        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        accId_1 = response.path("accountList.find{it.displayName == \"SOA Test Manual Account 1\" }.accountId.accountNumber");

        accId_2 = response.path("accountList.find{it.displayName == \"SOA Test Manual Account 2\" }.accountId.accountNumber");

        accId_3 = response.path("accountList.find{it.displayName == \"SOA Test Manual Account 3\" }.accountId.accountNumber");


    }

    /**
     * Tests that account data is brought back for manual account.
     * Version V1
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void verifyAfterCreate() {

        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Set URL to V1 before running again
        response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo("MANUAL"))
                .body("accountList.find{it.displayName == \"SOA Test Manual Account 1\" }.accountId.accountNumber", equalTo(accId_1))
                .body("accountList.find{it.displayName == \"SOA Test Manual Account 2\" }.accountId.accountNumber", equalTo(accId_2))
                .body("accountList.find{it.displayName == \"SOA Test Manual Account 3\" }.accountId.accountNumber", equalTo(accId_3));
    }

    /**
     * Update the account
     */
    @Test(dependsOnMethods = "verifyAfterCreate")
    public void updateManualAccount() {

        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "401K");
        context.put("accId", accId_1);
        context.put("displayName", displayName1);
        context.put("value", updatedValue);
        context.put("asOfDate", asOfDate);
        context.put("mnemonic2", "IRA");
        context.put("accId2", accId_2);
        context.put("displayName2", displayName2);
        context.put("source2", source);
        context.put("value2", updatedValue);
        context.put("asOfDate2", asOfDate);
        context.put("mnemonic3", "403B");
        context.put("accId3", accId_3);
        context.put("displayName3", displayName3);
        context.put("source3", source);
        context.put("value3", updatedValue);
        context.put("asOfDate3", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

        response = request.post(AccountsPaths.UPDATE_ACCOUNT_V1);

        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo("MANUAL"))
                .body("accountList.find{it.displayName == \"SOA Test Manual Account 1\" }.accountId.accountNumber", equalTo(accId_1))
                .body("accountList.find{it.displayName == \"SOA Test Manual Account 2\" }.accountId.accountNumber", equalTo(accId_2))
                .body("accountList.find{it.displayName == \"SOA Test Manual Account 3\" }.accountId.accountNumber", equalTo(accId_3))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));
    }

    /**
     * Tests that updated data is brought back from account/get
     * Version V1
     */
    @Test(dependsOnMethods = "updateManualAccount")
    public void verifyAfterUpdate() {

        context.put("externalDataSources", true);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo("MANUAL"))
                .body("accountList.find{it.displayName == \"SOA Test Manual Account 1\" }.accountId.accountNumber", equalTo(accId_1))
                .body("accountList.find{it.displayName == \"SOA Test Manual Account 2\" }.accountId.accountNumber", equalTo(accId_2))
                .body("accountList.find{it.displayName == \"SOA Test Manual Account 3\" }.accountId.accountNumber", equalTo(accId_3))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));


    }

    /**
     * Deletes the manual account
     */
    @Test(dependsOnMethods = "verifyAfterUpdate")
    public void deleteManualAccount() {

        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "401K");
        context.put("accId", accId_1);
        context.put("displayName", displayName1);
        context.put("value", updatedValue);
        context.put("asOfDate", asOfDate);
        context.put("mnemonic2", "IRA");
        context.put("accId2", accId_2);
        context.put("displayName2", displayName2);
        context.put("source2", source);
        context.put("value2", updatedValue);
        context.put("asOfDate2", asOfDate);
        context.put("mnemonic3", "403B");
        context.put("accId3", accId_3);
        context.put("displayName3", displayName3);
        context.put("source3", source);
        context.put("value3", updatedValue);
        context.put("asOfDate3", asOfDate);


        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().
                statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                // No accounts are returned
                .body("accountList", hasSize(0));
    }

    /**
     * Tests that data is deleted
     * Version V1
     */
    @Test(dependsOnMethods = "deleteManualAccount")
    public void verifyAfterDelete() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().
                statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                // No accounts are returned
                .body("accountList", hasSize(0));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}