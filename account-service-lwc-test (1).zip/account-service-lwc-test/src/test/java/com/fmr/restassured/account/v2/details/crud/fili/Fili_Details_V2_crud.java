/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.crud.fili;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.equalTo;

/**
 * Tests CRUD operations of account details V2 for Fili Accounts. First, retrieves Fili account, then loops through all
 * accounts and creates account details for each account.
 *
 * @author a560878 Updated by a608077 on 03/30/2022
 * Updated by @author a631781
 * Updated by a608077 on 10/11/2023 to include 3 new asset classes: Private Equity, Private Credit,
 * and Real Assets(PFCP-13826)
 */
@Test(groups = {Tags.CRITICAL, Tags.FILI, Tags.DETAILS, Tags.V2, Tags.TAM})

public class Fili_Details_V2_crud extends PAPBaseServiceTest
{

    protected Fili_Details_V2_crud()
    {
	super(Services.Account);
    }

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Fili_Details_V2_crud.class.getSimpleName();

    private static final String fsreqid = logTrackingId;

    // Test data
    private String accId;

    private final float updatedValue = 426.85f;

    private final String sourceSystem = AccountConstants.FILI;

    private static final String FEDERAL_TAX_WITHHOLDING_PCT = "federalTaxWithholdingPercent";

    private static final String STATE_TAX_WITHHOLDING_PCT = "stateTaxWithholdingPercent";

    private final String tamAssetClass = "TOTAL_EQUITY";

    private final String assetClass = "TOTAL_EQUITY";

    private final float netPercentage = 1.0f;

    private final String assetClass1 = "BOND";

    private final float netPercentage1 = 0.5f;

    private final String assetClass2 = "CASH";

    private final float netPercentage2 = 0.3f;

    private final String assetClass3 = "OTHER";

    private final float netPercentage3 = 0.4f;

    private final float netPercentageUpdated = 0.9f;

    private final float netPercentageUpdated1 = 0.2f;

    private final float netPercentageUpdated2 = 0.8f;

    private final float netPercentageUpdated3 = 0.7f;

    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";

    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";

    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";

    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";

    private final float netPercentage_T_ALTERNATIVE = 0.8f;

    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;

    private final float netPercentage_PEA = 0.4f;

    private final float netPercentage_Updated_PEA = 0.2f;

    private final float netPercentage_PCA = 0.2f;

    private final float netPercentage_Updated_PCA = 0.3f;

    private final float netPercentage_PRAA = 0.2f;

    private final float netPercentage_Updated_PRAA = 0.1f;

	private static final String TRUSTEE_TYPE = "FPTC";
	private static final String TRUSTEE_TYPE_UPDATE = "ABCD";

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
     * endpoint for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	p2TestDataUtil = new TestDataUtil();

	final String oAuth = AccountUtil.getOauthToken();

	accountsCommonTestData =
			TestDataUtil.populateRegressionTestData("account_get_FILI_Reg_Code_I_82", oAuth);

	String mid = accountsCommonTestData.getMid();
	accountsCommonTestData.setMid(mid);

	DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuth, "true");

	accountsCommonTestData
			.setPpid(Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth));

	// Common headers setup
	setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

	request.given().header(new Header("user-poe", AccountConstants.RETAIL))
			.header(new Header("user-mid", accountsCommonTestData.getMid()))
			.header(new Header("user-sid", accountsCommonTestData.getSid()))
			.header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));

	// Populate request variables
	context = new VelocityContext();
	context.put("source", sourceSystem);

	accountsCommonTestData.set(FEDERAL_TAX_WITHHOLDING_PCT, "0.8");
	accountsCommonTestData.set(STATE_TAX_WITHHOLDING_PCT, "0.8");

    }

    /**
     * Tests that account data is brought back for Fili account.
     * <p>
     * Version V2
     */
    @Test
    public void getFiliAccountInfo()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	// Call Account service v2
	response = request.post(AccountsPaths.GET_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200)
			.body("accountList[0].accountId.sourceSystem", equalTo(sourceSystem))
			.body("accountList", Matchers.not(Matchers.hasSize(0)));

	// Save data from backend
	accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
	accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
	accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
	accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
	accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));

    }

    /**
     * Creates a new Fili account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getFiliAccountInfo")
    public void createFiliAccount()
    {
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("source", accountsCommonTestData.getSourceSystem1());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

	// Call Account service
	response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
			"accountList[0].accountId.accountNumber",
			equalTo(accountsCommonTestData.getAccountNumber1()),
			"accountList[0].accountId.sourceSystem", equalTo("FILI"));
	accId = response.path("accountList[0].accountId.id");
    }

    /**
     * Create Fili account Details Request.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createFiliAccount")
    public void createAccountDetails()
    {

	request.header(new Header("excludeExternalDataSources", "true"));

	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "annuityAccountDetail");
	context.put("tamAssetClass", tamAssetClass);
	context.put(FEDERAL_TAX_WITHHOLDING_PCT, accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT));
	context.put(STATE_TAX_WITHHOLDING_PCT, accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT));
	context.put("assetClass", assetClass);
	context.put("netPercentage", netPercentage);
	context.put("assetClass1", assetClass1);
	context.put("netPercentage1", netPercentage1);
	context.put("assetClass2", assetClass2);
	context.put("netPercentage2", netPercentage2);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentage3);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA", netPercentage_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA", netPercentage_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA", netPercentage_PRAA);
		context.put("trusteeType", TRUSTEE_TYPE);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.accountId.sourceSystem",
			equalTo("FILI"),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.fidelityAccount",
			equalTo(true),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
			equalTo(tamAssetClass),

			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.federalTaxWithholdingPercent",
			equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.stateTaxWithholdingPercent",
			equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.accountId.id",
			Matchers.notNullValue(),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass + "'}.assetClass",
			equalTo(assetClass),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass + "'}.netPercentage",
			equalTo(netPercentage),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass1 + "'}.assetClass",
			equalTo(assetClass1),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass1 + "'}.netPercentage",
			equalTo(netPercentage1),

			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass2 + "'}.assetClass",
			equalTo(assetClass2),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass2 + "'}.netPercentage",
			equalTo(netPercentage2),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass3 + "'}.assetClass",
			equalTo(assetClass3),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass3 + "'}.netPercentage",
			equalTo(netPercentage3),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.trusteeType",
			equalTo(TRUSTEE_TYPE))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_T_ALTERNATIVE))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PCA))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PEA))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PRAA));
    }

    /**
     * Validate the Fili account details after create.
     * <p>
     * Version V2
     * //
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("source", sourceSystem);
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.accountId.sourceSystem",
			equalTo("FILI"),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.fidelityAccount",
			equalTo(true),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
			equalTo(tamAssetClass),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.federalTaxWithholdingPercent",
			equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.stateTaxWithholdingPercent",
			equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.accountId.id",
			Matchers.notNullValue(),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass + "'}.assetClass",
			equalTo(assetClass),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass + "'}.netPercentage",
			equalTo(netPercentage),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass1 + "'}.assetClass",
			equalTo(assetClass1),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass1 + "'}.netPercentage",
			equalTo(netPercentage1),

			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass2 + "'}.assetClass",
			equalTo(assetClass2),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass2 + "'}.netPercentage",
			equalTo(netPercentage2),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass3 + "'}.assetClass",
			equalTo(assetClass3),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
					+ assetClass3 + "'}.netPercentage",
			equalTo(netPercentage3),
			"accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
					+ accountsCommonTestData.getAccountNumber1()
					+ "'}.annuityAccountDetail.accountDetail.trusteeType",
			equalTo(TRUSTEE_TYPE))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_T_ALTERNATIVE))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PCA))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PEA))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_PRAA));
    }

    /**
     * Update the account details for Fili account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());

	context.put("value", updatedValue);
	context.put("source", sourceSystem);
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "annuityAccountDetail");
	context.put("assetClass", assetClass);
	context.put("netPercentage", netPercentageUpdated);
	context.put("assetClass1", assetClass1);
	context.put("netPercentage1", netPercentageUpdated1);
	context.put("assetClass2", assetClass2);
	context.put("netPercentage2", netPercentageUpdated2);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentageUpdated3);
	context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
	context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
	context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
	context.put("netPercentage_PEA", netPercentage_Updated_PEA);
	context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
	context.put("netPercentage_PCA", netPercentage_Updated_PCA);
	context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
	context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
		context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_DETAILS_UPDATE_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountDetails", notNullValue())
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.annuityAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo("FILI"))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.trusteeType",
					equalTo(TRUSTEE_TYPE_UPDATE))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					CoreMatchers.equalTo(assetClass))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass1))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated1))

			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass2))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated2))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass3))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated3))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_T_ALTERNATIVE))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PCA))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PEA))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PRAA));
    }

    /**
     * Validate the updated Fili account details.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("source", sourceSystem);
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountDetails", notNullValue())
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accountsCommonTestData.getAccountNumber1()
							+ "'}.annuityAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo("FILI"))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.trusteeType",
					equalTo(TRUSTEE_TYPE_UPDATE))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					CoreMatchers.equalTo(assetClass))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass1))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated1))

			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass2))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated2))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					CoreMatchers.equalTo(assetClass3))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + this.accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentageUpdated3))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_T_ALTERNATIVE))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PCA))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PEA))
			.body("accountDetails.find{it.annuityAccountDetail.accountDetail.accountId.id=='" + accId
							+ "'}.annuityAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
							+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
					CoreMatchers.equalTo(netPercentage_Updated_PRAA));

    }

    /**
     * Delete the Fili account Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteFiliAccount()
    {
	context.put("id", accId);
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200).body("isEmpty()", Matchers.is(true));
    }

    /**
     * Validate the Fili account was deleted.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteFiliAccount")
    public void getDetailsAfterDelete()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("isEmpty()",
			Matchers.is(true));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	p2TestDataUtil.closeSQLiteConnection();
    }

}