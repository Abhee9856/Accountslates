/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

/**
 * Tests account/CRUD operation for manual account with Partner and Dependent in one request. Tests will run against V1.
 *
 * @author a608077
 */
@Test(groups = {
        Tags.PIPELINE,
        Tags.ASYNCHRONOUS,
        Tags.MANUAL,
        Tags.ACCOUNT,
        Tags.V1,
        Tags.CRUD})
public class Multiple_Manual_Accounts_With_Partner_And_Dependent_In_One_Request extends PAPBaseServiceTest {

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private String accId_Principal;
    private String accId_Partner;
    private String accId_Dependent;
    private String pid_dependent;
    private String pid_partner;
    private final String asOfDate = "2014-10-31";
    private final float updatedValue = 426.85f;
    private String mid;// = "ManualAccountV1TestMid";
    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Multiple_Manual_Accounts_With_Partner_And_Dependent_In_One_Request.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    protected Multiple_Manual_Accounts_With_Partner_And_Dependent_In_One_Request() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        String oAuthToken = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_manual",oAuthToken);
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);
        testDataUtil = new TestDataUtil();

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuthToken, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuthToken));

        pid_dependent = Identity.createHouseholdIdentityDependent(accountsCommonTestData.getMid(), oAuthToken);
        pid_partner = Identity.createHouseholdIdentityPartner(accountsCommonTestData.getMid(), oAuthToken);

        // Populate request variables
        context = new VelocityContext();

        String source = "MANUAL";
        context.put("mid", accountsCommonTestData.getMid());
        context.put("source", source);
    }

    /**
     * Create a manual account
     */
    @Test
    public void createManualAccount() {

        float value = 818.89f;
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "401K");
        context.put("value", value);
        context.put("asOfDate", asOfDate);
        context.put("pid_partner", pid_partner);
        context.put("mnemonic2", "IRA");
        context.put("value2", value);
        context.put("pid_dependent", pid_dependent);
        context.put("mnemonic3", "403B");
        context.put("value3", value);


        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_PARTNER_DEPENDENT_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
                .body("accountList.accountId.find{it.owner.relationship == \"PRINCIPAL\" }.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body("accountList.accountId.find{it.owner.relationship == \"PARTNER\" }.owner.id", equalTo(pid_partner))
                .body("accountList.accountId.find{it.owner.relationship == \"DEPENDENT\" }.owner.id", equalTo(pid_dependent));

        accId_Principal = response.path("accountList.accountId.find{it.owner.relationship == \"PRINCIPAL\" }.accountNumber");
        accId_Partner = response.path("accountList.accountId.find{it.owner.relationship == \"PARTNER\" }.accountNumber");
        accId_Dependent = response.path("accountList.accountId.find{it.owner.relationship == \"DEPENDENT\" }.accountNumber");

    }

    /**
     * Tests that account data is brought back for manual account.
     * Version V1
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void verifyAfterCreate() {

        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        //Run test
        response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
                .body("accountList.accountId.find{it.owner.relationship == \"PRINCIPAL\" }.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body("accountList.accountId.find{it.owner.relationship == \"PARTNER\" }.owner.id", equalTo(pid_partner))
                .body("accountList.accountId.find{it.owner.relationship == \"DEPENDENT\" }.owner.id", equalTo(pid_dependent));

    }

    /**
     * Update the account
     */
    @Test(dependsOnMethods = "verifyAfterCreate")
    public void updateManualAccount() {

        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "401K");
        context.put("value", updatedValue);
        context.put("asOfDate", asOfDate);
        context.put("accId", accId_Principal);
        context.put("pid_partner", pid_partner);
        context.put("accId2", accId_Partner);
        context.put("mnemonic2", "IRA");
        context.put("value2", updatedValue);
        context.put("pid_dependent", pid_dependent);
        context.put("accId3", accId_Dependent);
        context.put("mnemonic3", "403B");
        context.put("value3", updatedValue);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_PARTNER_DEPENDENT_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.UPDATE_ACCOUNT_V1);

        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
                .body("accountList.accountId.find{it.owner.relationship == \"PRINCIPAL\" }.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body("accountList.accountId.find{it.owner.relationship == \"PARTNER\" }.owner.id", equalTo(pid_partner))
                .body("accountList.accountId.find{it.owner.relationship == \"DEPENDENT\" }.owner.id", equalTo(pid_dependent))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));
    }

    /**
     * Tests that updated data is brought back from account/get
     * Version V1
     */
    @Test(dependsOnMethods = "updateManualAccount")
    public void verifyAfterUpdate() {

        context.put("externalDataSources", true);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
                .body("accountList.accountId.find{it.owner.relationship == \"PRINCIPAL\" }.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body("accountList.accountId.find{it.owner.relationship == \"PARTNER\" }.owner.id", equalTo(pid_partner))
                .body("accountList.accountId.find{it.owner.relationship == \"DEPENDENT\" }.owner.id", equalTo(pid_dependent))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));


    }

    /**
     * Deletes the manual account
     */
    @Test(dependsOnMethods = "verifyAfterUpdate")
    public void deleteManualAccount() {

        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "401K");
        context.put("value", updatedValue);
        context.put("asOfDate", asOfDate);
        context.put("accId", accId_Principal);
        context.put("pid_partner", pid_partner);
        context.put("accId2", accId_Partner);
        context.put("mnemonic2", "IRA");
        context.put("value2", updatedValue);
        context.put("pid_dependent", pid_dependent);
        context.put("accId3", accId_Dependent);
        context.put("mnemonic3", "403B");
        context.put("value3", updatedValue);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_PARTNER_DEPENDENT_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().
                statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                // No accounts are returned
                .body("accountList", hasSize(0));
    }

    /**
     * Tests that data is deleted
     * Version V1
     */
    @Test(dependsOnMethods = "deleteManualAccount")
    public void verifyAfterDelete() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().
                statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                // No accounts are returned
                .body("accountList", hasSize(0));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}