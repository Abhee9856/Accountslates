/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * Contains tests that validate ScenarioID header validation for Account Composite operation for Retail Accounts -
 * includes CRUD validations (v2)
 *
 * @author a631781
 */
@Test(groups = {Tags.PIPELINE, Tags.ASYNCHRONOUS, Tags.RETAIL, Tags.COMPOSITE, Tags.V2})
public class Retail_Composite_v2_AllDetails_ScenarioId extends PAPBaseServiceTest
{
    
    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static Logger LOGGER = LogManager.getLogger(Retail_Composite_v2_AllDetails_ScenarioId.class);
    
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;
    
    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;
    
    /**
     * Global variable holding retailAccount information
     */
    private HashMap<String, String> retailAccountMap;
    
    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountTestData;
    
    private static final String CALLING_APP_ID = "AP136091";
    
    private static final String APP_ID = "AP136091";
    
    private static final String LOG_TRACKING_ID = Retail_Composite_v2_AllDetails_ScenarioId.class.getSimpleName();
    
    private static final String FSREQID = LOG_TRACKING_ID;
    
    private String scenarioId;
    
    Response allScenarioIDs;
    
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    
    /**
     * Constructor
     */
    protected Retail_Composite_v2_AllDetails_ScenarioId()
    {
        super(Services.Account);
    }
    
    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass()
    {
        this.oAuth = AccountUtil.getOauthToken();
        this.testDataUtil = new TestDataUtil();
        this.retailAccountMap = new HashMap<String, String>();
        
        this.accountTestData = TestDataUtil.populateRegressionTestData("account_default_ssn", this.oAuth);
        this.retailAccountMap = getRetailAccountInformationV2(this.accountTestData, this.oAuth);
        
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountTestData.getMid(), this.oAuth);
        final String ppid = Identity.createHouseholdIdentity(this.accountTestData.getMid(), this.oAuth);
        this.accountTestData.setPpid(ppid);
        // Get/Create ScenarioId
        allScenarioIDs = Scenario.getAllScenarios(this.accountTestData.getMid(), oAuth);
        scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null)
        {
            scenarioId = Scenario.createScenarioWithProductCode(this.accountTestData.getMid(), SCENARIO_PRODUCT_CODE,
                    SCENARIO_CATEGORY_CODE,
                    oAuth);
        }
    }
    
    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init()
    {
        this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);
        this.request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-id", scenarioId));
    }
    
    /**
     * Description: Validates an empty account list when calling get account composite retail before creation of an
     * account
     */
    @Test
    public void getCompositeAccountRetailV2BeforeCreate()
    {
        if (this.retailAccountMap.isEmpty())
        {
            throw new SkipException(
                    "'getCompositeAccountRetailV2BeforeCreate' test scenario cannot run due to failure to retrieve "
                            + "retail account information!");
        }
        
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", this.retailAccountMap.get("sourceSystem"));
        
        this.request.header(new Header("user-mid", this.accountTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }
    
    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after a create
     */
    @Test(dependsOnMethods = "getCompositeAccountRetailV2BeforeCreate")
    public void createCompositeAccountRetailV2()
    {
        final VelocityContext context = new VelocityContext();
        context.put("accountNumber", this.retailAccountMap.get("accountNumber"));
        context.put("source", this.retailAccountMap.get("sourceSystem"));
        context.put("ppid", this.accountTestData.getPpid());
        context.put("displayName", this.retailAccountMap.get("displayName"));
        context.put("mnemonic", this.retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", this.retailAccountMap.get("sourceSystem"));
        context.put("institutionName", this.retailAccountMap.get("institutionName"));
        context.put("value", this.retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", this.retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "111111.11");
        context.put("emergencyFundAmountValue", "111111.11");
        context.put("contribFreq", "MONTHLY");
        context.put("contribValue", "500");
        context.put("withdrawAmount", "500");
        context.put("withdrawFreq", "HOURLY");
        
        this.request.header(new Header("user-mid", this.accountTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountTestData.getSsn()));
        
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));
        
        this.response = this.request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", notNullValue())
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(this.retailAccountMap.get("accountNumber")))
                .body("accounts[0].account.accountId.sourceSystem",
                        equalTo(this.retailAccountMap.get("sourceSystem")))
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountTestData.getPpid()))
                .body("accounts[0].account.displayName",
                        equalTo(this.retailAccountMap.get("displayName")))
                .body("accounts[0].account.regCode.mnemonic",
                        equalTo(this.retailAccountMap.get("mnemonic")))
                .body("accounts[0].account.institutionName",
                        equalTo(this.retailAccountMap.get("institutionName")))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(
                                this.retailAccountMap.get("sourceMarketAmountValue"))))
                .body("accounts[0].details", notNullValue())
                .body("accounts[0].details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
                        equalTo(111111.11f))
                .body("accounts[0].contributions", notNullValue())
                .body("accounts[0].contributions.contributions[0].contribution.value", equalTo(500.0f))
                .body("accounts[0].contributions.contributions[0].frequency", equalTo("MONTHLY"))
                .body("accounts[0].suitability", notNullValue())
                .body("accounts[0].withdrawals", notNullValue())
                .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(500.0f))
                .body("accounts[0].withdrawals[0].amount.frequency", equalTo("HOURLY"));
        
        this.accountTestData
                .setAccountId1(this.response.jsonPath().getString("accounts[0].account.accountId.id"));
    }
    
    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after a create (get)
     */
    @Test(dependsOnMethods = "createCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterCreate()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", this.retailAccountMap.get("sourceSystem"));
        
        this.request.header(new Header("user-mid", this.accountTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", notNullValue())
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(this.retailAccountMap.get("accountNumber")))
                .body("accounts[0].account.accountId.sourceSystem",
                        equalTo(this.retailAccountMap.get("sourceSystem")))
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountTestData.getPpid()))
                .body("accounts[0].account.displayName",
                        equalTo(this.retailAccountMap.get("displayName")))
                .body("accounts[0].account.regCode.mnemonic",
                        equalTo(this.retailAccountMap.get("mnemonic")))
                .body("accounts[0].account.institutionName",
                        equalTo(this.retailAccountMap.get("institutionName")))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(
                                this.retailAccountMap.get("sourceMarketAmountValue"))))
                .body("accounts[0].details", notNullValue())
                .body("accounts[0].details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
                        equalTo(111111.11f))
                .body("accounts[0].contributions", notNullValue())
                .body("accounts[0].contributions.contributions[0].contribution.value", equalTo(500.0f))
                .body("accounts[0].contributions.contributions[0].frequency", equalTo("MONTHLY"))
                .body("accounts[0].suitability", notNullValue())
                .body("accounts[0].withdrawals", notNullValue())
                .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(500.0f))
                .body("accounts[0].withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }
    
    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "getCompositeAccountRetailV2AfterCreate")
    public void updateCompositeAccountRetailV2()
    {
        final VelocityContext context = new VelocityContext();
        context.put("accId", this.accountTestData.getAccountId1());
        context.put("accountNumber", this.retailAccountMap.get("accountNumber"));
        context.put("source", this.retailAccountMap.get("sourceSystem"));
        context.put("ppid", this.accountTestData.getPpid());
        context.put("displayName", this.retailAccountMap.get("displayName"));
        context.put("mnemonic", this.retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", this.retailAccountMap.get("sourceSystem"));
        context.put("institutionName", this.retailAccountMap.get("institutionName"));
        context.put("value", this.retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", this.retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "211111.11");
        context.put("emergencyFundAmountValue", "211111.11");
        context.put("contribFreq", "MONTHLY");
        context.put("contribValue", "600");
        context.put("withdrawAmount", "800");
        context.put("withdrawFreq", "HOURLY");
        
        this.request.header(new Header("user-mid", this.accountTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountTestData.getSsn()));
        
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));
        
        this.response = this.request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", equalTo(this.accountTestData.getAccountId1()))
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(this.retailAccountMap.get("accountNumber")))
                .body("accounts[0].account.accountId.sourceSystem",
                        equalTo(this.retailAccountMap.get("sourceSystem")))
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountTestData.getPpid()))
                .body("accounts[0].account.displayName",
                        equalTo(this.retailAccountMap.get("displayName")))
                .body("accounts[0].account.regCode.mnemonic",
                        equalTo(this.retailAccountMap.get("mnemonic")))
                .body("accounts[0].account.institutionName",
                        equalTo(this.retailAccountMap.get("institutionName")))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(
                                this.retailAccountMap.get("sourceMarketAmountValue"))))
                .body("accounts[0].details", notNullValue())
                .body("accounts[0].details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
                        equalTo(211111.11f))
                .body("accounts[0].contributions", notNullValue())
                .body("accounts[0].contributions.contributions[0].contribution.value", equalTo(600.0f))
                .body("accounts[0].contributions.contributions[0].frequency", equalTo("MONTHLY"))
                .body("accounts[0].suitability", notNullValue())
                .body("accounts[0].withdrawals", notNullValue())
                .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(800.0f))
                .body("accounts[0].withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }
    
    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after an update (get)
     */
    @Test(dependsOnMethods = "updateCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterUpdate()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", this.retailAccountMap.get("sourceSystem"));
        
        this.request.header(new Header("user-mid", this.accountTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", equalTo(this.accountTestData.getAccountId1()))
                .body("accounts[0].account.accountId.accountNumber",
                        equalTo(this.retailAccountMap.get("accountNumber")))
                .body("accounts[0].account.accountId.sourceSystem",
                        equalTo(this.retailAccountMap.get("sourceSystem")))
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountTestData.getPpid()))
                .body("accounts[0].account.displayName",
                        equalTo(this.retailAccountMap.get("displayName")))
                .body("accounts[0].account.regCode.mnemonic",
                        equalTo(this.retailAccountMap.get("mnemonic")))
                .body("accounts[0].account.institutionName",
                        equalTo(this.retailAccountMap.get("institutionName")))
                .body("accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(
                                this.retailAccountMap.get("sourceMarketAmountValue"))))
                .body("accounts[0].details", notNullValue())
                .body("accounts[0].details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
                        equalTo(211111.11f))
                .body("accounts[0].contributions", notNullValue())
                .body("accounts[0].contributions.contributions[0].contribution.value", equalTo(600.0f))
                .body("accounts[0].contributions.contributions[0].frequency", equalTo("MONTHLY"))
                .body("accounts[0].suitability", notNullValue())
                .body("accounts[0].withdrawals", notNullValue())
                .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(800.0f))
                .body("accounts[0].withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }
    
    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after a delete
     */
    @Test(dependsOnMethods = "getCompositeAccountRetailV2AfterUpdate")
    public void deleteCompositeAccountRetailV2()
    {
        final VelocityContext context = new VelocityContext();
        context.put("accId", this.accountTestData.getAccountId1());
        context.put("accountNumber", this.retailAccountMap.get("accountNumber"));
        context.put("source", this.retailAccountMap.get("sourceSystem"));
        context.put("ppid", this.accountTestData.getPpid());
        context.put("displayName", this.retailAccountMap.get("displayName"));
        context.put("mnemonic", this.retailAccountMap.get("mnemonic"));
        context.put("institutionName", this.retailAccountMap.get("institutionName"));
        context.put("value", this.retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", this.retailAccountMap.get("sourceMarketAsOfDate"));
        
        this.request.header(new Header("user-mid", this.accountTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountTestData.getSsn()));
        
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));
        
        this.response = this.request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);
        
        final String emptyResponse = this.response.jsonPath().getString("$");
        assertThat(emptyResponse, equalTo("[:]"));
    }
    
    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates an empty account list when calling get account composite retail after delete
     */
     @Test(dependsOnMethods = "deleteCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterDelete()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", this.retailAccountMap.get("sourceSystem"));
        
        this.request.header(new Header("user-mid", this.accountTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }
    
    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown()
    {
        this.testDataUtil.closeSQLiteConnection();
    }
    
    /**
     * Returns the response of retrieving a retail account
     *
     * @param accountsCommonTestData
     * @return
     */
    private static HashMap<String, String> getRetailAccountInformationV2(
            final AccountsCommonTestData accountsCommonTestData,
            final String oAuth)
    {
        final VelocityContext context = new VelocityContext();
        context.put("source", "RETAIL");
        
        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();
        
        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid())).header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        
        final Response response = request.post(AccountsPaths.GET_ACCOUNT_V2);
        
        if (response.statusCode() != HTTPStatusCodes.STATUS_200)
        {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));
            
            return null;
        }
        
        final JsonPath retailAccountJP = response.jsonPath();
        
        final HashMap<String, String> retailAccountMap = new HashMap<String, String>();
        retailAccountMap.put("accountNumber",
                retailAccountJP.getString("accountList[0].accountId.accountNumber"));
        retailAccountMap.put("sourceSystem",
                retailAccountJP.getString("accountList[0].accountId.sourceSystem"));
        retailAccountMap.put("displayName", retailAccountJP.getString("accountList[0].displayName"));
        retailAccountMap.put("mnemonic", retailAccountJP.getString("accountList[0].regCode.mnemonic"));
        retailAccountMap.put("institutionName", retailAccountJP.getString("accountList[0].institutionName"));
        retailAccountMap.put("sourceMarketAmountValue",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
        retailAccountMap.put("sourceMarketAmountValueType",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        retailAccountMap.put("sourceMarketAmountCurrency",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        retailAccountMap.put("sourceMarketAsOfDate",
                retailAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));
        
        return retailAccountMap;
    }
}
