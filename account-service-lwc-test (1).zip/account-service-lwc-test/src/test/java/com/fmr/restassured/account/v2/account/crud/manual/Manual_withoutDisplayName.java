/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Tests for account V2 CrUD operation for multiple regCodes.
 *
 * @author a783909
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.ACCOUNT,
        Tags.V2,
        Tags.CRUD})
public class Manual_withoutDisplayName extends PAPBaseServiceTest {

    protected Manual_withoutDisplayName() {
        super(Services.Account);
    }

    // Data setup
    AccountsCommonTestData accountsCommonTestData;
    private VelocityContext context;
    private String mid;// = "ManualAccountV2TestMid";
    private String displayName = "RA Test Manual Account";
    private String institutionName = "AA";

    private String institutionNameUpdated = "AA1";
    private final float value = 818.89f;
    private final float updatedValue = 426.85f;
    private final String source = "MANUAL";
    private final String asOfDate1 = "2014-10-31";
    private String accId;
    private static final String LOG_TRACKING_ID = Manual_withoutDisplayName.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        String oAuthToken = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_manual", oAuthToken);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);

        testDataUtil = new TestDataUtil();

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuthToken, "true");

        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuthToken));

        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("scenario-category-code", "DEF"));

        context = new VelocityContext();
        context.put("source", "MANUAL");

    }

    /**
     * Tests for account V2 CRUD operation for multiple displayNames.
     */

    @Test(dataProvider = "getManualData", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperationsWithoutDisplayName(final AccountRegCodeTestData data) {
        this.createManualAccountsWithoutDisplayName(data);
        this.verifyAfterCreateWithDisplayName(data);
        this.updateManualAccountInstitutionName(data);
        this.verifyAfterUpdate(data);
        this.deleteManualAccount(data);
        this.verifyManualAccountAfterDelete(data);

    }

    /**
     * Create Manual Account V2
     */
    private void createManualAccountsWithoutDisplayName(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("id", null);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", data.getRegCode1());
        context.put("value", value);
        context.put("asOfDate", asOfDate1);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2_NO_DISPLAYNAME));
        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);
        institutionName = response.path("accountList[0].institutionName");

        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(this.value))
                .body("accountList[0].displayName", equalTo(institutionName));

        accId = response.path("accountList[0].accountId.id");
    }

    /**
     * Verify that account data is brought back for manual account.
     */
    private void verifyAfterCreateWithDisplayName(AccountRegCodeTestData data) {
        // Generate request body
        context.put("mnemonicFilter", data.getRegCode1());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Set URL to V2 before running again
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.accountId.accountNumber", equalTo(accId))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(this.value))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.regCode.mnemonic", equalTo(data.getRegCode1()))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.displayName", equalTo(institutionName));
    }

    /**
     * Update the account.
     */
    private void updateManualAccountInstitutionName(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("id", accId);
        context.put("value", updatedValue);
        context.put("mnemonic", data.getRegCode1());
        context.put("asOfDate", asOfDate1);
        context.put("institutionName", institutionNameUpdated);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2_NO_DISPLAYNAME));

        // Call Account service
        response = request.post(AccountsPaths.UPDATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.accountId.accountNumber", equalTo(accId))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.regCode.mnemonic", equalTo(data.getRegCode1()))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(updatedValue))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.displayName", equalTo(institutionNameUpdated));

    }

    /**
     * Verify that updated account data is brought back for manual account.
     */
    private void verifyAfterUpdate(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("mnemonicFilter", data.getRegCode1());
        context.put("filterType", data.getFilterType());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.accountId.accountNumber", equalTo(accId))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.regCode.mnemonic", equalTo(data.getRegCode1()))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(updatedValue))
                .body("accountList.find{it.accountId.accountNumber=='" + accId + "'}.displayName", equalTo(institutionNameUpdated));

    }

    /**
     * Delete the account.
     */
    private void deleteManualAccount(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("id", accId);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", data.getRegCode1());
        context.put("value", updatedValue);
        context.put("asOfDate", asOfDate1);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("isEmpty()", Matchers.is(true));
    }

    /**
     * Validate the manual account was deleted.
     */
    private void verifyManualAccountAfterDelete(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("mnemonicFilter", data.getRegCode1());
        context.put("filterType", data.getFilterType());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("isEmpty()", Matchers.is(true));
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}