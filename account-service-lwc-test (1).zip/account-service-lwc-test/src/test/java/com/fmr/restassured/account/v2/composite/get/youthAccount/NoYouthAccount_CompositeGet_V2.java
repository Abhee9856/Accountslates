/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.get.youthAccount;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;

import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.v1.dss.realtimedata.AccountCompositeV1;

import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

/**
 * Contains tests that validate that given account is not youth account.
 *
 * @author a631781
 */
public class NoYouthAccount_CompositeGet_V2 extends PAPBaseServiceTest {

    protected NoYouthAccount_CompositeGet_V2() {
        super(Services.Account);
    }

    private String mid;
    private String ssn;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = AccountCompositeV1.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;
    private VelocityContext context;


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_default_ssn", oAuth);
        //Set default request headers
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ssn = accountsCommonTestData.getSsn();
        testDataUtil = new TestDataUtil();

        // Populate request context with user IDs
        context = new VelocityContext();

        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", ssn))
                .header(new Header("user-mid", mid))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
    }

    /**
     * Test for validating Youth Account Indicator for Retail Accounts
     * <p>
     * Version V2
     */
    @Test
    public void getYouthAccountComposite_V2() {
        context.put("source", AccountConstants.RETAIL);
        request = request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", not(empty()))
                .body("accounts[0].account.accountId.accountNumber", notNullValue())
                .body("accounts[0].account.isYouthAccount", equalTo(false));

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }

}