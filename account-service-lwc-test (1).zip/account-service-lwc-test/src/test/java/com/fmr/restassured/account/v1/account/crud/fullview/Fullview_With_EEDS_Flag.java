/*
 * Copyright 2018, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.fullview;

import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.pap.restassured.utilities.IOUtil;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operations for Fullview accounts with variation of EEDS flag against V1.
 *
 * @author a601767
 * Updated by a608077 on 05/03 to add EEDS variations
 */
@Test(groups = {
        Tags.PIPELINE,
        Tags.ASYNCHRONOUS,
        Tags.ACCOUNT,
        Tags.FULLVIEW,
        Tags.V1,
        Tags.CRUD
})
public class Fullview_With_EEDS_Flag extends PAPBaseServiceTest {
    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private final float updatedValue = 426.85f;

    private static final String LOG_TRACKING_ID = Fullview_With_EEDS_Flag.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    protected Fullview_With_EEDS_Flag() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_CRUD_Fullview__excludeExternalData flag_false_138",oAuth);

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("source", "FULLVIEW");
        context.put("ppid", accountsCommonTestData.getPpid());

    }

    /**
     * Get account info from the backend. Save the account number.
     */
    @Test
    public void getFullviewAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accountList", not(empty()));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Create the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void createFullviewAccount() {
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList", not(empty()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()));

        // Gets and saves the CFP account ID
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
        context.put("accId", accountsCommonTestData.getAccountId1());
    }

    /**
     * Validate the account is created in CFP
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createFullviewAccount")
    public void getFullviewAccountAfterCreateEEDSFalse() {
        //Exclude external data sources
        context.put("externalDataSources", "false");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList", not(empty()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountList[0].sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()));

    }

    /**
     * Validate the account is created in CFP
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountAfterCreateEEDSFalse")
    public void getFullviewAccountAfterCreateEEDSTrue() {
        //Exclude external data sources
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList", not(empty()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountList[0].sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()));

    }

    /**
     * Update the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountAfterCreateEEDSTrue")
    public void updateFullviewAccount() {
        //Change the amount of the account
        context.put("value", updatedValue);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList", not(empty()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));

    }

    /**
     * Validate the updated account with EEDS=True
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateFullviewAccount")
    public void getFullviewAccountAfterUpdateEEDSTrue() {
        //Exclude external data sources
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountList", not(empty()),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));

    }

    /**
     * Validate the updated account with EEDS=False
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountAfterUpdateEEDSTrue")
    public void getFullviewAccountAfterUpdateEEDSFalse() {
        //Exclude external data sources
        context.put("externalDataSources", "false");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList", not(empty()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        //value present in the backend will take precedence than the one in CFP
                        "accountList[0].sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()));

    }

    /**
     * Delete the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountAfterUpdateEEDSFalse")
    public void deleteFullviewAccount() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountList", empty());
    }

    /**
     * Validate the account was deleted with EEDS=True
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteFullviewAccount")
    public void getFullviewAccountAfterDeleteEEDSTrue() {
        //Exclude external data sources
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountList", empty());

    }

    /**
     * Validate the account was deleted with EEDS=False
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountAfterDeleteEEDSTrue")
    public void getFullviewAccountAfterDeleteEEDSFalse() {
        //Exclude external data sources
        context.put("externalDataSources", "false");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList", not(empty()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        //value present in the backend will take precedence than the one in CFP
                        "accountList[0].sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()));

    }
}
