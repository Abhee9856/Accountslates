/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.manual;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.restassured.http.Header;

/**
 * Tests Account Composite operation for a Manual account with asset allocation in details.
 * Test will create, update, and delete a composite account and
 * run get requests before and after each of those operations.
 *
 * @author a608077
 * Updated by a608077 on 08/30/2023 to include include-suitability-details header(PFCP-12115)
 *  Updated by a608077 on 10/24/2023 to include 3 new asset classes: Private Equity, Private Credit,
 *   and Real Assets for POR/WM scenario with EEDS=true(PFCP-13827)
 */
@Test(groups = {Tags.MANUAL, Tags.COMPOSITE, Tags.V2})
public class Manual_Composite_v2_AssetAllocation_POR extends PAPBaseServiceTest {

    /**
     * Constructor
     */
    protected Manual_Composite_v2_AssetAllocation_POR() {
        super(Services.Account);
    }
    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    private VelocityContext context;
    // Paths
    private String accountCompositeGetPath;

    private String accountCompositeCreatePath;

    private String accountCompositeUpdatePath;

    private String accountDeletePath;

    // Financial Instrument IDs and their symbols
    private FinancialInstrumentIds finstIds;

    private static final String SCENARIO_PRODUCT_CODE="WM";
    private static final String SCENARIO_CATEGORY_CODE="POR";

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Manual_Composite_v2_AssetAllocation_POR.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
    private final float netPercentage_T_ALTERNATIVE = 0.8f;
    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
    private final float netPercentage_PEA = 0.4f;
    private final float netPercentage_Updated_PEA = 0.2f;
    private final float netPercentage_PCA = 0.2f;
    private final float netPercentage_Updated_PCA = 0.3f;
    private final float netPercentage_PRAA = 0.2f;
    private final float netPercentage_Updated_PRAA = 0.1f;
    private String acctRoot, scenarioId;
    private final String details = "details.manualAccountDetail.";

    @BeforeClass(alwaysRun = true)
    public void initClass() {

        this.oAuth = AccountUtil.getOauthToken();

        this.accountsCommonTestData = TestDataUtil.populateRegressionTestData("accountCRUD_Manual", this.oAuth);
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


        // Create Principal
        Identity.createPrincipal(accountsCommonTestData.getMid(), oAuth);
        //Create Scenario
        scenarioId = Scenario.createScenarioWithProductCode(this.accountsCommonTestData.getMid(),
                SCENARIO_PRODUCT_CODE,SCENARIO_CATEGORY_CODE,oAuth);

        //Insert Household Identity
        this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentityWithProductCode(accountsCommonTestData.getMid(),
                oAuth,SCENARIO_PRODUCT_CODE,SCENARIO_CATEGORY_CODE));

        // Data setup
        this.accountsCommonTestData.set("updatedAmount", "15000.0");
        this.accountsCommonTestData.set("contribFreq", "YEARLY");
        this.accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        this.accountsCommonTestData.set("contribValue", "6000.0");
        this.accountsCommonTestData.set("updatedContribAmount", "500.0");
        this.accountsCommonTestData.set("withdrawAmount", "500.0");
        this.accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
        this.accountsCommonTestData.set("withdrawFreq", "YEARLY");
        this.accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
        this.accountsCommonTestData.set("detailValue", "42619.85");
        this.accountsCommonTestData.set("updatedDetailValue", "81819.89");
        this.accountsCommonTestData.set("value", "52619.85");
        this.accountsCommonTestData.set("updatedValue", "62619.85");
        this.accountsCommonTestData.setMnemonic1("IBRKFUND");
        this.accountsCommonTestData.setDisplayName1("Manual Composite CRUD RestAssured");
        this.accountsCommonTestData.setInstitutionName1("RETAIL");
        this.accountsCommonTestData.setSourceSystem1("MANUAL");


        // Resolve finstIds
        this.finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

        // Set operation paths
        this.accountCompositeGetPath = AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2;
        this.accountCompositeCreatePath = AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2;
        this.accountCompositeUpdatePath = AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2;
        this.accountDeletePath = AccountsPaths.DELETE_ACCOUNT_V2;
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

        this.request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-id", scenarioId))
                .header(new Header("excludeExternalDataSources", "true"));

        context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", this.accountsCommonTestData.getSourceSystem1());

    }
    /**
     * Description: Validates an empty account list when calling get account composite manual before creation of an
     * account (v2)
     */
    @Test
    public void getCompositeAccountManualV2BeforeCreate() {

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        this.response = this.request.log().ifValidationFails().post(this.accountCompositeGetPath);

        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts", hasSize(0));

    }

    @Test(dependsOnMethods = {"getCompositeAccountManualV2BeforeCreate"})
    public void createCompositeAccountManualV2() {

        // Generate request body
        context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
        context.put("source", this.accountsCommonTestData.getSourceSystem1());
        context.put("ppid", this.accountsCommonTestData.getPpid());
        context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", this.accountsCommonTestData.getSourceSystem1());
        context.put("value", this.accountsCommonTestData.get("value"));
        context.put("detailValue", this.accountsCommonTestData.get("detailValue"));
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.177);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.0f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_PRAA);
        context.put("contribValue", this.accountsCommonTestData.get("contribValue"));
        context.put("contribFreq", this.accountsCommonTestData.get("contribFreq"));
        context.put("withdrawAmount", this.accountsCommonTestData.get("withdrawAmount"));
        context.put("withdrawFreq", this.accountsCommonTestData.get("withdrawFreq"));
        context.put("GDSTOCK", this.finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", this.finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", this.finstIds.getFinstId("GBOND"));
        context.put("GCASH", this.finstIds.getFinstId("GCASH"));

        this.request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        // Make post request
        this.response = this.request.log().ifValidationFails().post(this.accountCompositeCreatePath);

        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()),
                        "accounts[0].account.displayName", equalTo(this.accountsCommonTestData.getDisplayName1()),
                        "accounts[0].account.regCode.mnemonic", equalTo(this.accountsCommonTestData.getMnemonic1()),
                        "accounts[0].account.regCode.sourceSystem", equalTo(this.accountsCommonTestData.getSourceSystem1()),
                        "accounts[0].account.institutionName", equalTo(this.accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("value"))),
                        //positions
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GDSTOCK")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GFSTOCK")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GBOND")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GCASH")),
                        //details
                        "accounts[0].details.manualAccountDetail.accountDetail.costBasis.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("detailValue"))),
                        "accounts[0].details.manualAccountDetail.state", equalTo("AK"))
                .body("accounts[0].details.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body("accounts[0].details.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body("accounts[0].details.manualAccountDetail.accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body("accounts[0].details.manualAccountDetail.accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body("accounts[0].details.manualAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_T_ALTERNATIVE))
                .body( "accounts[0].details.manualAccountDetail.accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PCA))
                .body("accounts[0].details.manualAccountDetail.accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PEA))
                .body("accounts[0].details.manualAccountDetail.accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PRAA),
                        //contributions
                        "accounts[0].contributions.contributions[0].contribution.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("contribValue"))),
                        "accounts[0].contributions.contributions[0].frequency",
                        equalTo(this.accountsCommonTestData.get("contribFreq")),
                        //withdrawals
                        "accounts[0].withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("withdrawAmount"))),
                        "accounts[0].withdrawals[0].amount.frequency",
                        equalTo(this.accountsCommonTestData.get("withdrawFreq")));

        // Save account number and ID
        this.accountsCommonTestData.setAccountId1(this.response.path("accounts[0].account.accountId.id"));
        this.accountsCommonTestData.setAccountNumber1(this.response.path("accounts[0].account.accountId.accountNumber"));
        this.accountsCommonTestData.set("asOfDate", this.response.path("accounts[0].account.sourceMarketValue.asOfDate"));
        String accNum =  this.accountsCommonTestData.getAccountNumber1();
        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
    }
    @Test(dependsOnMethods = "createCompositeAccountManualV2")
    public void getCompositeAccountManualV2AfterCreate()
    {
        this.request.given()
                .header(new Header("include-suitability-details", "true"));
        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        this.response = this.request.log().ifValidationFails().post(this.accountCompositeGetPath);

        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts[0].account.accountId.id", equalTo(this.accountsCommonTestData.getAccountId1()),
                        "accounts[0].account.accountId.accountNumber",
                        equalTo(this.accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                        equalTo(this.accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                        equalTo(this.accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                        equalTo(this.accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                        equalTo(this.accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                        equalTo(this.accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("value"))),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GDSTOCK")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GFSTOCK")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GBOND")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GCASH")),
                        //details
                        "accounts[0].details.manualAccountDetail.accountDetail.costBasis.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("detailValue"))),
                        "accounts[0].details.manualAccountDetail.state", equalTo("AK"))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_PRAA),
                        //suitability
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value",
                        equalTo(0f), "accounts[0].suitability.investmentObjective.targetAssetMix.name",
                        equalTo("Short Term"),
                        "accounts[0].contributions.contributions[0].contribution.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("contribValue"))),
                        "accounts[0].contributions.contributions[0].frequency",
                        equalTo(this.accountsCommonTestData.get("contribFreq")),
                        "accounts[0].withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("withdrawAmount"))),
                        "accounts[0].withdrawals[0].amount.frequency",
                        equalTo(this.accountsCommonTestData.get("withdrawFreq")));
    }

    @Test(dependsOnMethods = "getCompositeAccountManualV2AfterCreate")
    public void updateCompositeAccountManualV2()
    {
        context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
        context.put("accId", this.accountsCommonTestData.getAccountId1());
        context.put("source", this.accountsCommonTestData.getSourceSystem1());
        context.put("ppid", this.accountsCommonTestData.getPpid());
        context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", this.accountsCommonTestData.getSourceSystem1());
        context.put("value", this.accountsCommonTestData.get("updatedValue"));
        context.put("detailValue", this.accountsCommonTestData.get("updatedDetailValue"));
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.4f);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 1.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.70f);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.30f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_Updated_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_Updated_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
        context.put("contribValue", this.accountsCommonTestData.get("updatedContribAmount"));
        context.put("contribFreq", this.accountsCommonTestData.get("updatedContribFreq"));
        context.put("withdrawAmount", this.accountsCommonTestData.get("updatedWithdrawAmount"));
        context.put("withdrawFreq", this.accountsCommonTestData.get("updatedWithdrawFreq"));
        context.put("GDSTOCK", this.finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", this.finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", this.finstIds.getFinstId("GBOND"));
        context.put("GCASH", this.finstIds.getFinstId("GCASH"));

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_UPDATE_TEMPLATE_V2));

        // Make post request
        this.response = this.request.log().ifValidationFails().post(this.accountCompositeUpdatePath);

        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.id", equalTo(this.accountsCommonTestData.getAccountId1()),
                        "accounts[0].account.accountId.accountNumber",
                        equalTo(this.accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                        equalTo(this.accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                        equalTo(this.accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                        equalTo(this.accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                        equalTo(this.accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                        equalTo(this.accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedValue"))),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GDSTOCK")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GFSTOCK")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GBOND")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GCASH")),
                        //details
                        "accounts[0].details.manualAccountDetail.accountDetail.costBasis.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedDetailValue"))),
                        "accounts[0].details.manualAccountDetail.state", equalTo("AK"))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PRAA),

                        //suitability
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value",
                        equalTo(0f), "accounts[0].suitability.investmentObjective.targetAssetMix.name",
                        equalTo("Short Term"),
                        //contributions
                        "accounts[0].contributions.contributions[0].contribution.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedContribAmount"))),
                        "accounts[0].contributions.contributions[0].frequency",
                        equalTo(this.accountsCommonTestData.get("updatedContribFreq")),
                        //withdrawals
                        "accounts[0].withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedWithdrawAmount"))),
                        "accounts[0].withdrawals[0].amount.frequency",
                        equalTo(this.accountsCommonTestData.get("updatedWithdrawFreq")));
    }

    @Test(dependsOnMethods = "updateCompositeAccountManualV2")
    public void getCompositeAccountManualV2AfterUpdate()
    {
        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        this.response = this.request.log().ifValidationFails().post(this.accountCompositeGetPath);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accounts[0].account.accountId.id", equalTo(this.accountsCommonTestData.getAccountId1()),
                        "accounts[0].account.accountId.accountNumber",
                        equalTo(this.accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                        equalTo(this.accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                        equalTo(this.accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                        equalTo(this.accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                        equalTo(this.accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                        equalTo(this.accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedValue"))),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GDSTOCK")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GFSTOCK")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GBOND")),
                        "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
                        equalTo(this.finstIds.getFinstId("GCASH")),
                        //details
                        "accounts[0].details.manualAccountDetail.accountDetail.costBasis.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedDetailValue"))),
                        "accounts[0].details.manualAccountDetail.state", equalTo("AK"))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + details + "accountDetail.assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PRAA),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='BOND'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation.find{it.assetClass='CASH'}.netPercentage.value",
                        equalTo(0f), "accounts[0].suitability.investmentObjective.targetAssetMix.name",
                        equalTo("Short Term"),

                        "accounts[0].contributions.contributions[0].contribution.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedContribAmount"))),
                        "accounts[0].contributions.contributions[0].frequency",
                        equalTo(this.accountsCommonTestData.get("updatedContribFreq")),
                        "accounts[0].withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedWithdrawAmount"))),
                        "accounts[0].withdrawals[0].amount.frequency",
                        equalTo(this.accountsCommonTestData.get("updatedWithdrawFreq")));
    }

    @Test(dependsOnMethods = "getCompositeAccountManualV2AfterUpdate")
    public void deleteCompositeAccountManualV2()
    {
        context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
        context.put("accId", this.accountsCommonTestData.getAccountId1());
        context.put("source", this.accountsCommonTestData.getSourceSystem1());
        context.put("ppid", this.accountsCommonTestData.getPpid());
        context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
        context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        context.put("value", this.accountsCommonTestData.get("updatedValue"));
        context.put("asOfDate", this.accountsCommonTestData.get("asOfDate"));

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        // Make post request
        this.response = this.request.post(this.accountDeletePath);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = this.response.jsonPath().getString("$");
        assertThat(emptyResponse, equalTo("[:]"));
    }

    @Test(dependsOnMethods = "deleteCompositeAccountManualV2")
    public void getCompositeAccountManualV2AfterDelete()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", this.accountsCommonTestData.get("sourceSystem"));

        this.request.header(new Header("excludeExternalDataSources", "true"));

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts", hasSize(0));
    }
}