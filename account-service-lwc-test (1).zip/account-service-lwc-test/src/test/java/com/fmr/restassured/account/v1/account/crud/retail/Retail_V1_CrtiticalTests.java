/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Tests for v1 CRUD operations for Retail accounts using DataProvider (for
 * handling multiple regCodes).
 *
 * @author a631781
 */
@Test(groups = {
        Tags.CRITICAL,
        Tags.RETAIL,
        Tags.ACCOUNT,
        Tags.V1})
public class Retail_V1_CrtiticalTests extends PAPBaseServiceTest {

    protected Retail_V1_CrtiticalTests() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String source = "RETAIL";

    private final String asOfDate1 = "2014-10-31";

    private String mid;// = "RetailAccountV1TestMid";

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accId;

    private String accNumber;

    private String maskedAccNumber;

    private String displayName;

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("retail_critical_regcode", oAuth);
        testDataUtil = new TestDataUtil();
        this.mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(this.mid);
        accountsCommonTestData.setAsOfDate1(asOfDate1);
        accountsCommonTestData.setValue1(value);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", String.valueOf(value));

    }

    /**
     * Create Retail account with different combination of Regcodes from DataProvider.
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getRetailAccountData",
            dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data) {
        this.getRetailAccount(data);
        this.createRetailAccount(data);
        this.getRetailAccountAfterCreate(data);
        this.updateRetailAccount(data);
        this.deleteRetailAccount(data);
        this.getRetailAccountAfterDelete(data);
    }


    //Get account info from the backend.
    private void getRetailAccount(final AccountRegCodeTestData data) {
        // Generate request body
        this.context.put("source", this.source);
        this.context.put("externalDataSources", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
        	 Assert.assertEquals(dssResultCode, false);
        }

        response.then().log().ifValidationFails()
                .body("accountList", not(emptyArray()));


        //Get Account number based on the regCode
        if (null != response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1() + "'}.accountId.accountNumber")) {
            accNumber = response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1() + "'}.accountId.accountNumber");
        } else {
            accNumber = response.path("accountList[0].accountId.accountNumber");
        }

        maskedAccNumber = TestDataUtil.getMaskedAccountNumber(accNumber);

        displayName = response.path("accountList.find{it.accountId.id=='" + accId + "'}.nickName") != null ?
                response.path("accountList.find{it.accountId.id=='" + accId + "'}.nickName") + "-" + maskedAccNumber:maskedAccNumber;

        response.then().log().ifValidationFails()
                .body("accountList.find{it.accountId.accountNumber=='" + accNumber + "'}.displayName", equalTo(displayName));

    }

    //Create Retail Account
    private void createRetailAccount(final AccountRegCodeTestData data) {
        displayName = "RA Regression Tests";
        // Generate request body
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("value", String.valueOf(this.value));
        this.context.put("mnemonic", data.getRegCode1());
        this.context.put("source", data.getSrcFilter());
        this.context.put("displayName", displayName);
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("id", null);
        this.context.put("excludeExternalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        accId = response.path("accountList[0].accountId.id");

    }


    // Validate the created account.
    private void getRetailAccountAfterCreate(final AccountRegCodeTestData data) {
        // Exclude external data sources
        this.context.put("source", this.source);
        this.context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(this.value))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.regCode.mnemonic", equalTo(data.getRegCode1()))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(displayName));;
    }


    // Update account
    private void updateRetailAccount(final AccountRegCodeTestData data) {
        // Generate request body
        this.context.put("source", data.getSrcFilter());
        this.context.put("accId", accId);
        this.context.put("value", this.updatedValue);
        this.context.put("mnemonic", data.getRegCode1());
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("excludeExternalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(emptyArray()))
                .body("resultCode",  equalTo(true))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(updatedValue))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.regCode.mnemonic", equalTo(data.getRegCode1()));

    }

    // Validate Updated account
    private void getRetailAccountAfterUpdate(final AccountRegCodeTestData data) {
        // Exclude external data sources
        this.context.put("source", this.source);
        this.context.put("externalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(emptyArray()))
                .body("resultCode",  equalTo(true))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(updatedValue))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.regCode.mnemonic", equalTo(data.getRegCode1()));
    }


    // Delete Account
    private void deleteRetailAccount(final AccountRegCodeTestData data) {
        // Generate request body
        this.context.put("source", data.getSrcFilter());
        this.context.put("value", this.updatedValue);
        this.context.put("mnemonic", data.getRegCode1());
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("id", accId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service response
        request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

    }

    //Validate Account after delete
    private void getRetailAccountAfterDelete(final AccountRegCodeTestData data) {
        // Exclude external data sources
        this.context.put("source", this.source);
        this.context.put("externalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
