package com.fmr.restassured.account.v2.account.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

/**
 * Tests account/get operation for a Workplace account. Test will be run against
 * version V2. Created on 10/28/2020 to use the updated framework.
 *
 * @author a560878
 * Updated by a608077 on 10/13/2021 to include changes for 'scenario-id' header(PFCP-6168)
 * Updated by a608077 on 08/26/2022 to include unknown funding amount changes(PFCP-9908)
 */
@Test(groups = {
        Tags.WORKPLACE,
        Tags.ACCOUNT,
        Tags.V2,
        Tags.TARGET_ACCOUNT})
public class Workplace_v2_withTargetAccount extends PAPBaseServiceTest {
    private AccountsCommonTestData accountsCommonTestData;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private String accId;

    private String accountNum;

    private String sourceSystem;

    private String displayName;

    private String mnemonic;

    private float value;

    private String institutionName;

    private String asOfDate;

    private final float fundingAccountAmount = 5.55f;

    private TestDataUtil testDataUtil;

    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";

    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";
    
    private static final String TARGET_ACCOUNT_NAME = "NewTargetAccount";

    final VelocityContext context = new VelocityContext();
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Workplace_v2_withTargetAccount.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    private final float unknownAmount = 20.0f;
    private String mid;// = "WorkplaceAccountV2TestMid";

    /**
     * Generic constructor
     */
    protected Workplace_v2_withTargetAccount() {
        super(Services.Account);
    }

    /**
     * Initialization method used to set up the endpoint for the test, and build the request body from the Velocity
     * Template
     */

    @BeforeClass(alwaysRun = true)
    public void init() {

        final String oAuth = AccountUtil.getOauthToken();

        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Workplace_69", oAuth);

        //Set default request headers
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        testDataUtil = new TestDataUtil();

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);

        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");

        // Create Principal
        Identity.createPrincipal(accountsCommonTestData.getMid(), oAuth);
        String scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE, oAuth);
        this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", this.accountsCommonTestData.getMid(), oAuth));

        this.request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                //optional header scenario-id
                .header(new Header("scenario-id", scenarioId))
                .header(new Header("excludeExternalDataSources", "false"));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

    }

    /**
     * Test to validate account data is returned for Workplace accounts Version V2
     */
    @Test
    public void getWorkplaceAccountInfo() {

        // Call Account service
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200).body("accountList", not(emptyArray()))
                .body("accountList.accountId[0].sourceSystem", equalTo(AccountConstants.WORKPLACE));

        accountNum = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        mnemonic = response.path("accountList[0].regCode.mnemonic");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Creates a new Workplace account
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount() {
        context.put("accountNumber", accountNum);
        context.put("source", sourceSystem);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        //Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", equalTo(accountNum))
                .body("accountList[0].accountId.sourceSystem", equalTo(AccountConstants.WORKPLACE))
                .body("accountList[0].accountId.id", notNullValue());

        accId = response.path("accountList[0].accountId.id");
    }

    /**
     * Create target account
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void createTargetAccount() {
	context.remove("displayName");
        context.put("fundingAccountNumber", accountNum);
        context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("category", "INVESTOR_SELECTED_STRATEGY");
        context.put("unknownAmount", String.valueOf(unknownAmount));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount),
                        "targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME),
                        "targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountNum),
                        "targetAccounts[0].fundingAccounts[0].amount.value", equalTo(fundingAccountAmount),
                        "targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount),
                        "targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"));

        accountsCommonTestData.set(TARGET_ACCOUNT_NUMBER_KEY, response.path("targetAccounts[0].accountId.accountNumber"));
        accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
    }

    /**
     * Validates that the account was created
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void verifyWorkplaceAccountAfterCreate() {
        //Call Account service v2
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()),
                        "accountList[0].accountId.accountNumber", equalTo(accountNum),
                        "accountList[0].accountId.id", equalTo(accId),
                        "targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount),
                        "targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountNum),
                        "targetAccounts[0].fundingAccounts[0].amount.value", equalTo(fundingAccountAmount),
                        "targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount),
                        "targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"));
    }

    /**
     * Updates the account with new mnemonic
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "verifyWorkplaceAccountAfterCreate")
    public void updateWorkplaceAccount() {
        context.put("id", accId);
        context.put("accountNumber", accountNum);
        context.put("value", "10000.0");
        context.put("source", sourceSystem);
        context.put("ppid", accountsCommonTestData.getPpid());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

        //Set resource path
        response = request.post(AccountsPaths.UPDATE_ACCOUNT_V2);

        //Call service
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].regCode.mnemonic", equalTo(mnemonic))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(10000f))
                .body("accountList[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()));
    }

    /**
     * Validates that the account was updated correctly
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateWorkplaceAccount")
    public void verifyWorkplaceAccountAfterUpdate() {
        //Call Account service v2
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", equalTo(accountNum))
                .body("accountList[0].accountId.id", equalTo(accId))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(value));
    }

    /**
     * Deletes the account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "verifyWorkplaceAccountAfterUpdate")
    public void deleteWorkplaceAccount() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        //Set resource path
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("isEmpty()", Matchers.is(true));
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
