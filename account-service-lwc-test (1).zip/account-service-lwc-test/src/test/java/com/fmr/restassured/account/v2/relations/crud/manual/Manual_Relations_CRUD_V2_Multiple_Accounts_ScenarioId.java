/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.relations.crud.manual;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.not;

import com.fmr.ast.platform.account.domain.RelatedEntityType;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsRelationsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRelationsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.RelationsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;
import io.restassured.response.Response;

/**
 * Tests ScenarioID header implementation for manual relations for multiple accounts against V2.
 *
 * @author a631781
 */
@Test(groups = {Tags.RETAIL, Tags.RELATIONS, Tags.V2})
public class Manual_Relations_CRUD_V2_Multiple_Accounts_ScenarioId extends PAPBaseServiceTest
{
    
    protected Manual_Relations_CRUD_V2_Multiple_Accounts_ScenarioId()
    {
        super(Services.Account);
    }
    
    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private final VelocityContext context = new VelocityContext();
    private final TestDataUtil testDataUtil = new TestDataUtil();

    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID =
            Manual_Relations_CRUD_V2_Multiple_Accounts_ScenarioId.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    
    private String accId_1;
    private String accId_2;
    private String mid;// = "ManualRelationsV2TestMid";
    Response allScenarioIDs;
    
    /**
     * Initialization method used to populate the UserIdentifiers object based on the SSN, set up the endpoint for the
     * test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("accountRelationsCRUD_sameAccountMultipleRoletypes_retail",oAuth);
        mid = accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(mid);
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");

        String ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);
        this.accountsCommonTestData.setPpid(ppid);
        
        // Get/Create ScenarioId
        allScenarioIDs = Scenario.getAllScenarios(mid, oAuth);
        String scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null)
        {
            scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE,
                    oAuth);
        }
        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        
        this.request.given().header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()))
                .header(new Header("scenario-id", scenarioId));
        
        // Populate request variables
        this.accountsCommonTestData.setSourceSystem1("MANUAL");
        this.accountsCommonTestData.setMnemonic1("IRA");
        this.accountsCommonTestData.setAsOfDate1("2021-07-01");
        
        this.context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
        this.context.put("source", this.accountsCommonTestData.getSourceSystem1());
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        
    }
    
    /**
     * Create the Manual account.
     * <p>
     * Version V2
     */
    @Test
    public void createManualAccount()
    {
        this.context.put("mnemonic", "401K");
        String displayName1 = "SOA Test Manual Account 1";
        this.context.put("displayName", displayName1);
        float value = 818.89f;
        this.context.put("value", value);
        String asOfDate = "2021-06-10";
        this.context.put("asOfDate", asOfDate);
        context.put("institutionName", "InstitutionName1");
        this.context.put("mnemonic2", "IRA");
        String displayName2 = "SOA Test Manual Account 2";
        this.context.put("displayName2", displayName2);
        this.context.put("source2", this.accountsCommonTestData.getSourceSystem1());
        this.context.put("value2", value);
        this.context.put("asOfDate2", asOfDate);
        context.put("institutionName2", "InstitutionName2");
        
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));
        // Run test
        this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V2);
        
        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        String accNum1 = this.response
                .path("accountList.find{it.displayName == \"SOA Test Manual Account 1\" }.accountId.accountNumber");

        String accNum2 = this.response
                .path("accountList.find{it.displayName == \"SOA Test Manual Account 2\" }.accountId.accountNumber");
        
        this.accId_1 =
                this.response.path("accountList.find{it.displayName == \"SOA Test Manual Account 1\" }.accountId.id");
        
        this.accId_2 =
                this.response.path("accountList.find{it.displayName == \"SOA Test Manual Account 2\" }.accountId.id");
        
        this.context.put("accountNumber", accNum1);
        this.context.put("accountNumber2", accNum2);
        
        this.context.put("accId", this.accId_1);
        this.context.put("accId2", this.accId_2);
        this.request.given().header(new Header("excludeExternalDataSources", "true"));
    }
    
    /**
     * Create account relations.
     */
    @Test(dependsOnMethods = "createManualAccount", dataProvider = "getManualRelationsData", dataProviderClass =
            RelationsDataProviderUtil.class)
    public void createAccountRelations(final AccountRelationsTestData data)
    {
        // Generate request body
        context.put("beneficiaryAllocation", data.getBeneficiaryAllocationPct());
        context.put("roleType", data.getRoleType());
        context.put("entityType", data.getEntityType());
        
        context.put("beneficiaryAllocation2", data.getBeneficiaryAllocationPct2());
        context.put("roleType2", data.getRoleType2());
        context.put("entityType2", data.getEntityType2());
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_CREATE_V2_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.CREATE_ACCOUNT_RELATIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "accountRelations.find{it.accountId=='" + this.accId_1 + "'}", not(nullValue()),
                "accountRelations.find{it.accountId=='" + this.accId_2 + "'}", not(nullValue()));
        
        this.assertOnCreate(data);
        
    }
    
    /**
     * Validate the relations after create.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createAccountRelations", dataProvider = "getManualRelationsData", dataProviderClass =
            RelationsDataProviderUtil.class)
    public void getRelationsAfterCreate(final AccountRelationsTestData data)
    {
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "accountRelations.find{it.accountId=='" + this.accId_1 + "'}", not(nullValue()),
                "accountRelations.find{it.accountId=='" + this.accId_2 + "'}", not(nullValue()));
        
        this.assertOnCreate(data);
    }
    
    /**
     * Update the account relations.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getRelationsAfterCreate", dataProvider = "getManualRelationsData", dataProviderClass =
            RelationsDataProviderUtil.class)
    public void updateAccountRelations(final AccountRelationsTestData data)
    {
        // Account 1
        context.put("beneficiaryAllocation", data.getUpdatedBeneficiaryAllocationPct());
        context.put("roleType", data.getRoleType());
        context.put("entityType", data.getEntityType());
        
        // Account 2
        context.put("beneficiaryAllocation2", data.getUpdatedBeneficiaryAllocationPct2());
        context.put("roleType2", data.getRoleType2());
        context.put("entityType2", data.getEntityType2());
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_UPDATE_V2_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.UPDATE_ACCOUNT_RELATIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "accountRelations.find{it.accountId=='" + this.accId_1 + "'}", not(nullValue()),
                "accountRelations.find{it.accountId=='" + this.accId_2 + "'}", not(nullValue()));
        
        this.assertOnUpdate(data);
        
    }
    
    /**
     * Validate the updated relations.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateAccountRelations", dataProvider = "getManualRelationsData", dataProviderClass =
            RelationsDataProviderUtil.class)
    public void getRelationsAfterUpdate(final AccountRelationsTestData data)
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "accountRelations.find{it.accountId=='" + this.accId_1 + "'}", not(nullValue()),
                "accountRelations.find{it.accountId=='" + this.accId_2 + "'}", not(nullValue()));
        
        this.assertOnUpdate(data);
        
    }
    
    /**
     * Delete the account relations.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getRelationsAfterUpdate", dataProvider = "getManualRelationsData", dataProviderClass =
            RelationsDataProviderUtil.class)
    public void deleteAccountRelations(final AccountRelationsTestData data)
    {
        // Generate request body
        context.put("beneficiaryAllocation", data.getUpdatedBeneficiaryAllocationPct());
        context.put("roleType", data.getRoleType());
        context.put("entityType", data.getEntityType());
        
        context.put("beneficiaryAllocation2", data.getUpdatedBeneficiaryAllocationPct2());
        context.put("roleType2", data.getRoleType2());
        context.put("entityType2", data.getEntityType2());
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_DELETE_V2_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.DELETE_ACCOUNT_RELATIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
        
        this.assertOnDelete(data);
    }
    
    /**
     * Validate the relations were deleted.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteAccountRelations")
    public void getRelationsAfterDelete()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("isEmpty()",
                Matchers.is(true));
        
    }
    
    /**
     * @param data the test case data
     */
    private void assertOnCreate(final AccountRelationsTestData data)
    {
        // Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
        // so assertions need to be handled differently.
        if (data.getEntityType().equals(RelatedEntityType.OWNER.toString()))
        {
            response.then().body(
                    
                    // Assert on BeneficiaryAllocation
                    "accountRelations.find{it.accountId=='" + this.accId_1
                            + "'}.relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
                    equalTo(data.getBeneficiaryAllocationPct()),
                    
                    // Assert on RoleType
                    "accountRelations.find{it.accountId=='" + this.accId_1
                            + "'}.relatedEntities.find{it.type=='OWNER'}.roleType",
                    equalTo(data.getRoleType()),
                    
                    // Assert on EntityType
                    "accountRelations.find{it.accountId=='" + this.accId_1
                            + "'}.relatedEntities.find{it.type=='OWNER'}.type",
                    equalTo(data.getEntityType()));
        }
        else
        {
            response.then().body(
                    
                    // Assert on BeneficiaryAllocation
                    "accountRelations.find{it.accountId=='" + this.accId_1 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType() + "'}.ownershipPercent",
                    equalTo(Float.valueOf(data.getBeneficiaryAllocationPct())),
                    
                    // Assert on RoleType
                    "accountRelations.find{it.accountId=='" + this.accId_1 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType() + "'}.roleType",
                    equalTo(data.getRoleType()),
                    
                    // Assert on EntityType
                    "accountRelations.find{it.accountId=='" + this.accId_1 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType() + "'}.type",
                    equalTo(data.getEntityType()));
        }
        if (data.getEntityType2().equals(RelatedEntityType.OWNER.toString()))
        {
            response.then().body(
                    
                    // Assert on BeneficiaryAllocation
                    "accountRelations.find{it.accountId=='" + this.accId_2
                            + "'}.relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
                    equalTo(data.getBeneficiaryAllocationPct2()),
                    
                    // Assert on RoleType
                    "accountRelations.find{it.accountId=='" + this.accId_2
                            + "'}.relatedEntities.find{it.type=='OWNER'}.roleType",
                    equalTo(data.getRoleType2()),
                    
                    // Assert on EntityType
                    "accountRelations.find{it.accountId=='" + this.accId_2
                            + "'}.relatedEntities.find{it.type=='OWNER'}.type",
                    equalTo(data.getEntityType2()));
        }
        else
        {
            response.then().body(
                    
                    // Assert on BeneficiaryAllocation
                    "accountRelations.find{it.accountId=='" + this.accId_2 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType2() + "'}.ownershipPercent",
                    equalTo(Float.valueOf(data.getBeneficiaryAllocationPct2())),
                    
                    // Assert on RoleType
                    "accountRelations.find{it.accountId=='" + this.accId_2 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType2() + "'}.roleType",
                    equalTo(data.getRoleType2()),
                    
                    // Assert on EntityType
                    "accountRelations.find{it.accountId=='" + this.accId_2 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType2() + "'}.type",
                    equalTo(data.getEntityType2()));
            
        }
    }
    
    /**
     * @param data the test case data
     */
    private void assertOnUpdate(final AccountRelationsTestData data)
    {
        // Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
        // so assertions need to be handled differently.
        if (data.getEntityType().equals(RelatedEntityType.OWNER.toString()))
        {
            response.then().body(
                    
                    // Assert on BeneficiaryAllocation
                    "accountRelations.find{it.accountId=='" + this.accId_1
                            + "'}.relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
                    equalTo(data.getUpdatedBeneficiaryAllocationPct()),
                    
                    // Assert on RoleType
                    "accountRelations.find{it.accountId=='" + this.accId_1
                            + "'}.relatedEntities.find{it.type=='OWNER'}.roleType",
                    equalTo(data.getRoleType()),
                    
                    // Assert on EntityType
                    "accountRelations.find{it.accountId=='" + this.accId_1
                            + "'}.relatedEntities.find{it.type=='OWNER'}.type",
                    equalTo(data.getEntityType()));
        }
        else
        {
            response.then().body(
                    
                    // Assert on BeneficiaryAllocation
                    "accountRelations.find{it.accountId=='" + this.accId_1 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType() + "'}.ownershipPercent",
                    equalTo(Float.valueOf(data.getUpdatedBeneficiaryAllocationPct())),
                    
                    // Assert on RoleType
                    "accountRelations.find{it.accountId=='" + this.accId_1 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType() + "'}.roleType",
                    equalTo(data.getRoleType()),
                    
                    // Assert on EntityType
                    "accountRelations.find{it.accountId=='" + this.accId_1 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType() + "'}.type",
                    equalTo(data.getEntityType()));
        }
        if (data.getEntityType2().equals(RelatedEntityType.OWNER.toString()))
        {
            response.then().body(
                    
                    // Assert on BeneficiaryAllocation
                    "accountRelations.find{it.accountId=='" + this.accId_2
                            + "'}.relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
                    equalTo(data.getUpdatedBeneficiaryAllocationPct2()),
                    
                    // Assert on RoleType
                    "accountRelations.find{it.accountId=='" + this.accId_2
                            + "'}.relatedEntities.find{it.type=='OWNER'}.roleType",
                    equalTo(data.getRoleType2()),
                    
                    // Assert on EntityType
                    "accountRelations.find{it.accountId=='" + this.accId_2
                            + "'}.relatedEntities.find{it.type=='OWNER'}.type",
                    equalTo(data.getEntityType2()));
        }
        else
        {
            response.then().body(
                    
                    // Assert on BeneficiaryAllocation
                    "accountRelations.find{it.accountId=='" + this.accId_2 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType2() + "'}.ownershipPercent",
                    equalTo(Float.valueOf(data.getUpdatedBeneficiaryAllocationPct2())),
                    
                    // Assert on RoleType
                    "accountRelations.find{it.accountId=='" + this.accId_2 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType2() + "'}.roleType",
                    equalTo(data.getRoleType2()),
                    
                    // Assert on EntityType
                    "accountRelations.find{it.accountId=='" + this.accId_2 + "'}.relatedEntities.find{it.roleType=='"
                            + data.getRoleType2() + "'}.type",
                    equalTo(data.getEntityType2()));
            
        }
    }
    
    private void assertOnDelete(final AccountRelationsTestData data)
    {
        // Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
        // so assertions need to be handled differently.
        if (data.getEntityType().equals(RelatedEntityType.OWNER.toString()))
        {
            response.then().body("accountRelations.find{it.accountId=='" + this.accId_1
                    + "'}.relatedEntities.find{it.type=='OWNER'}", nullValue());
        }
        else
        {
            response.then().body("accountRelations.find{it.accountId=='" + this.accId_1
                    + "'}.relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}", nullValue());
        }
        if (data.getEntityType2().equals(RelatedEntityType.OWNER.toString()))
        {
            response.then().body("accountRelations.find{it.accountId=='" + this.accId_2
                    + "'}.relatedEntities.find{it.type=='OWNER'}", nullValue());
        }
        else
        {
            response.then().body("accountRelations.find{it.accountId=='" + this.accId_2
                    + "'}.relatedEntities.find{it.roleType=='" + data.getRoleType2() + "'}", nullValue());
        }
        
    }
    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
        this.testDataUtil.closeSQLiteConnection();
    }
}