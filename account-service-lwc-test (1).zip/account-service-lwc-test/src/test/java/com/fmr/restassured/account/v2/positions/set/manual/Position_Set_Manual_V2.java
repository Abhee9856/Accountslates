/****************************************************************************
 *
 * FIDELITY INVESTMENTS CONFIDENTIAL INFORMATION
 *
 * Copyright (c) 2021 Fidelity Investments.  All Rights Reserved.
 * Unauthorized reproduction, transmission, or distribution of
 * this software is a violation of applicable laws.
 *
 ****************************************************************************
 *
 * Department:  Personal Investing
 *
 * File Name:   Position_Set_Manual
 * @author: Kamlesh Vyas
 * @version: 1.0
 *
 ****************************************************************************/
package com.fmr.restassured.account.v2.positions.set.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

@Test(groups = {

		Tags.MANUAL,
		Tags.POSITIONS,
		Tags.V2,
		"PFCP-3068" })
public class Position_Set_Manual_V2 extends PAPBaseServiceTest
{

	public static final String LOG_TRACKING_ID = Position_Set_Manual_V2.class.getSimpleName();

	protected Position_Set_Manual_V2()
	{
		super(Services.Account);
	}

    private String principalPId;

	private String partnerPId;

	private String dependentPId;

	private String accountNumber;

	private String accountId;

    private String accountId2;

    private String accountId3;

    private final String sourceSystem = "MANUAL";

    private VelocityContext context;

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private static final Header EEDS = new Header("excludeExternalDataSources", "true");


	//Financial Instrument IDs and their symbols
	private FinancialInstrumentIds finstIds;


	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
	 * for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
				.populateRegressionTestData("accountCRUD_Manual", oAuth);
        String mid = accountsCommonTestData.getMid();
		DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


		principalPId = Identity.createHouseholdIdentity("mid", mid, oAuth);
		partnerPId = Identity.createHouseholdIdentityPartner(mid, oAuth);
		dependentPId = Identity.createHouseholdIdentityDependent(mid, oAuth);
		finstIds = new FinancialInstrumentIds("FFIDX", "FENY","QPISQ", "FEDTX");

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, LOG_TRACKING_ID,oAuth );

		this.request.given()
				.header(new Header("user-poe", "RETAIL"))
				.header(new Header("user-mid", accountsCommonTestData.getMid()))
				.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
				.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
				.header(new Header("log-tracking-id", LOG_TRACKING_ID))
				.header(EEDS);

		context = new VelocityContext();
		context.put("ppid", principalPId);
		context.put("source", "MANUAL");
	}

	/**
	 * Create the Manual account. Save the account id.
	 *
	 * Version V2
	 */
	@Test
	public void createThreeManualAccount()
	{
        float value = 5000.0f;
        context.put("value", value);
		context.put("source", sourceSystem);
        String displayName = "Display_Name";
        context.put("displayName", displayName);
        String institutionName = "InstitutionalName";
        context.put("institutionName", institutionName);
        String asOfDate = "2014-10-31";
        context.put("asOfDate", asOfDate);
        String mnemonic = "IRA";
        context.put("mnemonic", mnemonic);

		context.put("partnerPId", partnerPId);
		context.put("relationShip1", "PARTNER");
		context.put("value2", 8000.0f);
		context.put("source2", sourceSystem);
		context.put("displayName2", "something 2");
		context.put("institutionName", institutionName);
		context.put("asOfDate2", asOfDate);
		context.put("mnemonic2", "IRA");

		context.put("dependentPId", dependentPId);
		context.put("relationShip2", "DEPENDENT");
		context.put("value3", 4000f);
		context.put("source3", sourceSystem);
		context.put("displayName3", "Something 3");
		context.put("institutionName", institutionName);
		context.put("asOfDate3", asOfDate);
		context.put("mnemonic3", "IRRL");

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(HttpStatus.SC_OK)
				.body("accountList", Matchers.not(empty()),
						"accountList", Matchers.hasSize(3),
						"accountList[0].regCode.mnemonic", Matchers.notNullValue(),
						"accountList[0].accountId.accountNumber", Matchers.notNullValue());

		// Gets and saves the CFP account ID
		accountId = response.path("accountList.accountId.find{it.owner.relationship==\"PRINCIPAL\"}.accountNumber");
		accountNumber = response.path("accountList.accountId.find{it.owner.relationship==\"PRINCIPAL\"}.accountNumber");
		accountId2 = response.path("accountList.accountId.find{it.owner.relationship==\"PARTNER\"}.id");
        String accountNumber2 = response.path("accountList.accountId.find{it.owner.relationship==\"PARTNER\"}.accountNumber");
		accountId3 = response.path("accountList.accountId.find{it.owner.relationship==\"DEPENDENT\"}.id");
        String accountNumber3 = response.path("accountList.accountId.find{it.owner.relationship==\"DEPENDENT\"}.accountNumber");

		context.put("id", accountId);
		context.put("accountNumber", accountNumber);
		context.put("id2", accountId2);
		context.put("accountNumber2", accountNumber2);
		context.put("id3", accountId3);
		context.put("accountNumber3", accountNumber3);
	}

	/**
	 * Validate the account was created correctly.
	 */
	@Test(dependsOnMethods="createThreeManualAccount")
	public void getManualAccountAfterCreate()
	{
		// Generate request body

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
				.body("accountList", Matchers.hasSize(3));
	}

	/**
	 * get the positions before creation of positions
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods="getManualAccountAfterCreate")
	public void getAccountPositionsBeforeCreatePosition()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body(
						"accountList", Matchers.hasSize(3),
						"accountList[0].account.accountId.sourceSystem", equalTo(sourceSystem),
						"accountList.account.accountId.find{it.id==\""+accountId+"\"}.accountNumber", equalTo(accountNumber),
						"accountList.account.accountId.find{it.id==\""+accountId+"\"}.id", equalTo(accountId),
						"accountList.account.accountId.find{it.id==\""+accountId+"\"}.owner.id", equalTo(principalPId),
						"accountList.account.accountId.find{it.id==\""+accountId+"\"}.positions", Matchers.nullValue(),
						"accountList.account.accountId.find{it.id==\""+accountId2+"\"}.positions", Matchers.nullValue(),
						"accountList.account.accountId.find{it.id==\""+accountId3+"\"}.positions", Matchers.nullValue()
				);


	}

	/**
	 * Create the positions
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods="getManualAccountAfterCreate")
	public void setAccountPositions()
	{

		context.put("positiondesc1", "Description 1");
		context.put("positionMarketVal1", 5000.0f);
		context.put("positionQuantity1", 100);
		context.put("positionPrice1", 50.0f);
		context.put("costBasis1", 222);
		context.put("finstId2", finstIds.getFinstId("FENY"));
		context.put("symbol2", "FENY");
		context.put("type2", finstIds.getType("FENY"));
		context.put("name2", finstIds.getName("FENY"));

		context.put("positiondesc2", "Description 2");
		context.put("positionMarketVal2", 5000.0f);
		context.put("positionQuantity2", 100);
		context.put("positionPrice2", 50.0f);
		context.put("costBasis2", 444);
		context.put("finstId", finstIds.getFinstId("FFIDX"));
		context.put("symbol", "FFIDX");
		context.put("type", finstIds.getType("FFIDX"));
		context.put("name", finstIds.getName("FFIDX"));

		context.put("positiondesc3", "Description 3");
		context.put("positionMarketVal3", 5000.0f);
		context.put("positionQuantity3", 100);
		context.put("positionPrice3", 50.0f);
		context.put("costBasis3", 332);
		context.put("finstId3", finstIds.getFinstId("QPISQ"));
		context.put("symbol3", "QPISQ");
		context.put("type3", finstIds.getType("QPISQ"));
		context.put("name3", finstIds.getName("QPISQ"));

		context.put("positiondesc4", "Description 4");
		context.put("positionMarketVal4", 5000.0f);
		context.put("positionQuantity4", 100);
		context.put("positionPrice4", 50.0f);
		context.put("costBasis4", 332);
		context.put("finstId4", finstIds.getFinstId("FEDTX"));
		context.put("symbol4", "FEDTX");
		context.put("type4", finstIds.getType("FEDTX"));
		context.put("name4", finstIds.getName("FEDTX"));


		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_VM));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accountPositions", notNullValue(),
						"accountPositions[0].account.accountId.sourceSystem", equalTo(sourceSystem),
						"accountPositions.account.accountId.find{it.id==\""+accountId+"\"}.accountNumber", equalTo(accountNumber),
						"accountPositions.account.accountId.find{it.id==\""+accountId+"\"}.id", equalTo(accountId),
						"accountPositions.account.accountId.find{it.id==\""+accountId+"\"}.owner.id", equalTo(principalPId),
						"accountPositions.find{it.account.accountId.id==\""+accountId+"\"}.positions.allPositions", Matchers.notNullValue(),
						"accountPositions.find{it.account.accountId.id==\""+accountId2+"\"}.positions.allPositions", Matchers.notNullValue(),
						"accountPositions.find{it.account.accountId.id==\""+accountId3+"\"}.positions.allPositions", Matchers.notNullValue(),
						"accountPositions.find{it.account.accountId.id==\""+accountId3+"\"}.positions.allPositions", hasSize(2)
						);


	}
	/**
	 * get the positions before creation of positions
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods="setAccountPositions")
	public void getAccountPositionsAfterCreatePositionWithIRAFilter()
	{

		context.put("mnemonicFilter", "IRA");
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body(
						"accountList", Matchers.hasSize(2),
						"accountList[0].account.accountId.sourceSystem", equalTo(sourceSystem),
						"accountList.account.accountId.find{it.owner.relationship==\"PRINCIPAL\"}.accountNumber", equalTo(accountNumber),
						"accountList.account.accountId.find{it.owner.relationship==\"PRINCIPAL\"}.id", equalTo(accountId),
						"accountList.account.accountId.find{it.owner.relationship==\"PRINCIPAL\"}.owner.id", equalTo(principalPId),
						"accountList.find{it.account.accountId.owner.relationship==\"PRINCIPAL\"}.positions", Matchers.notNullValue(),
						"accountList.find{it.account.accountId.owner.relationship==\"PARTNER\"}.positions", Matchers.notNullValue()

				);


	}



}
