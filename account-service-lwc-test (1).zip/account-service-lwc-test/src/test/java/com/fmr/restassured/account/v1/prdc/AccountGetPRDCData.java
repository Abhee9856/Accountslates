package com.fmr.restassured.account.v1.prdc;
/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

import com.fmr.ast.platform.account.domain.Account;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.soap.SOAPBackendUtil;
import com.fmr.pap.restassured.common.soap.SOAPSecureHeader;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.SOAPOauthUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.w3c.dom.Document;

import java.util.List;
import java.util.Map;

import static com.fmr.restassured.account.helpers.SOAPOauthUtil.callVMPlanSoapAPI;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * verify displayName with nickName or ShortName from Soap API VMPlan
 * Get WID, PRDC account number from CID and PRDC APIs
 * @author a783909
 */

@Test(groups = {Tags.PRDC_DATA, Tags.V1})
public class AccountGetPRDCData extends PAPBaseServiceTest {
    protected AccountGetPRDCData()
    {
        super(Services.Account);
    }

    private VelocityContext context;

    public String mid;

    public String ssn;

    private static final String LOG_TRACKING_ID = AccountGetPRDCData.class.getSimpleName();

    private FilterableRequestSpecification frs;

    private final String source = "WORKPLACE";

    private final String asOfDate1 = "2014-10-31";

    private float value = 120.0F;

    private String wid,accNumber,retailLid, planNumber;

    final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;

    private AccountsCommonTestData accountsCommonTestData = null;

    private String vMPlanShortName;

    private SOAPSecureHeader secureHeader;

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";

    private static final String FSREQID = LOG_TRACKING_ID;

    @BeforeClass(alwaysRun = true)
    public void init() {
        this.accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_get_PRDC", oAuth);

        this.ssn = accountsCommonTestData.getSsn();
        StringBuilder builder = new StringBuilder(ssn);
        builder.insert(3, '-');
        builder.insert(6, '-');
        retailLid = builder.toString();

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setAsOfDate1(this.asOfDate1);
        this.accountsCommonTestData.setValue1(value);
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");

        this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", this.accountsCommonTestData.getMid(), oAuth));
        this.testDataUtil = new TestDataUtil();
        context = new VelocityContext();
        context.put("source", AccountConstants.WORKPLACE);
    }

    /**
     * Get WID from CDS API by passing fescoLid
     */
    @Test
    public void getWIDFromCDS()
    {
        frs = (FilterableRequestSpecification) request;
        this.request.header(new Header("fid-user-id", "couldBeAnything"))
                .header(new Header("fid-log-tracking-id", "TestQA"))
                .header(new Header("fid-principal-role", "PART"))
                .header(new Header("fid-user-id-type", "FidCust"))
                .header(new Header("Authorization", oAuth))
                .header(new Header("Content-Type", "application/json"));

        context.put("id",retailLid);
        context.put("idIssuer", "SSA");
        context.put("idType", "SSN");

        this.request.baseUri(AccountConstants.WDS_BASE_URI);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.WDS_GET_TEMPLATE));

        response = this.request.post(AccountConstants.WDS_GET_PATH);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(anyOf(is(200)))
                .body("id", not(empty()));

        wid= response.path("id");

    }

    /**
     * Tests that PRDC account data is brought back and displayName is verified with return-prdc-accounts=false
     * Version V1
     */
    @Test(dependsOnMethods = {"getWIDFromCDS"})
    private void getAccounts_V1_PRDC_False() {

        // Populate request variables
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        this.setDefaultRequestHeaders(oAuth);
        this.request.header(new Header("return-prdc-accounts", "false"));
        this.context = new VelocityContext();
        this.context.put("mid", this.accountsCommonTestData.getMid());
        this.context.put("fescoLid", this.accountsCommonTestData.getSsn());

        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("value", String.valueOf(this.value));
        // Generate request body
        this.context.put("source", this.source);
        this.context.put("externalDataSources", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList", Matchers.not(emptyArray()));

        planNumber= response.path("accountList[0].accountId.accountNumber");

        //verify the displayName with nickName or ShortName in VM Plan
        verifyDisplayNameInResponse(false);

    }
    /**
     * Get PRDC accounts from PRDC API by passing WID
     */
    @Test(dependsOnMethods = {"getWIDFromCDS","getAccounts_V1_PRDC_False"})
    public void getAccNumberFromPRDC()
    {
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();

        request.given().header(new Header("Authorization", oAuth));

        request.baseUri(AccountConstants.PRDC_BASE_URI);
        request.given()
                .pathParam("wid", wid);
        response = request.given().get(AccountConstants.PRDC_GET_PATH);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(200)
                .body("accountDetails", not(empty()));

        accNumber= response.path("accountDetails.find{it.planNbr=='" + planNumber
                + "'}.accountNbr");

    }

    /**
     * Tests that PRDC account data is brought back and displayName is verified with return-prdc-accounts=true
     * Version V1
     */
    @Test(dependsOnMethods = {"getAccNumberFromPRDC"})
    private void getAccounts_V1_PRDC_True() {

        // Populate request variables
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        this.setDefaultRequestHeaders(oAuth);
        this.request.header(new Header("return-prdc-accounts", "true"));
        this.context = new VelocityContext();
        this.context.put("mid", this.accountsCommonTestData.getMid());
        this.context.put("fescoLid", this.accountsCommonTestData.getSsn());

        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("value", String.valueOf(this.value));
        // Generate request body
        this.context.put("source", this.source);
        this.context.put("externalDataSources", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList", Matchers.not(emptyArray()));

        //verify the displayName with nickName or ShortName in VM Plan
        verifyDisplayNameInResponse(true);
    }

   @Test(dependsOnMethods = {"getAccounts_V1_PRDC_True"})
   public void getDetails_V1_PRDC_True() {
       getDetails_V2_PRDC(true);
   }

    @Test(dependsOnMethods = {"getDetails_V1_PRDC_True"})
    public void getDetails_V1_PRDC_False() {
        getDetails_V2_PRDC(false);
    }


    @Test(dependsOnMethods = {"getDetails_V1_PRDC_False"})
    public void getComposite_details_V1_PRDC_TRUE() {
        final VelocityContext context = new VelocityContext();

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("return-prdc-accounts", "true"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(200)
                .body("accounts", not(emptyArray()));

        validateCompositeAccountResponse(response, true);
    }
    @Test(dependsOnMethods = {"getComposite_details_V1_PRDC_TRUE"} )
    public void getComposite_details_V1_PRDC_FALSE() {

        final VelocityContext context = new VelocityContext();

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("return-prdc-accounts", "false"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = request.log().ifValidationFails()
                .post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        response.then().log().ifValidationFails().statusCode(200)
                .body("accounts", not(emptyArray()));

        validateCompositeAccountResponse(response, false);
    }

    private void validateCompositeAccountResponse(Response response, Boolean returnPrdcAccounts) {
        Object rawAccounts = response.jsonPath().get("accounts");
        if (!(rawAccounts instanceof List)) return;

        List<?> accountsList = (List<?>) rawAccounts;
        for (Object rawAccount : accountsList) {
            if (!(rawAccount instanceof Map)) continue;
            Map<?, ?> accountWrapper = (Map<?, ?>) rawAccount;

            Object accountObj = accountWrapper.get("account");
            if (!(accountObj instanceof Map)) continue;
            Map<?, ?> account = (Map<?, ?>) accountObj;

            // Extract accountId and accountNumber
            Object accountIdObj = account.get("accountId");
            if (!(accountIdObj instanceof Map)) continue;
            Map<?, ?> accountId = (Map<?, ?>) accountIdObj;
            String accountNumber = safeString(accountId.get("accountNumber"));

            // Extract details
            Object detailsObj = accountWrapper.get("details");
            if (!(detailsObj instanceof Map)) continue;
            Map<?, ?> details = (Map<?, ?>) detailsObj;

            // Extract durableAccountNumber
            String durableAccountNumber = safeString(details.get("durableAccountNumber"));

            // Extract planId and planNumber
            Object planIdObj = details.get("planId");
            String planNumber = null;
            if (planIdObj instanceof Map) {
                Map<?, ?> planId = (Map<?, ?>) planIdObj;
                planNumber = safeString(planId.get("planNumber"));
            }
            if (returnPrdcAccounts) {
                // Validate durableAccountNumber is present and matches accountNumber
                if (durableAccountNumber == null || durableAccountNumber.isEmpty()) {
                    response.then().body(
                    "responseDiagnostic.find { it.message != null && it.message.contains('Durable account number not found for plan number : " + planNumber + "') }",
                            Matchers.notNullValue()
                    ).body(
                            "responseDiagnostic.find { it.message != null && it.message.contains('Durable account number not found for plan number : " + planNumber + "') }.resultCode",
                            Matchers.equalTo(true)
                    );
                } else {
                    response.then().body("accounts.find { it.account.accountId.accountNumber == '" + accNumber + "' }.details.durableAccountNumber", Matchers.equalTo(accNumber));
                }
            } else {
                // Validate accountNumber equals planNumber
                if (planNumber != null) {
                    response.then().body("accounts.find { it.details.planId.planNumber == '" + planNumber + "' }.account.accountId.accountNumber", Matchers.equalTo(planNumber));
                }
            }
        }
    }

    private String safeString(Object obj) {
        return (obj instanceof String) ? (String) obj : null;
    }


    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown()
    {
        this.testDataUtil.closeSQLiteConnection();
    }

    private void verifyDisplayNameInResponse(Boolean prdcFlag) {
        setShortNameFromVMPlan();
        List<Account> actList = response.jsonPath().getList("accountList");
        Boolean isNickNameVerified = false;
        Boolean isShortNameVerified = false;

        for(int count=0;count< actList.size();count++){
            String accNumber = response.path("accountList["+count+"].accountId.accountNumber");
            if(prdcFlag)
            accNumber = TestDataUtil.getMaskedAccountNumber(accNumber);

            String displayName = response.path("accountList["+count+"].displayName");
            String nickName = response.path("accountList["+count+"].nickName");

            if (nickName != null && !isNickNameVerified) {
                Assert.assertEquals(displayName, nickName+"-"+accNumber);
                isNickNameVerified = true;
            } else if(!isShortNameVerified) {
                Assert.assertEquals(displayName,  vMPlanShortName+"-"+accNumber);
                isShortNameVerified = true;
            }

            if(isShortNameVerified && isNickNameVerified) break;
        }
    }

    private void setShortNameFromVMPlan()
    {
        this.secureHeader = SOAPOauthUtil.getSecureHeader();
        final Document defDoc = callVMPlanSoapAPI(
                this.secureHeader,
                accountsCommonTestData.getSsn(), planNumber);

        vMPlanShortName = SOAPBackendUtil.getXmlValue(defDoc,   "/Envelope/Body/GetRetirementPlanInfoResponse/" +
                "GetRetirementPlanInfoResult/Accounts/Account/ShortName");
    }

    private void getDetails_V2_PRDC(Boolean returnPrdcAccounts) {
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);
        this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);

        this.request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-fesco-lid", this.ssn))
                .header(new Header("user-mid", mid));

        if (returnPrdcAccounts) {
            this.request.header(new Header("return-prdc-accounts", "true"));
        }
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        response = this.request.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

        // Base response validation
        response.then().log().ifValidationFails().statusCode(200)
                .body("accountDetails", not(emptyArray()));

        if (returnPrdcAccounts) {
            // Validate accountNumber and planNumber separately
            response.then()
                    .body("accountDetails.find{it.accountId.accountNumber=='" + accNumber
                            + "'}planId.planNumber", equalTo(planNumber))
                    .body("accountDetails.find{it.accountId.accountNumber=='" + accNumber
                            + "'}.accountId.sourceSystem", equalTo(AccountConstants.WORKPLACE));
            String durableAccountNumber = response.jsonPath().getString("accountDetails.find{it.accountId.accountNumer=='"
                    + accNumber + "'}.accountDetails.durableAccountNumber");
            if(durableAccountNumber != null) {
                response.then()
                        .body("accountDetails.find{it.accountId.accountNumber ==' "
                                + accNumber + "'}.accountDetails.durableAccountNumber", equalTo(accNumber));

            }
        } else {
            // Validate accountNumber == planNumber when PRDC flag is false
            response.then()
                    .body("accountDetails.find{it.planId.planNumber=='" + planNumber
                            + "'}.accountId.accountNumber", equalTo(planNumber));
        }
        // Always check for durableAccountNumber presence
        if (!checkDurableAccountNumberPresence(response)) {
            response.then()
                    .body("responseDiagnostic.find { it.message.contains('Durable account number not found for plan number : " + planNumber + "') }.resultCode", equalTo(true));

        }
    }

    private boolean checkDurableAccountNumberPresence(Response response) {
        List<Map<String, Object>> accountDetails = response.jsonPath().getList("accountDetails");

        for (Map<String, Object> account : accountDetails) {
            Object durable = account.get("durableAccountNumber");
            Map<String, Object> planIdMap = (Map<String, Object>) account.get("planId");
            Object planId = planIdMap != null ? planIdMap.get("planNumber") : null;

            if (durable == null && planId != null) {
                response.then().body(
                        "responseDiagnostic.externalSystemDiagnostic.find { it.message.contains('Durable account number not found for plan number " + planId + "') }.result",
                        equalTo(true)
                );
            }
        }
        return true; // all accounts have durableAccountNumber or proper diagnostics
    }

}
