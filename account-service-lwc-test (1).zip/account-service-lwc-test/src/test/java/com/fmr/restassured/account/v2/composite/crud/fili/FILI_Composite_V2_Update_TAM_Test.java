/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.fili;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.MatcherAssert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

/**
 * Class to test TAM is created successfully via UPDATE method.
 *
 * @author a631781
 */
@Test(groups = {Tags.FILI, Tags.ACCOUNT, Tags.V2})
public class FILI_Composite_V2_Update_TAM_Test extends PAPBaseServiceTest {

    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(FILI_Composite_V2_Update_TAM_Test.class);

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    /**
     * Global variable holding filiAccount information
     */
    private HashMap<String, String> filiAccountMap;

    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountsCommonTestData;

    private String accNum;

    private String acctRoot;

    private final String details = "details.annuityAccountDetail.accountDetail.";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = FILI_Composite_V2_Update_TAM_Test.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private VelocityContext context;

    private static String tamName = "Growth with Income";
    private static float tamTotalEquity = 0.60F;
    private static float tamDomesticEquity = 0.42F;
    private static float tamForeignEquity = 0.18F;
    private static float tamBond = 0.35F;
    private static float tamCash = 0.05F;

    private static Integer tamRepositoryId = 179;
    private static Integer tamAssetAllocationId = 60;


    /**
     * Constructor
     */
    protected FILI_Composite_V2_Update_TAM_Test() {
        super(Services.Account);
    }

    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        filiAccountMap = new HashMap<>();

        accountsCommonTestData = TestDataUtil.populateRegressionTestData("fili_crud", oAuth);
        accountsCommonTestData.setMid("FiliCompositeV2TestMid");
        filiAccountMap = getFiliAccountInformationV2(accountsCommonTestData, oAuth);

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");

        final String ppid = Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth);
        accountsCommonTestData.setPpid(ppid);

        context = new VelocityContext();
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"));
    }

    /**
     * Description: Validates an empty account list when calling get account composite FILI before creation of an
     * account (v2)
     */
    @Test
    public void getCompositeAccountFILIV2BeforeCreate() {
        if (filiAccountMap.isEmpty()) {
            throw new SkipException(
                    "'getCompositeAccountFILIBeforeCreate' test scenario cannot run due to failure to retrieve fili "
                            + "account information!");
        }

        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", filiAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Description: Creates composite account
     */
    @Test(dependsOnMethods = "getCompositeAccountFILIV2BeforeCreate")
    public void createCompositeAccountFILIV2() {
        //Generate request body
        accNum = filiAccountMap.get("accountNumber");
        context.put("accountNumber", accNum);
        context.put("source", filiAccountMap.get("sourceSystem"));
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", filiAccountMap.get("displayName"));
        context.put("mnemonic", filiAccountMap.get("mnemonic"));
        context.put("sourceSystem2", filiAccountMap.get("sourceSystem"));
        context.put("institutionName", filiAccountMap.get("institutionName"));
        context.put("value", filiAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", filiAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "111111.11");
        context.put("emergencyFundAmountValue", "111111.11");

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.log().ifValidationFails().body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
        response = request.log().all().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().all().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(filiAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(filiAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(filiAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(filiAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(filiAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        filiAccountMap.get("sourceMarketAmountValue"))));


        accountsCommonTestData
                .setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
    }

    /**
     * Description: Validates the account composite response after create
     */
    @Test(dependsOnMethods = "createCompositeAccountFILIV2")
    public void getCompositeAccountFILIV2AfterCreate() {
        //Generate request body
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", filiAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(filiAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(filiAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(filiAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(filiAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(filiAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        filiAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details", notNullValue())
                .body(acctRoot + details + "emergencyFundAmount.value",
                        equalTo(111111.11f));

    }

    /**
     * Description: Create TAM via update call
     */
    @Test(dependsOnMethods = "getCompositeAccountFILIV2AfterCreate")
    public void updateCompositeAccountFILIV2() {
        //Generate request body
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", filiAccountMap.get("accountNumber"));
        context.put("source", filiAccountMap.get("sourceSystem"));
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", filiAccountMap.get("displayName"));
        context.put("mnemonic", filiAccountMap.get("mnemonic"));
        context.put("sourceSystem2", filiAccountMap.get("sourceSystem"));
        context.put("institutionName", filiAccountMap.get("institutionName"));
        context.put("value", filiAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", filiAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "211111.11");
        context.put("emergencyFundAmountValue", "211111.11");
        context.put("TAM_name", tamName);
        context.put("TAM_total_equity", tamTotalEquity);
        context.put("TAM_domestic_equity", tamDomesticEquity);
        context.put("TAM_foreign_equity", tamForeignEquity);
        context.put("TAM_bond", tamBond);
        context.put("TAM_cash", tamCash);
        context.put("TAM_repositoryTamId", tamRepositoryId);
        context.put("TAM_assetAllocationId", tamAssetAllocationId);

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.log().ifValidationFails().body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        response = request.log().all().post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().all().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(filiAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(filiAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(filiAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(filiAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(filiAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        filiAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "emergencyFundAmount.value", equalTo(211111.11f))
                .body(acctRoot + details + "targetAssetMixes[0].name", equalTo(tamName))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage", equalTo(tamTotalEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage", equalTo(tamDomesticEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage", equalTo(tamForeignEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage", equalTo(tamBond))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage", equalTo(tamCash));


    }

    /**
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "updateCompositeAccountFILIV2")
    public void getCompositeAccountFILIV2AfterUpdate() {
        //Generate request body
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", filiAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(filiAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(filiAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(filiAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(filiAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(filiAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        filiAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "emergencyFundAmount.value", equalTo(211111.11f))
                .body(acctRoot + details + "targetAssetMixes[0].name", equalTo(tamName))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage", equalTo(tamTotalEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage", equalTo(tamDomesticEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage", equalTo(tamForeignEquity))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage", equalTo(tamBond))
                .body(acctRoot + details + "targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage", equalTo(tamCash));
    }

    /**
     * Description: Delete the account
     */
    @Test(dependsOnMethods = "getCompositeAccountFILIV2AfterUpdate")
    public void deleteCompositeAccountFILIV2() {
        //Generate request body
//        final VelocityContext context = new VelocityContext();
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", filiAccountMap.get("accountNumber"));
        context.put("source", filiAccountMap.get("sourceSystem"));
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", filiAccountMap.get("displayName"));
        context.put("mnemonic", filiAccountMap.get("mnemonic"));
        context.put("institutionName", filiAccountMap.get("institutionName"));
        context.put("value", filiAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", filiAccountMap.get("sourceMarketAsOfDate"));

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()));

        request.log().ifValidationFails().body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = response.jsonPath().getString("$");
        MatcherAssert.assertThat(emptyResponse, equalTo("[:]"));
    }

    /**
     * Description: Validates an empty account list when calling get account composite FILI after delete
     */
    @Test(dependsOnMethods = "deleteCompositeAccountFILIV2")
    public void getCompositeAccountFILIV2AfterDelete() {
        //Generate request body
        context.put("sourceBasedRegistrationFilter", filiAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Returns the response of retrieving a fili account
     *
     * @param accountsCommonTestData the test data
     * @return filiAccountMap
     */
    private static HashMap<String, String> getFiliAccountInformationV2(
            final AccountsCommonTestData accountsCommonTestData, final String oAuth) {
        final VelocityContext context = new VelocityContext();
        context.put("source", "FILI");

        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();

        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        final Response response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        if (response.statusCode() != HTTPStatusCodes.STATUS_200) {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));

            return null;
        }

        final JsonPath filiAccountJP = response.jsonPath();

        final HashMap<String, String> filiAccountMap = new HashMap<>();
        filiAccountMap.put("accountNumber", filiAccountJP.getString("accountList[0].accountId.accountNumber"));
        filiAccountMap.put("sourceSystem", filiAccountJP.getString("accountList[0].accountId.sourceSystem"));
        filiAccountMap.put("displayName", filiAccountJP.getString("accountList[0].displayName"));
        filiAccountMap.put("mnemonic", filiAccountJP.getString("accountList[0].regCode.mnemonic"));
        filiAccountMap.put("institutionName", filiAccountJP.getString("accountList[0].institutionName"));
        filiAccountMap.put("sourceMarketAmountValue",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
        filiAccountMap.put("sourceMarketAmountValueType",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        filiAccountMap.put("sourceMarketAmountCurrency",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        filiAccountMap.put("sourceMarketAsOfDate",
                filiAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));

        return filiAccountMap;
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown() {
        testDataUtil.closeSQLiteConnection();
    }

}