/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.workplace;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import static org.hamcrest.Matchers.equalTo;

import org.hamcrest.Matchers;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.notNullValue;
import static org.testng.AssertJUnit.assertTrue;

/**
 * Tests composite/get for Workplace accounts v2. Starts by retrieving a workplace account,
 * and then retrieving all composite information from backend.
 * Also,checks if a custom fund is holding a digital asset or not(PFCP-10191)
 *
 * @author a608077
 */
@Test(groups = {
        Tags.WORKPLACE,
        Tags.COMPOSITE,
        Tags.V2})

public class Workplace_Composite_v2_Get_Digital_Assets extends PAPBaseServiceTest {
    protected Workplace_Composite_v2_Get_Digital_Assets() {
        super(Services.Account);
    }

    private String ppid;
    private String mnemonic;
    private String accountNumber;
    private final String sourceSystem = "WORKPLACE";
    private String displayName;
    private float value;
    Boolean containsDigitalAssets;

    private VelocityContext context;
    //Instance to the test data utility class
    TestDataUtil testDataUtil = new TestDataUtil();

    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Workplace_Composite_v2_Get_Digital_Assets.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        // Data setup
        AccountsCommonTestData accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_get_positions_workplace_digitalAsset", oAuth);

        String mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("excludeExternalDataSources", "false"));

        // Populate request context
        context = new VelocityContext();

    }
    /**
     * Get Workplace account info from the backend. Save the account number.
     */
    @Test
    public void getWorkplaceAccountInfo() {
        context.put("source", sourceSystem);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList", Matchers.notNullValue());

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
    }

    /**
     * Validate the positions.
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void getCompositeAccount() throws JSONException {

        context.put("sourceBasedRegistrationFilter",sourceSystem);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accounts", notNullValue())
                .body("accounts[0].account.accountId.sourceSystem", equalTo(sourceSystem))
                .body("accounts[0].account.accountId.accountNumber", equalTo(accountNumber))
                .body("accounts[0].account.regCode.mnemonic", equalTo(mnemonic))
                .body("accounts[0].account.displayName", equalTo(displayName))
                .body("accounts[0].account.accountId.owner.id", equalTo(ppid))
                .body("accounts[0].account.sourceMarketValue.amount.value", equalTo(value))
                .body("accounts.find{it.account.accountId.accountNumber==\"" + accountNumber + "\"}.positions", Matchers.notNullValue())
                .body("accounts.find{it.account.accountId.accountNumber==\"" + accountNumber + "\"}.positions.allPositions", Matchers.notNullValue());

        //Logic for validation of Digital assets
        JSONArray accountList = new JSONObject(response.getBody().asString()).getJSONArray("accounts");
        for (int i = 0; i < accountList.length(); i++) {
            JSONArray allPositions = accountList.getJSONObject(i).getJSONObject("positions").getJSONArray("allPositions");
            for (int j = 0; j < allPositions.length(); j++) {
                JSONObject financialAssetPosition = allPositions.getJSONObject(j)
                        .getJSONObject("workplacePosition").getJSONObject("financialAssetPosition");
                if (financialAssetPosition.has("investmentTypeCode") && financialAssetPosition.has("subInvestmentTypeCode"))
                {
                    containsDigitalAssets = true;
                }
            }
        }
        assertTrue("We don't have Digital Assets", containsDigitalAssets);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }
}
