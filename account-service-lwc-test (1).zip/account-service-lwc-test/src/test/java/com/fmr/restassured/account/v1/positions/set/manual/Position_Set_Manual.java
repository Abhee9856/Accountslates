/****************************************************************************
 *
 * FIDELITY INVESTMENTS CONFIDENTIAL INFORMATION
 *
 * Copyright (c) 2021 Fidelity Investments.  All Rights Reserved.
 * Unauthorized reproduction, transmission, or distribution of
 * this software is a violation of applicable laws.
 *
 ****************************************************************************
 *
 * Department:  Personal Investing
 *
 * File Name:   Position_Set_Manual
 * @author: Kamlesh Vyas
 * @version: 1.0
 * *  Updated by a608077 on 05/08/2024 to include EEDS=null(PFCP-15874)
 ****************************************************************************/
package com.fmr.restassured.account.v1.positions.set.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.not;

import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

@Test(groups = {

		Tags.MANUAL,
		Tags.POSITIONS,
		Tags.V1,
		"PFCP-3068" })
public class Position_Set_Manual extends PAPBaseServiceTest
{

	public static final String LOG_TRACKING_ID = Position_Set_Manual.class.getSimpleName();
	private static final String FSREQID = LOG_TRACKING_ID;
	private Integer gdStockId;

	private Integer gfStock;

	private Integer gBond;

	private Integer gCash;

	protected Position_Set_Manual()
	{
		super(Services.Account);
	}

    private String mid;

	private String ppid;

    private String accountNumber;

	private String accountId;


	private final String sourceSystem = "MANUAL";

    private VelocityContext context;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
	 * for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
				.populateRegressionTestData("accountCRUD_Manual", oAuth);
		mid = accountsCommonTestData.getMid();
		DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


		ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID,oAuth );

		// Populate request context with user IDs
		context = new VelocityContext();

		context.put(AccountConstants.MID, mid);
		context.put("ppid", ppid);

		//for positions
		context.put("gCashValue", "0.25");
		context.put("gBondValue", "0.25");
		context.put("gdStockValue", "0.25");
		context.put("gfStockValue", "0.25");
	}

	/**
	 *
	 *
	 * finst ID service Version V1
	 */
	@Test
	public void verifyFinancialInstrumentGenericId()
	{

		response = request.log().ifValidationFails().baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI)
				.get(AccountConstants.GET_FINANCIALINSTRUMENT_PATH);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(HttpStatus.SC_OK)
				.body("resultCode", equalTo(true),
						"genericFinstIdList.finstId.symbol", hasItems("GDSTOCK", "GFSTOCK","GBOND",
								"GCASH", "OTHER","UNKNOWN", "STOCK"));

		//get finst id from finst service

		gdStockId = response.path("genericFinstIdList.find{it.finstId.symbol=='GDSTOCK'}.finstId.finstId");
		gfStock = response.path("genericFinstIdList.find{it.finstId.symbol=='GFSTOCK'}.finstId.finstId");
		gBond = response.path("genericFinstIdList.find{it.finstId.symbol=='GBOND'}.finstId.finstId");
		gCash = response.path("genericFinstIdList.find{it.finstId.symbol=='GCASH'}.finstId.finstId");
	}

	/**
	 * Create the Manual account. Save the account id.
	 *
	 * Version V1
	 */
	@Test
	public void createManualAccount()
	{
        String mnemonic = "401K";
        context.put("mnemonic", mnemonic);
        float value = 100.0f;
        context.put("value", value);
		context.put("source", sourceSystem);
		context.put("accountNumber", accountNumber);
        String displayName = "Display_Name";
        context.put("displayName", displayName);
        String institutionName = "InstitutionalName";
        context.put("institutionName", institutionName);
        String asOfDate = "2014-10-31";
        context.put("asOfDate", asOfDate);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(HttpStatus.SC_OK)
				.body("resultCode", equalTo(true),
						"userIdentifier.mid", equalTo(mid),
						"accountList[0].regCode.mnemonic", equalTo(mnemonic),
						"accountList[0].accountId.accountNumber", Matchers.notNullValue());

		// Gets and saves the CFP account ID
		accountId = response.path("accountList[0].accountId.id");
		accountNumber = response.path("accountList[0].accountId.accountNumber");
		context.put("accId", accountId);
		context.put("accountNumber", accountNumber);
	}

	/**
	 * Validate the account was created correctly.
	 */
	@Test(dependsOnMethods="createManualAccount")
	public void getManualAccountAfterCreate()
	{
		// Generate request body
		context.put("externalDataSources", null);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
				.body("resultCode", equalTo(true),
						"accountList", not(empty()));


	}

	/**
	 * Create the positions
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods="getManualAccountAfterCreate")
	public void setAccountPositions()
	{
		context.put("externalDataSources", "true");
		context.put("GDSTOCK", gdStockId);
		context.put("GFSTOCK", gfStock);
		context.put("GBOND", gBond);
		context.put("GCASH", gCash);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_POSITIONS_SET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true),
						"userIdentifier.mid", equalTo(mid),
						"accountPositions[0].account.accountId.sourceSystem", equalTo(sourceSystem),
						"accountPositions[0].account.accountId.accountNumber", equalTo(accountNumber),
						"accountPositions[0].account.accountId.id", equalTo(accountId),
						"accountPositions[0].account.accountId.owner.id", equalTo(ppid),
						"accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId", equalTo(gdStockId),
						"accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId", equalTo(gfStock),
						"accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId", equalTo(gBond),
						"accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId", equalTo(gCash));

	}

	/**
	 * get the positions
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods="setAccountPositions")
	public void getAccountPositions()
	{
		context.put("externalDataSources", "true");
		context.put("GDSTOCK", gdStockId);
		context.put("GFSTOCK", gfStock);
		context.put("GBOND", gBond);
		context.put("GCASH", gCash);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_POSITIONS_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true),
						"userIdentifier.mid", equalTo(mid),
						"accountList[0].account.accountId.sourceSystem", equalTo(sourceSystem),
						"accountList[0].account.accountId.accountNumber", equalTo(accountNumber),
						"accountList[0].account.accountId.id", equalTo(accountId),
						"accountList[0].account.accountId.owner.id", equalTo(ppid),
						"accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId", equalTo(gdStockId),
						"accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId", equalTo(gfStock),
						"accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId", equalTo(gBond),
						"accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId", equalTo(gCash));

	}


}
