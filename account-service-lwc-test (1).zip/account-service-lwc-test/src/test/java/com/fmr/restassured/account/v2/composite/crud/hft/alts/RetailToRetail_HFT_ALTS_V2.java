/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.hft.alts;

import com.fmr.ast.platform.account.domain.DestinationAccountType;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.AccountConstants;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;

import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import com.fmr.restassured.hypofundtransfer.helpers.AccountHelper;
import com.fmr.restassured.hypofundtransfer.helpers.CreateAccount;
import com.fmr.restassured.hypofundtransfer.helpers.HypotheticalFundTransferConstants;
import com.fmr.restassured.hypofundtransfer.helpers.HypotheticalFundTransferPaths;

import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.CoreMatchers.notNullValue;

/**
 * Creates funds transfer between two retail accounts and then fetches postTransferBalances for ALTS through get/composite call
 * using header calculate-balances=fund-transfers
 *
 * @author a631781
 */
@Test(groups = {Tags.HYPO_FUND_TRANSFER, Tags.V2, Tags.COMPOSITE})
public class RetailToRetail_HFT_ALTS_V2 extends PAPBaseServiceTest {

    protected RetailToRetail_HFT_ALTS_V2() {
        super(Services.Account);
    }

    private AccountsCommonTestData testData = null;

    private VelocityContext context;

    private TestDataUtil testDataUtil;

    private static final String CALLING_APP_ID = "AP144949";

    private static final String APP_ID = "AP144949";

    private static final String LOG_TRACKING_ID = RetailToRetail_HFT_ALTS_V2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static String accountNumber, accountNumber2;

    private static String mid, ppid;

    private static String ssn;

    private static String accId1, accId2;

    private static String mnemonic, mnemonic2;

    private static String oAuth;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String assetClass = "TOTAL_EQUITY";

    private static final float netPercentage = 0.10f;

    private static final String assetClass1 = "BOND";

    private static final float netPercentage1 = 0.15f;

    private static final String assetClass2 = "CASH";

    private static final float netPercentage2 = 0.05f;

    private static final String assetClass3 = "OTHER";

    private static final float netPercentage3 = 0.20f;

    private static float srcMktValFundingAccount, srcMktValDestAccount;

    private static final float domEquityAmount1 = 5000;

    private static final float foreignEquityAmount1 = 0;

    private static final float bondAmount1 = 1000;

    private static final float cashAmount1 = 500;

    private static final float otherAmount1 = 2500;

    private static final float unknownAmount = 0;

    private final float totalAmount1 = domEquityAmount1 + foreignEquityAmount1 + bondAmount1 + cashAmount1
            + otherAmount1 + unknownAmount;

    private static final float totalAlternativeNetPercentage = 0.5f;

    private static final float netPercentage_PEA = 0.25f;

    private static final float netPercentage_PCA = 0.10f;

    private static final float netPercentage_PRAA = 0.15f;

    private static final float netPercentage_PEA1 = 0.15f;

    private static final float netPercentage_PRAA1 = 0.25f;

    private FilterableRequestSpecification frs;
    private final String host = AccountHelper.getQATestEnvHost();
    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, and build the
     * request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();

        testData = TestDataUtil.populateRegressionTestData("account_default_ssn", oAuth);

        mid = Identity.getUserIdentifier("lid", testData.getSsn(), oAuth).get("mid");
        testData.setMid(mid);
        ssn = testData.getSsn();
        String asOfDate1 = "2014-10-31";
        testData.setAsOfDate1(asOfDate1);

        DataCleanup.deleteCustomerDataFromCP("mid", testData.getMid(), oAuth, "true");

        testData.setPpid(Identity.createHouseholdIdentity("mid", testData.getMid(), oAuth));

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", testData.getSsn()))
                .header(new Header("user-mid", testData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("excludeExternalDataSources", "false"));

        // Populate request variables
        context = new VelocityContext();

        frs = (FilterableRequestSpecification) request;
    }

    /**
     * Create 2 Retail accounts in CFP for making Fund Transfer.
     */
    @Test
    public void createTwoRetailAccounts() {

        context.put("source", AccountConstants.RETAIL);
        context.put("mnemonicFilter", testData.getMnemonic1());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("accountList",
                not(Matchers.empty()));

        mnemonic = response.path("accountList[0].regCode.mnemonic").toString();
        accountNumber = response.path("accountList[0].accountId.accountNumber").toString();
        srcMktValFundingAccount = response.path("accountList[0].sourceMarketValue.amount.value");

        ppid = testData.getPpid();

        mnemonic2 = response.path("accountList[1].regCode.mnemonic").toString();
        accountNumber2 = response.path("accountList[1].accountId.accountNumber").toString();
        srcMktValDestAccount = response.path("accountList[1].sourceMarketValue.amount.value");

        String source2 = AccountConstants.RETAIL;

        String source = AccountConstants.RETAIL;
        frs.removeHeader("Authorization");
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "true"));
        final String accIds = CreateAccount.createAccounts(ssn, accountNumber, source, mnemonic,
                srcMktValFundingAccount, accountNumber2, source2, mnemonic2, srcMktValDestAccount, null,
                null, null, null, null, null, ppid, mid, request, oAuth);
        if (StringUtils.isNotBlank(accIds)) {
            final String[] arrAcc = accIds.split(",");
            accId1 = arrAcc[0];
            accId2 = arrAcc[1];
        }

    }

    @Test(dependsOnMethods = "createTwoRetailAccounts")
    public void createRetailAccountDetails1() {
        // Generate request body
        context.put("ppid", ppid);
        context.put("value", srcMktValFundingAccount);
        context.put("accountNumber", accountNumber);
        context.put("accId", accId1);
        context.put("isInherited", false);
        context.put("isProductSuitable", "true");
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "retailAccountDetail");
        context.put("_type", "RetailAccountDetails");
        context.put("emergencyFundAmount", 2500.0F);
        context.put("assetClass", assetClass);
        context.put("netPercentage", netPercentage);
        context.put("assetClass1", assetClass1);
        context.put("netPercentage1", netPercentage1);
        context.put("assetClass2", assetClass2);
        context.put("netPercentage2", netPercentage2);
        context.put("assetClass3", assetClass3);
        context.put("netPercentage3", netPercentage3);
        context.put("assetClass_TOTAL_ALTERNATIVE", "TOTAL_ALTERNATIVE");
        context.put("netPercentage_T_ALTERNATIVE", totalAlternativeNetPercentage);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", "PRIVATE_EQUITY_ALTERNATIVE");
        context.put("netPercentage_PEA", netPercentage_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", "PRIVATE_CREDIT_ALTERNATIVE");
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", "PRIVATE_REAL_ASSETS_ALTERNATIVE");
        context.put("netPercentage_PRAA", netPercentage_PRAA);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));
        // Call Account service

        response = request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);

        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1 + "'}.retailAccountDetail.isProductSuitable", equalTo(true))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass + "'}.assetClass", equalTo(assetClass))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass + "'}.netPercentage", equalTo(netPercentage))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass1 + "'}.assetClass", equalTo(assetClass1))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass1 + "'}.netPercentage", equalTo(netPercentage1))

                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass2 + "'}.assetClass", equalTo(assetClass2))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass2 + "'}.netPercentage", equalTo(netPercentage2))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass3 + "'}.assetClass", equalTo(assetClass3))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass3 + "'}.netPercentage", equalTo(netPercentage3))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                                + accId1
                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_ALTERNATIVE'}.assetClass",
                        equalTo("TOTAL_ALTERNATIVE"))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                                + accId1
                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_ALTERNATIVE'}.netPercentage",
                        equalTo(totalAlternativeNetPercentage))

                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                                + accId1
                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_ALTERNATIVE'}.allocation.find{it.assetClass=='PRIVATE_EQUITY_ALTERNATIVE'}.netPercentage",
                        equalTo(netPercentage_PEA))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                                + accId1
                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_ALTERNATIVE'}.allocation.find{it.assetClass=='PRIVATE_CREDIT_ALTERNATIVE'}.netPercentage",
                        equalTo(netPercentage_PCA))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                                + accId1
                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_ALTERNATIVE'}.allocation.find{it.assetClass=='PRIVATE_REAL_ASSETS_ALTERNATIVE'}.netPercentage",
                        equalTo(netPercentage_PRAA));
    }

    @Test(dependsOnMethods = {"createTwoRetailAccounts", "createRetailAccountDetails1"})
    public void createRetailAccountDetails2() {
        // Generate request body
        context.put("ppid", ppid);
        context.put("value", srcMktValDestAccount);
        context.put("accountNumber", accountNumber2);
        context.put("accId", accId2);
        context.put("isInherited", false);
        context.put("isProductSuitable", "true");
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "retailAccountDetail");
        context.put("_type", "RetailAccountDetails");
        context.put("emergencyFundAmount", 2600.0F);
        context.put("assetClass", assetClass);
        context.put("netPercentage", netPercentage);
        context.put("assetClass1", assetClass1);
        context.put("netPercentage1", netPercentage1);
        context.put("assetClass2", assetClass2);
        context.put("netPercentage2", netPercentage2);
        context.put("assetClass3", assetClass3);
        context.put("netPercentage3", netPercentage3);
        context.put("assetClass_TOTAL_ALTERNATIVE", "TOTAL_ALTERNATIVE");
        context.put("netPercentage_T_ALTERNATIVE", totalAlternativeNetPercentage);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", "PRIVATE_EQUITY_ALTERNATIVE");
        context.put("netPercentage_PEA", netPercentage_PEA1);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", "PRIVATE_CREDIT_ALTERNATIVE");
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", "PRIVATE_REAL_ASSETS_ALTERNATIVE");
        context.put("netPercentage_PRAA", netPercentage_PRAA1);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));
        // Call Account service

        response = request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);

        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2 + "'}.retailAccountDetail.isProductSuitable", equalTo(true))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass + "'}.assetClass", equalTo(assetClass))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass + "'}.netPercentage", equalTo(netPercentage))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass1 + "'}.assetClass", equalTo(assetClass1))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass1 + "'}.netPercentage", equalTo(netPercentage1))

                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass2 + "'}.assetClass", equalTo(assetClass2))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass2 + "'}.netPercentage", equalTo(netPercentage2))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass3 + "'}.assetClass", equalTo(assetClass3))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass3 + "'}.netPercentage", equalTo(netPercentage3))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                                + accId2
                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_ALTERNATIVE'}.allocation.find{it.assetClass=='PRIVATE_EQUITY_ALTERNATIVE'}.netPercentage",
                        equalTo(netPercentage_PEA1))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                                + accId2
                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_ALTERNATIVE'}.allocation.find{it.assetClass=='PRIVATE_CREDIT_ALTERNATIVE'}.netPercentage",
                        equalTo(netPercentage_PCA))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                                + accId2
                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='TOTAL_ALTERNATIVE'}.allocation.find{it.assetClass=='PRIVATE_REAL_ASSETS_ALTERNATIVE'}.netPercentage",
                        equalTo(netPercentage_PRAA1));
    }

    /**
     * Create the Fund Transfer between 2 Retail accounts.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"createRetailAccountDetails1", "createRetailAccountDetails2"})
    public void createFundTransfersRetail2Retail() {
        frs.removeHeader(CALLING_APP_ID);
        frs.removeHeader(APP_ID);
        frs.removeHeader(LOG_TRACKING_ID);
        frs.removeHeader(FSREQID);
        frs.removeHeader(oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", testData.getSsn()))
                .header(new Header("user-mid", testData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("excludeExternalDataSources", "true"));

        context.put("destAcct1", accountNumber2);
        context.put("destType1", DestinationAccountType.EXISTING_ACCOUNT.value());
        context.put("fundAcctNum1", accountNumber);
        context.put("transferType1", "FULL_BALANCE");
        context.put("totAmount1", totalAmount1);
        context.put("domEquityAmount1", domEquityAmount1);
        context.put("foreignEquityAmount1", foreignEquityAmount1);
        context.put("bondAmount1", bondAmount1);
        context.put("cashAmount1", cashAmount1);
        context.put("otherAmount1", otherAmount1);
        context.put("unknownAmount", unknownAmount);

        request.body(IOUtil.generateJsonRequest(context,
                HypotheticalFundTransferConstants.HYPOFUNDTRANSFER_CREATE_V1_TEMPLATE));
        response = request.baseUri(host).log().ifValidationFails().post(HypotheticalFundTransferPaths.HYPOFUNDTRNDFR_V1_PATH);

        validateResponse();
    }

    /**
     * Get details of Fund Transfer between Retail to Retail account after Create FT
     */
    @Test(dependsOnMethods = "createFundTransfersRetail2Retail")
    public void getFundTransfersRetail2Retail() {
        response = request.log().ifValidationFails().get(HypotheticalFundTransferPaths.HYPOFUNDTRNDFR_V1_PATH);
        validateResponse();

    }

    @Test(dependsOnMethods = "createFundTransfersRetail2Retail")
    public void getTransfersFromCompositeEEDSTrue() {
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeader("excludeExternalDataSources");

        context.put("sourceBasedRegistrationFilter", AccountConstants.RETAIL);
        context.put("includeFundTransferDetails", true);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails().given()
                .header(new Header("excludeExternalDataSources", "true"))
                .header(new Header("calculate-balances", "fund-transfers, equity-exposure"))
                .post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        float postTransferSrcMktValFundingAccount = srcMktValFundingAccount - totalAmount1;
        float postTransferSrcMktValDestAccount = srcMktValDestAccount + totalAmount1;

        //Funding Account Post Balance Alts
        //Expected Amount
        float postTransferTotalAlternativePEAAmount = (srcMktValFundingAccount + totalAmount1) * netPercentage_PEA;
        float postTransferTotalAlternativePCAAmount = (srcMktValFundingAccount + totalAmount1) * netPercentage_PCA;
        float postTransferTotalAlternativePRAAAmount = (srcMktValFundingAccount + totalAmount1) * netPercentage_PRAA;
        //Expected Percentage
        float postTransferALTsPEAPctExpected =
                (postTransferTotalAlternativePEAAmount / postTransferSrcMktValFundingAccount);
        float postTransferALTsPCAPctExpected =
                (postTransferTotalAlternativePCAAmount / postTransferSrcMktValFundingAccount);
        float postTransferALTsPRAAPctExpected =
                (postTransferTotalAlternativePRAAAmount / postTransferSrcMktValFundingAccount);
        //Actual Percentage and Amount and EquityPercentage
        float postTransferTotalAlternativePEAAmountActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_EQUITY_ALTERNATIVE'}.amount");
        float postTransferTotalAlternativePCAAmountActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_CREDIT_ALTERNATIVE'}.amount");
        float postTransferTotalAlternativePRAAAmountActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_REAL_ASSETS_ALTERNATIVE'}.amount");
        float postTransferALTsPEAPctActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_EQUITY_ALTERNATIVE'}.netPercentage");
        float postTransferALTsPCAPctActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_CREDIT_ALTERNATIVE'}.netPercentage");
        float postTransferALTsPRAAPctActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_REAL_ASSETS_ALTERNATIVE'}.netPercentage");
        float postTransferEquityPctActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber
                        + "'}.equityPercent");
        float detailsEquityPctActual =
                response.path("accounts.details.retailAccountDetail.accountDetail.find{it.accountId.accountNumber=='"
                        + accountNumber
                        + "'}.equityPercent");
        float postTransferALTsDomesticPctActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage");

        float postTransferALTsForeignPctActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage");

        //Destination Account Post Balance Alts
        //Expected Amount
        float postTransferALTsDestinationActPEAAmount = (srcMktValDestAccount - totalAmount1) * netPercentage_PEA1;
        float postTransferALTsDestinationActPCAAmount = (srcMktValDestAccount - totalAmount1) * netPercentage_PCA;
        float postTransferALTsDestinationActPRAAAmount = (srcMktValDestAccount - totalAmount1) * netPercentage_PRAA1;
        // Expected Percentage
        float postTransferALTsPEAPctDestActExpected =
                (postTransferALTsDestinationActPEAAmount / postTransferSrcMktValDestAccount);
        float postTransferALTsPCAPctDestActExpected =
                (postTransferALTsDestinationActPEAAmount / postTransferSrcMktValDestAccount);
        float postTransferALTsPRAAPctDestExpected =
                (postTransferALTsDestinationActPEAAmount / postTransferSrcMktValDestAccount);
        //Actual Amount, Percentage and Equity Percentage for Destination Account
        float postTransferALTsDestinationActPEAAmountActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2 + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_EQUITY_ALTERNATIVE'}.amount");
        float postTransferALTsDestinationActPCAAmountActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2 + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_CREDIT_ALTERNATIVE'}.amount");
        float postTransferALTsDestinationActPRAAAmountActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2 + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_REAL_ASSETS_ALTERNATIVE'}.amount");

        float postTransferALTsPEAPctDestActActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2 + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_EQUITY_ALTERNATIVE'}.netPercentage");
        float postTransferALTsPCAPctDestActActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2 + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_CREDIT_ALTERNATIVE'}.netPercentage");
        float postTransferALTsPRAAPctDestActActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2 + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_ALTERNATIVE'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='PRIVATE_REAL_ASSETS_ALTERNATIVE'}.netPercentage");
        float postTransferEquityPctDestActActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2
                        + "'}.equityPercent");
        float detailsEquityPctDestActActual =
                response.path("accounts.details.retailAccountDetail.accountDetail.find{it.accountId.accountNumber=='"
                        + accountNumber2
                        + "'}.equityPercent");
        float postTransferALTsDomesticPctDestAct =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2 + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage");

        float postTransferALTsForeignPctDestAct =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2 + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage");

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accounts", not(Matchers.empty()))
                .body("postTransferBalances", CoreMatchers.not(Matchers.empty()))
                .body("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber
                        + "'}.accountId.accountNumber", equalTo(accountNumber))
                .body("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2
                        + "'}.accountId.accountNumber", equalTo(accountNumber2))
                .body("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber
                                + "'}.sourceMarketValue",
                        equalTo(srcMktValFundingAccount))
                .body("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2
                                + "'}.sourceMarketValue",
                        equalTo(srcMktValDestAccount));

        //Validating PostTransfer TotalAlternativeNetPercentage for Funding Account
        assertThat(postTransferALTsPEAPctExpected).isCloseTo(postTransferALTsPEAPctActual, within(0.9f));
        assertThat(postTransferALTsPCAPctExpected).isCloseTo(postTransferALTsPCAPctActual, within(0.9f));
        assertThat(postTransferALTsPRAAPctExpected).isCloseTo(postTransferALTsPRAAPctActual, within(0.9f));

        assertThat(postTransferTotalAlternativePEAAmount)
                .isCloseTo(postTransferTotalAlternativePEAAmountActual, within(0.9f));
        assertThat(postTransferTotalAlternativePCAAmount)
                .isCloseTo(postTransferTotalAlternativePCAAmountActual, within(0.9f));
        assertThat(postTransferTotalAlternativePRAAAmount)
                .isCloseTo(postTransferTotalAlternativePRAAAmountActual, within(0.9f));

        //Validating PostTransfer TotalAlternativeNetPercentage for Destination Account
        assertThat(postTransferALTsPEAPctDestActExpected).isCloseTo(postTransferALTsPEAPctDestActActual, within(0.9f));
        assertThat(postTransferALTsPCAPctDestActExpected).isCloseTo(postTransferALTsPCAPctDestActActual, within(0.9f));
        assertThat(postTransferALTsPRAAPctDestExpected).isCloseTo(postTransferALTsPRAAPctDestActActual, within(0.9f));

        assertThat(postTransferALTsDestinationActPEAAmount)
                .isCloseTo(postTransferALTsDestinationActPEAAmountActual, within(0.9f));
        assertThat(postTransferALTsDestinationActPCAAmount)
                .isCloseTo(postTransferALTsDestinationActPCAAmountActual, within(0.9f));
        assertThat(postTransferALTsDestinationActPRAAAmount)
                .isCloseTo(postTransferALTsDestinationActPRAAAmountActual, within(0.9f));

        //Equity Percentage Validation Funding Account
        //Funding Account
        assertThat(AccountUtil
                .calculateEquityPct(netPercentage, 0, netPercentage_PEA, netPercentage_PCA, netPercentage_PRAA))
                .isCloseTo(detailsEquityPctActual, within(0.009f));
        assertThat(AccountUtil
                .calculateEquityPct(postTransferALTsDomesticPctActual, postTransferALTsForeignPctActual,
                        postTransferALTsPEAPctActual, postTransferALTsPCAPctActual,
                        postTransferALTsPRAAPctActual))
                .isCloseTo(postTransferEquityPctActual, within(0.009f));
        //Destination Account
        assertThat(AccountUtil
                .calculateEquityPct(netPercentage, 0, netPercentage_PEA1, netPercentage_PCA,
                        netPercentage_PRAA1))
                .isCloseTo(detailsEquityPctDestActActual, within(0.009f));
        assertThat(AccountUtil
                .calculateEquityPct(postTransferALTsDomesticPctDestAct, postTransferALTsForeignPctDestAct,
                        postTransferALTsPEAPctDestActActual, postTransferALTsPCAPctDestActActual,
                        postTransferALTsPRAAPctDestActActual))
                .isCloseTo(postTransferEquityPctDestActActual, within(0.009f));
        validateResponse();

    }

    private void validateResponse() {

        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("transfers",
                        not(Matchers.empty()), "transfers[0].fundingDetails[0].fundingAccountNumber",
                        notNullValue(), "transfers[0].fundingDetails[0].fundingAccountNumber",
                        equalTo(accountNumber), "transfers[0].destinationAccountNumber", notNullValue(),
                        "transfers[0].destinationAccountNumber", equalTo(accountNumber2))
                .body("transfers[0].fundingDetails[0].domesticEquityAmount", notNullValue(),
                        "transfers[0].fundingDetails[0].foreignEquityAmount", notNullValue())
                .body("transfers[0].fundingDetails[0].transferType", equalTo("FULL_BALANCE"),
                        "transfers[0].fundingDetails[0].totalAmount", notNullValue());

    }

    // Delete Account
    @Test(dependsOnMethods = "getTransfersFromCompositeEEDSTrue")
    public void deleteRetailAccount() {
        // Generate request body
        context.put("source", AccountConstants.RETAIL);
        context.put("mnemonic", mnemonic);
        context.put("asOfDate", testData.getAsOfDate1());
        context.put("accountNumber", accountNumber);
        context.put("id", accId1);
        request.body(IOUtil.generateJsonRequest(context,
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service response
        request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.HTTP_200);

    }

    // Delete second Account
    @Test(dependsOnMethods = "deleteRetailAccount")
    public void deleteRetailAccount2() {
        // Generate request body
        context.put("source", AccountConstants.RETAIL);
        context.put("mnemonic", mnemonic);
        context.put("asOfDate", testData.getAsOfDate1());
        context.put("accountNumber", accountNumber2);
        context.put("id", accId2);
        request.body(IOUtil.generateJsonRequest(context,
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service response
        request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.HTTP_200);

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
