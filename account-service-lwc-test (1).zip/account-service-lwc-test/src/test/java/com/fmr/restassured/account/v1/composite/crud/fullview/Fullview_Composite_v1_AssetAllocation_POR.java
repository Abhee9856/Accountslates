package com.fmr.restassured.account.v1.composite.crud.fullview;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.not;

/**
 * Contains tests that validate the Account Composite operation for Retail Accounts for
 * Asset Allocation in details v1- includes CRUD validations
 *  @author a608077
 */
@Test(groups = {Tags.FULLVIEW, Tags.COMPOSITE, Tags.V1})
public class Fullview_Composite_v1_AssetAllocation_POR extends PAPBaseServiceTest {

    protected Fullview_Composite_v1_AssetAllocation_POR()
    {
        super(Services.Account);
    }

    //Context
    private VelocityContext context;

    private AccountsCommonTestData accountsCommonTestData;
    private String accNum;
    private static String scenarioId;
    private String acctRoot;
    final String catchupPath = ".contributions.find{it.contributionType=='CATCHUP'}";

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Fullview_Composite_v1_AssetAllocation_POR.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
    private final float netPercentage_T_ALTERNATIVE = 0.8f;
    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
    private final float netPercentage_PEA = 0.4f;
    private final float netPercentage_Updated_PEA = 0.2f;
    private final float netPercentage_PCA = 0.2f;
    private final float netPercentage_Updated_PCA = 0.3f;
    private final float netPercentage_PRAA = 0.2f;
    private final float netPercentage_Updated_PRAA = 0.1f;

    private static final String SCENARIO_PRODUCT_CODE="WM";
    private static final String SCENARIO_CATEGORY_CODE="POR";

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init()
    {
        String oAuth = AccountUtil.getOauthToken();

        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Fullview",oAuth);
        //Data setup
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("contribFreq", "YEARLY");
        accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        accountsCommonTestData.set("contribAmount", "6000");
        accountsCommonTestData.set("updatedContribAmount", "500");
        accountsCommonTestData.set("withdrawAmount", "3000");
        accountsCommonTestData.set("updatedWithdrawAmount", "3500");
        accountsCommonTestData.set("withdrawFreq", "YEARLY");
        accountsCommonTestData.set("updatedWithdrawFreq", "ONE_TIME");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");

        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


        // Create Principal
        Identity.createPrincipal(accountsCommonTestData.getMid(), oAuth);
        //Create Scenario
        scenarioId = Scenario.createScenarioWithProductCode(this.accountsCommonTestData.getMid(),
                SCENARIO_PRODUCT_CODE,SCENARIO_CATEGORY_CODE,oAuth);

        //Insert Household Identity
        this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentityWithProductCode(accountsCommonTestData.getMid(),
                oAuth,SCENARIO_PRODUCT_CODE,SCENARIO_CATEGORY_CODE));

        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", AccountConstants.FULLVIEW);
        context.put("scenarioId", scenarioId);
    }

    /**
     * Get Fullview account info from the backend. Save the account number.
     */
    @Test
    public void getFullviewAccountInfo()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void getCompositeAccount()
    {
        // Exclude external data
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());

    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getCompositeAccount")
    public void createCompositeAccount()
    {
        // Generate request body
        accNum = accountsCommonTestData.getAccountNumber1();
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accNum);
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.177);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.0f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_PRAA);
        context.put("_type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS);
        context.put("contribFreq", "YEARLY");
        context.put("contribValue", "500");
        context.put("contributionTaxType", "POST_TAX");
        context.put("contributionType", "CATCHUP");
        context.put("contributor", "EMPLOYER");
        context.put("contribBasisTypeCd", "BASE");
//        context.put("contribFreq2", "BIMONTHLY");
//        context.put("contribValue2", "900");
//        context.put("contributionTaxType2", "AGGREGATE");
//        context.put("contributionType2", "REGULAR");
//        context.put("contributor2", "INDIVIDUAL");
//        context.put("contribBasisTypeCd2", "BASEBONUS");
//        context.put("riskTolerance", 2);
//        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
//        context.put("withdrawalStartYear", 2055);
//        context.put("withdrawalEndYear", 2085);
//        context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
//        context.put("equityPercent", 0.35);
//        context.put("originalOwnerBirthDate", "1958-11-09");
//        context.put("originalOwnerDeceasedDate", "2022-11-09");
//        context.put("withdrawalEligibilityStartDate", "2022-11-09");
//        context.put("withdrawalEligibilityEndDate", "2052-11-09");
//        context.put("originalOwnerSpouse", "false");
//        context.put("federalTaxWithholding", 0.15);
//        context.put("stateTaxWithholding", 0.05);
//        context.put("isBackdoorRoth", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PCA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PEA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PRAA))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(3000.0f))
                .body("accounts[0].withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("withdrawFreq")));

        //Save account number and ID
        accountsCommonTestData.setAccountId1(response.path(acctRoot + "account.accountId.id"));
        accountsCommonTestData.setAccountNumber1(response.path(acctRoot + "account.accountId.accountNumber"));
    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void getCompositeAccountAfterCreate()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PCA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PEA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PRAA))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body("accounts[0].withdrawals[0].amount.amount.value", equalTo(3000.0f))
                .body("accounts[0].withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("withdrawFreq")));

    }

    /**
     * Runs an update on the new account and verifies content in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterCreate")
    public void updateCompositeAccount()
    {
        // Populate variables for tests into context
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
        context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.4f);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 1.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.70f);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.30f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_Updated_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_Updated_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
        context.put("contribValue", "600");
        context.put("contribFreq", "YEARLY");

        // Generate request body
        context.put("source", AccountConstants.FULLVIEW);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PRAA))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(3500.0f))
                .body(acctRoot + "withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("updatedWithdrawFreq")));

    }

    /**
     * Gets the composite accounts and verifies that content is still coming back.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateCompositeAccount")
    public void getCompositeAccountAfterUpdate()
    {
        // Generate request body

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response

        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PRAA))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(3500.0f))
                .body(acctRoot + "withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("updatedWithdrawFreq")));
    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterUpdate")
    public void deleteCompositeAccount()
    {
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("scenarioId", scenarioId);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accountList", empty());
    }

    /**
     * Call delete and confirm that no accounts come back in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void getCompositeAccountAfterDelete()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());
    }
}
