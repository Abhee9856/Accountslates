/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Tests for v1 CRUD operations for Manual accounts without displayName.
 *
 * @author a783909
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.ACCOUNT,
        Tags.V1})
public class Manual_without_DisplayName extends PAPBaseServiceTest {

    protected Manual_without_DisplayName() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String source = "MANUAL";

    private final String asOfDate1 = "2014-10-31";

    private String mid;// = "ManualAccountV1TestMid";

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accId;

    private String regCode1 = "IRA";

    private String institutionName="AA";

    private String institutionNameUpdated="AA1";

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        String oAuthToken = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_manual", oAuthToken);
        setDefaultRequestHeaders(oAuthToken);

        testDataUtil = new TestDataUtil();

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuthToken, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuthToken));

        // Populate request variables
        context = new VelocityContext();

        context.put("mid", accountsCommonTestData.getMid());
        context.put("source", source);

    }

    /**
     * Create Manual account with different combination of InstitutionName from DataProvider.
     * <p>
     * Version V1
     */

    @Test()
    public void performCrudOperationsWithoutDisplayName() {
        this.createManualAccountsWithoutDisplayName();
        this.verifyDisplayNameAfterCreate();
        this.updateInstitutionNameManualAccount();
        this.getManualAccountAfterUpdate();
        this.deleteManualAccount();
        this.getManualAccountAfterDelete();

    }

    //Create Manual Account
    private void createManualAccountsWithoutDisplayName() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", regCode1);
        context.put("value", value);
        context.put("asOfDate", asOfDate1);
        context.put("institutionName", institutionName);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_NO_DISPLAYNAME));
        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);
        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", Matchers.equalTo(true))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
                .body("accountList[0].displayName", equalTo(institutionName));

        accId = response.path("accountList[0].accountId.id");
    }

    // Validate the created account.
    private void verifyDisplayNameAfterCreate()
    {
        this.context.put("source", this.source);
        this.context.put("mid", this.mid);
        this.context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(institutionName));
    }

    // Update account
    private void updateInstitutionNameManualAccount() {
        // Generate request body
        this.context.put("source", source);
        this.context.put("accId", accId);
        this.context.put("value", this.updatedValue);
        this.context.put("mnemonic", regCode1);
        this.context.put("institutionName", institutionNameUpdated);
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("excludeExternalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_NO_DISPLAYNAME));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(emptyArray()))
                .body("resultCode",  equalTo(true))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(institutionNameUpdated));

    }

    // Validate Updated account
    private void getManualAccountAfterUpdate() {
        // Exclude external data sources
        this.context.put("source", this.source);
        this.context.put("externalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(emptyArray()))
                .body("resultCode",  equalTo(true))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(institutionNameUpdated));
    }


    // Delete Account
    private void deleteManualAccount() {
        // Generate request body
        this.context.put("source", source);
        this.context.put("value", this.updatedValue);
        this.context.put("mnemonic", regCode1);
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("id", accId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service response
        request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

    }

    //Validate Account after delete
    private void getManualAccountAfterDelete() {
        // Exclude external data sources
        this.context.put("source", this.source);
        this.context.put("externalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterTest(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
