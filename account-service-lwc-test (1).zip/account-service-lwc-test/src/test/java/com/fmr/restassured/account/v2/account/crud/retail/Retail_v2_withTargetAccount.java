package com.fmr.restassured.account.v2.account.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.Matchers.*;

/**
 * Tests account CRUD operations for retail with target account for v2 version
 *
 * @author a608077
 * a609599 Updated for changes to productSubType
 * Updated by a608077 on 10/13/2021 to include changes for 'scenario-id' header(PFCP-6168)
 * Updated by a608077 on 08/26/2022 to include unknown funding amount changes(PFCP-9908)
 * Updated by a608077 on 10/17/2024 to update Validation for trustType and trustTypeInd(PFCP-17321)
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.ACCOUNT,
		Tags.V2,
		Tags.TARGET_ACCOUNT, "PFCP-3938", "PFCP-4608", "PFCP-7957"})

public class Retail_v2_withTargetAccount extends PAPBaseServiceTest
{

	private AccountsCommonTestData accountsCommonTestData;

	//Test data
	private final float fundingAccountAmount = 5.55f;

	private final float updatedValue = 426.85f;

	private TestDataUtil testDataUtil;

	private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";

	private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";

	private static final String TARGET_ACCOUNT_NAME = "NewTargetAccount";

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private static final String isProductSuitable = "true";

	private static final String isProductSuitableUpdate = "false";

	private static final String productSubType = "FIXED INCOME";

	private static final String updatedProductSubType = "EQUITY";

	private final float unknownAmount = 20.0f;

	/**
	 * Start and End years for targetAccountPreferences - both should be greater than the current year.
	 */
	int startYear = ZonedDateTime.now().plusYears(1).getYear();

	int updatedStartYear = ZonedDateTime.now().plusYears(5).getYear();

	int endYear = ZonedDateTime.now().plusYears(2).getYear();

	int updatedEndYear = ZonedDateTime.now().plusYears(6).getYear();

	private static final String LOG_TRACKING_ID = Retail_v2_withTargetAccount.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	//Velocity Context
	private final VelocityContext context = new VelocityContext();

	protected Retail_v2_withTargetAccount()
	{
		super(Services.Account);
	}

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
		accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);

		//Set default request headers
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
				FSREQID, oAuth);

		testDataUtil = new TestDataUtil();

		String mid = this.accountsCommonTestData.getMid();
		this.accountsCommonTestData.setMid(mid);

		DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");

		// Create Principal
		Identity.createPrincipal(accountsCommonTestData.getMid(), oAuth);
		String scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE,
				SCENARIO_CATEGORY_CODE, oAuth);
		this.accountsCommonTestData.setPpid(
				Identity.createHouseholdIdentity("mid", this.accountsCommonTestData.getMid(), oAuth));

		this.request.given()
				.header(new Header("user-poe", AccountConstants.RETAIL))
				.header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
				.header(new Header("user-mid", accountsCommonTestData.getMid()))
				.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
				.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
				//optional header scenario-id
				.header(new Header("scenario-id", scenarioId));

	}

	/**
	 * Get retail account info from the backend.
	 */
	@Test
	public void getRetailAccountInfo()
	{

		// Generate request body
		context.put("source", AccountConstants.RETAIL);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service v2
		response = request.post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(200)
				.body("accountList", not(emptyArray()))
				.body("accountList[0].accountId.accountNumber", notNullValue())
				.body("accountList[0].accountId", notNullValue());

		// use the values below to populate create request
		accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
		accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
		accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
		accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
		accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));

	}

	/**
	 * Create the account
	 */
	@Test(dependsOnMethods = "getRetailAccountInfo")
	public void createRetailAccount()
	{

		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("mnemonic", accountsCommonTestData.getMnemonic1());
		context.put("value", accountsCommonTestData.getValue1());
		context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(200)
				.body("accountList[0].sourceMarketValue.amount.value",
						equalTo(accountsCommonTestData.getValue1()))
                                .body("accountList[0].accountId.id", not(nullValue()))
                                .body("accountList[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
                                .body("accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
                                .body("accountList[0].regCode.mnemonic",
						equalTo(accountsCommonTestData.getMnemonic1()))
                                .body("accountList[0].sourceMarketValue", not(nullValue()));

		accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
	}

	/**
	 * Create target account
	 */
	@Test(dependsOnMethods = "createRetailAccount")
	public void createTargetAccount()
	{

		context.remove("displayName");
		context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
		context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
		context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
		context.put("category", "INVESTOR_SELECTED_STRATEGY");
		context.put("riskTolerance", "8");
		context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
		context.put("withdrawalStartYear", startYear);
		context.put("withdrawalEndYear", endYear);
		context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
		context.put("investmentObjectiveIA", "CONSERVATIVE");
		context.put("withdrawalNeeds", "CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5");
		context.put("anticipatedExpenses", "NOT_LIKELY");
		context.put("annualWithdrawalPercent", 0.2f);
		context.put("isProductSuitable", isProductSuitable);
		context.put("productSubType", productSubType);
		context.put("assetClass1", "BOND");
		context.put("netPercentage1", 0.9f);
		context.put("unknownAmount", String.valueOf(unknownAmount));
		context.put("irrevocableTrust", "false");
		context.put("trustType", null);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

		// Call Account service
		response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
				.body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].complementaryAdjustmentOption",
						equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
				.body("targetAccounts[0].isProductSuitable",
						equalTo(Boolean.valueOf(isProductSuitable)))
				.body("targetAccounts[0].irrevocableTrust", equalTo(false))
				.body("targetAccounts[0].trustType", equalTo(null))
				.body("targetAccounts[0].productSubType", equalTo(productSubType))
				.body("targetAccounts[0].targetAccountPreferences.riskTolerance", equalTo(8))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalStartYear",
						equalTo(startYear))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalEndYear", equalTo(endYear))
				.body("targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
						equalTo("CONSERVATIVE"))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
						equalTo("CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5"))
				.body("targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
						equalTo(0.2f))
				.body("targetAccounts[0].targetAccountPreferences.anticipatedExpenses",
						equalTo("NOT_LIKELY"))
				.body("targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage",
						equalTo(0.9f))
				.body("targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
						equalTo("SELL_BETWEEN_51_AND_75"));

		accountsCommonTestData.set(TARGET_ACCOUNT_NUMBER_KEY,
				response.path("targetAccounts[0].accountId.accountNumber"));
		accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
	}

	/**
	 * Verify retail account info is being returned
	 */
	@Test(dependsOnMethods = "createTargetAccount")
	public void verifyRetailAccountInfoAfterCreate()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		response = request.post(AccountsPaths.GET_ACCOUNT_V2);

		//Assert on response
		response.then().statusCode(200)
				.body("accountList[0].sourceMarketValue.amount.value",
						equalTo(accountsCommonTestData.getValue1()))
				.body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
				.body("accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("accountList[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
				.body("accountList[0].sourceMarketValue", not(nullValue()))
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage",
						equalTo(0.9f))
				.body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
				.body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption",
						equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
				.body("targetAccounts[0].isProductSuitable",
						equalTo(Boolean.valueOf(isProductSuitable)))
				.body("targetAccounts[0].productSubType", equalTo(productSubType))
				.body("targetAccounts[0].irrevocableTrust", equalTo(false))
				.body("targetAccounts[0].trustType", equalTo(null))
				.body("targetAccounts[0].targetAccountPreferences.riskTolerance", equalTo(8))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalStartYear",
						equalTo(startYear))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalEndYear", equalTo(endYear))
				.body("targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
						equalTo("SELL_BETWEEN_51_AND_75"))
				.body("targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
						equalTo("CONSERVATIVE"))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
						equalTo("CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5"))
				.body("targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
						equalTo(0.2f))
				.body("targetAccounts[0].targetAccountPreferences.anticipatedExpenses",
						equalTo("NOT_LIKELY"));

	}

	/**
	 * Updates for the target account.
	 */
	@Test(dependsOnMethods = "verifyRetailAccountInfoAfterCreate")
	public void updateTargetAccount()
	{

		context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
		context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
		context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
		context.put("category", "INVESTOR_SELECTED_STRATEGY");
		context.put("riskTolerance", "1");
		context.put("withdrawalStartYear", updatedStartYear);
		context.put("withdrawalEndYear", updatedEndYear);
		context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
		context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
		context.put("targetAccountId", accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
		context.put("targetAccountNumber", accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
		context.put("isProductSuitable", isProductSuitableUpdate);
		context.put("productSubType", updatedProductSubType);
		context.put("assetClass1", "BOND");
		context.put("netPercentage1", 0.5f);
		context.put("investmentObjectiveIA", "NONE");
		context.put("withdrawalNeeds", "TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6");
		context.put("anticipatedExpenses", "LIKELY");
		context.put("annualWithdrawalPercent", 0.02f);
		float updatedUnknownAmount = 26.0f;
		context.put("unknownAmount", String.valueOf(updatedUnknownAmount));

		// Generate new request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

		response = request.post(AccountsPaths.UPDATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(200)
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].accountId.owner.relationship", equalTo("PRINCIPAL"))
				.body("targetAccounts[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage",
						equalTo(0.5f))
				.body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
				.body("targetAccounts[0].regCode.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount",
						equalTo(updatedUnknownAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption",
						equalTo("MOVE_TO_MANAGED_ACCOUNT"))
				.body("targetAccounts[0].isProductSuitable",
						equalTo(Boolean.valueOf(isProductSuitableUpdate)))
				.body("targetAccounts[0].productSubType", equalTo(updatedProductSubType))
				.body("targetAccounts[0].irrevocableTrust", equalTo(false))
				.body("targetAccounts[0].trustType", equalTo(null))
				.body("targetAccounts[0].targetAccountPreferences.riskTolerance", equalTo(1))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalStartYear",
						equalTo(updatedStartYear))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalEndYear",
						equalTo(updatedEndYear))
				.body("targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
						equalTo("NONE"))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
						equalTo("TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6"))
				.body("targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
						equalTo(0.02f))
				.body("targetAccounts[0].targetAccountPreferences.anticipatedExpenses",
						equalTo("LIKELY"))
				.body("targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
						equalTo("SELL_BETWEEN_51_AND_75"));

	}

	/**
	 * Updates for the retail account.
	 */
	@Test(dependsOnMethods = "updateTargetAccount")
	public void updateRetailAccount()
	{

		context.put("value", updatedValue);
		context.put("id", accountsCommonTestData.getAccountId1());

		// Generate new request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

		response = request.post(AccountsPaths.UPDATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(200)
				.body("accountList[0].sourceMarketValue", not(nullValue()))
				.body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue))
				.body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
				.body("accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("accountList[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("accountList[0].regCode.mnemonic",
						equalTo(accountsCommonTestData.getMnemonic1()));

	}

	/**
	 * Verify retail account info is being returned
	 */
	@Test(dependsOnMethods = "updateRetailAccount")
	public void verifyRetailAccountInfoAfterUpdate()
	{

		this.request.given()
				.header(new Header("excludeExternalDataSources", "true"));
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		response = request.post(AccountsPaths.GET_ACCOUNT_V2);

		//Assert on response
		response.then().log().ifValidationFails()
				.statusCode(200)
				.body("accountList[0].sourceMarketValue", not(nullValue()))
				.body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue))
				.body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
				.body("accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("accountList[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage",
						equalTo(0.5f))
				.body("targetAccounts[0].irrevocableTrust", equalTo(false))
				.body("targetAccounts[0].trustType", equalTo(null))
				.body("accountList[0].regCode.mnemonic",
						equalTo(accountsCommonTestData.getMnemonic1()));

	}

	/**
	 * Delete target account
	 */
	@Test(dependsOnMethods = "verifyRetailAccountInfoAfterUpdate")
	public void deleteTargetAccount()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(200)
				.body("isEmpty()", Matchers.is(true));
	}

	/**
	 * Validate the updated retail account.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "deleteTargetAccount")
	public void getRetailAccountAfterTargetAccountDelete()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(200)
				.body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
				.body("accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
				.body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));

	}

	/**
	 * Delete the retail account.
	 */
	@Test(dependsOnMethods = "getRetailAccountAfterTargetAccountDelete")
	public void deleteRetailAccount()
	{
		// Generate new request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

		response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(200)
				.body("isEmpty()", Matchers.is(true));
	}

	/**
	 * Validate the retail account was deleted.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "deleteRetailAccount")
	public void getRetailAccountAfterDelete()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(200)
				.body("isEmpty()", Matchers.is(true));
	}

	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}
}
