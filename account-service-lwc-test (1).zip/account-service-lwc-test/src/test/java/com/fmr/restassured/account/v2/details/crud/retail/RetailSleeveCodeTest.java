/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.v2.details.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.Header;


/**
 * Test sleeve data for accounts v2 details
 *
 * @author a651454
 */
@Test(groups = {Tags.RETAIL, Tags.DETAILS, Tags.V2, "PFCP-3010"})
public class RetailSleeveCodeTest extends PAPBaseServiceTest
{
    protected RetailSleeveCodeTest() { super(Services.Account); }
    
    // Logger
    Logger logger = LogManager.getLogger(this.getClass());
    private static final String oAuthToken = AccountUtil.getOauthToken();
    
    // DSS constants
    private static final String DSS_POSITIONS_V2_QA1_HOST = "https://dpserviceuat.fmr.com";
    private static final String DSS_POSITIONS_V2_QA1_URI = "/ftgw/dp/position/v2";
    private static final String TEMPLATE_DSS_POSITION_V2 = "/template/dss/get_dss_positions_v2_acct_sub_type.vm";
    
    // Velocity context
    private VelocityContext context;
    
    // Test data
    private static final String RETAIL_LID = "000000251";
    private static final String ACCOUNT_NUMBER = "Y97742476";
    private static final String ACCOUNT_SOURCE = "RETAIL";
    
    
    /**
     * Initialization method to run before every test.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
        this.setDefaultRequestHeaders(oAuthToken);
        this.request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", RETAIL_LID))
                .header(new Header("fsreqid", Tags.REGRESSION + "_" + this.getClass().getSimpleName()))
                .header(new Header("AppId", "AP106532"))
                .header(new Header("excludeExternalDataSources", "false"));
        
        // Populate request variables
        this.context = new VelocityContext();
        this.context.put("accountNumber", ACCOUNT_NUMBER);
        this.context.put("source", ACCOUNT_SOURCE);
    }
    
    /**
     * Verifies sleeve data returned by Accounts V2 Details against DSS Positions V2.
     * The only check being made at this point is presence/absence of sleeve data in both calls and if present,
     * the number of sleeve data structures returned by each.
     */
    @Test
    public void verifySleeveData()
    {
        AccountSleeveData accountSleeveData = getAccountV2SleeveData();
        DssSleeveData dssSleeveData = getDssV2SleeveData();
        assertThat(accountSleeveData.count, equalTo(dssSleeveData.count));
        
    }
    
    /**
     * Makes a call to Account V2 Details and returns account sleeve data.
     *
     * @return the account sleeve data
     */
    private AccountSleeveData getAccountV2SleeveData()
    {
        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));
    
        // Call the Account Details service
        this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
        
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
        
        AccountSleeveData accountSleeveData = new AccountSleeveData();
        if (CollectionUtils.isNotEmpty(response.body().jsonPath().getList(
                "accountDetails[0].retailAccountDetail.accountDetail.sleeveDetails")))
        {
            List<Object> sleeveDetails = response.body().jsonPath().getList(
                    "accountDetails[0].retailAccountDetail.accountDetail.sleeveDetails");
            accountSleeveData.count = sleeveDetails.size();
         }
    
        return accountSleeveData;
    }
    
    /**
     * Makes a call to DSS Positions V2 and returns account sleeve data.
     *
     * @return the account sleeve data
     */
    private DssSleeveData getDssV2SleeveData()
    {
        this.request = RestAssured.given().baseUri(DSS_POSITIONS_V2_QA1_HOST);

        this.request.header(new Header("user-poe", AccountConstants.RETAIL))
                .header("Authorization", oAuthToken)
                .header("Content-Type", "application/json")
                .header("user-poe", AccountConstants.RETAIL)
                .header("fsreqid", Tags.REGRESSION + "_" + this.getClass().getSimpleName())
                .header("AppId", "AP136091")
                .header("AppName", "Advice and Planning Platform")
                .header("FACSC", "ROLE=FidCust")
                .header("rtazlid", RETAIL_LID)
                .header("rtazallrealmslids", "Retail=" + RETAIL_LID);
    
        this.context.put("returnAvailabilityStatus", "true");
        this.context.put("returnAccountGainLossDetail", "true");
        this.context.put("returnPositionMarketValDetail", "true");
    
        this.request.body(IOUtil.generateJsonRequest(this.context, TEMPLATE_DSS_POSITION_V2));
    
        // Call DSS Positions V2
        this.response = this.request.log().ifValidationFails().post(DSS_POSITIONS_V2_QA1_URI);
    
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
        
        DssSleeveData dssSleeveData = new DssSleeveData();
        if (this.response.body().jsonPath().get("position.acctDetails.acctDetail[0].sleeveDetails") != null &&
                CollectionUtils.isNotEmpty(this.response.body().jsonPath().getList(
                        "position.acctDetails.acctDetail[0].sleeveDetails.sleeveDetail")))
        {
            List<Object> sleeveDetails = this.response.body().jsonPath().getList(
                    "position.acctDetails.acctDetail[0].sleeveDetails.sleeveDetail");
            dssSleeveData.count = sleeveDetails.size();
        }
        
        return dssSleeveData;
    }
  
    
    /**
     * Represents sleeve data returned by Account Details V2 call
     */
    private static class AccountSleeveData
    {
        int count = 0;
        // Add more deserialized sleeve data
    }
    
    /**
     * Represents sleeve data returned by DSS Positions V2 call
     */
    private static class DssSleeveData
    {
        int count = 0;
        // Add more deserialized sleeve data
    }
    
}
