/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.notNullValue;


/**
 * Tests CRUD operations for Workplace accounts-PRDC accounts with variation of EEDS flag against V2.
 *
 * @author a608077
 */

@Test(groups = {Tags.PRDC_DATA, Tags.V2, Tags.ACCOUNT, Tags.WORKPLACE})
public class Workplace_V2_CRUD_PRDC extends PAPBaseServiceTest {
    protected Workplace_V2_CRUD_PRDC() {
        super(Services.Account);
    }

    private VelocityContext context;

    public String mid;

    public String ssn;
    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Workplace_V2_CRUD_PRDC.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;
    private AccountsCommonTestData accountsCommonTestData;
    final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;
    private FilterableRequestSpecification frs;


    @BeforeTest
    public void init() {

         accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Workplace 2", oAuth);

        this.ssn = accountsCommonTestData.getSsn();

        mid = accountsCommonTestData.getMid();

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        accountsCommonTestData.setPpid(Identity.
                createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        frs = (FilterableRequestSpecification) request;

        testDataUtil = new TestDataUtil();
        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("return-prdc-accounts", "true"));

        context = new VelocityContext();
        context.put("source", AccountConstants.WORKPLACE);

    }

    /**
     * Get account info from the backend. Save the account number.
     * Since the EEDS flag is false by default,this method will bring back data from the backend.
     */
    @Test
    public void getWorkplaceAccountInfo() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", Matchers.not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId", notNullValue());

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Create the account in CFP
     * Version V2
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount() {

        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", Matchers.not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", Matchers.equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountList[0].accountId.sourceSystem", Matchers.equalTo(AccountConstants.WORKPLACE))
                .body("accountList[0].accountId.id", notNullValue());


        // Gets and saves the CFP account ID
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
    }


    /**
     * Validate the account is created in CFP
     * Version V2
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void getWorkplaceAccountAfterCreateEEDSFalse() {

        //Setting Exclude external data sources flag
        this.request.given()
                .header(new Header("excludeExternalDataSources", "false"));

        context.put("source", AccountConstants.WORKPLACE);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList[0].regCode.mnemonic", Matchers.equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", Matchers.equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", Matchers.equalTo(accountsCommonTestData.getAccountId1()),
                        "accountList[0].sourceMarketValue.amount.value", Matchers.equalTo(accountsCommonTestData.getValue1()));
    }

    /**
     * Update the account.
     * Version V2
     */
    @Test(dependsOnMethods = "getWorkplaceAccountAfterCreateEEDSFalse")
    public void updateWorkplaceAccount() {

        //Change the amount of the account
        context.put("id", accountsCommonTestData.getAccountId1());
        float updatedValue = 426.85f;
        context.put("value", updatedValue);
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

        response = request.post(AccountsPaths.UPDATE_ACCOUNT_V2);

        // Assert on response
        response.then().statusCode(200)
                .body("accountList", Matchers.not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", Matchers.equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("accountList[0].accountId.id", Matchers.equalTo(accountsCommonTestData.getAccountId1()))
                .body("accountList[0].accountId.owner.id", Matchers.equalTo(accountsCommonTestData.getPpid()))
                .body("accountList[0].accountId.sourceSystem", Matchers.equalTo(accountsCommonTestData.getSourceSystem1()))
                .body("accountList[0].sourceMarketValue.amount.value", Matchers.equalTo(updatedValue));

    }

    /**
     * Validate the updated account.
     * Version V2
     */
    @Test(dependsOnMethods = "updateWorkplaceAccount")
    public void getWorkplaceAccountAfterUpdateEEDSFalse() {

        context.put("source", AccountConstants.WORKPLACE);
        this.frs.removeHeader("excludeExternalDataSources");

        this.request.given()
                .header(new Header("excludeExternalDataSources", "false"));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList[0].regCode.mnemonic", Matchers.equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", Matchers.equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", Matchers.equalTo(accountsCommonTestData.getAccountId1()),
                        //value present in the backend will take precedence than the one in CFP
                        "accountList[0].sourceMarketValue.amount.value", Matchers.equalTo(accountsCommonTestData.getValue1()));
    }

    /**
     * Delete the account.
     * Version V2
     */
    @Test(dependsOnMethods = "getWorkplaceAccountAfterUpdateEEDSFalse")
    public void deleteWorkplaceAccount() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("isEmpty()", Matchers.is(true));
    }

    /**
     * Validate the account was deleted.
     * Version V2
     */
    @Test(dependsOnMethods = "deleteWorkplaceAccount")
    public void getWorkplaceAccountAfterDeleteEEDSTrue() {

        this.frs.removeHeader("excludeExternalDataSources");
        this.request.given().header(new Header("excludeExternalDataSources", "true"));

        context.put("source", AccountConstants.WORKPLACE);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(200)
                .body("isEmpty()", Matchers.is(true));

    }

    /**
     * Validate the account wasn't deleted from backend as EEDS=false
     * Version V2
     */
    @Test(dependsOnMethods = "deleteWorkplaceAccount")
    public void getWorkplaceAccountAfterDeleteEEDSFalse() {

        this.frs.removeHeader("excludeExternalDataSources");
        this.request.given().header(new Header("excludeExternalDataSources", "false"));

        context.put("source", AccountConstants.WORKPLACE);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList[0].regCode.mnemonic", Matchers.equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", Matchers.equalTo(accountsCommonTestData.getAccountNumber1()),
                        //value present in the backend will take precedence than the one in CFP
                        "accountList[0].sourceMarketValue.amount.value", Matchers.equalTo(accountsCommonTestData.getValue1()));
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown() {
        this.testDataUtil.closeSQLiteConnection();
    }
}
