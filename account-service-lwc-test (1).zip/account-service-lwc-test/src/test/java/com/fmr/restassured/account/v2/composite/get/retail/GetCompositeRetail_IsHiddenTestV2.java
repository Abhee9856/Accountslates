/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.get.retail;

import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.is;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import java.util.ArrayList;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;

/**
 * this test first makes call to DSS account V2 api
 *      and find the accountNumber which has isHidden true in preferenceDetails
 * then it makes call to Planning Account API Composite V2 with return-hidden-account header as true
 *      and asserts that the accountNumber is returned and hidden property is true
 *  then it makes call again to Planning Account API V2 with return-hidden-account header as false
 *      and asserts that the accountNumber is not returned which is hidden as per DSS Acct V2 API isHidden property
 */

@Test(groups = {Tags.REGRESSION, Tags.RETAIL, Tags.V2})
public class GetCompositeRetail_IsHiddenTestV2 extends PAPBaseServiceTest
{

	protected GetCompositeRetail_IsHiddenTestV2()
	{
		super(Services.Account);
	}

	private static final Logger LOGGER = LogManager.getLogger(GetCompositeRetail_IsHiddenTestV2.class);

	private static final String sourceSystem = "RETAIL";

	private String ssn;

	private String mid;

	private String sid;


	private static final String CALLING_APP_ID = "AP106532";

	private static final String APP_ID = "AP106532";

	private static final String LOG_TRACKING_ID = GetCompositeRetail_IsHiddenTestV2.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private static final String APP_NAME = "Advice and Planning Platform";

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private Response accountResponse;

	private final String oAuth = AccountUtil.getOauthToken();

	String hiddenRetailAccountFromDss;

	private FilterableRequestSpecification frs;

	private int numberOfAccountReturnedByDSS;

	private int numberOfHiddenAccountsReturnedByDSS;

	private VelocityContext context;

	@BeforeClass
	public void init()
	{
		// Data setup
		AccountsCommonTestData accountsCommonTestData = TestDataUtil
				.populateRegressionTestData("retail_is_hidden_account", oAuth);

		mid = accountsCommonTestData.getMid();
		sid = accountsCommonTestData.getSid();//.replace("-", "");
		DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


		ssn = accountsCommonTestData.getSsn();

		context = new VelocityContext();
		// Common headers setup
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	}

	@Test
	public void getDSS_V2()
	{
		//Set DSS Headers
		frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeadersForDSS();

		// Generate request body
		context.put("acctCategory", "Brokerage");

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

		request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
		response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)));

		hiddenRetailAccountFromDss = response.path("acctDetails.find{it.preferenceDetail.isHidden == true && it.gainLossBalanceDetail.totalMarketVal == 0.0}.acctNum");
		ArrayList<String> list = response.path("acctDetails.findAll{it.preferenceDetail.isHidden == true && it.gainLossBalanceDetail.totalMarketVal == 0.0}.acctNum");
		numberOfHiddenAccountsReturnedByDSS = list.size();
		numberOfAccountReturnedByDSS = response.path("totalNumOfAcct");
		LOGGER.info("Account which has isHidden as true from DSS is {}", hiddenRetailAccountFromDss);
	}

	@Test(dependsOnMethods = {"getDSS_V2"})
	public void getRetailAccountInfo_v2_WithReturnHiddenAccountsTrue()
	{
		// Set request headers
		frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
		setRequestHeadersForAccount();
		// Generate request body
		context.put("source", sourceSystem);
		context.put("mid", mid);
		context.put("excludeExternalDataSources", "false");
		context.put("retailLid", ssn);
		context.put("pointOfEntry", "RETAIL");
		context.put("role", "FidCust");
		context.put("productCode", SCENARIO_PRODUCT_CODE);
		context.put("categoryCode", SCENARIO_CATEGORY_CODE);
		request.header("return-hidden-accounts", true);
		context.put("sourceBasedRegistrationFilter", "RETAIL");
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		// Call Account service v2
		accountResponse = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		accountResponse.then().log().ifValidationFails().statusCode(200);
		if(null != hiddenRetailAccountFromDss)
		{
			ArrayList<String> accountList = accountResponse.path("accounts.account.accountId.accountNumber");
			int numberOfAccountOfWhenReturnHiddenAccountIsTrue = accountList.size();
			Assert.assertEquals(numberOfAccountReturnedByDSS, numberOfAccountOfWhenReturnHiddenAccountIsTrue);

			Assert.assertNotNull(accountResponse.path(
					"accounts.find{it.account.accountId.accountNumber == '" + hiddenRetailAccountFromDss + "'}"));


			Assert.assertTrue(accountResponse.path(
					"accounts.find{it.account.accountId.accountNumber == '" + hiddenRetailAccountFromDss + "'}.account.isHidden"));

		}
	}

	@Test(dependsOnMethods = {"getRetailAccountInfo_v2_WithReturnHiddenAccountsTrue"})
	public void getRetailAccountInfo_v2_WithReturnHiddenAccountsFalse()
	{
		// Set request headers
		frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
		setRequestHeadersForAccount();
		// Generate request body
		context.put("source", sourceSystem);
		context.put("mid", mid);
		context.put("excludeExternalDataSources", "false");
		context.put("retailLid", ssn);
		context.put("pointOfEntry", "RETAIL");
		context.put("role", "FidCust");
		context.put("productCode", SCENARIO_PRODUCT_CODE);
		context.put("categoryCode", SCENARIO_CATEGORY_CODE);
		request.header("return-hidden-accounts", false);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		// Call Account service v2
		accountResponse = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		accountResponse.then().log().ifValidationFails().statusCode(200);

		Assert.assertNull(accountResponse.path("accounts.find{it.account.accountId.accountNumber == '"+hiddenRetailAccountFromDss+"'}"));
		ArrayList<String> accountList = accountResponse.path("accounts.account.accountId.accountNumber");
		int numberOfAccountOfWhenReturnHiddenAccountIsFalse = accountList.size();

		Assert.assertEquals(numberOfAccountReturnedByDSS, numberOfAccountOfWhenReturnHiddenAccountIsFalse +numberOfHiddenAccountsReturnedByDSS);


	}

	private void setDefaultRequestHeadersForDSS()
	{
		this.request.given().header(new Header("AppId", "AP106532"))
				.header(new Header("fsreqid", FSREQID))
				.header(new Header("Authorization", oAuth))
				.header(new Header("AppName", APP_NAME))
				.header(new Header("rtazlid", this.ssn))
				.header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
				.header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
				.header(new Header("FACMC", "MID=" + this.mid))
				.header(new Header("FACFC", "SESSION_KEY=1"))
				.header(new Header("Content-Type", "application/json"));
	}

	private void setRequestHeadersForAccount()
	{
		// Account headers setup
		this.request.given()
				.header(new Header("user-poe", AccountConstants.RETAIL))
				.header(new Header("user-mid", mid))
				.header(new Header("user-retail-lid", ssn))

				.header(new Header("realTimeData", "false"))

				.header(new Header("Content-Type", "application/json"));

	}
}
