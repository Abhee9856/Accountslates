/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.dss.realtimedata;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;

/**
 * Tests Account Positions operation with real time data from DSS Positions API
 *
 * @author a730306 Updated by a730306 on 11/08/2022 to include unsettledCash,
 * unsettledMargin and unsettledShort for real time check(PFCP-10801)
 */

@Test(groups = {Tags.REAL_TIME_DATA, Tags.V1})
public class AccountPositionsV1 extends PAPBaseServiceTest
{

    protected AccountPositionsV1()
    {
	super(Services.Account);
    }

    private String accountNumber;

    private VelocityContext context;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = AccountPositionsV1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String APP_NAME = "Advice and Planning Platform";

    public static final String ACCOUNT_CATEGORY = "Brokerage";

    private float value;

    private String ssn;

    private Float unsettledCash;

    private Float unsettledMargin;

    private Float unsettledShort;

    private final String oAuth = AccountUtil.getOauthToken();

    private TestDataUtil testDataUtil;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
	// Data setup
	AccountsCommonTestData accountsCommonTestData = TestDataUtil
			.populateRegressionTestData("account_realizedgainloss_get_positive", oAuth);

	final String oAuth = AccountUtil.getOauthToken();

	String mid = accountsCommonTestData.getMid();
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


	this.ssn = accountsCommonTestData.getSsn();

	testDataUtil = new TestDataUtil();

	// Populate request context with user IDs
	context = new VelocityContext();
	context.put("source", AccountConstants.RETAIL);

    }

    @Test
    public void getAccountsPositionsV1()
    {
	this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

	this.request.header(new Header("realTimeData", "true"));

	context.put("allPlans", "true");
	context.put("excludeExternalDataSources", "false");
	context.put("retailLid", this.ssn);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_POSITION_GET_TEMPLATE_V1));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V1);

	// Assert on response
	response.then().statusCode(200);
	Boolean resultCode = response.path("resultCode");
	Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	response.then().log().ifValidationFails().body("accountList", not(emptyArray()))
			.body("accountList[0].account.accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
			.body("accountList[0].account.accountId.accountNumber", notNullValue())
			.body("accountList[0].account.accountId", notNullValue());

	this.accountNumber = this.response.path("accountList[0].account.accountId.accountNumber");
	this.unsettledCash = this.response.path("accountList[0].account.unsettledCashValue.value");
	this.unsettledMargin = this.response.path("accountList[0].account.unsettledMargin.value");
	this.unsettledShort = this.response.path("accountList[0].account.unsettledShort.value");
    }

    @Test
    public void getDSS_AccountPositions_V2()
    {

	FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
	frs.removeHeaders();

	this.setDefaultRequestHeadersForDSS();

	context.put("acctCategory", ACCOUNT_CATEGORY);
	context.put("returnAvailabilityStatus", "true");
	context.put("returnAccountGainLossDetail", "true");
	context.put("returnPositionMarketValDetail", "true");
	context.put("accountNumber", this.accountNumber);

	this.request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_POSITION_V2));

	response = this.request.post(AccountConstants.DSS_ACCOUNT_POSITIONS_V2_PATH);

	// Assert on response
	response.then().statusCode(anyOf(is(200), is(206)))
			.body("position.acctDetails.acctDetail", not(emptyArray()))
			.body("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber + "'}.acctNum",
					notNullValue());

	if (null != this.response.path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
			+ "'}.activityDetail.unsettledCash"))
	{
	    Assert.assertEquals(this.response.path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
			    + "'}.activityDetail.unsettledCash"), unsettledCash);
	}

	if (null != this.response.path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
			+ "'}.activityDetail.unsettledMargin"))
	{
	    Assert.assertEquals(this.response.path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
			    + "'}.activityDetail.unsettledMargin"), unsettledMargin);
	}

	if (null != this.response.path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
			+ "'}.activityDetail.unsettledShort"))
	{
	    Assert.assertEquals(this.response.path("position.acctDetails.acctDetail.find{it.acctNum=='" + accountNumber
			    + "'}.activityDetail.unsettledShort"), unsettledShort);
	}

    }

    private void setDefaultRequestHeadersForDSS()
    {
	this.request.given().header(new Header("AppId", "AP106532"))
			.header(new Header("fsreqid", FSREQID))
			.header(new Header("Authorization", oAuth))
			.header(new Header("AppName", APP_NAME))
			.header(new Header("rtazlid", this.ssn))
			.header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
			.header(new Header("FACSC", "ROLE=FidCust"))
			.header(new Header("Content-Type", "application/json"));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	this.testDataUtil.closeSQLiteConnection();
    }
}
