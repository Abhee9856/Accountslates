/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.empty;

/**
 * Tests for transferType for v1 CRUD operations for Retail Target accounts using DataProvider
 *
 * @author a631781
 */
@Test(groups = {
		Tags.TARGET_ACCOUNT,
		Tags.RETAIL,
		Tags.V1, Tags.TAM})
public class Retail_TargetAccount_TransferType extends PAPBaseServiceTest
{

    protected Retail_TargetAccount_TransferType()
    {
	super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private final String source = "RETAIL";

    private float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final float fundingAccountAmount = 5.55f;

    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";

    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";
    
    private static final String TARGET_ACCOUNT_NAME = "NewTargetAccount";

    private static final String isProductSuitable = "true";

    private static final String isProductSuitableUpdate = "false";

    private static final String productSubType = "FIXED INCOME";

    private static final String updatedProductSubType = "EQUITY";

    private final float unknownAmount = 20.0f;

    private final float updatedUnknownAmount = 26.0f;

    private String mid;

    private String ssn;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accId;

    private String accNumber;

    /**
     * Start and End years for targetAccountPreferences - both should be greater than the current year.
     */
    int startYear = ZonedDateTime.now().plusYears(1).getYear();

    int updatedStartYear = ZonedDateTime.now().plusYears(5).getYear();

    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    int updatedEndYear = ZonedDateTime.now().plusYears(6).getYear();

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_withTargetAccount.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();
	accountsCommonTestData = TestDataUtil.populateRegressionTestData("retail_critical_regcode", oAuth);
	mid = accountsCommonTestData.getMid();
	ssn = accountsCommonTestData.getSsn();
	testDataUtil = new TestDataUtil();

	accountsCommonTestData.setValue1(value);
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



	accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", mid, oAuth));

	setDefaultRequestHeaders(oAuth);

	// Populate request variables
	context = new VelocityContext();
	context.put("mid", mid);
	context.put("retailLid", ssn);

    }

    /**
     * Create Retail Target account with different combination of transferType from DataProvider.
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getRetailAccountData",
		    dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data)
    {
	this.getRetailAccount(data);
	this.createRetailAccount(data);
	this.createTargetAccount(data);
	this.getRetailAccountAfterCreate(data);
	this.updateTargetAccount(data);
	this.updateRetailAccount(data);
	this.getRetailAccountAfterUpdate(data);
	this.deleteTargetAccount(data);
	this.getRetailAccountAfterTargetAccountDelete(data);
	this.deleteRetailAccount(data);
	this.getRetailAccountAfterDelete(data);
    }

    //Get account info from the backend.
    private void getRetailAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	this.context.put("source", this.source);
	this.context.put("externalDataSources", false);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("accountList", not(emptyArray()));

	//Get Account number based on the regCode
	if (null != response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1()
			+ "'}.accountId.accountNumber"))
	{
	    accNumber = response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1()
			    + "'}.accountId.accountNumber");
	}
	else
	{
	    accNumber = response.path("accountList[0].accountId.accountNumber");

	}

    }

    //Create Retail Account
    private void createRetailAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	this.context.put("ppid", this.accountsCommonTestData.getPpid());
	this.context.put("value", String.valueOf(this.value));
	this.context.put("mnemonic", data.getRegCode1());
	this.context.put("source", source);
	this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
	this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
	this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
	this.context.put("accountNumber", accNumber);
	this.context.put("id", null);
	this.context.put("excludeExternalDataSources", true);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

	//Asset on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

	accId = response.path("accountList[0].accountId.id");

    }

    /**
     * Create target account
     */
    private void createTargetAccount(final AccountRegCodeTestData data)
    {
	    
	// Generate request body
	context.remove("displayName");
	context.put("targetAccountSourceSystem", source);
	context.put("targetAccountPpid", accountsCommonTestData.getPpid());
	context.put("fundingAccountNumber", accNumber);
	context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
	context.put("fundingAccountValue", String.valueOf(fundingAccountAmount));
	context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
	context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
	context.put("category", "INVESTOR_SELECTED_STRATEGY");
	context.put("riskTolerance", "8");
	context.put("withdrawalStartYear", startYear);
	context.put("withdrawalEndYear", endYear);
	context.put("investmentObjectiveIA", "CONSERVATIVE");
	context.put("withdrawalNeeds", "CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5");
	context.put("anticipatedExpenses", "NOT_LIKELY");
	context.put("annualWithdrawalPercent", 0.2f);
	context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
	context.put("assetAllocation", 0.4);
	context.put("isProductSuitable", isProductSuitable);
	context.put("productSubType", productSubType);
	context.put("unknownAmount", String.valueOf(unknownAmount));
	context.put("transferType", data.getTransferType());

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("userIdentifier.mid", Matchers.equalTo(accountsCommonTestData.getMid()),
					"userIdentifier.retailLid", Matchers.equalTo(accountsCommonTestData.getSsn()),
					"targetAccounts", not(empty()),
					"targetAccounts[0].accountId.sourceSystem", Matchers.equalTo(source),
					"targetAccounts[0].accountId.owner.relationship", Matchers.equalTo("PRINCIPAL"),
					"targetAccounts[0].accountId.owner.id",
					Matchers.equalTo(accountsCommonTestData.getPpid()),
					"targetAccounts[0].displayName", Matchers.equalTo(TARGET_ACCOUNT_NAME),
					"targetAccounts[0].sourceMarketValue.amount.value",
					Matchers.equalTo(fundingAccountAmount),
					"targetAccounts[0].regCode.sourceSystem", Matchers.equalTo(source),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					Matchers.equalTo(accNumber),
					"targetAccounts[0].fundingAccounts[0].amount.value",
					Matchers.equalTo(fundingAccountAmount),
					"targetAccounts[0].fundingAccounts[0].unknownAmount",
					Matchers.equalTo(unknownAmount),
					"targetAccounts[0].complementaryAdjustmentOption",
					Matchers.equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"),
					"targetAccounts[0].isProductSuitable",
					Matchers.equalTo(Boolean.valueOf(isProductSuitable)),
					"targetAccounts[0].productSubType", Matchers.equalTo(productSubType),
					"targetAccounts[0].targetAccountPreferences.riskTolerance", Matchers.equalTo(8),
					"targetAccounts[0].targetAccountPreferences.withdrawalStartYear",
					Matchers.equalTo(startYear),
					"targetAccounts[0].targetAccountPreferences.withdrawalEndYear",
					Matchers.equalTo(endYear),
					"targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
					Matchers.equalTo("SELL_BETWEEN_51_AND_75"),
					"targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
					Matchers.equalTo("CONSERVATIVE"),
					"targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
					Matchers.equalTo("CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5"),
					"targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
					Matchers.equalTo(0.2f),
					"targetAccounts[0].targetAccountPreferences.anticipatedExpenses",
					Matchers.equalTo("NOT_LIKELY"),
					"targetAccounts[0].equityPercent", Matchers.equalTo(0.5f),
					"targetAccounts[0].assetAllocation.allocation", hasSize(4),
					"targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					Matchers
							.equalTo(0.4f),
					"targetAccounts[0].annualContribution.value", Matchers.equalTo(999.55f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.5f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
							+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.35f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
							+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.15f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					Matchers
							.equalTo(0.4f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
					Matchers
							.equalTo(0.1f),
					"targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
					Matchers.equalTo(0.45f),
					"targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
					Matchers.equalTo(0.54f),
					"targetAccounts[0].targetAssetMixes[0].category",
					Matchers.equalTo("INVESTOR_SELECTED_STRATEGY"),
					"targetAccounts[0].targetAssetMixes[0].repositoryTamId", Matchers.equalTo(3),
					"targetAccounts[0].targetAssetMixes[0].assetAllocationId", Matchers.equalTo(50),
					"targetAccounts[0].targetAssetMixes[0].context", Matchers.equalTo("Standard"),
					"targetAccounts[0].fundingAccounts[0].transferType",
					Matchers.equalTo(data.getTransferType()));

	accountsCommonTestData
			.set(TARGET_ACCOUNT_NUMBER_KEY, response.path("targetAccounts[0].accountId.accountNumber"));
	accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
    }

    /**
     * Validate the retail account.
     * <p>
     * Version V1
     */
    private void getRetailAccountAfterCreate(final AccountRegCodeTestData data)
    {

	// Exclude external data sources
	context.put("externalDataSources", "true");

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("userIdentifier.mid", Matchers.equalTo(accountsCommonTestData.getMid()),
					"userIdentifier.retailLid", Matchers.equalTo(accountsCommonTestData.getSsn()),
					"targetAccounts", not(empty()),
					"targetAccounts[0].accountId.sourceSystem", Matchers.equalTo(source),
					"targetAccounts[0].accountId.owner.relationship", Matchers.equalTo("PRINCIPAL"),
					"targetAccounts[0].accountId.owner.id",
					Matchers.equalTo(accountsCommonTestData.getPpid()),
					"targetAccounts[0].displayName", Matchers.equalTo(TARGET_ACCOUNT_NAME),
					"targetAccounts[0].sourceMarketValue.amount.value",
					Matchers.equalTo(fundingAccountAmount),
					"targetAccounts[0].regCode.sourceSystem", Matchers.equalTo(source),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					Matchers.equalTo(accNumber),
					"targetAccounts[0].fundingAccounts[0].amount.value",
					Matchers.equalTo(fundingAccountAmount),
					"targetAccounts[0].fundingAccounts[0].unknownAmount",
					Matchers.equalTo(unknownAmount),
					"targetAccounts[0].complementaryAdjustmentOption",
					Matchers.equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"),
					"targetAccounts[0].isProductSuitable",
					Matchers.equalTo(Boolean.valueOf(isProductSuitable)),
					"targetAccounts[0].productSubType", Matchers.equalTo(productSubType),
					"targetAccounts[0].targetAccountPreferences.riskTolerance", Matchers.equalTo(8),
					"targetAccounts[0].targetAccountPreferences.withdrawalStartYear",
					Matchers.equalTo(startYear),
					"targetAccounts[0].targetAccountPreferences.withdrawalEndYear",
					Matchers.equalTo(endYear),
					"targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
					Matchers.equalTo("SELL_BETWEEN_51_AND_75"),
					"targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
					Matchers.equalTo("CONSERVATIVE"),
					"targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
					Matchers.equalTo("CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5"),
					"targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
					Matchers.equalTo(0.2f),
					"targetAccounts[0].targetAccountPreferences.anticipatedExpenses",
					Matchers.equalTo("NOT_LIKELY"),
					"targetAccounts[0].equityPercent", Matchers.equalTo(0.5f),
					"targetAccounts[0].assetAllocation.allocation", hasSize(4),
					"targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					Matchers
							.equalTo(0.4f),
					"targetAccounts[0].annualContribution.value", Matchers.equalTo(999.55f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.5f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
							+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.35f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
							+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.15f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					Matchers
							.equalTo(0.4f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
					Matchers
							.equalTo(0.1f),
					"targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
					Matchers.equalTo(0.45f),
					"targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
					Matchers.equalTo(0.54f),
					"targetAccounts[0].targetAssetMixes[0].category",
					Matchers.equalTo("INVESTOR_SELECTED_STRATEGY"),
					"targetAccounts[0].targetAssetMixes[0].repositoryTamId", Matchers.equalTo(3),
					"targetAccounts[0].targetAssetMixes[0].assetAllocationId", Matchers.equalTo(50),
					"targetAccounts[0].targetAssetMixes[0].context", Matchers.equalTo("Standard"),
					"targetAccounts[0].fundingAccounts[0].transferType",
					Matchers.equalTo(data.getTransferType()));

    }

    /**
     * Update target account
     */
    private void updateTargetAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put(TARGET_ACCOUNT_NUMBER_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
	context.put(TARGET_ACCOUNT_ID_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
	context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
	context.put("category", "FINAL");
	context.put("riskTolerance", "5");
	context.put("withdrawalStartYear", updatedStartYear);
	context.put("withdrawalEndYear", updatedEndYear);
	context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
	context.put("assetAllocation", 0.5);
	context.put("isProductSuitable", isProductSuitableUpdate);
	context.put("investmentObjectiveIA", "NONE");
	context.put("withdrawalNeeds", "TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6");
	context.put("anticipatedExpenses", "LIKELY");
	context.put("annualWithdrawalPercent", "0.002");
	context.put("productSubType", updatedProductSubType);
	context.put("unknownAmount", String.valueOf(updatedUnknownAmount));
	context.put("transferType", data.getTransferType());

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("targetAccounts", not(empty()),
					"targetAccounts[0].accountId.sourceSystem", Matchers.equalTo(source),
					"targetAccounts[0].accountId.owner.relationship", Matchers.equalTo("PRINCIPAL"),
					"targetAccounts[0].accountId.owner.id",
					Matchers.equalTo(accountsCommonTestData.getPpid()),
					"targetAccounts[0].displayName", Matchers.equalTo(TARGET_ACCOUNT_NAME),
					"targetAccounts[0].sourceMarketValue.amount.value",
					Matchers.equalTo(fundingAccountAmount),
					"targetAccounts[0].regCode.sourceSystem", Matchers.equalTo(source),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					Matchers.equalTo(accNumber),
					"targetAccounts[0].fundingAccounts[0].amount.value",
					Matchers.equalTo(fundingAccountAmount),
					"targetAccounts[0].fundingAccounts[0].unknownAmount",
					Matchers.equalTo(updatedUnknownAmount),
					"targetAccounts[0].fundingAccounts[0].transferType",
					Matchers.equalTo(data.getTransferType()),
					"targetAccounts[0].complementaryAdjustmentOption",
					Matchers.equalTo("MOVE_TO_MANAGED_ACCOUNT"),
					"targetAccounts[0].isProductSuitable",
					Matchers.equalTo(Boolean.valueOf(isProductSuitableUpdate)),
					"targetAccounts[0].productSubType", Matchers.equalTo(updatedProductSubType),
					"targetAccounts[0].targetAccountPreferences.riskTolerance", Matchers.equalTo(5),
					"targetAccounts[0].targetAccountPreferences.withdrawalStartYear",
					Matchers.equalTo(updatedStartYear),
					"targetAccounts[0].targetAccountPreferences.withdrawalEndYear",
					Matchers.equalTo(updatedEndYear),
					"targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
					Matchers.equalTo("SELL_BETWEEN_51_AND_75"),
					"targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
					Matchers.equalTo("NONE"),
					"targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
					Matchers.equalTo("TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6"),
					"targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
					Matchers.equalTo(0.002f),
					"targetAccounts[0].targetAccountPreferences.anticipatedExpenses",
					Matchers.equalTo("LIKELY"),
					"targetAccounts[0].equityPercent", Matchers.equalTo(0.5f),
					"targetAccounts[0].assetAllocation.allocation", hasSize(4),
					"targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					Matchers
							.equalTo(0.5f),
					"targetAccounts[0].annualContribution.value", Matchers.equalTo(999.55f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.5f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
							+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.35f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
							+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.15f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					Matchers
							.equalTo(0.4f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
					Matchers
							.equalTo(0.1f),
					"targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
					Matchers.equalTo(0.45f),
					"targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
					Matchers.equalTo(0.54f),
					"targetAccounts[0].targetAssetMixes[0].category", Matchers.equalTo("FINAL"),
					"targetAccounts[0].targetAssetMixes[0].repositoryTamId", Matchers.equalTo(3),
					"targetAccounts[0].targetAssetMixes[0].assetAllocationId", Matchers.equalTo(50),
					"targetAccounts[0].targetAssetMixes[0].context", Matchers.equalTo("Standard"));

    }

    /**
     * Update the account.
     * <p>
     * Version V1
     */
    private void updateRetailAccount(final AccountRegCodeTestData data)
    {
	// Change the amount of the account
	context.put("value", updatedValue);
	context.put("accId", accId);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("userIdentifier.mid", Matchers.equalTo(accountsCommonTestData.getMid()),
					"userIdentifier.retailLid", Matchers.equalTo(accountsCommonTestData.getSsn()),
					"accountList[0].accountId.accountNumber", Matchers.equalTo(accNumber),
					"accountList[0].accountId.id", Matchers.equalTo(accId),
					"accountList[0].accountId.sourceSystem", Matchers.equalTo(source),
					"accountList[0].accountId.owner.relationship", Matchers.equalTo("PRINCIPAL"),
					"accountList[0].accountId.owner.id",
					Matchers.equalTo(accountsCommonTestData.getPpid()),
					"accountList[0].regCode.mnemonic", Matchers.equalTo(data.getRegCode1()),
					"accountList[0].sourceMarketValue.amount.value", Matchers.equalTo(updatedValue),
					"targetAccounts", not(empty()),
					"targetAccounts[0].accountId.sourceSystem", Matchers.equalTo(source),
					"targetAccounts[0].accountId.owner.relationship", Matchers.equalTo("PRINCIPAL"),
					"targetAccounts[0].accountId.owner.id",
					Matchers.equalTo(accountsCommonTestData.getPpid()),
					"targetAccounts[0].displayName", Matchers.equalTo(TARGET_ACCOUNT_NAME),
					"targetAccounts[0].sourceMarketValue.amount.value",
					Matchers.equalTo(fundingAccountAmount),
					"targetAccounts[0].regCode.sourceSystem", Matchers.equalTo(source),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					Matchers.equalTo(accNumber),
					"targetAccounts[0].fundingAccounts[0].amount.value",
					Matchers.equalTo(fundingAccountAmount),
					"targetAccounts[0].fundingAccounts[0].transferType",
					Matchers.equalTo(data.getTransferType()),
					"targetAccounts[0].complementaryAdjustmentOption",
					Matchers.equalTo("MOVE_TO_MANAGED_ACCOUNT"),
					"targetAccounts[0].isProductSuitable",
					Matchers.equalTo(Boolean.valueOf(isProductSuitableUpdate)),
					"targetAccounts[0].productSubType", Matchers.equalTo(updatedProductSubType),
					"targetAccounts[0].equityPercent", Matchers.equalTo(0.5f),
					"targetAccounts[0].annualContribution.value", Matchers.equalTo(999.55f),
					"targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
					Matchers.equalTo("SELL_BETWEEN_51_AND_75"),
					"targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
					Matchers.equalTo("NONE"),
					"targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
					Matchers.equalTo("TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6"),
					"targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
					Matchers.equalTo(0.002f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.5f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
							+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.35f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
							+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.15f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					Matchers
							.equalTo(0.4f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
					Matchers
							.equalTo(0.1f),
					"targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
					Matchers.equalTo(0.45f),
					"targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
					Matchers.equalTo(0.54f),
					"targetAccounts[0].targetAssetMixes[0].category", Matchers.equalTo("FINAL"),
					"targetAccounts[0].targetAssetMixes[0].repositoryTamId", Matchers.equalTo(3),
					"targetAccounts[0].targetAssetMixes[0].assetAllocationId", Matchers.equalTo(50),
					"targetAccounts[0].targetAssetMixes[0].context", Matchers.equalTo("Standard"));

    }

    /**
     * Validate the updated retail account.
     * <p>
     * Version V1
     */
    private void getRetailAccountAfterUpdate(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("externalDataSources", "true");
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", Matchers.equalTo(true),
					"userIdentifier.mid", Matchers.equalTo(accountsCommonTestData.getMid()),
					"accountList[0].regCode.mnemonic", Matchers.equalTo(data.getRegCode1()),
					"accountList[0].accountId.accountNumber", Matchers.equalTo(accNumber),
					"accountList[0].accountId.id", Matchers.equalTo(accId),
					"accountList[0].sourceMarketValue.amount.value", Matchers.equalTo(updatedValue),
					"targetAccounts", not(empty()),
					"targetAccounts[0].accountId.sourceSystem", Matchers.equalTo(source),
					"targetAccounts[0].accountId.owner.relationship", Matchers.equalTo("PRINCIPAL"),
					"targetAccounts[0].accountId.owner.id",
					Matchers.equalTo(accountsCommonTestData.getPpid()),
					"targetAccounts[0].displayName", Matchers.equalTo(TARGET_ACCOUNT_NAME),
					"targetAccounts[0].sourceMarketValue.amount.value",
					Matchers.equalTo(fundingAccountAmount),
					"targetAccounts[0].regCode.sourceSystem", Matchers.equalTo(source),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					Matchers.equalTo(accNumber),
					"targetAccounts[0].fundingAccounts[0].amount.value",
					Matchers.equalTo(fundingAccountAmount),
					"targetAccounts[0].fundingAccounts[0].unknownAmount",
					Matchers.equalTo(updatedUnknownAmount),
					"targetAccounts[0].fundingAccounts[0].transferType",
					Matchers.equalTo(data.getTransferType()),
					"targetAccounts[0].complementaryAdjustmentOption",
					Matchers.equalTo("MOVE_TO_MANAGED_ACCOUNT"),
					"targetAccounts[0].isProductSuitable",
					Matchers.equalTo(Boolean.valueOf(isProductSuitableUpdate)),
					"targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
					Matchers.equalTo("SELL_BETWEEN_51_AND_75"),
					"targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
					Matchers.equalTo("NONE"),
					"targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
					Matchers.equalTo("TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6"),
					"targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
					Matchers.equalTo(0.002f),
					"targetAccounts[0].productSubType", Matchers.equalTo(updatedProductSubType),
					"targetAccounts[0].equityPercent", Matchers.equalTo(0.5f),
					"targetAccounts[0].annualContribution.value", Matchers.equalTo(999.55f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.5f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
							+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.35f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
							+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
					Matchers
							.equalTo(0.15f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
					Matchers
							.equalTo(0.4f),
					"targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
					Matchers
							.equalTo(0.1f),
					"targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
					Matchers.equalTo(0.45f),
					"targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
					Matchers.equalTo(0.54f),
					"targetAccounts[0].targetAssetMixes[0].category", Matchers.equalTo("FINAL"),
					"targetAccounts[0].targetAssetMixes[0].repositoryTamId", Matchers.equalTo(3),
					"targetAccounts[0].targetAssetMixes[0].assetAllocationId", Matchers.equalTo(50),
					"targetAccounts[0].targetAssetMixes[0].context", Matchers.equalTo("Standard"));

    }

    /**
     * Delete target account
     */
    private void deleteTargetAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("targetAccounts", empty());
    }

    /**
     * Validate the updated retail account.
     * <p>
     * Version V1
     */
    private void getRetailAccountAfterTargetAccountDelete(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("externalDataSources", "true");
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", Matchers.equalTo(true),
					"userIdentifier.mid", Matchers.equalTo(accountsCommonTestData.getMid()),
					"accountList[0].regCode.mnemonic", Matchers.equalTo(data.getRegCode1()),
					"accountList[0].accountId.accountNumber", Matchers.equalTo(accNumber),
					"accountList[0].accountId.id", Matchers.equalTo(accId),
					"targetAccounts", empty());

    }

    // Delete Account
    private void deleteRetailAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	this.context.put("source", data.getSrcFilter());
	this.context.put("value", this.updatedValue);
	this.context.put("mnemonic", data.getRegCode1());
	this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
	this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
	this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
	this.context.put("accountNumber", accNumber);
	this.context.put("id", accId);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

	// Call Account service response
	request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
	// Assert on response
	this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

    }

    //Validate Account after delete
    private void getRetailAccountAfterDelete(final AccountRegCodeTestData data)
    {
	// Exclude external data sources
	this.context.put("source", this.source);
	this.context.put("externalDataSources", true);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
	// Assert on response
	this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}
