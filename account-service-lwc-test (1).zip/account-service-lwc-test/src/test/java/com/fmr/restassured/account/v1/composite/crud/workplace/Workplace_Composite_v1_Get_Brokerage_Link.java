/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.testng.AssertJUnit.assertFalse;

/**
 * Tests composite/get for Workplace accounts v1 specifically for brokerage linked accounts and their positions. Starts
 * by retrieving a workplace account and then retrieving all composite information from backend. PFCP-11737
 *
 * @author a608077
 * Updted by a631781. Added header "calculate-balances"
 */
@Test(groups = {Tags.WORKPLACE, Tags.COMPOSITE, Tags.V1})
public class Workplace_Composite_v1_Get_Brokerage_Link extends PAPBaseServiceTest
{

	protected Workplace_Composite_v1_Get_Brokerage_Link()
	{
		super(Services.Account);
	}

	private String ppid;

	private String mnemonic;

	private String accountNumber;

	private final String sourceSystem = "WORKPLACE";

	private String displayName;

	private float value;

	private int accRoot;

	private Boolean containsIsBrokerageLinkPosition;

	private Boolean containsIsBrokerageLinkDetails;

	private VelocityContext context;

	// Instance to the test data utility class
	TestDataUtil testDataUtil = new TestDataUtil();

	private static final String CALLING_APP_ID = "AP136091";

	private static final String APP_ID = "AP136091";

	private static final String LOG_TRACKING_ID = Workplace_Composite_v1_Get_Digital_Assets.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
		// Data setup
		AccountsCommonTestData accountsCommonTestData = TestDataUtil
		                .populateRegressionTestData("account_get_positions_brokerage_account", oAuth);

		String mid = accountsCommonTestData.getMid();
		DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


		ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

		// Populate request context with user IDs
		context = new VelocityContext();
		context.put("mid", mid);
		context.put("fescoLid", accountsCommonTestData.getSsn());
		context.put("ppid", ppid);
		context.put("source", sourceSystem);

	}

	/**
	 * Get Workplace account info from the backend. Save the account number.
	 */
	@Test
	public void getWorkplaceAccountInfo()
	{
		request.given().header(new Header("calculate-balances", "brokerage-link"));
		context.put("source", sourceSystem);
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true))
		                .body("accountList", Matchers.notNullValue());

		mnemonic = response.path("accountList[0].regCode.mnemonic");
		accountNumber = response.path("accountList[0].accountId.accountNumber");
		displayName = response.path("accountList[0].displayName");
		value = response.path("accountList[0].sourceMarketValue.amount.value");
	}

	/**
	 * Validate the positions.
	 */
	@Test(dependsOnMethods = "getWorkplaceAccountInfo")
	public void getCompositeAccount() throws JSONException
	{
		context.put("sourceBasedRegistrationFilter", sourceSystem);
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
		                .body("resultCode", equalTo(true)).body("accounts", notNullValue())
		                .body("accounts[0].account.accountId.sourceSystem", equalTo(sourceSystem))
		                .body("accounts[0].account.accountId.accountNumber", equalTo(accountNumber))
		                .body("accounts[0].account.regCode.mnemonic", equalTo(mnemonic))
		                .body("accounts[0].account.displayName", equalTo(displayName))
		                .body("accounts[0].account.accountId.owner.id", equalTo(ppid))
		                .body("accounts[0].account.sourceMarketValue.amount.value", equalTo(value))
		                .body("accounts.find{it.account.accountId.accountNumber==\"" + accountNumber
		                                + "\"}.positions", Matchers.notNullValue())
		                .body("accounts.find{it.account.accountId.accountNumber==\"" + accountNumber
		                                + "\"}.positions.position", Matchers.notNullValue());

		// Logic for validation of brokerage linked accounts
		JSONArray accountList = new JSONObject(response.getBody().asString()).getJSONArray("accounts");
		for (int i = 0; i < accountList.length(); i++)
		{
			JSONObject details = accountList.getJSONObject(i).getJSONObject("details");
			if (details.optString("isBrokerageLink").equals("true"))
			{
				containsIsBrokerageLinkDetails = true;
				accRoot = i;
				break;
			}
		}
		if (containsIsBrokerageLinkDetails == true)
		{
			if (accountList.getJSONObject(accRoot).getJSONObject("positions") != null)
			{
				JSONArray allPositions = accountList.getJSONObject(accRoot).getJSONObject("positions")
				                .getJSONArray("position");
				for (int j = 0; j < allPositions.length(); j++)
				{
					JSONObject workplacePosition = allPositions.getJSONObject(j);
					if (workplacePosition.optString("isBrokerageLink").equals("true"))
					{
						containsIsBrokerageLinkPosition = true;
						break;
					}
					else
					{
						containsIsBrokerageLinkPosition = false;
					}
				}
				assertFalse("Brokerage linked positions found!", containsIsBrokerageLinkPosition);
			}
		}
	}

	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}
}
