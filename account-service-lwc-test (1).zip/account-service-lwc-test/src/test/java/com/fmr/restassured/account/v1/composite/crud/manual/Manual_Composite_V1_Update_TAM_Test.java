/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.empty;

/**
 * Class to test TAM is created successfully via UPDATE method.
 *
 * @author a631781
 */
@Test(groups = {Tags.MANUAL, Tags.COMPOSITE, Tags.V1})
public class Manual_Composite_V1_Update_TAM_Test extends PAPBaseServiceTest {

    private AccountsCommonTestData accountsCommonTestData;

    private String oAuth;

    // Paths
    private String accountCompositeGetPath;

    private String accountCompositeCreatePath;

    private String accountCompositeUpdatePath;

    private String accountDeletePath;

    // Context
    private VelocityContext context;
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String acctRoot;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Manual_Composite_V1_Update_TAM_Test.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static String tamName = "Balanced";
    private static float tamTotalEquity = 0.50F;
    private static float tamDomesticEquity = 0.35F;
    private static float tamForeignEquity = 0.15F;
    private static float tamBond = 0.40F;
    private static float tamCash = 0.10F;

    private static String tamCategory = "INVESTOR_SELECTED_STRATEGY";
    private static Integer tamRepositoryTamId = 178;
    private static Integer tamAssetAllocationId = 50;

    /**
     * Constructor
     */
    protected Manual_Composite_V1_Update_TAM_Test() {
        super(Services.Account);
    }

    /**
     * Initialization method used to: </br>
     * 1. Retrieve the oAuth token </br>
     * 2. Retrieve the test data from SQLite DB & set up any other test data </br>
     * 3. Set operation paths </br>
     * 4. Build partial contents of the velocity context
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();

        accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN, oAuth);
        accountsCommonTestData.setMid("ManualCompositeV1TestMid");
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        // Data setup
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");
        accountsCommonTestData.setMnemonic1("IRA");
        accountsCommonTestData.setDisplayName1("Manual Composite CRUD RestAssured");
        accountsCommonTestData.setInstitutionName1("Manual Institution");
        accountsCommonTestData.setSourceSystem1("MANUAL");
        accountsCommonTestData.setPpid(
                String.valueOf(Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth)));

        // Set operation paths
        accountCompositeGetPath = AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1;
        accountCompositeCreatePath = AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1;
        accountCompositeUpdatePath = AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1;
        accountDeletePath = AccountsPaths.DELETE_ACCOUNT_V1;

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", "MANUAL");
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
    }

    // Get Composite account before create
    @Test
    public void getCompositeAccountManualBeforeCreate() {
        // Exclude external data
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "accounts", empty());

    }

    //Create composite account
    @Test(dependsOnMethods = {"getCompositeAccountManualBeforeCreate"})
    public void createCompositeAccountManual() {
        // Generate request body
        context.put("externalDataSources", "true");
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("withdrawAmount", "2000");
        context.put("withdrawFreq", "BIMONTHLY");
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("_type", AccountConstants.MANUAL_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.MANUAL_ACCOUNT_DETAILS);


        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeCreatePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accounts[0].account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        "accounts[0].account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accounts[0].account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accounts[0].account.institutionName", equalTo(accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()),
                        "accounts[0].details.costBasis.value", equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))),
                        "accounts[0].details.state", equalTo("AK"));


        // Save account number and ID
        accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
        accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
    }

    //Get composite account after create
    @Test(dependsOnMethods = "createCompositeAccountManual")
    public void getCompositeAccountManualAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accountsCommonTestData.getAccountNumber1() + "'}.";
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()))
                .body(acctRoot + "details.state", equalTo("AK"));
    }

    //Create TAM via update call
    @Test(dependsOnMethods = "getCompositeAccountManualAfterCreate")
    public void updateCompositeAccountManual() {
        // Populate updated variables for tests into context
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("TAM_name", tamName);
        context.put("TAM_total_equity", tamTotalEquity);
        context.put("TAM_domestic_equity", tamDomesticEquity);
        context.put("TAM_foreign_equity", tamForeignEquity);
        context.put("TAM_bond", tamBond);
        context.put("TAM_cash", tamCash);
        context.put("TAM_category", tamCategory);
        context.put("TAM_repositoryTamId", tamRepositoryTamId);
        context.put("TAM_assetAllocationId", tamAssetAllocationId);


        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.post(accountCompositeUpdatePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()))
                .body(acctRoot + "details.state", equalTo("AK"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo(tamName))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".netPercentage.value", equalTo(tamTotalEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(tamDomesticEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(tamForeignEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}"
                        + ".netPercentage.value", equalTo(tamBond))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}"
                        + ".netPercentage.value", equalTo(tamCash));
    }

    //Get composite account after update
    @Test(dependsOnMethods = "updateCompositeAccountManual")
    public void getCompositeAccountManualAfterUpdate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo(tamName))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".netPercentage.value", equalTo(tamTotalEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(tamDomesticEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(tamForeignEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}"
                        + ".netPercentage.value", equalTo(tamBond))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}"
                        + ".netPercentage.value", equalTo(tamCash));
    }

    //Delete Composite Account
    @Test(dependsOnMethods = "getCompositeAccountManualAfterUpdate")
    public void deleteCompositeAccountManual() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(accountDeletePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true)).body("accountList", empty());
    }

    //Get composite after Delete
    @Test(dependsOnMethods = "deleteCompositeAccountManual")
    public void getCompositeAccountManualAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "accounts", empty());
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown() {
        testDataUtil.closeSQLiteConnection();
    }

}