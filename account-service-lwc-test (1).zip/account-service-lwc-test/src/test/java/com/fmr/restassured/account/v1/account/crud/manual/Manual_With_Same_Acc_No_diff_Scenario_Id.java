/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.manual;

import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;

/**
 * Tests account, operation for inserting account number and different scenario id is created succssfully
 *
 * @author a609599
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.ACCOUNT,
        Tags.V1,
        Tags.ACCNUM })
public class Manual_With_Same_Acc_No_diff_Scenario_Id extends PAPBaseServiceTest {

    private VelocityContext context;

    private String acc_no;
    private String acc_id;
    private String acc_id2;
    private AccountsCommonTestData accountsCommonTestData = null;
    private final String asOfDate = "2014-10-31";
    private final String displayName1 = "Test Manual Account 1";
    private final String accountNo = "1234-test";
    private final String productCodeIGE = "IGE";
    private final String productCodeDIV = "DIV";
    private final String productCatCode = "DEF";
    private final float value = 818.89f;
    String source = "MANUAL";
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Manual_With_Same_Acc_No_diff_Scenario_Id.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private String mid;// = "ManualAccountV1TestMid";


    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;


    protected Manual_With_Same_Acc_No_diff_Scenario_Id() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        String oAuthToken = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        //Data setup
        this.accountsCommonTestData = TestDataUtil.populateRegressionTestData("accountCRUD_Manual",oAuthToken);
        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuthToken, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuthToken));

        // Populate request variables
        context = new VelocityContext();

        context.put("mid", accountsCommonTestData.getMid());
        context.put("source", source);
    }

    /**
     * Create a manual account
     */
    @Test
    public void createManualAccount() {
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "401K");
        context.put("displayName", displayName1);
        context.put("value", value);
        context.put("asOfDate", asOfDate);
        context.put("productCode", productCodeIGE);
        context.put("categoryCode", productCatCode);
        context.put("accountNumber", accountNo);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        acc_no = response.path("accountList.find{it.displayName == \"Test Manual Account 1\" }.accountId.accountNumber");

        acc_id = response.path("accountList.find{it.displayName == \"Test Manual Account 1\" }.accountId.id");



    }

    /**
     * Tests that account data is brought back for manual account.
     * Version V1
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void verifyAfterCreate() {

        this.request.given()
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo("MANUAL"))
                .body("accountList.find{it.displayName == \"Test Manual Account 1\" }.accountId.accountNumber", equalTo(acc_no))
                .body("resultCode", equalTo(true));

    }

    /**
     * Create a manual account with diff scenario
     */
    @Test(dependsOnMethods = "verifyAfterCreate")
    public void createManualAccountWithSameNoDiffScenario() {

        String oAuthToken = AccountUtil.getOauthToken();

        final String scenarioId = Scenario.createScenarioWithProductCode(this.accountsCommonTestData.getMid(),
                "DIV", "DEF", oAuthToken);

        this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentityWithProductCode(this.accountsCommonTestData.getMid(), oAuthToken,
               "DIV", "DEF"));
        float value = 426.85f;
        context.put("mnemonic", "401K");
        context.put("displayName", displayName1);
        context.put("value", value);
        context.put("asOfDate", asOfDate);
        context.put("accountNumber", accountNo);
        context.remove("productCode");
        context.put("productCode", productCodeDIV);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
                .body("resultCode", equalTo(true));;

        acc_no = response.path("accountList.find{it.displayName == \"Test Manual Account 1\" }.accountId.accountNumber");

        acc_id2 = response.path("accountList.find{it.displayName == \"Test Manual Account 1\" }.accountId.id");

    }
    /**
     * Verify the account with another scenario same no is created
     */
    @Test(dependsOnMethods = "createManualAccountWithSameNoDiffScenario")
    public void verifyAfterCreateWithSameAccNoDiffScenario() {

        this.request.given()
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo("MANUAL"))
                .body("accountList.find{it.displayName == \"Test Manual Account 1\" }.accountId.accountNumber", equalTo(acc_no))
                .body("resultCode", equalTo(true));
    }

    /**
     * Deletes the manual account
     */
    @Test(dependsOnMethods = "verifyAfterCreateWithSameAccNoDiffScenario")
    public void deleteManualAccount() {

        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "401K");
        context.put("displayName", displayName1);
        context.put("value", value);
        context.put("asOfDate", asOfDate);
        context.remove("accountNumber");
        context.put("accId", acc_id);
        context.remove("productCode");
        context.put("productCode", productCodeIGE);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", is(notNullValue()));
    }

    /**
     * Deletes the manual account
     */
    @Test(dependsOnMethods = "verifyAfterCreateWithSameAccNoDiffScenario")
    public void deleteManualAccount2() {

        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "401K");
        context.put("displayName", displayName1);
        context.put("value", value);
        context.put("asOfDate", asOfDate);
        context.remove("accountNumber");
        context.put("accId", acc_id2);
        context.remove("productCode");
        context.put("productCode", productCodeDIV);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", is(notNullValue()))
                .body("accountList", hasSize(0));
    }

    /**
     * Tests that data is deleted
     * Version V2
     */
    @Test(dependsOnMethods = "deleteManualAccount2")
    public void verifyAfterDelete() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        //Run test
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", is(notNullValue()))
                .body("accountList", hasSize(0));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}