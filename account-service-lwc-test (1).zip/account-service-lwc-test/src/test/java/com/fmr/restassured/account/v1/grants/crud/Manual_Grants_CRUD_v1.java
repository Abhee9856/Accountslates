/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.grants.crud;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsGrantsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;

import com.fmr.pap.restassured.utilities.IOUtil;

import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountGrantsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountGrantsTestDataOneGrant;

import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.GrantsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Random;

/**
 * Tests for Manual grants CRUD v1
 * Test Flow:
 * o	Create Principal, Scenario and Identity
 * o	Create manual account and get account with grants before create
 * o	Create grants then get account with grants after create
 * o	Update grants then get account with grants after update
 * o	Delete grants then get account with grants after delete
 * o	Delete account then get account after delete
 *
 * @author a608077
 */
@Test(groups = {
        Tags.CRITICAL,
        Tags.GRANTS,
        Tags.ACCOUNT,
        Tags.V1,
        Tags.CRUD})

public class Manual_Grants_CRUD_v1 extends PAPBaseServiceTest {

    private String ssn;
    private String mid;
    private String ppid;
    private static final String PRODUCT_CODE = "ECP";
    private static final String CATEGORY_CODE = "DEF";
    private static final String sourceSystem = "MANUAL";

    //ToDo: Pull out FinstId from DB instead of hardcoding directly
    private static final String ENTITY_ID = "478030703";
    private static final String ENTITY_TYPE_CODE = "CUSIP";

    private VelocityContext context;

    private AccountGrantsTestData grantsData;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Manual_Grants_CRUD_v1.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    String oAuthToken = AccountUtil.getOauthToken();

    // Data setup
    final AccountsCommonTestData accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_grants_manual", oAuthToken);

    protected Manual_Grants_CRUD_v1() {
        super(Services.Account);
    }

    private boolean debug = false;
    
    private final int grantSequence = generateSequenceNumber();
    
    private final int vestSequence = generateSequenceNumber();

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        debug = Boolean.valueOf(System.getProperty("debug"));

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);
        if(debug){request.filters(new RequestLoggingFilter(), new ResponseLoggingFilter());}
        
//        accountsCommonTestData.setMid("ManualAccountGrantsV1TestMid");
        
        testDataUtil = new TestDataUtil();
        grantsData = new AccountGrantsTestData();
        mid = accountsCommonTestData.getMid();
        ssn = accountsCommonTestData.getSsn();

        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuthToken, "true");

        grantsData.setMid(mid);
        grantsData.setProductCode(PRODUCT_CODE);
        grantsData.setCategoryCode(CATEGORY_CODE);
        grantsData.setEntityId(ENTITY_ID);
        grantsData.setEntityTypeCode(ENTITY_TYPE_CODE);
        grantsData.setSource(sourceSystem);

        ppid = Identity.createPrincipalWithEntity(AccountConstants.MID, mid, grantsData.getProductCode(), grantsData.getCategoryCode(),
                grantsData.getEntityTypeCode(), grantsData.getEntityId(), oAuthToken);

        String scenarioId = Scenario.createScenarioWithProductCodeEntityIdEntityCode(mid, grantsData.getProductCode(), grantsData.getCategoryCode(),
                        grantsData.getEntityId(), grantsData.getEntityTypeCode(),oAuthToken, "test");

        Identity.createHouseholdIdentityWithEntityIDandEntityCode(mid, ppid, ssn, oAuthToken,
                "PRINCIPAL", grantsData.getProductCode(), grantsData.getCategoryCode(),
                        grantsData.getEntityId(), grantsData.getEntityTypeCode(), scenarioId, "Regression Manual GrantsV1");

        grantsData.setPpid(ppid);
        grantsData.setScenarioId(scenarioId);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", grantsData.getMid());
        context.put("source", grantsData.getSource());
        context.put("pointOfEntry", "RETAIL");
        context.put("productCode", grantsData.getProductCode());
        context.put("categoryCode", grantsData.getCategoryCode());
        context.put("entityId", grantsData.getEntityId());
        context.put("entityTypeCode", grantsData.getEntityTypeCode());
        context.put("scenarioId", grantsData.getScenarioId());

    }

    /**
     * Generating random number for grant sequence
     */
    @Test
    public int generateSequenceNumber() {
        // creating an object of Random class
        Random random = new Random();
        // Generates random integers 0 to 999
        return random.nextInt(1000);
    }

    /**
     * Create a manual account
     */
    @Test
    public void createManualAccount() {

        context.put("ppid", ppid);
        context.put("mnemonic", "IRA");
        context.put("retailLid", ssn);
        context.put("value", "2000.88");
        context.put("asOfDate", "2014-10-31");
        context.put("productCode", grantsData.getProductCode());
        context.put("categoryCode", grantsData.getCategoryCode());
        context.put("scenarioId", grantsData.getScenarioId());
        if (null != grantsData.getEntityId()) {
            context.put("entityId", grantsData.getEntityId());
        }
        if (null != grantsData.getEntityTypeCode()) {
            context.put("entityTypeCode", grantsData.getEntityTypeCode());
        }
        //Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));


        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);


        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList[0].accountId.accountNumber", notNullValue());

        String accId = response.path("accountList[0].accountId.id");

        grantsData.setAccId(accId);
        grantsData.setAccNumber(response.path("accountList[0].accountId.accountNumber"));
    }

    /**
     * Tests that account is created successfully.
     * Version V1
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void verifyManualAccountCreated() {
        //Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));


        //Run test
        response = this.request.post(AccountsPaths.GET_ACCOUNT_V1);


        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(grantsData.getMid()))
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountId.accountNumber", notNullValue())
                .body("accountList.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountId.sourceSystem", equalTo(sourceSystem))
                .body("accountList.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountId", notNullValue());

    }

    /**
     * This is the test flow. It iterates through the data provider, performing CRUD operations for each use case.
     *
     * @param data the test cases
     */
    @Test(dependsOnMethods = "verifyManualAccountCreated", dataProvider = "getOneGrantOneVestData",
            dataProviderClass = GrantsDataProviderUtil.class)

    public void performCrudOperations(final AccountGrantsTestDataOneGrant data) {
        this.createAccountGrants(data);
        this.verifyAfterCreate();
        this.updateAccountGrants(data);
        this.verifyAfterUpdateGrants();
        this.deleteAccountGrants(data);
        this.verifyAfterDeleteGrants();
    }

    /**
     * Create manual grants for a manual account type
     */

    private void createAccountGrants(final AccountGrantsTestDataOneGrant data) {
        context.put("retailLid", ssn);
        context.put("accId", grantsData.getAccId());
        context.put("accountNumber", grantsData.getAccNumber());
        context.put("grantDate", data.getGrantDate());
        context.put("stockOptionId", data.getStockOptionId());
        context.put("grantType", data.getGrantType());
        context.put("grantSequence", grantSequence);
        context.put("scenarioId", grantsData.getScenarioId());
        context.put("entityId", grantsData.getEntityId());
        context.put("entityTypeCode", grantsData.getEntityTypeCode());
        context.put("grantPrice", data.getGrantPrice());
        context.put("vestedShares", data.getVestedShares());
        context.put("unvestedShares", data.getUnvestedShares());
        context.put("vestedValue", data.getVestedValue());
        context.put("unvestedValue", data.getUnvestedValue());
        context.put("expirationDate", data.getExpirationDate());
        context.put("vestDate", data.getVest_vestDate());
        context.put("vestShares", data.getVest_vestShares());
        context.put("vestSequence", vestSequence);
        context.put("distributionDate", data.getVest_distributionDate());
        context.put("performancePercentage", data.getVest_perfPercentage());

        //Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_CREATE_TEMPLATE));


        //Run test
        response = request.post(AccountsGrantsPaths.CREATE_ACCOUNTS_GRANTS_V1);


        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(grantsData.getMid()))
                .body("accountGrants", not(emptyArray()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].stockOptionId", equalTo(data.getStockOptionId()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].grantType", equalTo(data.getGrantType()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].grantDate", startsWith(data.getGrantDate()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].sequence", equalTo(grantSequence))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].grantPrice.value", equalTo(data.getGrantPrice()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vestedShares", equalTo(data.getVestedShares()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].unvestedShares", equalTo(data.getUnvestedShares()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vestedValue.value", equalTo(data.getVestedValue()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].unvestedValue.value", equalTo(data.getUnvestedValue()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].expirationDate", startsWith(data.getExpirationDate()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vests[0].vestDate", startsWith(data.getVest_vestDate()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vests[0].vestShares", equalTo(data.getVest_vestShares()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vests[0].sequence", equalTo(vestSequence))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vests[0].distributionDate", startsWith(data.getVest_distributionDate()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vests[0].performancePercentage", equalTo(data.getVest_perfPercentage()));
    }

    /**
     * Tests that created grants are brought back from account/grants/get
     */
    private void verifyAfterCreate() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_GET_TEMPLATE));


        //Run test
        response = request.post(AccountsGrantsPaths.GET_ACCOUNTS_GRANTS_V1);


        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(grantsData.getMid()))
                .body("accountGrants", not(emptyArray()));

    }


    /**
     * Updates the grants
     */

    private void updateAccountGrants(final AccountGrantsTestDataOneGrant data) {

        context.put("grantDate", data.getGrantDate());
        context.put("stockOptionId", data.getStockOptionId());
        context.put("grantType", data.getGrantType());
        context.put("grantPrice", data.getUpdatedGrantPrice());
        context.put("vestedShares", data.getUpdatedVestedShares());
        context.put("unvestedShares", data.getUpdatedUnvestedShares());
        context.put("vestedValue", data.getUpdatedVestedValue());
        context.put("unvestedValue", data.getUpdatedUnvestedValue());
        context.put("expirationDate", data.getUpdatedExpirationDate());
        context.put("vestDate", data.getUpdatedVest_vestDate());
        context.put("vestShares", data.getUpdatedVest_vestShares());
        context.put("distributionDate", data.getUpdatedVest_distributionDate());
        context.put("performancePercentage", data.getUpdatedVest_perfPercentage());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_UPDATE_TEMPLATE));


        //Run test
        response = request.post(AccountsGrantsPaths.UPDATE_ACCOUNTS_GRANTS_V1);


        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(grantsData.getMid()))
                .body("accountGrants", not(emptyArray()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].stockOptionId", equalTo(data.getStockOptionId()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].grantType", equalTo(data.getGrantType()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].grantDate", startsWith(data.getGrantDate()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].sequence", equalTo(grantSequence))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].grantPrice.value", equalTo(data.getUpdatedGrantPrice()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vestedShares", equalTo(data.getUpdatedVestedShares()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].unvestedShares", equalTo(data.getUpdatedUnvestedShares()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vestedValue.value", equalTo(data.getUpdatedVestedValue()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].unvestedValue.value", equalTo(data.getUpdatedUnvestedValue()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].expirationDate", startsWith(data.getUpdatedExpirationDate()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vests[0].vestDate", startsWith(data.getUpdatedVest_vestDate()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vests[0].vestShares", equalTo(data.getUpdatedVest_vestShares()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vests[0].sequence", equalTo(vestSequence))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vests[0].distributionDate", startsWith(data.getUpdatedVest_distributionDate()))
                .body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountGrants[0].vests[0].performancePercentage", equalTo(data.getUpdatedVest_perfPercentage()));
    }

    /**
     * Tests that updated grantsData is brought back from account/grants/get
     */

    private void verifyAfterUpdateGrants() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_GET_TEMPLATE));


        //Run test
        response = request.post(AccountsGrantsPaths.GET_ACCOUNTS_GRANTS_V1);


        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(grantsData.getMid()))
                .body("accountGrants", not(emptyArray()));

    }


    /**
     * Delete account grants
     */
    private void deleteAccountGrants(final AccountGrantsTestDataOneGrant data) {

        context.put("accountNumber", this.grantsData.getAccNumber());
        context.put("grantDate", data.getGrantDate());
        context.put("stockOptionId", data.getStockOptionId());
        context.put("grantType", data.getGrantType());
        context.put("grantPrice", data.getUpdatedGrantPrice());
        context.put("vestedShares", data.getUpdatedVestedShares());
        context.put("unvestedShares", data.getUpdatedUnvestedShares());
        context.put("vestedValue", data.getUpdatedVestedValue());
        context.put("unvestedValue", data.getUpdatedUnvestedValue());
        context.put("expirationDate", data.getUpdatedExpirationDate());
        context.put("vestDate", data.getUpdatedVest_vestDate());
        context.put("vestShares", data.getUpdatedVest_vestShares());
        context.put("distributionDate", data.getUpdatedVest_distributionDate());
        context.put("performancePercentage", data.getUpdatedVest_perfPercentage());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_DELETE_TEMPLATE));


        //Run test
        response = request.post(AccountsGrantsPaths.DELETE_ACCOUNTS_GRANTS_V1);


        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(grantsData.getMid()))
                .body("responseDiagnostic.resultDetail", equalTo("Account Grants are deleted."));
    }

    private void verifyAfterDeleteGrants() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_GET_TEMPLATE));


        //Run test
        response = request.post(AccountsGrantsPaths.GET_ACCOUNTS_GRANTS_V1);


        // Assert on response
        this.response.then().log().ifValidationFails()
                .statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(grantsData.getMid()))
                .body("accountsGrants", empty());


    }


    /**
     * Deletes the manual account
     */
    @Test(dependsOnMethods = "performCrudOperations")
    public void deleteManualAccount() {

        context.put("ppid", ppid);
        context.put("mnemonic", "IRA");
        context.put("retailLid", ssn);
        context.put("value", "2000.88");
        context.put("asOfDate", "2014-10-31");
        context.put("productCode", grantsData.getProductCode());
        context.put("categoryCode", grantsData.getCategoryCode());
        context.put("scenarioId", grantsData.getScenarioId());
        if (null != grantsData.getEntityId()) {
            context.put("entityId", grantsData.getEntityId());
        }
        if (null != grantsData.getEntityTypeCode()) {
            context.put("entityTypeCode", grantsData.getEntityTypeCode());
        }

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_V1_TEMPLATE_FOR_GRANTS));

        // Call Account service
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(mid))
                // No accounts are returned
                .body("accountList", empty());
    }

    /**
     * Tests that updated grantsData is brought back from account/get
     * Version V1
     */
    @Test(dependsOnMethods = "deleteManualAccount")
    public void verifyAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(mid))
                // No accounts are returned
                .body("accountList", empty());

    }


    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }


}
