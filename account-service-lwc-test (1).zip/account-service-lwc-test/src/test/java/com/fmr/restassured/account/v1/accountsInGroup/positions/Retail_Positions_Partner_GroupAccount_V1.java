/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.accountsInGroup.positions;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.GroupsUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests when group call is made to account service: i.e. if there is group id and group type in the request after the call to household identity if we identity that the mid in the request is the partners mid. park all accounts by default under the partner.
 *
 * @author a631781, Story# PFCP-18785
 */
@Test(groups = {
        Tags.REGRESSION,
        Tags.RETAIL,
        Tags.POSITIONS,
        Tags.GROUP,
        Tags.V1})
public class Retail_Positions_Partner_GroupAccount_V1 extends PAPBaseServiceTest {

    protected Retail_Positions_Partner_GroupAccount_V1() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;
    private String principalMid, partnerMid;
    private String principalSsn, partnerSsn;
    private String product = "WM";
    private String poe = "RETAIL";
    private String oAuth;
    private String groupId;
    private String groupType = "APO_WM";
    private String groupName = "RetailGroupPartnerTest" + GroupsUtil.generateRandomNumber();

    private int principalId, partnerId;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";
    private static final String SCENARIO_PRODUCT_CODE = "WM";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
     * endpoint for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);
        testDataUtil = new TestDataUtil();
        principalMid = accountsCommonTestData.getMid();
        principalSsn = accountsCommonTestData.getSsn();
        // Get Partner's Mid
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_get_Retail_Reg_Code_I_1", oAuth);
        partnerMid = accountsCommonTestData.getMid();
        partnerSsn = accountsCommonTestData.getSsn();

        //Set default REST header with authorization token
        setDefaultRequestHeaders(oAuth);
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", principalMid, oAuth, "true");

        //Get APO call and Delete existing groupId for the user
        response = GroupsUtil.getGroupId(oAuth, principalMid, poe, product);
        int getGroupStatus = response.statusCode();
        if (200 == getGroupStatus) {
            String existingGroupType = response.path("groups[0].type");
            GroupsUtil.deleteGroup(response.path("groups[0].id"), existingGroupType, oAuth, poe);
        }
        //Crate group
        response = GroupsUtil.createGroup(oAuth, groupName, principalSsn, partnerSsn, principalMid, partnerMid, poe, product);
        groupId = response.path("groups[0].id");
        // Create Group Household with Partner
        response = GroupsUtil.createHouseholdIdentityWithGroupId(oAuth, principalMid, groupId, groupType, partnerMid, poe, product);
        principalId = response.path("identities.find{it.relationship=='PRINCIPAL'}.planningPartyId");
        partnerId = response.path("identities.find{it.relationship=='PARTNER'}.planningPartyId");
    }

    /**
     * Get retail account positions info for Partner and validate owner relationship and ID are of partner.
     */
    @Test
    public void getRetailPositionsPartnerID() {
        // Populate request variables
        context = new VelocityContext();
        context.put("mid", partnerMid);
        context.put("retailLid", partnerSsn);
        context.put("source", AccountConstants.RETAIL);
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);
        context.put("groupId", groupId);
        context.put("groupType", groupType);
        context.put("externalDataSources", false);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
                response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode) {
            Assert.assertEquals(dssResultCode, false);
        }

        String relationship = response.path("accountList[0].account.accountId.owner.relationship");
        String actualPartnerID = response.path("accountList[0].account.accountId.owner.id");
        Assert.assertEquals(relationship, "PARTNER");
        Assert.assertEquals(actualPartnerID, String.valueOf(partnerId));
    }

    /**
     * Delete GroupID
     */
    @AfterClass(alwaysRun = true)
    public void deleteGroupId() {
        GroupsUtil.deleteGroup(groupId, groupType, oAuth, poe);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, principalMid, oAuth, "true");
        testDataUtil.closeSQLiteConnection();
    }
}