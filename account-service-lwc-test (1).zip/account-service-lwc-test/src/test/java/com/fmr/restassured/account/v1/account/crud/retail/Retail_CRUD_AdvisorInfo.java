/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.retail;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Tests Advisor Info for v1 CRUD operations for Retail accounts
 *
 * @author a631781
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.ACCOUNT,
		Tags.V1})
public class Retail_CRUD_AdvisorInfo extends PAPBaseServiceTest
{

    protected Retail_CRUD_AdvisorInfo()
    {
	super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String source = "RETAIL";

    private final String asOfDate1 = "2014-10-31";

    private final String displayName = "Retail Account Advisor Info";

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accId;

    private String accNumber;

    private String ppid;

    private String mnemonic;

    private String poe = "FRIAG";

    private String advisorId = "7690112176";

    private String advisorRealm = "FRIAG";

    private String advisorPlanNumber = "500958";

    private String gnumber = "G07492038";

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();
	// Set default headers
	setDefaultRequestHeaders(oAuth);

	// Populate request variables
	context = new VelocityContext();

    }

    //Test Account V1 for Advisor Info
    @Test
    public void performCrudOperations()
    {
	this.getRetailAccount();
	this.createRetailAccount();
	this.getRetailAccountAfterCreate();
	this.updateRetailAccount();
	this.getRetailAccountAfterUpdate();
	this.deleteRetailAccount();
    }

    //Get account info from the backend.
    private void getRetailAccount()
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", false);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	response.then().log().ifValidationFails().body("accountList", not(emptyArray()));
	accNumber = response.path("accountList[0].accountId.accountNumber");
	ppid = response.path("accountList[0].accountId.owner.id");
	mnemonic = response.path("accountList[0].regCode.mnemonic");
    }

    //Create Retail Account
    private void createRetailAccount()
    {
	// Generate request body
	context.put("source", source);
	context.put("excludeExternalDataSources", true);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	context.put("ppid", ppid);
	context.put("value", String.valueOf(value));
	context.put("mnemonic", mnemonic);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("id", null);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

	//Asset on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.pointOfEntry", equalTo(poe))
			.body("userIdentifier.advisorInformation.advisorId", equalTo(advisorId))
			.body("userIdentifier.advisorInformation.advisorRealm", equalTo(advisorRealm))
			.body("userIdentifier.advisorInformation.advisorPlanNumber", equalTo(advisorPlanNumber))
			.body("accountList[0].accountId.accountNumber", equalTo(accNumber))
			.body("accountList[0].sourceMarketValue.amount.value", equalTo(value))
			.body("accountList[0].displayName", equalTo(displayName));

	accId = response.path("accountList[0].accountId.id");

    }

    //Get after create
    private void getRetailAccountAfterCreate()
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", true);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.pointOfEntry", equalTo(poe))
			.body("userIdentifier.advisorInformation.advisorId", equalTo(advisorId))
			.body("userIdentifier.advisorInformation.advisorRealm", equalTo(advisorRealm))
			.body("userIdentifier.advisorInformation.advisorPlanNumber", equalTo(advisorPlanNumber))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNumber))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value",
					equalTo(value))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(displayName));

    }

    //Update Retail Account
    private void updateRetailAccount()
    {
	// Generate request body
	context.put("source", source);
	context.put("excludeExternalDataSources", true);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	context.put("ppid", ppid);
	context.put("value", String.valueOf(updatedValue));
	context.put("mnemonic", mnemonic);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("accId", accId);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

	//Asset on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.pointOfEntry", equalTo(poe))
			.body("userIdentifier.advisorInformation.advisorId", equalTo(advisorId))
			.body("userIdentifier.advisorInformation.advisorRealm", equalTo(advisorRealm))
			.body("userIdentifier.advisorInformation.advisorPlanNumber", equalTo(advisorPlanNumber))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNumber))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value",
					equalTo(updatedValue))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(displayName));

    }

    // Get after Update
    private void getRetailAccountAfterUpdate()
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", true);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.pointOfEntry", equalTo(poe))
			.body("userIdentifier.advisorInformation.advisorId", equalTo(advisorId))
			.body("userIdentifier.advisorInformation.advisorRealm", equalTo(advisorRealm))
			.body("userIdentifier.advisorInformation.advisorPlanNumber", equalTo(advisorPlanNumber))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNumber))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value",
					equalTo(updatedValue))
			.body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(displayName));

    }

    //Delete Retail Account
    private void deleteRetailAccount()
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", true);
	context.put("poe", poe);
	context.put("advisorId", advisorId);
	context.put("advisorRealm", advisorRealm);
	context.put("advisorPlanNumber", advisorPlanNumber);
	context.put("gnumber", gnumber);
	context.put("ppid", ppid);
	context.put("value", String.valueOf(value));
	context.put("mnemonic", mnemonic);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("id", accId);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

	// Call Account service response
	request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

    }

}
