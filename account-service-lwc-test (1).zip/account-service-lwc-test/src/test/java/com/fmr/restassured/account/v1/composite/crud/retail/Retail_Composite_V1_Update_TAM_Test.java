/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

/**
 * Class to test TAM is created successfully via UPDATE method.
 *
 * @author a631781
 */
@Test(groups = {Tags.RETAIL, Tags.ACCOUNT, Tags.V1})
public class Retail_Composite_V1_Update_TAM_Test extends PAPBaseServiceTest {

    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Retail_Composite_V1_Update_TAM_Test.class);

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accNum;

    private String acctRoot;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    /**
     * Global variable holding retailAccount information
     */
    private HashMap<String, String> retailAccountMap;

    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountTestData;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Composite_V1_Update_TAM_Test.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String source = "RETAIL";

    private String scenarioId;

    private VelocityContext context;
    private static String tamName = "Growth with Income";
    private static float tamTotalEquity = 0.60F;
    private static float tamDomesticEquity = 0.42F;
    private static float tamForeignEquity = 0.18F;
    private static float tamBond = 0.35F;
    private static float tamCash = 0.05F;

    private static String tamCategory = "INVESTOR_SELECTED_STRATEGY";
    private static Integer tamRepositoryTamId = 179;
    private static Integer tamAssetAllocationId = 60;

    /**
     * Constructor
     */
    protected Retail_Composite_V1_Update_TAM_Test() {
        super(Services.Account);
    }

    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {

        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        retailAccountMap = new HashMap<>();

        accountTestData = TestDataUtil.populateRegressionTestData("accountCRUD_Retail", oAuth);
        accountTestData.setMid("RetailCompositeV1TestMid");

        retailAccountMap = getRetailAccountInformation(accountTestData, oAuth);

        DataCleanup.deleteCustomerDataFromCP("mid", accountTestData.getMid(), oAuth, "true");

        final String ppid = Identity.createHouseholdIdentity(accountTestData.getMid(), oAuth);
        accountTestData.setPpid(ppid);
        // Get/Create ScenarioId
        Response allScenarioIDs = Scenario.getAllScenarios(accountTestData.getMid(), oAuth);
        scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null) {
            scenarioId = Scenario.createScenarioWithProductCode(accountTestData.getMid(), "IGE", "DEF",
                    oAuth);
        }
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
    }

    // Get Composite account before create
    @Test
    public void getCompositeAccountRetailBeforeCreate() {
        if (retailAccountMap.isEmpty()) {
            throw new SkipException(
                    "'getCompositeAccountRetailBeforeCreate' test scenario cannot run due to failure to retrieve "
                            + "retail account information!");
        }

        context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", true);
        context.put("source", source);
        context.put("scenarioId", scenarioId);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    //Create composite account
    @Test(dependsOnMethods = "getCompositeAccountRetailBeforeCreate")
    public void createCompositeAccountRetail() {
        accNum = retailAccountMap.get("accountNumber");
        context.put("externalDataSources", true);
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("accountNumber", accNum);
        context.put("scenarioId", scenarioId);
        context.put("source", source);
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", source);
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "111111.11");
        context.put("emergencyFundAmount", "111111.11");
        context.put("isProductSuitable", "false");
        context.put("suitabilityStatus", "SUITABLE");
        context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
        context.put("type", "RetailAccountDetails");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details.emergencyFundAmount.value", equalTo(111111.11f));


        accountTestData.setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
    }

    //Get composite account after create
    @Test(dependsOnMethods = "createCompositeAccountRetail")
    public void getCompositeAccountRetailAfterCreate() {
        this.request.given().header(new Header("include-suitability-details", "true"));
        VelocityContext context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", true);
        context.put("source", source);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))));


    }

        //Create TAM via update call
    @Test(dependsOnMethods = "getCompositeAccountRetailAfterCreate")
    public void updateCompositeAccountRetail() {
        context.put("externalDataSources", true);
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", retailAccountMap.get("accountNumber"));
        context.put("source", source);
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", source);
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "211111.11");
        context.put("emergencyFundAmount", "211111.11");
        context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
        context.put("type", "RetailAccountDetails");
        context.put("isProductSuitable", "false");
        context.put("suitabilityStatus", "SUITABLE");
        context.put("TAM_name", tamName);
        context.put("TAM_total_equity", tamTotalEquity);
        context.put("TAM_domestic_equity", tamDomesticEquity);
        context.put("TAM_foreign_equity", tamForeignEquity);
        context.put("TAM_bond", tamBond);
        context.put("TAM_cash", tamCash);
        context.put("TAM_category", tamCategory);
        context.put("TAM_repositoryTamId", tamRepositoryTamId);
        context.put("TAM_assetAllocationId", tamAssetAllocationId);


        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);
        response.prettyPrint();
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details.emergencyFundAmount.value", equalTo(211111.11f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo(tamName))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".netPercentage.value", equalTo(tamTotalEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(tamDomesticEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(tamForeignEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}"
                        + ".netPercentage.value", equalTo(tamBond))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}"
                        + ".netPercentage.value", equalTo(tamCash));

    }

    //Get composite account after update
    @Test(dependsOnMethods = "updateCompositeAccountRetail")
    public void getCompositeAccountRetailAfterUpdate() {
        this.request.given().header(new Header("include-suitability-details", "true"));
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", true);
        context.put("source", source);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".netPercentage.value", equalTo(tamTotalEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(tamDomesticEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}"
                                + ".allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(tamForeignEquity))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}"
                        + ".netPercentage.value", equalTo(tamBond))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}"
                        + ".netPercentage.value", equalTo(tamCash));

    }

    //Delete Composite Account
    @Test(dependsOnMethods = "getCompositeAccountRetailAfterUpdate")
    public void deleteCompositeAccountRetail() {
        final VelocityContext context = new VelocityContext();

        context.put("externalDataSources", true);
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", retailAccountMap.get("accountNumber"));
        context.put("source", source);
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", source);
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accountList",
                hasSize(0));
    }

    //Get composite after Delete
    @Test(dependsOnMethods = "deleteCompositeAccountRetail")
    public void getCompositeAccountRetailAfterDelete() {
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", true);
        context.put("source", source);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Returns the response of retrieving a retail account
     *
     * @param accountsCommonTestData the test data
     * @return retailAccountMap
     */
    private static HashMap<String, String> getRetailAccountInformation(
            final AccountsCommonTestData accountsCommonTestData, final String oAuth) {
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("source", "RETAIL");
        // context.put("mnemonicFilter", "IRA");

        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();

        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        request.given().log().all();
        final Response response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        response.then().log().all();
        if (response.statusCode() != HTTPStatusCodes.STATUS_200) {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));

            return null;
        }

        final JsonPath retailAccountJP = response.jsonPath();

        final HashMap<String, String> retailAccountMap = new HashMap<>();
        retailAccountMap.put("accountNumber",
                retailAccountJP.getString("accountList[0].accountId.accountNumber"));
        retailAccountMap.put("sourceSystem",
                retailAccountJP.getString("accountList[0].accountId.sourceSystem"));
        retailAccountMap.put("displayName", retailAccountJP.getString("accountList[0].displayName"));
        retailAccountMap.put("mnemonic", retailAccountJP.getString("accountList[0].regCode.mnemonic"));
        retailAccountMap.put("institutionName", retailAccountJP.getString("accountList[0].institutionName"));
        retailAccountMap.put("sourceMarketAmountType",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount._type"));
        retailAccountMap.put("sourceMarketAmountValue",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
        retailAccountMap.put("sourceMarketAmountValueType",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        retailAccountMap.put("sourceMarketAmountCurrency",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        retailAccountMap.put("sourceMarketAsOfDate",
                retailAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));

        return retailAccountMap;
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown() {
        testDataUtil.closeSQLiteConnection();
    }
}