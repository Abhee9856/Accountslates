/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.get.workplace.regcode;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.commons.collections.CollectionUtils;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.notNullValue;

/**
 * Tests for v1/account/get operation for workplace accounts using DataProvider (for handling multiple regCodes).
 *
 * @author a560878
 *
 */
@Test(groups = {
		Tags.PIPELINE, 
		Tags.ASYNCHRONOUS,
		Tags.WORKPLACE, 
		Tags.ACCOUNT, 
		Tags.V1, 
		Tags.GET})

public class WorkplaceRegCodeGetV1 extends PAPBaseServiceTest
{

	protected WorkplaceRegCodeGetV1()
	{
		super(Services.Account);
	}

	// Data setup

	private VelocityContext context;

	private final List<List<AccountRegCodeTestData>> workplaceRegCdList = new ArrayList<>();

	/** Instance to the test data utility class */
	private TestDataUtil testDataUtil;

	private String mid;// = "WorkplaceAccountV1TestMid";

	private String token;

	/**
	 * Initialization method used to populate the UserIdentifiers object based (when needed) on the default SSN, and
	 * build the request header.
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{
		this.token = AccountUtil.getOauthToken();
		this.testDataUtil = new TestDataUtil();
		this.setDefaultRequestHeaders(this.token);

	}

	/**
	 * Test for getting Workplace Accounts using data provider.
	 *
	 * Version V1
	 */
	@Test(dataProvider = "getWorkplaceAccountRegCode", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
	public void getWorkplaceAccountsForRegCodes(final AccountRegCodeTestData data)
	{
		this.context = new VelocityContext();
		this.context.put("fescoLid", data.getSsn());
		this.context.put("mnemonicFilter", data.getRegCode1());
		this.context.put("source", data.getSrcFilter());

		this.request =
		        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE));
		this.request.log().uri();
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
		if (CollectionUtils.isNotEmpty(response.path("accountList"))
		        && (response.jsonPath().getList("accountList").size() > 0))
		{
			response.then().body("accountList[0].accountId", notNullValue())
			        .body("accountList[0].accountId.owner.id", notNullValue())
			        .body("accountList[0].accountId.accountNumber", notNullValue()).body("accountList", notNullValue());
		}
	}

	/**
	 *
	 * Cleanup operation for SQLite DB connection
	 *
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}

}