/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDateTime;

import static org.hamcrest.Matchers.equalTo;

/**
 * Tests CRUD operations of account details V2 for Workplace Account for nqdcFixedRateOfReturn element
 * Story #PFCP-18759
 *
 * @author a631781
 */
@Test(groups = {
        Tags.WORKPLACE,
        Tags.DETAILS,
        Tags.V1})
public class Workplace_Details_NQDC_V1_Test extends PAPBaseServiceTest {

    protected Workplace_Details_NQDC_V1_Test() {
        super(Services.Account);
    }

    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Workplace_Details_V1_Crud.class.getSimpleName()+ LocalDateTime.now();

    private static final String fsreqid = logTrackingId;

    private String ppid;

    // Test data
    private String mid;

    private String accId;

    private String accountNum;

    private String sourceSystem = AccountConstants.WORKPLACE;

    private String displayName;

    private String mnemonic;

    private String institutionName;

    private String asOfDate;

    private float value = 818.89f;

    private final float updatedValue = 426.85f;

    private String accountId;

    private String ownerId;

    private String accNum;

    private String assertRegCode;

    private float nqdcFixedRateOfReturn = 0.2f;
    private float updatedNqdcFixedRateOfReturn = 0.4f;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        p2TestDataUtil = new TestDataUtil();

        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_workplace_nqdc_test", oAuth);

        mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(mid);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        ppid = Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth);
        // Data setup
        accountsCommonTestData.setPpid(ppid);

        // Endpoint setup
        setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("sid", accountsCommonTestData.getSid());
        context.put("source", sourceSystem);
        context.put("poe", "NETBENEFITS");
        context.put("fescoLid", accountsCommonTestData.getSsn());

    }

    /**
     * Tests that account data is brought back for Workplace account.
     * <p>
     * Version V1
     */
    @Test
    public void getWorkplaceAccountInfo() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service v1
        response = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

        accountId = response.path("accountList[0].accountId.id");
        accountsCommonTestData.setAccountId1(accountId);
        accountNum = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        mnemonic = response.path("accountList[0].regCode.mnemonic");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        accountsCommonTestData.setValue1(value);
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
        ownerId = response.path("accountList[0].accountId.owner.id");
        accountsCommonTestData.setPpid(ownerId);
    }

    /**
     * Creates a new Workplace account
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount() {
        // Generate request body
        context.put("mid", accountsCommonTestData.getMid());
        context.put("sid", accountsCommonTestData.getSid());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("excludeExternalDataSources", true);
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNum);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        accNum = accountNum;
        assertRegCode = mnemonic;

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
                .body("accountList[0].accountId.accountNumber", equalTo(accNum))
                .body("accountList[0].regCode.mnemonic", equalTo(assertRegCode))
                .body("accountList[0].displayName", equalTo(displayName))
                .body("accountList[0].institutionName", equalTo(institutionName))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

        accId = response.path("accountList[0].accountId.id");
        accNum = response.path("accountList[0].accountId.accountNumber");

    }

    /**
     * Create Workplace account Details Request with nqdcFixedRateOfReturn.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void createAccountDetails() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("externalDataSources", true);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accNum);
        context.put("accId", accId);
        context.put("isInherited", false);
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "WorkplaceAccountDetails");
        context.put("_type", "WorkplaceAccountDetails");
        context.put("nqdcFixedRateOfReturn", nqdcFixedRateOfReturn);

        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

        // Call Account service
        response =
                request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
                        equalTo(accNum))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id", equalTo(accId))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.relationship",
                        equalTo("PRINCIPAL"))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountDetails.find{it.accountId.id=='" + accId
                                + "'}.nqdcFixedRateOfReturn",
                        equalTo(nqdcFixedRateOfReturn));

    }

    /**
     * Validate the Workplace account details after create.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", sourceSystem);
        context.put("accountNumber", accNum);
        context.put("accId", accId);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
                        equalTo(accNum))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id", equalTo(accId))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.relationship",
                        equalTo("PRINCIPAL"))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()))
                .body("accountDetails.find{it.accountId.id=='" + accId
                                + "'}.nqdcFixedRateOfReturn",
                        equalTo(nqdcFixedRateOfReturn));

    }

    /**
     * Update the account details nqdcFixedRateOfReturn for Workplace account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("externalDataSources", true);
        context.put("value", updatedValue);
        context.put("source", sourceSystem);
        context.put("accountNumber", accNum);
        context.put("accId", accId);
        context.put("isInherited", false);
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "WorkplaceAccountDetails");
        context.put("_type", "WorkplaceAccountDetails");
        context.put("nqdcFixedRateOfReturn", updatedNqdcFixedRateOfReturn);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
                        equalTo(accNum))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id", equalTo(accId))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.relationship",
                        equalTo("PRINCIPAL"))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountDetails.find{it.accountId.id=='" + accId
                                + "'}.nqdcFixedRateOfReturn",
                        equalTo(updatedNqdcFixedRateOfReturn));
    }

    /**
     * Validate the updated Workplace account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", sourceSystem);
        context.put("accountNumber", accNum);
        context.put("accId", accId);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
                        equalTo(accNum))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id", equalTo(accId))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.relationship",
                        equalTo("PRINCIPAL"))
                .body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountDetails.find{it.accountId.id=='" + accId
                                + "'}.nqdcFixedRateOfReturn",
                        equalTo(updatedNqdcFixedRateOfReturn));

    }

    /**
     * Delete the Workplace account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteAccountDetails() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", updatedValue);
        context.put("source", sourceSystem);
        context.put("accountNumber", accNum);
        context.put("accId", accId);
        context.put("isInherited", false);
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "WorkplaceAccountDetails");
        context.put("_type", "WorkplaceAccountDetails");

        request
                .body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        p2TestDataUtil.closeSQLiteConnection();
    }

}