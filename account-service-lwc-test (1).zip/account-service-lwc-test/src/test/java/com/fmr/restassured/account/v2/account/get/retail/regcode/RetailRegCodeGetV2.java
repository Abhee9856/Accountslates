/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.get.retail.regcode;

import static org.hamcrest.CoreMatchers.equalTo;

import static org.hamcrest.Matchers.*;

import io.restassured.specification.FilterableRequestSpecification;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;

import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;

/**
 * Tests for v2/account/get operation for retail accounts using DataProvider (for handling multiple regCodes).
 *
 * @author a653510
 * Updated by a608077 on 09/06/2021 to include: Changes for accountLegalAttributeDetails(PFCP-5456)
 * Updated by a608077 on 09/23/2021 to include: Changes for the new header for legal attributes(PFCP-6187)
 * Updated by a608077 on 08/08/2023 to include: Revisited regCodes and added more test data(PFCP-13401)
 */
@Test(groups = {
        Tags.RETAIL,
        Tags.ACCOUNT,
        Tags.V2,
        Tags.GET})
public class RetailRegCodeGetV2 extends PAPBaseServiceTest {

    protected RetailRegCodeGetV2() {
        super(Services.Account);
    }

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private final Header eeds = new Header("excludeExternalDataSources", "false");

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = RetailRegCodeGetV2.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    FilterableRequestSpecification frs;
    private VelocityContext context;
    private String mid;// = "RetailAccountV2TestMid";

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {

        final String oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        frs = (FilterableRequestSpecification) request;
        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(eeds);

    }

    /**
     * Test for getting Retail Accounts using data provider for reg codes
     *
     * Version V2
     */
    @Test(dataProvider = "getRetailAccountRegCodeGet", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void getRetailAccountsForRegCodes(final AccountRegCodeTestData data) {

        frs.removeHeader("user-retail-lid");
        frs.removeHeader("user-mid");

        request.given()
                .header(new Header("user-retail-lid", data.getSsn()))
                .header(new Header("user-mid", data.getMidInRequest()));

        // Data setup
        context = new VelocityContext();
        context.put("mnemonicFilter", data.getRegCode1());
        context.put("filterType", data.getFilterType());
        context.put("source", data.getSrcFilter());

        request = request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(empty()))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue())
                .body("accountList[0].regCode.mnemonic", equalTo(data.getRegCode1()))
                .body("accountList[0].accountLegalAttributeDetails.accountTypeCode", equalTo(data.getAccountTypeCode()))
                .body("accountList[0].accountLegalAttributeDetails.legalConstructCode", equalTo(data.getLegalConstructCode()))
                .body("accountList[0].accountLegalAttributeDetails.legalConstructModifierCode",
                        equalTo(data.getLegalConstructModifierCode()));
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }

}
