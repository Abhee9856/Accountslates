/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.hft.postTransferBalanceCal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.AccountConstants;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.hypofundtransfer.helpers.AccountHelper;
import com.fmr.restassured.hypofundtransfer.helpers.HypotheticalFundTransferPaths;

import java.time.ZonedDateTime;

import org.apache.velocity.VelocityContext;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;

/**
 * Creates funds transfer between Retail and Target accounts and
 * then fetches postTransferBalances through get/composite call
 * using header calculate-balances=fund-transfers
 *
 * @author a631781
 */
@Test(groups = {Tags.HYPO_FUND_TRANSFER, Tags.V2, Tags.COMPOSITE, Tags.AssetAllocation})
public class RetailToTargetAct_HFT_PostTransferBalance_V2 extends PAPBaseServiceTest {

    protected RetailToTargetAct_HFT_PostTransferBalance_V2() {
        super(Services.Account);
    }

    private AccountsCommonTestData accountsCommonTestData;

    private TestDataUtil testDataUtil;

    int startYear = ZonedDateTime.now().plusYears(1).getYear();

    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    private static String targetAccountNumber;

    private static String targetAccountId;

    private static final String isProductSuitable = "true";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = RetailToTargetAct_HFT_PostTransferBalance_V2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final float sourceMarketValue = 50000;

    private static final String assetClass = "TOTAL_EQUITY";

    private static final float netPercentageEquity = 0.40f;

    private static final float netPercentageFEqt = 0.15f;

    private static final String assetClassFEqt = "FOREIGN_EQUITY";

    private static final float netPercentageDomEqt = 0.25f;

    private static final String assetClassDomEqt = "DOMESTIC_EQUITY";

    private static final String assetClass1 = "BOND";

    private static final float netPercentage1Bond = 0.15f;

    private static final String assetClass2 = "CASH";

    private static final float netPercentage2Cash = 0.25f;

    private static final String assetClass3 = "OTHER";

    private static final float netPercentage3Other = 0.20f;

    private static float srcMktValFundingAccount, srcMktValDestAccount;

    private static final float domEquityAmount1 = 3000;

    private static final float foreignEquityAmount1 = 2000;

    private static final float bondAmount1 = 1000;

    private static final float cashAmount1 = 500;

    private static final float otherAmount1 = 2500;

    private static final float unknownAmount = 0;

    private final float totalAmount1 = domEquityAmount1 + foreignEquityAmount1 + bondAmount1 + cashAmount1
            + otherAmount1 + unknownAmount;

    private FilterableRequestSpecification frs;

    private static float fundingAccountAmount;

    //Context
    private final VelocityContext context = new VelocityContext();
    private final String host = AccountHelper.getQATestEnvHost();

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        String oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("retail_critical_regcode", oAuth);
        //Data setup
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("contribAmount", "6000.0");
        accountsCommonTestData.set("contribFreq", "YEARLY");
        accountsCommonTestData.set("withdrawAmount", "500.0");
        accountsCommonTestData.set("withdrawFreq", "YEARLY");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        accountsCommonTestData.set("updatedContribAmount", "500.0");
        accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
        accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(
                Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
        frs = (FilterableRequestSpecification) request;
    }

    /**
     * Get Retail account info from the backend. Save the account number.
     */
    public void getRetailAccountInfo() {
        //Setting Exclude external data sources flag
        this.frs.removeHeader("excludeExternalDataSources");
        this.request.given()
                .header(new Header("excludeExternalDataSources", "false"));

        // Generate request body
        context.put("source", AccountConstants.RETAIL);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(empty()));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(sourceMarketValue);
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void getCompositeAccount() {
        //Setting Exclude external data sources flag
        this.frs.removeHeader("excludeExternalDataSources");
        this.request.given()
                .header(new Header("excludeExternalDataSources", "true"));

        // Exclude external data
        context.put("sourceBasedRegistrationFilter", AccountConstants.RETAIL);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", empty());

    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccount")
    public void createCompositeAccount() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("accId", "");
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("contribValue", accountsCommonTestData.get("contribAmount"));
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("assetClass_T_Equity", assetClass);
        context.put("netPercentage_T_Equity", netPercentageEquity);
        context.put("assetClass_FOREIGN_EQUITY", assetClassFEqt);
        context.put("netPercentage_FE", netPercentageFEqt);
        context.put("assetClass_DOMESTIC_EQUITY", assetClassDomEqt);
        context.put("netPercentage_DE", netPercentageDomEqt);
        context.put("assetClass1", assetClass1);
        context.put("netPercentage1", netPercentage1Bond);
        context.put("assetClass3", assetClass2);
        context.put("netPercentage3", netPercentage2Cash);
        context.put("assetClass4", assetClass3);
        context.put("netPercentage4", netPercentage3Other);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        // Make post request
        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", not(empty()));

        //Save account number and ID
        accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
        accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
        srcMktValFundingAccount = response.path("accounts[0].account.sourceMarketValue.amount.value");
    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void getCompositeAccountAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.id=='"
                        + accountsCommonTestData.getAccountId1()
                        + "'}.details.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass + "'}.assetClass", equalTo(assetClass))
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.id=='"
                        + accountsCommonTestData.getAccountId1()
                        + "'}.details.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass + "'}.netPercentage", equalTo(netPercentageEquity))
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.id=='"
                        + accountsCommonTestData.getAccountId1()
                        + "'}.details.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass1 + "'}.assetClass", equalTo(assetClass1))
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.id=='"
                        + accountsCommonTestData.getAccountId1()
                        + "'}.details.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass1 + "'}.netPercentage", equalTo(netPercentage1Bond))

                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.id=='"
                        + accountsCommonTestData.getAccountId1()
                        + "'}.details.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass2 + "'}.assetClass", equalTo(assetClass2))
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.id=='"
                        + accountsCommonTestData.getAccountId1()
                        + "'}.details.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass2 + "'}.netPercentage", equalTo(netPercentage2Cash))
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.id=='"
                        + accountsCommonTestData.getAccountId1()
                        + "'}.details.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass3 + "'}.assetClass", equalTo(assetClass3))
                .body("accounts.find{it.details.retailAccountDetail.accountDetail.accountId.id=='"
                        + accountsCommonTestData.getAccountId1()
                        + "'}.details.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass3 + "'}.netPercentage", equalTo(netPercentage3Other));

    }

    /**
     * Create a new target account. Save the account ID and account number.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterCreate")
    public void createTargetAccount() {
        fundingAccountAmount = totalAmount1;

        context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("category", "INVESTOR_SELECTED_STRATEGY");
        context.put("isProductSuitable", isProductSuitable);
        context.put("withdrawalNeeds", "TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
        context.put("riskTolerance", "8");
        context.put("assetClass_T_Equity", assetClass);
        context.put("netPercentage_T_Equity", netPercentageEquity);
        context.put("assetClass_FOREIGN_EQUITY", assetClassFEqt);
        context.put("netPercentage_FE", netPercentageFEqt);
        context.put("assetClass_DOMESTIC_EQUITY", assetClassDomEqt);
        context.put("netPercentage_DE", netPercentageDomEqt);
        context.put("assetClass1", assetClass1);
        context.put("netPercentage1", netPercentage1Bond);
        context.put("assetClass3", assetClass2);
        context.put("netPercentage3", netPercentage2Cash);
        context.put("cashAmount1", cashAmount1);
        context.put("otherAmount1", otherAmount1);
        context.put("bondAmount1", bondAmount1);
        context.put("domEquityAmount1", domEquityAmount1);
        context.put("foreignEquityAmount1", foreignEquityAmount1);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", empty())
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("targetAccounts[0].fundingAccounts[0].amount.value", equalTo(fundingAccountAmount));

        //Save target account number and ID
        targetAccountNumber = response.path("targetAccounts[0].accountId.accountNumber");
        targetAccountId = response.path("targetAccounts[0].accountId.id");
        srcMktValDestAccount = response.path("targetAccounts[0].sourceMarketValue.amount.value");
    }

    /**
     * Get details of Fund Transfer between Retail to Retail account after Create FT
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void getFundTransfersRetail2Retail() {
        response = request.baseUri(host).log().ifValidationFails().get(HypotheticalFundTransferPaths.HYPOFUNDTRNDFR_V1_PATH);
        validateResponse();
    }

    @Test(dependsOnMethods = "getFundTransfersRetail2Retail")
    public void getTransfersFromComposite() {
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeader("excludeExternalDataSources");

        context.put("sourceBasedRegistrationFilter", AccountConstants.RETAIL);
        context.put("includeFundTransferDetails", true);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails()
                .given()
                .header(new Header("excludeExternalDataSources", "true"))
                .header(new Header("calculate-balances", "fund-transfers, equity-exposure"))
                .post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        validatePostTransferBalanceFundingAccount();
        validatePostTransferBalanceDestinationAccount();
        validateResponse();

    }

    private void validatePostTransferBalanceFundingAccount() {
        //Expected Amounts
        float expectedPTOtherAmt =
                AccountUtil.postTransferAstAllocationAmountFundingAct(srcMktValFundingAccount, totalAmount1,
                        netPercentage3Other, otherAmount1);
        float expectedPTBondAmt =
                AccountUtil.postTransferAstAllocationAmountFundingAct(srcMktValFundingAccount, totalAmount1,
                        netPercentage1Bond, bondAmount1);
        float expectedPTCashAmt =
                AccountUtil.postTransferAstAllocationAmountFundingAct(srcMktValFundingAccount, totalAmount1,
                        netPercentage2Cash, cashAmount1);
        float expectedPTDomesticAmt =
                AccountUtil.postTransferAstAllocationAmountFundingAct(srcMktValFundingAccount, totalAmount1,
                        netPercentageDomEqt, domEquityAmount1);
        float expectedPTForeignAmt =
                AccountUtil.postTransferAstAllocationAmountFundingAct(srcMktValFundingAccount, totalAmount1,
                        netPercentageFEqt, foreignEquityAmount1);

        // Actual Amounts
        float actualPTOtherAmt =
                response.path("postTransferBalances.find{it.accountId.id=='" + accountsCommonTestData
                        .getAccountId1() + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='OTHER'}.amount");
        float actualPTBondAmt =
                response.path("postTransferBalances.find{it.accountId.id=='" + accountsCommonTestData
                        .getAccountId1() + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='BOND'}.amount");
        float actualPTCashAmt =
                response.path("postTransferBalances.find{it.accountId.id=='" + accountsCommonTestData
                        .getAccountId1() + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='CASH'}.amount");
        float actualPTDomesticAmt =
                response.path("postTransferBalances.find{it.accountId.id=='" + accountsCommonTestData
                        .getAccountId1() + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='DOMESTIC_EQUITY'}.amount");
        float actualPTForeignAmt =
                response.path("postTransferBalances.find{it.accountId.id=='" + accountsCommonTestData
                        .getAccountId1() + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='FOREIGN_EQUITY'}.amount");

        //Expected netPercentage
        float expectedPTOtherPct = expectedPTOtherAmt / srcMktValFundingAccount;
        float expectedPTBondPct = expectedPTBondAmt / srcMktValFundingAccount;
        float expectedPTCashPct = expectedPTCashAmt / srcMktValFundingAccount;
        float expectedPTDomesticPct = expectedPTDomesticAmt / srcMktValFundingAccount;
        float expectedPTForeignPct = expectedPTForeignAmt / srcMktValFundingAccount;

        // Actual netPercentage
        float actualPTOtherPct =
                response.path("postTransferBalances.find{it.accountId.id=='" + accountsCommonTestData
                        .getAccountId1() + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='OTHER'}.netPercentage");
        float actualPTBondPct =
                response.path("postTransferBalances.find{it.accountId.id=='" + accountsCommonTestData
                        .getAccountId1() + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='BOND'}.netPercentage");
        float actualPTCashPct =
                response.path("postTransferBalances.find{it.accountId.id=='" + accountsCommonTestData
                        .getAccountId1() + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='CASH'}.netPercentage");
        float actualPTDomesticPct =
                response.path("postTransferBalances.find{it.accountId.id=='" + accountsCommonTestData
                        .getAccountId1() + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage");
        float actualPTForeignPct =
                response.path("postTransferBalances.find{it.accountId.id=='" + accountsCommonTestData
                        .getAccountId1() + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage");
        // Assertion
        assertThat(expectedPTOtherAmt).isCloseTo(actualPTOtherAmt, within(0.9f));
        assertThat(expectedPTBondAmt).isCloseTo(actualPTBondAmt, within(0.9f));
        assertThat(expectedPTCashAmt).isCloseTo(actualPTCashAmt, within(0.9f));
        assertThat(expectedPTDomesticAmt).isCloseTo(actualPTDomesticAmt, within(0.9f));
        assertThat(expectedPTForeignAmt).isCloseTo(actualPTForeignAmt, within(0.9f));
        assertThat(expectedPTOtherPct).isCloseTo(actualPTOtherPct, within(0.9f));
        assertThat(expectedPTBondPct).isCloseTo(actualPTBondPct, within(0.9f));
        assertThat(expectedPTCashPct).isCloseTo(actualPTCashPct, within(0.9f));
        assertThat(expectedPTDomesticPct).isCloseTo(actualPTDomesticPct, within(0.9f));
        assertThat(expectedPTForeignPct).isCloseTo(actualPTForeignPct, within(0.9f));

    }

    private void validatePostTransferBalanceDestinationAccount() {
        //Expected Amounts
        float expectedPTOtherAmt =
                AccountUtil.postTransferAstAllocationAmountTargetAct(srcMktValDestAccount, netPercentage3Other);
        float expectedPTBondAmt =
                AccountUtil.postTransferAstAllocationAmountTargetAct(srcMktValDestAccount, netPercentage1Bond);
        float expectedPTCashAmt =
                AccountUtil.postTransferAstAllocationAmountTargetAct(srcMktValDestAccount, netPercentage2Cash);
        float expectedPTDomesticAmt =
                AccountUtil.postTransferAstAllocationAmountTargetAct(srcMktValDestAccount, netPercentageDomEqt);
        float expectedPTForeignAmt =
                AccountUtil.postTransferAstAllocationAmountTargetAct(srcMktValDestAccount, netPercentageFEqt);
        System.out.println(" other Amount ##" + expectedPTOtherAmt);

        // Actual Amounts
        float actualPTOtherAmt =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + targetAccountNumber
                        + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='OTHER'}.amount");
        float actualPTBondAmt =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + targetAccountNumber
                        + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='BOND'}.amount");
        float actualPTCashAmt =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + targetAccountNumber
                        + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='CASH'}.amount");
        float actualPTDomesticAmt =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + targetAccountNumber
                        + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='DOMESTIC_EQUITY'}.amount");
        float actualPTForeignAmt =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + targetAccountNumber
                        + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='FOREIGN_EQUITY'}.amount");

        // Actual netPercentage
        float actualPTOtherPct =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + targetAccountNumber
                        + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='OTHER'}.netPercentage");
        float actualPTBondPct =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + targetAccountNumber
                        + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='BOND'}.netPercentage");
        float actualPTCashPct =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + targetAccountNumber
                        + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='CASH'}.netPercentage");
        float actualPTDomesticPct =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + targetAccountNumber
                        + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage");
        float actualPTForeignPct =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + targetAccountNumber
                        + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage");
        // Assertion
        assertThat(expectedPTOtherAmt).isCloseTo(actualPTOtherAmt, within(0.9f));
        assertThat(expectedPTBondAmt).isCloseTo(actualPTBondAmt, within(0.9f));
        assertThat(expectedPTCashAmt).isCloseTo(actualPTCashAmt, within(0.9f));
        assertThat(expectedPTDomesticAmt).isCloseTo(actualPTDomesticAmt, within(0.9f));
        assertThat(expectedPTForeignAmt).isCloseTo(actualPTForeignAmt, within(0.9f));
        assertThat(netPercentage3Other).isCloseTo(actualPTOtherPct, within(0.9f));
        assertThat(netPercentage1Bond).isCloseTo(actualPTBondPct, within(0.9f));
        assertThat(netPercentage2Cash).isCloseTo(actualPTCashPct, within(0.9f));
        assertThat(netPercentageDomEqt).isCloseTo(actualPTDomesticPct, within(0.9f));
        assertThat(netPercentageFEqt).isCloseTo(actualPTForeignPct, within(0.9f));

    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getTransfersFromComposite")
    public void deleteCompositeAccount() {
        //Exclude external data sources
        this.frs.removeHeader("excludeExternalDataSources");
        this.request.given()
                .header(new Header("excludeExternalDataSources", "true"));
        // Generate new request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("id", accountsCommonTestData.getAccountId1());
        request.body(IOUtil.generateJsonRequest(context,
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("isEmpty()", Matchers.is(true));
    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void deleteSecondCompositeAccount() {
        //Target account fields
        context.put("targetAccountId", targetAccountId);
        context.put("targetAccountNumber", targetAccountNumber);
        context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("isProductSuitable", isProductSuitable);
        context.put("transferType", "FULL_BALANCE");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("isEmpty()", Matchers.is(true));

    }

    /**
     * Call delete and confirm that no accounts come back in the response.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void getCompositeAccountAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.HTTP_200)
                .body("accounts", empty());
    }

    private void validateResponse() {

        this.response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("transfers", CoreMatchers.not(Matchers.empty()))
                .body("transfers[0].fundingDetails[0].fundingAccountNumber", notNullValue())
                .body("transfers[0].fundingDetails[0].fundingAccountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("transfers[0].destinationAccountNumber", notNullValue())
                .body("transfers[0].destinationAccountNumber",
                        equalTo(targetAccountNumber))
                .body("transfers[0].fundingDetails[0].bondAmount", notNullValue())
                .body("transfers[0].fundingDetails[0].transferType", equalTo("FULL_BALANCE"))
                .body("transfers[0].fundingDetails[0].totalAmount", notNullValue());

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}