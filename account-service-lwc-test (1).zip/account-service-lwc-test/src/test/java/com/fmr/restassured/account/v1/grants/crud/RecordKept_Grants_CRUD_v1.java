/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.grants.crud;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsGrantsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountGrantsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;

/**
 * Tests for RecordKept grants CRUD v1
 * Test Flow:
 * o	Create Principal, Scenario and Identity
 * o	Create workplace account and get account with grants before create
 * o	Create grants then get account with grants after create
 * o	Update grants then get account with grants after update
 * o	Delete grants then get account with grants after delete
 * o	Delete account then get account after delete
 *
 * @author a608077
 */
@Test(groups = {
		Tags.CRITICAL,
		Tags.GRANTS,
		Tags.ACCOUNT,
		Tags.V1,
		Tags.CRUD})
public class RecordKept_Grants_CRUD_v1 extends PAPBaseServiceTest
{

    private String mid;

    private String ssn;

    private String ppid;

    private static final String PRODUCT_CODE = "ECP";

    private static final String CATEGORY_CODE = "DEF";

    private static final String sourceSystem = "RETAIL";

    private static final String ENTITY_ID = "G5960L103";

    private static final String ENTITY_TYPE_CODE = "CUSIP";

    private static final String WORKPLACE_CLIENT_ID = "000752437";

    private VelocityContext context;

    private AccountGrantsTestData grantsData;

    private static final String LOG_TRACKING_ID = RecordKept_Grants_CRUD_v1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    String oAuthToken = AccountUtil.getOauthToken();

    // Data setup
    final AccountsCommonTestData accountsCommonTestData =
		    TestDataUtil.populateRegressionTestData("account_grants_rk", oAuthToken);

    protected RecordKept_Grants_CRUD_v1()
    {
	super(Services.Account);
    }

    private boolean debug = false;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	debug = Boolean.valueOf(System.getProperty("debug"));

	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);
	if (debug)
	{
	    request.filters(new RequestLoggingFilter(), new ResponseLoggingFilter());
	}

	accountsCommonTestData.setMid("RetailAccountGrantsV1TestMid");

	testDataUtil = new TestDataUtil();
	grantsData = new AccountGrantsTestData();
	mid = accountsCommonTestData.getMid();
	ssn = accountsCommonTestData.getSsn();

	DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuthToken, "true");

	grantsData.setMid(mid);
	grantsData.setProductCode(PRODUCT_CODE);
	grantsData.setCategoryCode(CATEGORY_CODE);
	grantsData.setEntityId(ENTITY_ID);
	grantsData.setEntityTypeCode(ENTITY_TYPE_CODE);
	grantsData.setSource(sourceSystem);
	grantsData.setWorkplaceClientId(WORKPLACE_CLIENT_ID);
	String stockOptionId = "COVASO-07";
	grantsData.setStockOptionId(stockOptionId);
	String grantType = "NQ";
	grantsData.setGrantType(grantType);
	String grantDate = "2010-12-01T00:00:00.000+0000";
	grantsData.setGrantDate(grantDate);
	int sequence = 1;
	grantsData.setSequence(sequence);

	ppid = Identity.createPrincipalWithEntity(AccountConstants.MID, mid, grantsData.getProductCode(),
			grantsData.getCategoryCode(),
			grantsData.getEntityTypeCode(), grantsData.getEntityId(), oAuthToken);

	String scenarioId = Scenario.createScenarioWithProductCodeEntityIdEntityCode(mid, grantsData.getProductCode(),
			grantsData.getCategoryCode(),
			grantsData.getEntityId(),grantsData.getEntityTypeCode(), oAuthToken, "test");

	Identity.createHouseholdIdentityWithEntityIDandEntityCode(mid, ppid, ssn, oAuthToken,
			"PRINCIPAL", grantsData.getProductCode(), grantsData.getCategoryCode(),
			grantsData.getEntityId(), grantsData.getEntityTypeCode(), scenarioId,
			"Regression Manual GrantsV1");

	grantsData.setPpid(ppid);
	grantsData.setScenarioId(scenarioId);

	// Populate request variables
	context = new VelocityContext();
	context.put("retailLid", ssn);
	context.put("fescoLid", ssn);
	context.put("mid", grantsData.getMid());
	context.put("source", grantsData.getSource());
	context.put("pointOfEntry", "RETAIL");
	context.put("productCode", grantsData.getProductCode());
	context.put("categoryCode", grantsData.getCategoryCode());
	context.put("entityId", grantsData.getEntityId());
	context.put("entityTypeCode", grantsData.getEntityTypeCode());
	context.put("scenarioId", grantsData.getScenarioId());
	context.put("workplaceClientId", grantsData.getWorkplaceClientId());

    }

    /**
     * Tests that account data is brought back for retail account.
     * <p>
     * Version v1
     */
    @Test
    public void getRetailAccountInfo()
    {

	//Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	//Call Account service v1
	response = request.post(AccountsPaths.GET_ACCOUNT_V1);

	//Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	response.then().log().ifValidationFails().body("userIdentifier.retailLid", equalTo(ssn))
			.body("accountList", not(emptyArray()));

	grantsData.setAccNumber(response.path("accountList[1].accountId.accountNumber"));
	accountsCommonTestData.setDisplayName1(response.path("accountList[1].displayName"));
	accountsCommonTestData.setMnemonic1(response.path("accountList[1].regCode.mnemonic"));
	accountsCommonTestData.setValue1(response.path("accountList[1].sourceMarketValue.amount.value"));
	accountsCommonTestData.setInstitutionName1(response.path("accountList[1].institutionName"));
	accountsCommonTestData.setAsOfDate1(response.path("accountList[1].sourceMarketValue.asOfDate"));
    }

    /**
     * Create the account
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount()
    {

	context.put("ppid", ppid);
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accountNumber", grantsData.getAccNumber());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

	response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);

	response.then().log().ifValidationFails()
			.statusCode(200).body("resultCode", equalTo(true))
			.body("accountList[0].accountId.id", not(nullValue()))
			.body("accountList[0].accountId", not(nullValue()));
	grantsData.setAccId(response.path("accountList[0].accountId.id"));

    }

    /**
     * Tests that updated data is brought back from account/get
     * <p>
     * Version v1
     */
    @Test(dependsOnMethods = "createRetailAccount")
    public void verifyRetailAccountInfoAfterCreate()
    {

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	// Call Account service
	response = request.post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200).body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(mid))
			.body("accountList", not(emptyArray()))
			.body("accountList.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.accountId.accountNumber", equalTo(grantsData.getAccNumber()))
			.body("accountList.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountId.owner.id",
					equalTo(ppid))
			.body("accountList.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.accountId.sourceSystem", equalTo(sourceSystem))
			.body("accountList.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.sourceMarketValue.amount.value",
					equalTo(accountsCommonTestData.getValue1()))
			.body("accountList.find{it.accountId.id=='" + grantsData.getAccId() + "'}.regCode.mnemonic",
					equalTo(accountsCommonTestData.getMnemonic1()));

    }

    /**
     * Create the account grant
     */
    @Test(dependsOnMethods = "verifyRetailAccountInfoAfterCreate")
    public void createAccountGrants()
    {

	context.put("retailLid", ssn);
	context.put("accId", grantsData.getAccId());
	context.put("accountNumber", grantsData.getAccNumber());
	context.put("grantDate", grantsData.getGrantDate());
	context.put("stockOptionId", grantsData.getStockOptionId());
	context.put("grantType", grantsData.getGrantType());
	context.put("grantSequence", grantsData.getSequence());
	context.put("scenarioId", grantsData.getScenarioId());
	context.put("entityId", grantsData.getEntityId());
	context.put("entityTypeCode", grantsData.getEntityTypeCode());
	context.put("grantPrice", 22.82f);
	context.put("vestedShares", 0.0f);
	context.put("unvestedShares", 0.0f);
	context.put("vestedValue", 0.0f);
	context.put("unvestedValue", 0.0f);
	context.put("grantSequence", grantsData.getSequence());
	context.put("expirationDate", "2009-02-11");
	context.put("vestDate", "2002-02-12");
	context.put("vestShares", 2243.0f);
	context.put("vestSequence", grantsData.getSequence());
	context.put("distributionDate", "2002-02-12");
	context.put("performancePercentage", 5.0f);

	//Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_CREATE_TEMPLATE));

	//Run test
	response = request.post(AccountsGrantsPaths.CREATE_ACCOUNTS_GRANTS_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(grantsData.getMid()))
			//Account Grants v1 doesn't return a response body, even on successful creation
			.body("accountGrants", not(emptyArray()));

    }

    /**
     * Tests that created grants are brought back from account/grants/get
     */

    @Test(dependsOnMethods = "createAccountGrants")
    public void verifyAfterCreate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_GET_TEMPLATE));

	//Run test
	response = request.post(AccountsGrantsPaths.GET_ACCOUNTS_GRANTS_V1);

	// Assert on response
	this.response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(grantsData.getMid()))
			.body("accountGrants", not(emptyArray()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountId.id",
					equalTo(grantsData.getAccId()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.accountId.accountNumber", equalTo(grantsData.getAccNumber()))
			/*
			the below 4 properties act as a key to match RK grants from SPS backend
			and then override and return these as part of 'overriddenGrant' object
			*/
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.stockOptionId",
					equalTo(grantsData.getStockOptionId()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.grantType",
					equalTo(grantsData.getGrantType()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.grantDate",
					equalTo(grantsData.getGrantDate()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.sequence",
					equalTo(grantsData.getSequence()))

			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.grantPrice.value",
					equalTo(22.82f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.recordKeptAccountGrants[0].overriddenGrant.vestedShares", equalTo(0.0f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.recordKeptAccountGrants[0].overriddenGrant.unvestedShares", equalTo(0.0f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.vestedValue.value",
					equalTo(0.0f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.unvestedValue.value",
					equalTo(0.0f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.expirationDate",
					equalTo("2009-02-11T00:00:00.000+0000"))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.vests[0].vestDate",
					equalTo("2002-02-12T00:00:00.000+0000"))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.vests[0].vestShares",
					equalTo(2243.0f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.recordKeptAccountGrants[0].overriddenGrant.vests[0].sequence", equalTo(1))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.vests[0].distributionDate",
					equalTo("2002-02-12T00:00:00.000+0000"))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.vests[0].performancePercentage",
					equalTo(5.0f));

    }

    /**
     * Update the account grants info
     */
    @Test(dependsOnMethods = "verifyAfterCreate")
    public void updateAccountGrants()
    {

	context.put("retailLid", ssn);
	context.put("accId", grantsData.getAccId());
	context.put("accountNumber", grantsData.getAccNumber());
	context.put("grantDate", grantsData.getGrantDate());
	context.put("stockOptionId", grantsData.getStockOptionId());
	context.put("grantType", grantsData.getGrantType());
	context.put("grantSequence", grantsData.getSequence());
	context.put("scenarioId", grantsData.getScenarioId());
	context.put("entityId", grantsData.getEntityId());
	context.put("entityTypeCode", grantsData.getEntityTypeCode());
	context.put("grantPrice", 22.82f);
	context.put("vestedShares", 5.0f);
	context.put("unvestedShares", 4.0f);
	context.put("vestedValue", 250.0f);
	context.put("unvestedValue", 200.0f);
	context.put("grantSequence", grantsData.getSequence());
	context.put("expirationDate", "2009-02-11");
	context.put("vestDate", "2002-02-12");
	context.put("vestShares", 2243.0f);
	context.put("vestSequence", grantsData.getSequence());
	context.put("distributionDate", "2002-02-12");
	context.put("performancePercentage", 5.0f);

	//Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_UPDATE_TEMPLATE));

	//Run test
	response = request.post(AccountsGrantsPaths.UPDATE_ACCOUNTS_GRANTS_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(grantsData.getMid()))
			//Account Grants v1 doesn't return a response body, even on successful creation
			.body("accountGrants", not(emptyArray()));

    }

    /**
     * Tests that created grants are brought back from account/grants/get
     */

    @Test(dependsOnMethods = "updateAccountGrants")
    public void verifyAfterUpdate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_GET_TEMPLATE));

	//Run test
	response = request.post(AccountsGrantsPaths.GET_ACCOUNTS_GRANTS_V1);

	// Assert on response
	this.response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(grantsData.getMid()))
			.body("accountGrants", not(emptyArray()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId() + "'}.accountId.id",
					equalTo(grantsData.getAccId()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.accountId.accountNumber", equalTo(grantsData.getAccNumber()))
			/*
			the below 4 properties act as a key to match RK grants from SPS backend
			and then override and return these as part of 'overriddenGrant' object
			*/
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.stockOptionId",
					equalTo(grantsData.getStockOptionId()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.grantType",
					equalTo(grantsData.getGrantType()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.grantDate",
					equalTo(grantsData.getGrantDate()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.sequence",
					equalTo(grantsData.getSequence()))

			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.grantPrice.value",
					equalTo(22.82f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.recordKeptAccountGrants[0].overriddenGrant.vestedShares", equalTo(5.0f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.recordKeptAccountGrants[0].overriddenGrant.unvestedShares", equalTo(4.0f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.vestedValue.value",
					equalTo(250.0f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.unvestedValue.value",
					equalTo(200.0f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.expirationDate",
					equalTo("2009-02-11T00:00:00.000+0000"))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.vests[0].vestDate",
					equalTo("2002-02-12T00:00:00.000+0000"))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.vests[0].vestShares",
					equalTo(2243.0f))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.recordKeptAccountGrants[0].overriddenGrant.vests[0].sequence", equalTo(1))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.vests[0].distributionDate",
					equalTo("2002-02-12T00:00:00.000+0000"))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
							+ "'}.recordKeptAccountGrants[0].overriddenGrant.vests[0].performancePercentage",
					equalTo(5.0f));

    }

    /**
     * Delete account grants
     */
    @Test(dependsOnMethods = "verifyAfterUpdate")
    public void deleteAccountGrants()
    {

	context.put("retailLid", ssn);
	context.put("accId", grantsData.getAccId());
	context.put("accountNumber", grantsData.getAccNumber());
	context.put("grantDate", grantsData.getGrantDate());
	context.put("stockOptionId", grantsData.getStockOptionId());
	context.put("grantType", grantsData.getGrantType());
	context.put("grantSequence", grantsData.getSequence());
	context.put("scenarioId", grantsData.getScenarioId());
	context.put("entityId", grantsData.getEntityId());
	context.put("entityTypeCode", grantsData.getEntityTypeCode());
	context.put("grantPrice", 22.82f);
	context.put("vestedShares", 5.0f);
	context.put("unvestedShares", 4.0f);
	context.put("vestedValue", 250.0f);
	context.put("unvestedValue", 200.0f);
	context.put("grantSequence", grantsData.getSequence());
	context.put("expirationDate", "2009-02-11");
	context.put("vestDate", "2002-02-12");
	context.put("vestShares", 2243.0f);
	context.put("vestSequence", grantsData.getSequence());
	context.put("distributionDate", "2002-02-12");
	context.put("performancePercentage", 5.0f);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_DELETE_TEMPLATE));

	//Run test
	response = request.post(AccountsGrantsPaths.DELETE_ACCOUNTS_GRANTS_V1);

	// Assert on response
	this.response.then().log().ifValidationFails()
			.statusCode(200).body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(grantsData.getMid()))
			.body("responseDiagnostic.resultDetail", equalTo("Account Grants are deleted."));
    }

    @Test(dependsOnMethods = "deleteAccountGrants")
    public void verifyAfterDeleteGrants()
    {

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GRANTS_GET_TEMPLATE));

	//Run test
	response = request.post(AccountsGrantsPaths.GET_ACCOUNTS_GRANTS_V1);

	// Assert on response
	this.response.then().log().ifValidationFails()
			.statusCode(200).body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(grantsData.getMid()))
			.body("accountsGrants.find{it.accountId.id=='" + grantsData.getAccId()
					+ "'}.recordKeptAccountGrants[0].overriddenGrant", equalTo(null));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}
