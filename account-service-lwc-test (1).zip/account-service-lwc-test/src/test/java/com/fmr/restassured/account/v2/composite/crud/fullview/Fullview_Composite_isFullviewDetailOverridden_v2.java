/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.fullview;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;

import io.restassured.specification.FilterableRequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.assertj.core.api.Assertions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

/**
 * Tests Composite Details V2 for isFullviewDetailOverridden combinations for Fullview Account
 *
 * @author a631781
 */
@Test
public class Fullview_Composite_isFullviewDetailOverridden_v2 extends PAPBaseServiceTest {
    protected Fullview_Composite_isFullviewDetailOverridden_v2() {
        super(Services.Account);
    }

    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Fullview_Composite_isFullviewDetailOverridden_v2.class);


    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountsCommonTestData;

    private String accountNumber;

    private String ppid;

    private String acctRoot;

    private final String details = "details.fullviewAccountDetail.accountDetail.";


    private VelocityContext context;
    private String mid;
    private TestDataUtil testDataUtil;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private String source = "FULLVIEW";
    private String mnemonic;

    private String accountId;

    private String displayName;

    private float value;

    private String institutionName;

    private String asOfDate;
    private float historicMarketValue = 7777f;
    private float historicMarketValueResponse;
    private Boolean isFullviewDetailOverridden;
    private Boolean isFullviewDetailOverriddenReq;
    private float detailValue = 111f;
    private FilterableRequestSpecification frs;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Fullview", oAuth);
        testDataUtil = new TestDataUtil();

        mid = accountsCommonTestData.getMid();

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(oAuth);
        request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("log-tracking-id", "AP136091PFCP"));
        // Populate request variables
        context = new VelocityContext();
        frs = (FilterableRequestSpecification) request;

    }

    /**
     * Create Fullview composite account Details with different combination of isFullviewDetailOverridden from DataProvider.
     * <p>
     * Version V2
     */
    @Test(dataProvider = "getFullViewData",
            dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data) {
        getFullviewAccountInfo();
        createCompositeAccountFullviewV2();
        getCompositeAccountFullviewV2AfterCreate();
        updateCompositeAccountFullviewV2(data);
        getCompositeAccountFullviewV2AfterUpdate();
        deleteCompositeAccountFullviewV2();
        getCompositeAccountFullviewV2AfterDelete();

    }

    //Get Fullview Account
    private void getFullviewAccountInfo() {
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "false"));
        // Generate request body
        context.put("source", source);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()));

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        source = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Description: Validates the account composite response after a Composite create
     */
    private void createCompositeAccountFullviewV2() {
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "true"));
        // Generate request body
        context.put("accountNumber", accountNumber);
        context.put("accId", "");
        context.put("source", source);
        context.put("ppid", ppid);
        context.put("mnemonic", mnemonic);
        context.put("sourceSystem2", source);
        context.put("value", value);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);
        context.put("detailValue", detailValue);
        context.put("isFullviewDetailOverridden", "");
        context.put("historicMarketValue", "");
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails()
                .post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accountNumber + "'}.";

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(ppid))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(mnemonic))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(value))
                .body(acctRoot + details, notNullValue());


        accountId = response.path("accounts[0].account.accountId.id");

    }

    /**
     * Description: Validates the account composite response after a create
     */
    private void getCompositeAccountFullviewV2AfterCreate() {

        //Generate request body
        context.put("sourceBasedRegistrationFilter", source);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(ppid))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(mnemonic))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(value))
                .body(acctRoot + "details.fullviewAccountDetail.historicMarketValue.amount.value", equalTo(value));

    }

    /**
     * Description: Validates the account composite response after an update
     */
    private void updateCompositeAccountFullviewV2(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("accId", accountId);
        context.put("accountNumber", accountNumber);
        context.put("source", source);
        context.put("ppid", ppid);
        context.put("mnemonic", mnemonic);
        context.put("sourceSystem2", source);
        context.put("value", value);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);
        context.put("historicMarketValue", historicMarketValue);
        context.put("detailValue", detailValue);
        if (data.getIsFullviewDetailOverridden().equals("Y")) {
            isFullviewDetailOverriddenReq = true;
            isFullviewDetailOverridden = true;

        } else if (data.getIsFullviewDetailOverridden().equals("N")) {
            isFullviewDetailOverriddenReq = false;
            isFullviewDetailOverridden = false;
        } else {
            isFullviewDetailOverriddenReq = null;
            isFullviewDetailOverridden = false;
        }

        context.put("isFullviewDetailOverridden", isFullviewDetailOverriddenReq);
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails()
                .post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(ppid))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(mnemonic))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(value));
        historicMarketValueResponse = response.path(acctRoot + "details.fullviewAccountDetail.historicMarketValue.amount.value");
        if (isFullviewDetailOverridden) {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(historicMarketValue);
        } else {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(value);
        }
    }

    /**
     * Description: Validates the account composite response after an update
     */
    private void getCompositeAccountFullviewV2AfterUpdate() {
        //Generate request body
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "false"));
        context.put("sourceBasedRegistrationFilter", source);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountNumber))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(ppid))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(mnemonic))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(value));
        if (isFullviewDetailOverridden) {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(historicMarketValue);
        } else {
            Assertions.assertThat(historicMarketValueResponse).isEqualTo(value);
        }
    }

    /**
     * Description: Validates the account composite response after a delete
     */
    private void deleteCompositeAccountFullviewV2() {
        //Generate request body
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "true"));
        context.put("accId", accountId);
        context.put("accountNumber", accountNumber);
        context.put("source", source);
        context.put("ppid", ppid);
        context.put("mnemonic", mnemonic);
        context.put("sourceSystem2", source);
        context.put("value", value);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = response.jsonPath().getString("$");
        assertThat(emptyResponse, equalTo("[:]"));
    }

    /**
     * Description: Validates an empty account list when calling get account composite Fullview after delete
     */
    private void getCompositeAccountFullviewV2AfterDelete() {
        //Generate request body
        context.put("sourceBasedRegistrationFilter", source);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

}
