/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.contributions.set;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.equalTo;

/**
 * Tests negative scenarios for Set/Get operation for Workplace contributions against V2.
 *
 * @author a608077
 *
 */
@Test(groups = {
        Tags.WORKPLACE,
        Tags.CONTRIBUTIONS,
        Tags.V2})
public class Workplace_Contributions_Set_v2_Negative extends PAPBaseServiceTest {
    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private TestDataUtil testDataUtil;
    //Context
    private final VelocityContext context = new VelocityContext();

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Workplace_Contributions_Set_v2.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;


    protected Workplace_Contributions_Set_v2_Negative()
    {
        super(Services.Account);
    }

    /**
     * Initialization method used to:
     * 1. Get the default SSN and use it to retrieve the MID.
     * 2. Set the Base URI
     * 3. Get the account service operation paths.
     * 4. Build the request header (with OAuth token).
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
        String oAuth = AccountUtil.getOauthToken();

        testDataUtil= new TestDataUtil();

        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_CRUD_RK_Workplace_69",oAuth);

        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(
                Identity.createHouseholdIdentity(AccountConstants.MID, accountsCommonTestData.getMid(), oAuth));

        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                //.header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("return-workplace-overridden-contributions", "true"));

    }

    /**
     * Get Workplace account info from the backend. Save the account number.
     */
    @Test
    public void getWorkplaceAccountInfo()
    {
        // Generate request body
        context.put("source", AccountConstants.WORKPLACE);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(empty()));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }
    /**
     * Create the Workplace account. Save the account id.
     * Version V2
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount() {

        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList", not(empty()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()));

        // Gets and saves the CFP account ID
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
        context.put("accId", accountsCommonTestData.getAccountId1());
    }
    /**
     * Set account contributions with 2 same contributions using- contribTaxType,contribType,contributor,electionCd & accountId
     * Version V2
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void setContributions() {

        // Generate request body
        context.put("contribValue",1426.85);
        context.put("contribBasisTypeCd","BASECMMSN" );
        context.put("contributionName","BEFORE-TAX" );
        context.put("electionCd","12");
        context.put("valueType", "PERCENT");
        context.put("contribType","SIMPLE");
        context.put("contribTaxType","PRE_TAX");
        context.put("contribLevelType","FAMILY");
        context.put("frequency","MONTHLY");
        context.put("contributor","INDIVIDUAL");

        //contribution2
        context.put("contribValue",1426.85);
        context.put("contribBasisTypeCd2","BASECMMSN" );
        context.put("contributionName2","BEFORE-TAX" );
        context.put("electionCd2","12");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountConstants.SET_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(422)
                .body("responseDiagnostic[0].detail", equalTo("Could not process contributions data to the database, while performing a set operation"));


    }
    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}
