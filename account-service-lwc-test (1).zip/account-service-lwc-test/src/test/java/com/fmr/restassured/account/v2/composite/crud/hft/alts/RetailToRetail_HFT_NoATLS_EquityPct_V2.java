/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.hft.alts;

import com.fmr.ast.platform.account.domain.DestinationAccountType;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.AccountConstants;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.hypofundtransfer.helpers.AccountHelper;
import com.fmr.restassured.hypofundtransfer.helpers.CreateAccount;
import com.fmr.restassured.hypofundtransfer.helpers.HypotheticalFundTransferConstants;
import com.fmr.restassured.hypofundtransfer.helpers.HypotheticalFundTransferPaths;

import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.within;
import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.CoreMatchers.notNullValue;

/**
 * Creates funds transfer between two retail accounts, with no ALTS and then fetches postTransferBalances through get/composite call
 * using header calculate-balances="fund-transfers, equity-exposure", and Calculates Equity Percentage at Details and PostTransferBalance level
 *
 * @author a631781
 */
public class RetailToRetail_HFT_NoATLS_EquityPct_V2 extends PAPBaseServiceTest {

    protected RetailToRetail_HFT_NoATLS_EquityPct_V2() {
        super(Services.Account);
    }

    private AccountsCommonTestData testData = null;

    private VelocityContext context;

    private TestDataUtil testDataUtil;

    private static final String CALLING_APP_ID = "AP144949";

    private static final String APP_ID = "AP144949";

    private static final String LOG_TRACKING_ID = RetailToRetail_HFT_ALTS_V2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static String accountNumber, accountNumber2;

    private static String mid, ppid;

    private static String ssn;

    private static String accId1, accId2;

    private static String mnemonic, mnemonic2;

    private static String oAuth;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String assetClass = "TOTAL_EQUITY";

    private static final float netPercentage = 0.10f;

    private static final String assetClass1 = "BOND";

    private static final float netPercentage1 = 0.15f;

    private static final String assetClass2 = "CASH";

    private static final float netPercentage2 = 0.05f;

    private static final String assetClass3 = "OTHER";

    private static final float netPercentage3 = 0.20f;

    private static float srcMktValFundingAccount, srcMktValDestAccount;

    private static final float domEquityAmount1 = 5000;

    private static final float foreignEquityAmount1 = 0;

    private static final float bondAmount1 = 1000;

    private static final float cashAmount1 = 500;

    private static final float otherAmount1 = 2500;

    private static final float unknownAmount = 0;

    private final float totalAmount1 = domEquityAmount1 + foreignEquityAmount1 + bondAmount1 + cashAmount1
            + otherAmount1 + unknownAmount;

    private FilterableRequestSpecification frs;
    private final String host = AccountHelper.getQATestEnvHost();
    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, and build the
     * request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();

        testData = TestDataUtil.populateRegressionTestData("account_default_ssn", oAuth);

        mid = Identity.getUserIdentifier("lid", testData.getSsn(), oAuth).get("mid");
        testData.setMid(mid);
        ssn = testData.getSsn();
        String asOfDate1 = "2014-10-31";
        testData.setAsOfDate1(asOfDate1);

        DataCleanup.deleteCustomerDataFromCP("mid", testData.getMid(), oAuth, "true");

        testData.setPpid(Identity.createHouseholdIdentity("mid", testData.getMid(), oAuth));

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", testData.getSsn()))
                .header(new Header("user-mid", testData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("excludeExternalDataSources", "false"));

        // Populate request variables
        context = new VelocityContext();

        frs = (FilterableRequestSpecification) request;
    }

    /**
     * Create 2 Retail accounts in CFP for making Fund Transfer.
     */
    @Test
    public void createTwoRetailAccounts() {
        context.put("source", AccountConstants.RETAIL);
        context.put("mnemonicFilter", testData.getMnemonic1());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("accountList",
                not(Matchers.empty()));

        mnemonic = response.path("accountList[0].regCode.mnemonic").toString();
        accountNumber = response.path("accountList[0].accountId.accountNumber").toString();
        srcMktValFundingAccount = response.path("accountList[0].sourceMarketValue.amount.value");

        ppid = testData.getPpid();

        mnemonic2 = response.path("accountList[1].regCode.mnemonic").toString();
        accountNumber2 = response.path("accountList[1].accountId.accountNumber").toString();
        srcMktValDestAccount = response.path("accountList[1].sourceMarketValue.amount.value");

        String source2 = AccountConstants.RETAIL;

        String source = AccountConstants.RETAIL;
        frs.removeHeader("Authorization");
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "true"));
        final String accIds = CreateAccount.createAccounts(ssn, accountNumber, source, mnemonic,
                srcMktValFundingAccount, accountNumber2, source2, mnemonic2, srcMktValDestAccount, null,
                null, null, null, null, null, ppid, mid, request, oAuth);
        if (StringUtils.isNotBlank(accIds)) {
            final String[] arrAcc = accIds.split(",");
            accId1 = arrAcc[0];
            accId2 = arrAcc[1];
        }

    }

    @Test(dependsOnMethods = "createTwoRetailAccounts")
    public void createRetailAccountDetails1() {
        // Generate request body
        context.put("ppid", ppid);
        context.put("value", srcMktValFundingAccount);
        context.put("accountNumber", accountNumber);
        context.put("accId", accId1);
        context.put("isInherited", false);
        context.put("isProductSuitable", "true");
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "retailAccountDetail");
        context.put("_type", "RetailAccountDetails");
        context.put("emergencyFundAmount", 2500.0F);
        context.put("assetClass", assetClass);
        context.put("netPercentage", netPercentage);
        context.put("assetClass1", assetClass1);
        context.put("netPercentage1", netPercentage1);
        context.put("assetClass2", assetClass2);
        context.put("netPercentage2", netPercentage2);
        context.put("assetClass3", assetClass3);
        context.put("netPercentage3", netPercentage3);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));
        // Call Account service

        response = request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);

        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1 + "'}.retailAccountDetail.isProductSuitable", equalTo(true))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass + "'}.assetClass", equalTo(assetClass))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass + "'}.netPercentage", equalTo(netPercentage))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass1 + "'}.assetClass", equalTo(assetClass1))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass1 + "'}.netPercentage", equalTo(netPercentage1))

                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass2 + "'}.assetClass", equalTo(assetClass2))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass2 + "'}.netPercentage", equalTo(netPercentage2))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass3 + "'}.assetClass", equalTo(assetClass3))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId1
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass3 + "'}.netPercentage", equalTo(netPercentage3));

    }

    @Test(dependsOnMethods = {"createTwoRetailAccounts", "createRetailAccountDetails1"})
    public void createRetailAccountDetails2() {
        // Generate request body
        context.put("ppid", ppid);
        context.put("value", srcMktValDestAccount);
        context.put("accountNumber", accountNumber2);
        context.put("accId", accId2);
        context.put("isInherited", false);
        context.put("isProductSuitable", "true");
        context.put("isPreviousEmployersAccount", false);
        context.put("state", "NC");
        context.put("type", "retailAccountDetail");
        context.put("_type", "RetailAccountDetails");
        context.put("emergencyFundAmount", 2600.0F);
        context.put("assetClass", assetClass);
        context.put("netPercentage", netPercentage);
        context.put("assetClass1", assetClass1);
        context.put("netPercentage1", netPercentage1);
        context.put("assetClass2", assetClass2);
        context.put("netPercentage2", netPercentage2);
        context.put("assetClass3", assetClass3);
        context.put("netPercentage3", netPercentage3);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));
        // Call Account service

        response = request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);

        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2 + "'}.retailAccountDetail.isProductSuitable", equalTo(true))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass + "'}.assetClass", equalTo(assetClass))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass + "'}.netPercentage", equalTo(netPercentage))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass1 + "'}.assetClass", equalTo(assetClass1))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass1 + "'}.netPercentage", equalTo(netPercentage1))

                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass2 + "'}.assetClass", equalTo(assetClass2))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass2 + "'}.netPercentage", equalTo(netPercentage2))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass3 + "'}.assetClass", equalTo(assetClass3))
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
                        + accId2
                        + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
                        + assetClass3 + "'}.netPercentage", equalTo(netPercentage3));
    }

    /**
     * Create the Fund Transfer between 2 Retail accounts.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"createRetailAccountDetails1", "createRetailAccountDetails2"})
    public void createFundTransfersRetail2Retail() {
        frs.removeHeader(CALLING_APP_ID);
        frs.removeHeader(APP_ID);
        frs.removeHeader(LOG_TRACKING_ID);
        frs.removeHeader(FSREQID);
        frs.removeHeader(oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-retail-lid", testData.getSsn()))
                .header(new Header("user-mid", testData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("excludeExternalDataSources", "true"));

        context.put("destAcct1", accountNumber2);
        context.put("destType1", DestinationAccountType.EXISTING_ACCOUNT.value());
        context.put("fundAcctNum1", accountNumber);
        context.put("transferType1", "FULL_BALANCE");
        context.put("totAmount1", totalAmount1);
        context.put("domEquityAmount1", domEquityAmount1);
        context.put("foreignEquityAmount1", foreignEquityAmount1);
        context.put("bondAmount1", bondAmount1);
        context.put("cashAmount1", cashAmount1);
        context.put("otherAmount1", otherAmount1);
        context.put("unknownAmount", unknownAmount);

        request.body(IOUtil.generateJsonRequest(context,
                HypotheticalFundTransferConstants.HYPOFUNDTRANSFER_CREATE_V1_TEMPLATE));
        response = request.baseUri(host).log().ifValidationFails().post(HypotheticalFundTransferPaths.HYPOFUNDTRNDFR_V1_PATH);

        validateResponse();
    }

    /**
     * Get details of Fund Transfer between Retail to Retail account after Create FT
     */
    @Test(dependsOnMethods = "createFundTransfersRetail2Retail")
    public void getFundTransfersRetail2Retail() {
        response = request.log().ifValidationFails().get(HypotheticalFundTransferPaths.HYPOFUNDTRNDFR_V1_PATH);
        validateResponse();

    }

    @Test(dependsOnMethods = "createFundTransfersRetail2Retail")
    public void getTransfersFromCompositeEEDSTrue() {
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeader("excludeExternalDataSources");

        context.put("sourceBasedRegistrationFilter", AccountConstants.RETAIL);
        context.put("includeFundTransferDetails", true);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails().given()
                .header(new Header("excludeExternalDataSources", "true"))
                .header(new Header("calculate-balances", "fund-transfers, equity-exposure"))
                .post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        float postTransferSrcMktValFundingAccount = srcMktValFundingAccount;
        float postTransferSrcMktValDestAccount = srcMktValDestAccount;
        System.out.println("transfer amount ### " + totalAmount1);

        //Funding Account EquityPercentage
        float postTransferEquityPctActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber
                        + "'}.equityPercent");
        float detailsEquityPctActual =
                response.path("accounts.details.retailAccountDetail.accountDetail.find{it.accountId.accountNumber=='"
                        + accountNumber
                        + "'}.equityPercent");
        float postTransferALTsDomesticPctActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage");

        float postTransferALTsForeignPctActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage");

        // Expected Equity Percentage for Destination Account
        float postTransferEquityPctDestActActual =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2
                        + "'}.equityPercent");
        float detailsEquityPctDestActActual =
                response.path("accounts.details.retailAccountDetail.accountDetail.find{it.accountId.accountNumber=='"
                        + accountNumber2
                        + "'}.equityPercent");
        float postTransferALTsDomesticPctDestAct =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2 + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage");

        float postTransferALTsForeignPctDestAct =
                response.path("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2 + "'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='TOTAL_EQUITY'}"
                        + ".assetAllocationAndBalances.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage");

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accounts", not(Matchers.empty()))
                .body("postTransferBalances", CoreMatchers.not(Matchers.empty()))
                .body("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber
                        + "'}.accountId.accountNumber", equalTo(accountNumber))
                .body("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2
                        + "'}.accountId.accountNumber", equalTo(accountNumber2))
                .body("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber
                                + "'}.sourceMarketValue",
                        equalTo(srcMktValFundingAccount))
                .body("postTransferBalances.find{it.accountId.accountNumber=='" + accountNumber2
                                + "'}.sourceMarketValue",
                        equalTo(postTransferSrcMktValDestAccount));

        //Equity Percentage Validation Funding Account
        //Funding Account
        assertThat(AccountUtil
                .calculateEquityPct(netPercentage, 0, 0, 0, 0))
                .isCloseTo(detailsEquityPctActual, within(0.009f));
        assertThat(AccountUtil
                .calculateEquityPct(postTransferALTsDomesticPctActual, postTransferALTsForeignPctActual,
                        0, 0, 0))
                .isCloseTo(postTransferEquityPctActual, within(0.009f));
        //Destination Account
        assertThat(AccountUtil
                .calculateEquityPct(netPercentage, 0, 0, 0, 0))
                .isCloseTo(detailsEquityPctDestActActual, within(0.009f));
        assertThat(AccountUtil
                .calculateEquityPct(postTransferALTsDomesticPctDestAct, postTransferALTsForeignPctDestAct,
                        0, 0, 0))
                .isCloseTo(postTransferEquityPctDestActActual, within(0.009f));
        validateResponse();

    }

    private void validateResponse() {

        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("transfers",
                        not(Matchers.empty()), "transfers[0].fundingDetails[0].fundingAccountNumber",
                        notNullValue(), "transfers[0].fundingDetails[0].fundingAccountNumber",
                        equalTo(accountNumber), "transfers[0].destinationAccountNumber", notNullValue(),
                        "transfers[0].destinationAccountNumber", equalTo(accountNumber2))
                .body("transfers[0].fundingDetails[0].domesticEquityAmount", notNullValue(),
                        "transfers[0].fundingDetails[0].foreignEquityAmount", notNullValue())
                .body("transfers[0].fundingDetails[0].transferType", equalTo("FULL_BALANCE"),
                        "transfers[0].fundingDetails[0].totalAmount", notNullValue());

    }

    // Delete Account
    @Test(dependsOnMethods = "getTransfersFromCompositeEEDSTrue")
    public void deleteRetailAccount() {
        // Generate request body
        context.put("source", AccountConstants.RETAIL);
        context.put("mnemonic", mnemonic);
        context.put("asOfDate", testData.getAsOfDate1());
        context.put("accountNumber", accountNumber);
        context.put("id", accId1);
        request.body(IOUtil.generateJsonRequest(context,
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service response
        request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.HTTP_200);

    }

    // Delete second Account
    @Test(dependsOnMethods = "deleteRetailAccount")
    public void deleteRetailAccount2() {
        // Generate request body
        context.put("source", AccountConstants.RETAIL);
        context.put("mnemonic", mnemonic);
        context.put("asOfDate", testData.getAsOfDate1());
        context.put("accountNumber", accountNumber2);
        context.put("id", accId2);
        request.body(IOUtil.generateJsonRequest(context,
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service response
        request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(
                com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.HTTP_200);

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}