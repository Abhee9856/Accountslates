/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.hasSize;

/**
 * Contains tests that validate NPDCDB flag for Account Composite operation for Retail Accounts
 *
 * @author a631781
 */

@Test(groups = {Tags.RETAIL, Tags.ACCOUNT, Tags.V1})
public class Retail_Composite_NPDCDB_V1 extends PAPBaseServiceTest
{

    /**
     * Constructor
     */
    protected Retail_Composite_NPDCDB_V1()
    {
	super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    final String oAuth = AccountUtil.getOauthToken();

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Composite_NPDCDB_V1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String displayName = "ABC";

    private final String institutionName = "ABC";

    private final String source = "RETAIL";

    private final String asOfDate1 = "2014-10-31";

    private String mid;

    private String acctRoot;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accId;

    private String accNumber;

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);
	testDataUtil = new TestDataUtil();
	mid = accountsCommonTestData.getMid();

	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



	accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", mid, oAuth));

	this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	// Populate request variables
	context = new VelocityContext();
	context.put("mid", mid);
	context.put("retailLid", accountsCommonTestData.getSsn());
	context.put("ppid", accountsCommonTestData.getPpid());
    }

    /**
     * Test isNpDCDBComplied flag for Regcode NPDC/DB
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getNPDCDBRetailAccountData",
		    dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data)
    {
	getRetailAccount(data);
	createCompositeAccountRetail(data);
	getCompositeAccountRetailAfterCreate(data);
	updateCompositeAccountRetail(data);
	getCompositeAccountRetailAfterUpdate(data);
	deleteCompositeAccountRetail(data);
	getCompositeAccountRetailAfterDelete(data);
    }

    //Get account info from the backend.
    private void getRetailAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", false);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	response.then().log().ifValidationFails().body("accountList", not(emptyArray()));

	//Get Account number based on the regCode
	if (null != response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1()
			+ "'}.accountId.accountNumber"))
	{
	    accNumber = response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1()
			    + "'}.accountId.accountNumber");
	}
	else
	{
	    accNumber = response.path("accountList[0].accountId.accountNumber");

	}

    }

    /**
     * Description: Validates the account composite response after a create
     */
    private void createCompositeAccountRetail(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("externalDataSources", true);
	context.put("accountNumber", accNumber);
	context.put("accId", "");
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("mnemonic", data.getRegCode1());
	context.put("sourceSystem2", source);
	context.put("value", String.valueOf(value));
	context.put("institutionName", institutionName);
	context.put("asOfDate", asOfDate1);
	context.put("detailValue", "111111.11");
	context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
	context.put("type", "RetailAccountDetails");
	context.put("emergencyFundAmount", "111111.11");
	context.put("isNpDCDBComplied", "true");
	context.put("TAM_total_equity", 0.5);
	context.put("TAM_domestic_equity", 0.4);
	context.put("TAM_foreign_equity", 0.1);
	context.put("TAM_bond", 0.5);
	context.put("TAM_cash", 0.0);
	context.put("TAM_category", "INVESTOR_SELECTED_STRATEGY");
	context.put("TAM_name", "Aggressive Growth");
	context.put("TAM_repositoryTamId", 181);
	context.put("TAM_assetAllocationId", 85);

	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

	response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

	acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNumber + "'}.";
	response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
			.body("resultCode", equalTo(true))
			.body(acctRoot + "account.accountId.id", notNullValue())
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
			.body(acctRoot + "account.regCode.mnemonic", equalTo(data.getRegCode1()))
			.body(acctRoot + "details.isNpDCDBComplied", equalTo(true));

	accId = response.path(acctRoot + "account.accountId.id");

    }

    /**
     * Description: Validates the account composite response after a create (get)
     */
    private void getCompositeAccountRetailAfterCreate(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("externalDataSources", true);
	context.put("source", source);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
	response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
			.body("resultCode", equalTo(true))
			.body(acctRoot + "account.accountId.id", notNullValue())
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
			.body(acctRoot + "account.regCode.mnemonic", equalTo(data.getRegCode1()))
			.body(acctRoot + "details.isNpDCDBComplied", equalTo(true));
    }

    /**
     * Description: Validates the account composite response after a update
     */
    private void updateCompositeAccountRetail(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("externalDataSources", true);
	context.put("accountNumber", accNumber);
	context.put("accId", accId);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("mnemonic", data.getRegCode1());
	context.put("sourceSystem2", source);
	context.put("institutionName", institutionName);
	context.put("asOfDate", asOfDate1);
	context.put("value", String.valueOf(updatedValue));
	context.put("detailValue", "111111.11");
	context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
	context.put("type", "RetailAccountDetails");
	context.put("emergencyFundAmount", "111111.11");
	context.put("isNpDCDBComplied", "true");

	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

	response = request.log().ifValidationFails().post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

	response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
			.body("resultCode", equalTo(true))
			.body(acctRoot + "account.accountId.id", notNullValue())
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
			.body(acctRoot + "account.regCode.mnemonic", equalTo(data.getRegCode1()))
			.body(acctRoot + "details.isNpDCDBComplied", equalTo(true));

	accId = response.path(acctRoot + "account.accountId.id");
    }

    /**
     * Description: Validates the account composite response after a update (get)
     */
    private void getCompositeAccountRetailAfterUpdate(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("externalDataSources", true);
	context.put("source", source);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
	response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
			.body("resultCode", equalTo(true))
			.body(acctRoot + "account.accountId.id", notNullValue())
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
			.body(acctRoot + "account.regCode.mnemonic", equalTo(data.getRegCode1()))
			.body(acctRoot + "details.isNpDCDBComplied", equalTo(true));
    }

    /**
     * Description: Validates the account composite response after a delete
     */
    private void deleteCompositeAccountRetail(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("externalDataSources", true);
	context.put("accountNumber", accNumber);
	context.put("accId", accId);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("mnemonic", data.getRegCode1());
	context.put("sourceSystem2", source);
	context.put("institutionName", institutionName);
	context.put("asOfDate", asOfDate1);
	context.put("value", String.valueOf(updatedValue));

	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

	response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);
	response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
			.body("accountList", hasSize(0));
    }

    /**
     * Description: Validates an empty account list when calling get account composite retail after delete
     */
    private void getCompositeAccountRetailAfterDelete(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("externalDataSources", true);
	context.put("source", source);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
	response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
			hasSize(0));
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown()
    {
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


	testDataUtil.closeSQLiteConnection();
    }
}
