/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.crud.fili;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Tests for FILI account V2 CrUD operation for multiple regCodes.
 *
 * @author a631781
 */
@Test(groups = {
        Tags.CRITICAL,
        Tags.FILI,
        Tags.ACCOUNT,
        Tags.V2,
        Tags.CRUD})
public class FILI_CriticalTests extends PAPBaseServiceTest {

    protected FILI_CriticalTests() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private final String source = "FILI";

    private final float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String asOfDate1 = "2014-10-31";

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private String mid;// = "FiliAccountV2TestMid";

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accNumber;

    private String accId;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        this.accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_fili", oAuth);
        this.testDataUtil = new TestDataUtil();

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
        this.accountsCommonTestData.setAsOfDate1(this.asOfDate1);
        this.accountsCommonTestData.setValue1(this.value);
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


        this.accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", this.accountsCommonTestData.getMid(), oAuth));

        this.setDefaultRequestHeaders(oAuth);
        this.request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-fili-lid", this.accountsCommonTestData.getSsn()))
                .header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("log-tracking-id", "AP136091"))
                .header(new Header("excludeExternalDataSources", "false"));

        // Populate request variables
        this.context = new VelocityContext();

    }

    /**
     * Create FILI account with different combination of Regcodes from DataProvider.
     * <p>
     * Version V2
     */
    @Test(dataProvider = "getFiliData",
            dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data) {
        this.getFiliAccountInfo(data);
        this.createFiliAccount(data);
        this.getFiliAccountAfterCreate(data);
        this.updateFiliAccount(data);
        this.getFiliAccountAfterUpdate(data);
        this.deleteFiliAccount(data);
        this.getFiliAccountAfterDelete(data);
    }

    // Get Fili Account
    private void getFiliAccountInfo(final AccountRegCodeTestData data) {
        // Generate request body
        this.context.put("source", this.source);

        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()));

        //Get Account number based on the regCode
        if (null != response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1() + "'}.accountId.accountNumber")) {
            accNumber = response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1() + "'}.accountId.accountNumber");
        } else {
            accNumber = response.path("accountList[0].accountId.accountNumber");
        }
    }

    //Create FILI Account
    private void createFiliAccount(final AccountRegCodeTestData data) {
        // Generate request body
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("value", String.valueOf(this.value));
        this.context.put("mnemonic", data.getRegCode1());
        this.context.put("source", data.getSrcFilter());
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("id", null);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));
        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.accountNumber=='" + accNumber + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.accountNumber=='" + accNumber + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.accountNumber=='" + accNumber + "'}.sourceMarketValue.amount.value", equalTo(this.value))
                .body("accountList.find{it.accountId.accountNumber=='" + accNumber + "'}.regCode.mnemonic", equalTo(data.getRegCode1()));
        accId = response.path("accountList[0].accountId.id");
    }

    // Validate created FILI account
    private void getFiliAccountAfterCreate(final AccountRegCodeTestData data) {
        // Exclude external data sources
        this.request.given().header(new Header("excludeExternalDataSources", "true"));
        this.context.put("source", this.source);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.regCode.mnemonic", equalTo(data.getRegCode1()));
    }

    //Update FILI account
    private void updateFiliAccount(final AccountRegCodeTestData data) {
        // Generate request body
        this.context.put("source", data.getSrcFilter());
        this.context.put("id", accId);
        this.context.put("value", this.updatedValue);
        this.context.put("mnemonic", data.getRegCode1());
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V2);
        response.prettyPrint();
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(updatedValue))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.regCode.mnemonic", equalTo(data.getRegCode1()));
    }

    // Validate Updated account
    private void getFiliAccountAfterUpdate(final AccountRegCodeTestData data) {
        // Exclude external data sources
        this.request.given().header(new Header("excludeExternalDataSources", "true"));
        this.context.put("source", this.source);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.regCode.mnemonic", equalTo(data.getRegCode1()));
    }


    //Delete FILI account
    private void deleteFiliAccount(final AccountRegCodeTestData data) {
        // Generate request body
        this.context.put("source", data.getSrcFilter());
        this.context.put("value", this.updatedValue);
        this.context.put("mnemonic", data.getRegCode1());
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("id", accId);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));
        // Call Account service response =
        this.request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
    }

    // Validate after delete
    private void getFiliAccountAfterDelete(final AccountRegCodeTestData data) {
        this.context.put("source", this.source);
        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }
}