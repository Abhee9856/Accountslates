/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Contains tests that validate NPDCDB flag for Account Details operation for Retail Accounts
 *
 * @author a631781
 */

@Test(groups = {Tags.RETAIL, Tags.DETAILS, Tags.V1})
public class Retail_Detail_NPDCDB_V1 extends PAPBaseServiceTest
{

    protected Retail_Detail_NPDCDB_V1()
    {
	super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private final String oAuth = AccountUtil.getOauthToken();

    private float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String source = "RETAIL";

    private final String asOfDate1 = "2014-10-31";

    private final String productSubType = "FIXED INCOME";

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String mid;

    private String accId;

    private String accNumber;

	private static final String TRUSTEE_TYPE = "FPTC";
	private static final String TRUSTEE_TYPE_UPDATE = "ABCD";

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);
	testDataUtil = new TestDataUtil();
	mid = accountsCommonTestData.getMid();
	accountsCommonTestData.setAsOfDate1(asOfDate1);
	accountsCommonTestData.setValue1(value);
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



	accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

	setDefaultRequestHeaders(oAuth);

	// Populate request variables
	context = new VelocityContext();
	context.put("mid", mid);
	context.put("retailLid", accountsCommonTestData.getSsn());
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", String.valueOf(value));

    }

    /**
     * Create Retail account with different combination of Regcodes from DataProvider.
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getNPDCDBRetailAccountData",
		    dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data)
    {
	getRetailAccount(data);
	createRetailAccount(data);
	createRetailAccountDetails(data);
	getRetailAccountDetailsAfterCreate(data);
	updateRetailAccountDetails(data);
	getRetailAccountDetailsAfterUpdate(data);
	deleteRetailAccount(data);

    }

    //Get account info from the backend.
    private void getRetailAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("source", source);
	context.put("externalDataSources", false);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }
	response.then().log().ifValidationFails().body("accountList", not(emptyArray()));

	//Get Account number based on the regCode
	if (null != response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1()
			+ "'}.accountId.accountNumber"))
	{
	    accNumber = response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1()
			    + "'}.accountId.accountNumber");
	}
	else
	{
	    accNumber = response.path("accountList[0].accountId.accountNumber");

	}

    }

    //Create Retail Account
    private void createRetailAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", String.valueOf(value));
	context.put("mnemonic", data.getRegCode1());
	context.put("source", data.getSrcFilter());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
	context.put("accountNumber", accNumber);
	context.put("id", null);
	context.put("excludeExternalDataSources", true);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

	//Asset on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("resultCode", equalTo(true))
			.body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

	accId = response.path("accountList[0].accountId.id");

    }

    // Create Retail account Details V1.
    private void createRetailAccountDetails(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("value", value);
	context.put("accountNumber", accNumber);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isProductSuitable", "true");
	context.put("isPreviousEmployersAccount", false);
	context.put("type", "RetailAccountDetails");
	context.put("_type", "RetailAccountDetails");
	context.put("emergencyFundAmount", 2500.0F);
	context.put("externalDataSources", true);
	context.put("productSubType", productSubType);
	context.put("isNpDCDBComplied", "true");
		context.put("trusteeType", TRUSTEE_TYPE);

	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
	// Call Account service
	response =
			request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", Matchers.equalTo(true),
					"userIdentifier.mid", Matchers.equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem",
					equalTo(source),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNumber),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id",
					equalTo(accId),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isNpDCDBComplied",
					equalTo(true),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.trusteeType",
					equalTo(TRUSTEE_TYPE));
    }

    // Get Retail account details V1
    private void getRetailAccountDetailsAfterCreate(final AccountRegCodeTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.prettyPrint();
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", Matchers.equalTo(true),
					"userIdentifier.mid", Matchers.equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem",
					equalTo(source),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNumber),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id",
					equalTo(accId),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isNpDCDBComplied",
					equalTo(true),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.trusteeType",
					equalTo(TRUSTEE_TYPE));
    }

    // Update Retail account Details V1.
    private void updateRetailAccountDetails(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("value", value);
	context.put("accountNumber", accNumber);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isProductSuitable", "true");
	context.put("isPreviousEmployersAccount", false);
	context.put("type", "RetailAccountDetails");
	context.put("_type", "RetailAccountDetails");
	context.put("emergencyFundAmount", 2500.0F);
	context.put("externalDataSources", true);
	context.put("productSubType", productSubType);
		context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
	// Call Account service
	response =
			request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", Matchers.equalTo(true),
					"userIdentifier.mid", Matchers.equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem",
					equalTo(source),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNumber),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id",
					equalTo(accId),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isNpDCDBComplied",
					equalTo(true),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.trusteeType",
					equalTo(TRUSTEE_TYPE_UPDATE));
    }

    // Get Retail account details V1 after updating Details
    private void getRetailAccountDetailsAfterUpdate(final AccountRegCodeTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.prettyPrint();
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", Matchers.equalTo(true),
					"userIdentifier.mid", Matchers.equalTo(accountsCommonTestData.getMid()),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem",
					equalTo(source),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNumber),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id",
					equalTo(accId),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.isNpDCDBComplied",
					equalTo(true),
					"accountDetails.find{it.accountId.id=='" + accId + "'}.trusteeType",
					equalTo(TRUSTEE_TYPE_UPDATE));
    }

    // Delete Account
    private void deleteRetailAccount(final AccountRegCodeTestData data)
    {
	// Generate request body
	context.put("source", data.getSrcFilter());
	context.put("value", updatedValue);
	context.put("mnemonic", data.getRegCode1());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
	context.put("accountNumber", accNumber);
	context.put("id", accId);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

	// Call Account service response
	request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
	//Data cleanup
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


	testDataUtil.closeSQLiteConnection();
    }
}
