package com.fmr.restassured.account.v2.composite.get.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;

/**
 * Tests Account Composite get(v2) operation for an account returns suitability only when
 * the whitelisted app id is passed (PFCP-12115)
 * Currently whitelisted app id are AP106564, AP118468, AP136091 and AP145081.
 * @author a608077
 */
@Test(groups = {
        Tags.RETAIL,
        Tags.COMPOSITE,
        Tags.V2,
        Tags.GET})
public class Retail_Composite_Get_v2_Suitability_WithAppId extends PAPBaseServiceTest {

        protected Retail_Composite_Get_v2_Suitability_WithAppId() {
            super(Services.Account);
        }

        //Velocity Context
        private VelocityContext context;

        //Instance to the test data utility class
        private TestDataUtil testDataUtil;

        private static final String SCENARIO_CATEGORY_CODE = "DEF";
        private static final String SCENARIO_PRODUCT_CODE = "IGE";

        //Logging Details
        private static final String CALLING_APP_ID = "AP106532";
        private static final String APP_ID = "AP106532";
        private static final String LOG_TRACKING_ID = Retail_Composite_Get_v2_Suitability_WithAppId.class.getSimpleName();
        private static final String FSREQID = LOG_TRACKING_ID;

        /**
         * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
         * for the test, and build the request body from Velocity.
         */
        @BeforeClass
        public void init() {

            final String oAuth = AccountUtil.getOauthToken();

            testDataUtil = new TestDataUtil();

            // Data setup
            AccountsCommonTestData accountsCommonTestData =
                    TestDataUtil.populateRegressionTestData("account_default_ssn", oAuth);

            //Set default REST header with authorization token
            setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

            //Data cleanup
            DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuth, "true");

            accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

            this.request.given()
                    .header(new Header("user-poe", AccountConstants.RETAIL))
                    .header(new Header("user-mid", accountsCommonTestData.getMid()))
                    .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                    .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                    .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                    .header(new Header("excludeExternalDataSources", "false"));



            // Populate common variables for tests into context
            context = new VelocityContext();
            context.put("sourceBasedRegistrationFilter", "RETAIL");
        }

        /**
         * Get composite call- checks for suitability object not
         * coming with include-suitability-details = false
         */
        @Test
        public void getCompositeSuitabilityInfo_NonWhitelistedAppId() {

            FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
            frs.removeHeader("AppId");
            frs.removeHeader("Calling-app-id");

            this.request.given()
                    .header(new Header("AppId", "AP106532"))
                    .header(new Header("Calling-app-id", "AP106532"));
            // Generate request body
            request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

            // Call Account service
            response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

            response.then().log().ifValidationFails()
                    .statusCode(HTTPStatusCodes.STATUS_200)
                    .body("accounts[0].account.accountId.accountNumber", notNullValue())
                    .body("accounts[0].details",notNullValue())
                    .body("accounts[0].positions",notNullValue())
                    .body("accounts[0].suitability.size()",is(0));

        }
    /**
     * Get composite call- checks for suitability object coming with include-suitability-details =true
     */
    @Test
    public void getCompositeSuitabilityInfo_WhitelistedAppId() {

        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeader("AppId");
        frs.removeHeader("Calling-app-id");
        
        this.request.given()
        	.header(new Header("AppId", "AP106564"))
        	.header(new Header("Calling-app-id", "AP106564"));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.accountNumber", notNullValue())
                .body("accounts[0].details",notNullValue())
                .body("accounts[0].positions",notNullValue())
                .body("accounts[0].suitability", notNullValue());

    }
        /**
         * Cleanup operation for SQLite DB connection
         */
        @AfterClass(alwaysRun = true)
        public void cleanUpDBConnections() {
            this.testDataUtil.closeSQLiteConnection();
        }
    }

