/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.v2.positions.crud.manual;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.http.Header;
import io.restassured.response.Response;

/**
 * * Tests ScenarioID header implementation for Manual positions against V2.
 * *
 * * @author a631781
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.POSITIONS,
        Tags.V2,
        Tags.CRUD,
        "PFCP-6168"})
public class Manual_Positions_CRUD_V2_scenarioId extends PAPBaseServiceTest {

    public static final String LOG_TRACKING_ID = Manual_Positions_CRUD_V2_scenarioId.class.getSimpleName();

    protected Manual_Positions_CRUD_V2_scenarioId() {
        super(Services.Account);
    }

    private TestDataUtil testDataUtil;

    private String principalPId;

    private String partnerPId;

    private String dependentPId;

    private String accountNumber;

    private String accountId;

    private String accountId2;

    private String accountId3;

    private final String sourceSystem = "MANUAL";

    private VelocityContext context;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final Header EEDS = new Header("excludeExternalDataSources", "true");

    //Financial Instrument IDs and their symbols
    private FinancialInstrumentIds finstIds;

    Response allScenarioIDs;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("accountCRUD_Manual", oAuth);

        String mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        principalPId = Identity.createHouseholdIdentity("mid", mid, oAuth);
        partnerPId = Identity.createHouseholdIdentityPartner(mid, oAuth);
        dependentPId = Identity.createHouseholdIdentityDependent(mid, oAuth);
        finstIds = new FinancialInstrumentIds("FFIDX", "FENY", "QPISQ", "FEDTX");
        testDataUtil = new TestDataUtil();
        // Get/Create ScenarioId
        allScenarioIDs = Scenario.getAllScenarios(mid, oAuth);
        String scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null) {
            scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE,
                    oAuth);
        }
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
                LOG_TRACKING_ID, oAuth);
        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("log-tracking-id", LOG_TRACKING_ID))
                .header(new Header("scenario-id", scenarioId))
                .header(EEDS);

        context = new VelocityContext();
        context.put("ppid", principalPId);
        context.put("source", "MANUAL");
    }

    /**
     * Create manual accounts.
     */
    @Test
    public void createManualAccounts() {
        float value = 5000.0f;
        context.put("value", value);
        context.put("source", sourceSystem);
        String displayName = "Display_Name";
        context.put("displayName", displayName);
        String institutionName = "InstitutionalName";
        context.put("institutionName", institutionName);
        String asOfDate = "2014-10-31";
        context.put("asOfDate", asOfDate);
        String mnemonic = "IRA";
        context.put("mnemonic", mnemonic);

        context.put("partnerPId", partnerPId);
        context.put("relationShip1", "PARTNER");
        context.put("value2", 8000.0f);
        context.put("source2", sourceSystem);
        context.put("displayName2", "something 2");
        context.put("institutionName", institutionName);
        context.put("asOfDate2", asOfDate);
        context.put("mnemonic2", "IRA");

        context.put("dependentPId", dependentPId);
        context.put("relationShip2", "DEPENDENT");
        context.put("value3", 4000f);
        context.put("source3", sourceSystem);
        context.put("displayName3", "Something 3");
        context.put("institutionName", institutionName);
        context.put("asOfDate3", asOfDate);
        context.put("mnemonic3", "IRRL");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList", Matchers.not(empty()),
                        "accountList", Matchers.hasSize(3),
                        "accountList[0].regCode.mnemonic", Matchers.notNullValue(),
                        "accountList[0].accountId.accountNumber", Matchers.notNullValue());

        // Gets and saves the CFP account ID
        accountId = response.path("accountList.accountId.find{it.owner.relationship=='PRINCIPAL'}.accountNumber");
        accountNumber = response.path("accountList.accountId.find{it.owner.relationship=='PRINCIPAL'}.accountNumber");
        accountId2 = response.path("accountList.accountId.find{it.owner.relationship=='PARTNER'}.id");
        String accountNumber2 = response.path("accountList.accountId.find{it.owner.relationship=='PARTNER'}.accountNumber");
        accountId3 = response.path("accountList.accountId.find{it.owner.relationship=='DEPENDENT'}.id");
        String accountNumber3 = response.path("accountList.accountId.find{it.owner.relationship=='DEPENDENT'}.accountNumber");

        context.put("id", accountId);
        context.put("accountNumber", accountNumber);
        context.put("id2", accountId2);
        context.put("accountNumber2", accountNumber2);
        context.put("id3", accountId3);
        context.put("accountNumber3", accountNumber3);
    }

    /**
     * Validate the accounts were created correctly.
     */
    @Test(dependsOnMethods = "createManualAccounts")
    public void getManualAccountsAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("accountList", Matchers.hasSize(3));
    }

    /**
     * Get the positions before creation of positions
     */
    @Test(dependsOnMethods = "getManualAccountsAfterCreate")
    public void getAccountPositionsBeforeCreatePosition() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body(
                        "accountList", Matchers.hasSize(3),
                        "accountList[0].account.accountId.sourceSystem", equalTo(sourceSystem),
                        "accountList.account.accountId.find{it.id==\"" + accountId + "\"}.accountNumber",
                        equalTo(accountNumber),
                        "accountList.account.accountId.find{it.id==\"" + accountId + "\"}.id", equalTo(accountId),
                        "accountList.account.accountId.find{it.id==\"" + accountId + "\"}.owner.id",
                        equalTo(principalPId),
                        "accountList.account.accountId.find{it.id==\"" + accountId + "\"}.positions",
                        Matchers.nullValue(),
                        "accountList.account.accountId.find{it.id==\"" + accountId2 + "\"}.positions",
                        Matchers.nullValue(),
                        "accountList.account.accountId.find{it.id==\"" + accountId3 + "\"}.positions",
                        Matchers.nullValue()
                );
    }

    /**
     * Create positions
     */
    @Test(dependsOnMethods = "getAccountPositionsBeforeCreatePosition")
    public void createAccountPositions() {
        context.put("positiondesc1", "Description 1");
        context.put("positionMarketVal1", 5000.0f);
        context.put("positionQuantity1", 100);
        context.put("positionPrice1", 50.0f);
        context.put("costBasis1", 222);
        context.put("finstId2", finstIds.getFinstId("FENY"));
        context.put("symbol2", "FENY");
        context.put("type2", finstIds.getType("FENY"));
        context.put("name2", finstIds.getName("FENY"));

        context.put("positiondesc2", "Description 2");
        context.put("positionMarketVal2", 5000.0f);
        context.put("positionQuantity2", 100);
        context.put("positionPrice2", 50.0f);
        context.put("costBasis2", 444);
        context.put("finstId", finstIds.getFinstId("FFIDX"));
        context.put("symbol", "FFIDX");
        context.put("type", finstIds.getType("FFIDX"));
        context.put("name", finstIds.getName("FFIDX"));

        context.put("positiondesc3", "Description 3");
        context.put("positionMarketVal3", 5000.0f);
        context.put("positionQuantity3", 100);
        context.put("positionPrice3", 50.0f);
        context.put("costBasis3", 332);
        context.put("finstId3", finstIds.getFinstId("QPISQ"));
        context.put("symbol3", "QPISQ");
        context.put("type3", finstIds.getType("QPISQ"));
        context.put("name3", finstIds.getName("QPISQ"));

        context.put("positiondesc4", "Description 4");
        context.put("positionMarketVal4", 5000.0f);
        context.put("positionQuantity4", 100);
        context.put("positionPrice4", 50.0f);
        context.put("costBasis4", 332);
        context.put("finstId4", finstIds.getFinstId("FEDTX"));
        context.put("symbol4", "FEDTX");
        context.put("type4", finstIds.getType("FEDTX"));
        context.put("name4", finstIds.getName("FEDTX"));

        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_VM));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountPositions", notNullValue(),
                        "accountPositions[0].account.accountId.sourceSystem", equalTo(sourceSystem),
                        "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.accountNumber",
                        equalTo(accountNumber),
                        "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.id", equalTo(accountId),
                        "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.owner.id",
                        equalTo(principalPId),
                        "accountPositions.find{it.account.accountId.id==\"" + accountId + "\"}.positions.allPositions",
                        Matchers.notNullValue(),
                        "accountPositions.find{it.account.accountId.id==\"" + accountId2 + "\"}.positions.allPositions",
                        Matchers.notNullValue(),
                        "accountPositions.find{it.account.accountId.id==\"" + accountId3 + "\"}.positions.allPositions",
                        Matchers.notNullValue(),
                        "accountPositions.find{it.account.accountId.id==\"" + accountId3 + "\"}.positions.allPositions",
                        hasSize(2)
                );
    }

    /**
     * Get the positions after creation of positions
     */
    @Test(dependsOnMethods = "createAccountPositions")
    public void getAccountPositionsAfterCreate() {
        context.put("mnemonicFilter", "IRA");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body(
                        "accountList", Matchers.hasSize(2),
                        "accountList[0].account.accountId.sourceSystem", equalTo(sourceSystem),
                        "accountList.account.accountId.find{it.owner.relationship=='PRINCIPAL'}.accountNumber",
                        equalTo(accountNumber),
                        "accountList.account.accountId.find{it.owner.relationship=='PRINCIPAL'}.id", equalTo(accountId),
                        "accountList.account.accountId.find{it.owner.relationship=='PRINCIPAL'}.owner.id",
                        equalTo(principalPId),
                        "accountList.find{it.account.accountId.owner.relationship=='PRINCIPAL'}.positions",
                        Matchers.notNullValue(),
                        "accountList.find{it.account.accountId.owner.relationship=='PARTNER'}.positions",
                        Matchers.notNullValue()

                );
    }

    /**
     * Update positions
     */
    @Test(dependsOnMethods = "getAccountPositionsAfterCreate")
    public void updateAccountPositions() {
        context.put("positionMarketVal1", 1500.0f);
        context.put("positionMarketVal2", 3000.0f);

        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_VM));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountPositions", notNullValue(),
                        "accountPositions[0].account.accountId.sourceSystem", equalTo(sourceSystem),
                        "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.accountNumber",
                        equalTo(accountNumber),
                        "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.id", equalTo(accountId),
                        "accountPositions.account.accountId.find{it.id==\"" + accountId + "\"}.owner.id",
                        equalTo(principalPId),
                        "accountPositions.find{it.account.accountId.id==\"" + accountId + "\"}.positions.allPositions",
                        Matchers.notNullValue(),
                        "accountPositions.find{it.account.accountId.id==\"" + accountId2 + "\"}.positions.allPositions",
                        Matchers.notNullValue(),
                        "accountPositions.find{it.account.accountId.id==\"" + accountId3 + "\"}.positions.allPositions",
                        Matchers.notNullValue(),
                        "accountPositions.find{it.account.accountId.id==\"" + accountId3 + "\"}.positions.allPositions",
                        hasSize(2),
                        "accountPositions.find{it.account.accountId.id==\"" + accountId
                                + "\"}.positions.allPositions[0]"
                                + ".financialAssetPosition.position.marketValue.value", equalTo(1500.0f),
                        "accountPositions.find{it.account.accountId.id==\"" + accountId2
                                + "\"}.positions.allPositions[0]"
                                + ".financialAssetPosition.position.marketValue.value", equalTo(3000.0f)

                );
    }

    /**
     * Get the positions after positions update
     */
    @Test(dependsOnMethods = "updateAccountPositions")
    public void getAccountPositionsAfterUpdate() {
        //context.put("mnemonicFilter", "IRA");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body(
                        "accountList", Matchers.hasSize(2),
                        "accountList[0].account.accountId.sourceSystem", equalTo(sourceSystem),
                        "accountList.account.accountId.find{it.owner.relationship=='PRINCIPAL'}.accountNumber",
                        equalTo(accountNumber),
                        "accountList.account.accountId.find{it.owner.relationship=='PRINCIPAL'}.id", equalTo(accountId),
                        "accountList.account.accountId.find{it.owner.relationship=='PRINCIPAL'}.owner.id",
                        equalTo(principalPId),
                        "accountList.find{it.account.accountId.owner.relationship=='PRINCIPAL'}.positions",
                        Matchers.notNullValue(),
                        "accountList.find{it.account.accountId.owner.relationship=='PARTNER'}.positions",
                        Matchers.notNullValue(),
                        "accountList.find{it.account.accountId.owner.relationship=='PRINCIPAL'}.positions.marketValue"
                                + ".amount.value", equalTo(1500.0f),
                        "accountList.find{it.account.accountId.owner.relationship=='PARTNER'}.positions.marketValue"
                                + ".amount.value", equalTo(3000.0f)
                );
    }

    /**
     * Deletes the manual accounts
     */
    @Test(dependsOnMethods = "getAccountPositionsAfterUpdate")
    public void deleteManualAccount() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        //Run test
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("isEmpty()", Matchers.is(true));
    }

    /**
     * Validate the accounts were deleted.
     */
    @Test(dependsOnMethods = "deleteManualAccount")
    public void getAccountAfterDelete() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("isEmpty()", Matchers.is(true));
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}
