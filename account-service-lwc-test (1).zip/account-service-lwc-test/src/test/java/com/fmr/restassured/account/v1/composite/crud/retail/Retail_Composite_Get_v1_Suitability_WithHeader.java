package com.fmr.restassured.account.v1.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.*;

/**
 * Tests Account Composite get(v1) operation for an account returns suitability only when
 * the 'include-suitability-details' header is passed (PFCP-12115)
 * @author a608077
 */
@Test(groups = {
        Tags.RETAIL,
        Tags.COMPOSITE,
        Tags.V1,
        Tags.GET})
public class Retail_Composite_Get_v1_Suitability_WithHeader extends PAPBaseServiceTest {

        protected Retail_Composite_Get_v1_Suitability_WithHeader() {
            super(Services.Account);
        }

        //Velocity Context
        private VelocityContext context;

        //Instance to the test data utility class
        private TestDataUtil testDataUtil;

        //Logging Details
        private static final String CALLING_APP_ID = "AP106532";
        private static final String APP_ID = "AP106532";
        private static final String LOG_TRACKING_ID = Retail_Composite_Get_v1_Suitability_WithHeader.class.getSimpleName();
        private static final String FSREQID = LOG_TRACKING_ID;

        /**
         * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
         * for the test, and build the request body from Velocity.
         */
        @BeforeClass
        public void init() {
            final String oAuth = AccountUtil.getOauthToken();

            testDataUtil = new TestDataUtil();

            // Data setup
            AccountsCommonTestData accountsCommonTestData =
                    TestDataUtil.populateRegressionTestData("account_default_ssn", oAuth);

            //Set default REST header with authorization token
            setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

            //Data cleanup
            DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuth, "true");

            accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

            // Populate common variables for tests into context
            context = new VelocityContext();
            context.put("sourceBasedRegistrationFilter", "RETAIL");
            context.put("mid", accountsCommonTestData.getMid());
            context.put("retailLid", accountsCommonTestData.getSsn());
            context.put("ppid", accountsCommonTestData.getPpid());
            context.put("externalDataSources", false);
        }

        /**
         * Get composite call- checks for suitability object not
         * coming with include-suitability-details = false
         */
        @Test
        public void getCompositeSuitabilityInfo_false() {

            this.request.given()
                    .header(new Header("include-suitability-details", "false"));

            // Generate request body
            request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

            response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

            response.then().log().ifValidationFails()
                    .statusCode(HTTPStatusCodes.STATUS_200)
                    .body("accounts[0].account.accountId.accountNumber", notNullValue())
                    .body("accounts[0].details",notNullValue())
                    .body("accounts[0].positions",notNullValue())
                    .body("accounts[0].suitability",nullValue())
                    .body("resultCode", equalTo(true));


        }
    /**
     * Get composite call- checks for suitability object coming with include-suitability-details =true
     */
    @Test
    public void getCompositeSuitabilityInfo_true() {

        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeader("include-suitability-details");

        this.request.given()
                .header(new Header("include-suitability-details", "true"));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        response.then().log().ifValidationFails()
                .statusCode(HTTPStatusCodes.STATUS_200)
                .body("accounts[0].account.accountId.accountNumber", notNullValue())
                .body("accounts[0].details",notNullValue())
                .body("accounts[0].positions",notNullValue())
                .body("accounts[0].suitability", notNullValue())
                .body("resultCode", equalTo(true));

    }
        /**
         * Cleanup operation for SQLite DB connection
         */
        @AfterClass(alwaysRun = true)
        public void cleanUpDBConnections() {
            this.testDataUtil.closeSQLiteConnection();
        }
    }

