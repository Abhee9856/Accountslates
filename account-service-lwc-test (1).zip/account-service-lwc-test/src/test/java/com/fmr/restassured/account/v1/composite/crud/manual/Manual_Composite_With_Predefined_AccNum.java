/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static io.restassured.config.HeaderConfig.headerConfig;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.empty;

/**
 * Tests Manual Account is successfully created with a predefined Account Number (PFCP-7644)
 *
 * @author a702588
 */
@Test(groups = {Tags.ACCNUM,Tags.COMPOSITE, Tags.MANUAL, Tags.V1})
public class Manual_Composite_With_Predefined_AccNum extends PAPBaseServiceTest {

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;
    private String mid;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    // Context
    private VelocityContext context;

    // Paths
    private String accountCompositeGetPath;

    private String accountCompositeCreatePath;

    private String accountDeletePath;

    // Financial Instrument IDs and their symbols
    private FinancialInstrumentIds finstIds;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Manual_Composite_With_Predefined_AccNum.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String PRODUCT_CODE_IGE = "IGE";

    private static final String PRODUCT_CODE_DIV = "DIV";

    private static final String CATEGORY_CODE = "DEF";

    private static final String ACCOUNT_NUMBER = "TEST-ACCOUNT-New";
    private String scenarioIdDiv;
    private String acctIdDiv;


    //Start and End years for accountPreferencesIA - both should be greater than the current year.
    int startYear = ZonedDateTime.now().plusYears(1).getYear();
    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    /**
     * Constructor
     */
    protected Manual_Composite_With_Predefined_AccNum() {
        super(Services.Account);
    }

    /**
     * Initialization method used to: </br>
     * 1. Retrieve the oAuth token </br>
     * 2. Retrieve the test data from SQLite DB & set up any other test data </br>
     * 3. Set operation paths </br>
     * 4. Build partial contents of the velocity context
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {

        oAuth = AccountUtil.getOauthToken();

        testDataUtil = new TestDataUtil();

        accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_manual", oAuth);
        this.mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        // Data setup
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("contribFreq", "YEARLY");
        accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        accountsCommonTestData.set("contribValue", "6000.0");
        accountsCommonTestData.set("updatedContribAmount", "500.0");
        accountsCommonTestData.set("withdrawAmount", "500.0");
        accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
        accountsCommonTestData.set("withdrawFreq", "YEARLY");
        accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");
        accountsCommonTestData.setMnemonic1("IBRKFUND");
        accountsCommonTestData.setDisplayName1("Manual Predefined Account Number RestAssured");
        accountsCommonTestData.setInstitutionName1("Manual Institution");
        accountsCommonTestData.setSourceSystem1("MANUAL");
        accountsCommonTestData.setPpid(
                String.valueOf(Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth)));

        // Resolve finstIds
        finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

        // Set operation paths
        accountCompositeGetPath = AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1;
        accountCompositeCreatePath = AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1;
        accountDeletePath = AccountsPaths.DELETE_ACCOUNT_V1;

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", "MANUAL");
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", CATEGORY_CODE))
                .header(new Header("scenario-product-code", PRODUCT_CODE_IGE));

        request.given().
                config(RestAssured.config().headerConfig(headerConfig().overwriteHeadersWithName(
                        "scenario-product-code","Content-Type")));
    }

    /**
     * Description: Validates an empty account list when calling get account composite manual before creation of an
     * account (v1)
     */
    @Test
    public void getCompositeAccountManualBeforeCreate() {

        // Exclude external data
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());

    }

    /**
     * Description: Create Composite Account
     */
    @Test(dependsOnMethods = {"getCompositeAccountManualBeforeCreate"})
    public void createCompositeAccountManualWithAccNum() {

        accountsCommonTestData.setAccountNumber1(ACCOUNT_NUMBER);

        // Generate request body
        context.put("externalDataSources", "true");
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", finstIds.getFinstId("GBOND"));
        context.put("GCASH", finstIds.getFinstId("GCASH"));
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("contribValue", accountsCommonTestData.get("contribValue"));
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("_type", AccountConstants.MANUAL_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.MANUAL_ACCOUNT_DETAILS);
        context.put("riskTolerance", 1);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);


        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeCreatePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "accounts[0].account.accountId.accountNumber",equalTo(accountsCommonTestData.getAccountNumber1()),
                "resultCode",equalTo(true), "accounts[0].account.accountId.owner.id",
                equalTo(accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                equalTo(accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                equalTo(accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                equalTo(accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                equalTo(accountsCommonTestData.getInstitutionName1()),
                "accounts[0].account.sourceMarketValue.amount.value",
                equalTo(accountsCommonTestData.getValue1()),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GDSTOCK")),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GFSTOCK")),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GBOND")),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GCASH")), "accounts[0].details.costBasis.value",
                equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))), "accounts[0].details.state",
                equalTo("AK"),
                "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(1),
                "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),
                "accounts[0].contributions.contributions[0].contribution.value",
                equalTo(Float.valueOf(accountsCommonTestData.get("contribValue"))),
                "accounts[0].contributions.contributions[0].frequency",
                equalTo(accountsCommonTestData.get("contribFreq")),
                "accounts[0].withdrawals[0].amount.amount.value",
                equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
                "accounts[0].withdrawals[0].amount.frequency",
                equalTo(accountsCommonTestData.get("withdrawFreq")));

        // Save account number and ID
        accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
        accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));

    }


    /**
     * Description: Validates the account composite response after create
     */
    @Test(dependsOnMethods = "createCompositeAccountManualWithAccNum")
    public void getCompositeAccountManualAfterCreate() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
                equalTo(true), "accounts[0].account.accountId.id",
                equalTo(accountsCommonTestData.getAccountId1()), "accounts[0].account.accountId.accountNumber",
                equalTo(accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                equalTo(accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                equalTo(accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                equalTo(accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                equalTo(accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                equalTo(accountsCommonTestData.getInstitutionName1()),
                "accounts[0].account.sourceMarketValue.amount.value",
                equalTo(accountsCommonTestData.getValue1()),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GDSTOCK")),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GFSTOCK")),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GBOND")),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GCASH")), "accounts[0].details.costBasis.value",
                equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))), "accounts[0].details.state",
                equalTo("AK"),
                "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(1),
                "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),
                "accounts[0].contributions.contributions[0].contribution.value",
                equalTo(Float.valueOf(accountsCommonTestData.get("contribValue"))),
                "accounts[0].contributions.contributions[0].frequency",
                equalTo(accountsCommonTestData.get("contribFreq")),
                "accounts[0].withdrawals[0].amount.amount.value",
                equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
                "accounts[0].withdrawals[0].amount.frequency",
                equalTo(accountsCommonTestData.get("withdrawFreq")));
    }

    /**
     * Description: Create Composite Account
     */
    @Test(dependsOnMethods = {"getCompositeAccountManualAfterCreate"})
    public void createCompositeAccountManualWithSameAccNumSameScenario() {

        // Generate request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", finstIds.getFinstId("GBOND"));
        context.put("GCASH", finstIds.getFinstId("GCASH"));
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("contribValue", accountsCommonTestData.get("contribValue"));
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("_type", AccountConstants.MANUAL_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.MANUAL_ACCOUNT_DETAILS);
        context.put("riskTolerance", 1);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);


        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeCreatePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "errorString",equalTo("ERROR - Invalid account number: "+ TestDataUtil.getMaskedAccountNumber(accountsCommonTestData.getAccountNumber1())));

    }

    /**
     * Description: Create Composite Account
     */
    @Test(dependsOnMethods = {"createCompositeAccountManualWithSameAccNumSameScenario"})
    public void createCompositeAccountManualWithSameAccNumDiffScenario() {

	scenarioIdDiv = Scenario.createScenarioWithProductCode(accountsCommonTestData.getMid(), PRODUCT_CODE_DIV, CATEGORY_CODE, oAuth);

        accountsCommonTestData.setPpid(Identity.createHouseholdIdentityWithProductCode(accountsCommonTestData.getMid(), oAuth,
                PRODUCT_CODE_DIV, CATEGORY_CODE));

        request.header("scenario-product-code", PRODUCT_CODE_DIV);

        // Generate request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", finstIds.getFinstId("GBOND"));
        context.put("GCASH", finstIds.getFinstId("GCASH"));
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("contribValue", accountsCommonTestData.get("contribValue"));
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("_type", AccountConstants.MANUAL_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.MANUAL_ACCOUNT_DETAILS);
        context.put("riskTolerance", 1);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("scenarioId", scenarioIdDiv);
        context.put("ppid", accountsCommonTestData.getPpid());


        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeCreatePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "accounts[0].account.accountId.accountNumber",equalTo(accountsCommonTestData.getAccountNumber1()),
                "resultCode",equalTo(true), "accounts[0].account.accountId.owner.id",
                equalTo(accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                equalTo(accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                equalTo(accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                equalTo(accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                equalTo(accountsCommonTestData.getInstitutionName1()),
                "accounts[0].account.sourceMarketValue.amount.value",
                equalTo(accountsCommonTestData.getValue1()),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GDSTOCK")),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GFSTOCK")),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GBOND")),
                "accounts[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId",
                equalTo(finstIds.getFinstId("GCASH")), "accounts[0].details.costBasis.value",
                equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))), "accounts[0].details.state",
                equalTo("AK"),
                "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(1),
                "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),
                "accounts[0].contributions.contributions[0].contribution.value",
                equalTo(Float.valueOf(accountsCommonTestData.get("contribValue"))),
                "accounts[0].contributions.contributions[0].frequency",
                equalTo(accountsCommonTestData.get("contribFreq")),
                "accounts[0].withdrawals[0].amount.amount.value",
                equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
                "accounts[0].withdrawals[0].amount.frequency",
                equalTo(accountsCommonTestData.get("withdrawFreq")));
        acctIdDiv = response.path("accounts[0].account.accountId.id");

    }

    /**
     * Description: Deletes the account
     */
    @Test(dependsOnMethods = "createCompositeAccountManualWithSameAccNumDiffScenario")
    public void deleteCompositeAccountManual() {

	request.header("scenario-product-code", PRODUCT_CODE_DIV);
	context.put("accId", acctIdDiv);
	context.put("scenarioId", scenarioIdDiv);
	context.put("ppid", accountsCommonTestData.getPpid());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(accountDeletePath);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true)).body("accountList", empty());
    }

    /**
     * Description: Validates an empty account list when calling get account composite manual after delete
     */
    @Test(dependsOnMethods = "deleteCompositeAccountManual")
    public void getCompositeAccountManualAfterDelete() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());
    }

    /**
     * Description: Validates an empty account list when calling get account composite manual after delete
     */
    @Test(dependsOnMethods = "getCompositeAccountManualAfterDelete")
    public void getCompositeAccountManualAfterDeleteAcc2() {
        request.header("scenario-product-code", PRODUCT_CODE_DIV);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(accountCompositeGetPath);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}

