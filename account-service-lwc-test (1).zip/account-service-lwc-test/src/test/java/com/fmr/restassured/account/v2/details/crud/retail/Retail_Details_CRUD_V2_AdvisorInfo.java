/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;

/**
 * The Class Retail_Details_CRUD_V2_AdvisorInfo.
 * 
 * @author a703000
 * 
 */
@Test(groups = {Tags.CRITICAL, Tags.RETAIL, Tags.DETAILS, Tags.V2, Tags.TAM, "PFCP-18051"})
public class Retail_Details_CRUD_V2_AdvisorInfo extends PAPBaseServiceTest
{

	protected Retail_Details_CRUD_V2_AdvisorInfo()
	{
		super(Services.Account);
	}


	// Data setup
	private AccountsCommonTestData accountsCommonTestData = new AccountsCommonTestData();

	private VelocityContext context;

	private final float value = 818.89f;

	private final float updatedValue = 426.85f;

	private String ppid;

	private String accId;

	private String accNumber;

	private String accRegCode;

	private String poe = "FRIAG";

	private String advisorLoginId = "7690041287";

	private String advisorRealmType = "FRIAG";

	private String advisorPlanNumber = "500958";

	private String gnumber = "G07492038";
	
	private static final String LOG_TRACKING_ID = Retail_Details_CRUD_V2_AdvisorInfo.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private static final String productSubType = "FIXED INCOME";

	private static final String updatedProductSubType = "EQUITY";

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private final Header eeds = new Header("excludeExternalDataSources", "true");

	private final Header eedsFalse = new Header("excludeExternalDataSources", "false");

	// Velocity Keys
	private static final String IS_TRANSFER_TO_SURVIVOR_IND = "isTransferToSurvivorIndicator";

	private static final String VESTED_VALUE = "vestedValue";

	private static final String UNVESTED_VALUE = "unvestedValue";

	private static final String YEARS_REMAINING = "yearsRemaining";

	private static final String BENEFICIARY_AVAILABLE = "beneficiaryAvailable";

	private static final String COMPLEMENTARY_ADJUSTMENT_OPT = "complementaryAdjustmentOption";

	private static final String EQUITY_PERCENT = "equityPercent";

	private static final String FEDERAL_TAX_WITHHOLDING_PCT = "federalTaxWithholdingPercent";

	private static final String STATE_TAX_WITHHOLDING_PCT = "stateTaxWithholdingPercent";

	private static final String WITHDRAWAL_START_DATE = "withdrawalEligibilityStartDate";

	private static final String WITHDRAWAL_END_DATE = "withdrawalEligibilityEndDate";

	private final float emergencyFund = 3500f;

	FilterableRequestSpecification frs = null;

	private static final String PRODUCT_SUB_TYPE = "productSubType";

	private final String originalOwnerBirthDate = "1960-11-30T00:00:00.000+0000";

	private final String originalOwnerDeceasedDate = "2022-12-30T00:00:00.000+0000";

	private final String tamAssetClass = "TOTAL_EQUITY";

	private final String assetClass = "TOTAL_EQUITY";

	private final float netPercentage = 1.0f;

	private final float netPercentageUpdated = 0.9f;

	private final String assetClass1 = "BOND";

	private final float netPercentage1 = 0.5f;

	private final float netPercentageUpdated1 = 0.2f;

	private final String assetClass2 = "CASH";

	private final float netPercentage2 = 0.3f;

	private final float netPercentageUpdated2 = 0.8f;

	private final String assetClass3 = "OTHER";

	private final float netPercentage3 = 0.4f;

	private final float netPercentageUpdated3 = 0.7f;

	private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";

	private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";

	private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";

	private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";

	private final float netPercentage_T_ALTERNATIVE = 0.8f;

	private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;

	private final float netPercentage_PEA = 0.4f;

	private final float netPercentage_Updated_PEA = 0.2f;

	private final float netPercentage_PCA = 0.2f;

	private final float netPercentage_Updated_PCA = 0.3f;

	private final float netPercentage_PRAA = 0.2f;

	private final float netPercentage_Updated_PRAA = 0.1f;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{

		final String oAuth = AccountUtil.getOauthToken();

		accountsCommonTestData.setValue1(value);

		accountsCommonTestData.set("isInherited", "false");
		accountsCommonTestData.set("isPreviousEmployersAccount", "false");
		accountsCommonTestData.set("state", "AK");
		accountsCommonTestData.setSourceSystem1("RETAIL");
		accountsCommonTestData.set(IS_TRANSFER_TO_SURVIVOR_IND, "true");
		accountsCommonTestData.set(VESTED_VALUE, "100.0");
		accountsCommonTestData.set(UNVESTED_VALUE, "200.0");
		accountsCommonTestData.set(YEARS_REMAINING, "10");
		accountsCommonTestData.set(BENEFICIARY_AVAILABLE, "true");
		accountsCommonTestData.set(COMPLEMENTARY_ADJUSTMENT_OPT, "MANAGED_LOCK_CURRENT_ALLOCATION");
		accountsCommonTestData.set(EQUITY_PERCENT, "0.8");
		accountsCommonTestData.set(FEDERAL_TAX_WITHHOLDING_PCT, "0.8");
		accountsCommonTestData.set(STATE_TAX_WITHHOLDING_PCT, "0.8");
		accountsCommonTestData.set(PRODUCT_SUB_TYPE, productSubType);
		accountsCommonTestData.set(FEDERAL_TAX_WITHHOLDING_PCT, "0.8");
		accountsCommonTestData.set(STATE_TAX_WITHHOLDING_PCT, "0.8");
		accountsCommonTestData.set(WITHDRAWAL_START_DATE, "2020-01-01T00:00:00.000+0000");
		accountsCommonTestData.set(WITHDRAWAL_END_DATE, "2020-01-01T00:00:00.000+0000");

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
                FSREQID, oAuth);
		
		request.given().header(new Header("user-poe", poe))
		                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
		                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
		                .header(new Header("advisor-login-id", advisorLoginId))
		                .header(new Header("advisor-realm-type", advisorRealmType))
		                .header(new Header("advisor-plan-number", advisorPlanNumber))
		                .header(new Header("gnumber", gnumber))
		                .header(new Header("excludeExternalDataSources", "false"));

		// Populate request variables
		context = new VelocityContext();
		context.put("value", String.valueOf(value));
		String source = "RETAIL";
		context.put("source", source);
		context.put(IS_TRANSFER_TO_SURVIVOR_IND, accountsCommonTestData.get(IS_TRANSFER_TO_SURVIVOR_IND));
		context.put(VESTED_VALUE, accountsCommonTestData.get(VESTED_VALUE));
		context.put(UNVESTED_VALUE, accountsCommonTestData.get(UNVESTED_VALUE));
		context.put(YEARS_REMAINING, accountsCommonTestData.get(YEARS_REMAINING));
		context.put(BENEFICIARY_AVAILABLE, accountsCommonTestData.get(BENEFICIARY_AVAILABLE));
		context.put(COMPLEMENTARY_ADJUSTMENT_OPT, accountsCommonTestData.get(COMPLEMENTARY_ADJUSTMENT_OPT));
		context.put(EQUITY_PERCENT, accountsCommonTestData.get(EQUITY_PERCENT));
		context.put(FEDERAL_TAX_WITHHOLDING_PCT, accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT));
		context.put(STATE_TAX_WITHHOLDING_PCT, accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT));
		context.put(WITHDRAWAL_START_DATE, accountsCommonTestData.get(WITHDRAWAL_START_DATE));
		context.put(WITHDRAWAL_END_DATE, accountsCommonTestData.get(WITHDRAWAL_END_DATE));

		context.put("emergencyFundAmount", 2500.0F);
		frs = (FilterableRequestSpecification) request;
	}

	/**
	 * Get account info from the backend. Save the account number.
	 * <p>
	 * Version V2
	 */
	@Test
	public void getRetailAccountInfo()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
		accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));

		accRegCode = response.path("accountList[0].regCode.mnemonic").toString();
		accNumber = response.path("accountList[0].accountId.accountNumber");

		accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
		accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
		accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));

		if (null != (response.path("accountList[0].sourceMarketValue"))) {
			accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
			accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
		}
		ppid = response.path("accountList[0].accountId.owner.id");
		context.put("ppid", ppid);
		accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
		accId = response.path("accountList[0].accountId.id");
		if (accId != null) {
			context.put("accId", accId);
		}

	}

	/**
	 * Create the Retail account.
	 * <p>
	 * Version V2
	 * <p>
	 * Add the EEDS header value as TRUE
	 */
	@Test(dependsOnMethods = "getRetailAccountInfo")
	public void createRetailAccount()
	{
		frs.removeHeader("excludeExternalDataSources");
		request.given().header(eeds);

		context.put("ppid", ppid);
		context.put("mnemonic", accRegCode);
		context.put("value", value);
		context.put("accountNumber", accNumber);
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		context.put("institutionName", accountsCommonTestData.getInstitutionName1());
		context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
		
		if(accId != null)
		{
			//Data cleanup - delete the retail account before creating Retail account
			this.deleteRetailAccount();
			this.frs.removeHeader("accId");
			context.remove("accId");

		}

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);
		// Assert on response
		response.then().log().ifValidationFails().statusCode(200)
		                .body("accountList.find{it.accountId.accountNumber=='"
		                                + accountsCommonTestData.getAccountNumber1()
		                                + "'}.accountId.accountNumber",
		                                equalTo(accountsCommonTestData.getAccountNumber1()))
		                .body("accountList.find{it.accountId.accountNumber=='"
		                                + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id",
		                                notNullValue());

		accId = response.path("accountList.find{it.accountId.accountNumber=='"
		                + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id");
	}

	/**
	 * Validate the Retail Account details after create.
	 * <p>
	 * Version V2
	 * <p>
	 * Add the EEDS header value as FALSE
	 */
	@Test(dependsOnMethods = "createRetailAccount")
	public void verifyRetailAccountDetailsBeforeCreateWithEEDSFalse()
	{
		frs.removeHeader("excludeExternalDataSources");
		request.given().header(eedsFalse);
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		                "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
		                                + accId + "'}.retailAccountDetail.isBrokerageLinkAccount",
		                notNullValue(),
		                "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.fidelityAccount",
		                notNullValue(),
		                "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.isPasAccount",
		                notNullValue(),
		                "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountLevel",
		                notNullValue(),
		                "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.hasUnsettledShares",
		                notNullValue());
	}

	/**
	 * Validate the Retail Account details after create.
	 * <p>
	 * Version V2
	 * <p>
	 * Add the EEDS header value as TRUE
	 */
	@Test(dependsOnMethods = "verifyRetailAccountDetailsBeforeCreateWithEEDSFalse")
	public void verifyRetailAccountDetailsBeforeCreate()
	{
		frs.removeHeader("excludeExternalDataSources");
		request.given().header(eeds);
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

	}

	/**
	 * Create Retail Account Details Request.
	 * <p>
	 * Version V2 Add the EEDS header value as TRUE
	 */
	@Test(dependsOnMethods = "verifyRetailAccountDetailsBeforeCreate")
	public void createRetailAccountDetails()
	{
		// Generate request body
		context.put("ppid", ppid);
		context.put("value", value);
		context.put("accountNumber", accNumber);
		context.put("accId", accId);
		context.put("isInherited", false);
		context.put("isProductSuitable", "true");
		context.put("isPreviousEmployersAccount", false);
		context.put("state", "NC");
		context.put("type", "retailAccountDetail");
		context.put("_type", "RetailAccountDetails");
		context.put("emergencyFundAmount", 2500.0F);
		context.put("productSubType", productSubType);
		context.put("tamAssetClass", tamAssetClass);
		context.put("originalOwnerBirthDate", originalOwnerBirthDate);
		context.put("originalOwnerSpouse", "false");
		context.put("originalOwnerDeceasedDate", originalOwnerDeceasedDate);
		context.put("assetClass", assetClass);
		context.put("netPercentage", netPercentage);
		context.put("assetClass1", assetClass1);
		context.put("netPercentage1", netPercentage1);
		context.put("assetClass2", assetClass2);
		context.put("netPercentage2", netPercentage2);
		context.put("assetClass3", assetClass3);
		context.put("netPercentage3", netPercentage3);
		context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
		context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
		context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
		context.put("netPercentage_PEA", netPercentage_PEA);
		context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
		context.put("netPercentage_PCA", netPercentage_PCA);
		context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
		context.put("netPercentage_PRAA", netPercentage_PRAA);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));
		// Call Account service
		response = request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.isProductSuitable", equalTo(true))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.suitabilityStatus", equalTo("SUITABLE"))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.productSubType", equalTo(productSubType))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
		                                equalTo(tamAssetClass))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.originalOwnerBirthDate",
		                                equalTo(originalOwnerBirthDate))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.originalOwnerDeceasedDate",
		                                equalTo(originalOwnerDeceasedDate))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.originalOwnerSpouse",
		                                equalTo(false))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.federalTaxWithholdingPercent",
		                                equalTo(Float.valueOf(accountsCommonTestData
		                                                .get(FEDERAL_TAX_WITHHOLDING_PCT))))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.stateTaxWithholdingPercent",
		                                equalTo(Float.valueOf(
		                                                accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass + "'}.assetClass", equalTo(assetClass))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass + "'}.netPercentage", equalTo(netPercentage))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass1 + "'}.assetClass", equalTo(assetClass1))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass1 + "'}.netPercentage", equalTo(netPercentage1))

		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass2 + "'}.assetClass", equalTo(assetClass2))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass2 + "'}.netPercentage", equalTo(netPercentage2))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass3 + "'}.assetClass", equalTo(assetClass3))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass3 + "'}.netPercentage", equalTo(netPercentage3))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_T_ALTERNATIVE))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_PCA))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_PEA))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_PRAA));
	}

	/**
	 * Validate the Retail Account details after create.
	 * <p>
	 * Version V2
	 * <p>
	 * Add the EEDS header value as FALSE
	 */

	@Test(dependsOnMethods = "createRetailAccountDetails")
	public void getRetailAccountDetailsAfterCreate()
	{
		frs.removeHeader("excludeExternalDataSources");
		request.given().header(eedsFalse);
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		                "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
		                                + accId + "'}.retailAccountDetail.isBrokerageLinkAccount",
		                notNullValue(),
		                "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.fidelityAccount",
		                equalTo(true))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
		                                equalTo(tamAssetClass))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.originalOwnerBirthDate",
		                                equalTo(originalOwnerBirthDate))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.originalOwnerDeceasedDate",
		                                equalTo(originalOwnerDeceasedDate))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.originalOwnerSpouse",
		                                equalTo(false))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.isProductSuitable", equalTo(true))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.suitabilityStatus", equalTo("SUITABLE"))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.productSubType", equalTo(productSubType))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass + "'}.assetClass", equalTo(assetClass))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass + "'}.netPercentage", equalTo(netPercentage))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass1 + "'}.assetClass", equalTo(assetClass1))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass1 + "'}.netPercentage", equalTo(netPercentage1))

		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass2 + "'}.assetClass", equalTo(assetClass2))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass2 + "'}.netPercentage", equalTo(netPercentage2))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass3 + "'}.assetClass", equalTo(assetClass3))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass3 + "'}.netPercentage", equalTo(netPercentage3))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_T_ALTERNATIVE))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_PCA))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_PEA))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_PRAA));

	}

	

	/**
	 * Update the account details for Retail Account.
	 * <p>
	 * Version V2
	 * <p>
	 * Add the EEDS header value as TRUE
	 */
	@Test(dependsOnMethods = "getRetailAccountDetailsAfterCreate")
	public void updateRetailAccountDetails()
	{
		context.put("ppid", ppid);
		context.put("value", updatedValue);
		context.put("accountNumber", accNumber);
		context.put("accId", accId);
		context.put("isPasAccount", true);
		context.put("isProductSuitable", "false");
		context.put("isBrokerageLinkAccount", true);
		context.put("state", "NC");
		context.put("type", "retailAccountDetail");
		context.put("_type", "RetailAccountDetails");
		context.put("emergencyFundAmount", emergencyFund);
		context.put("productSubType", updatedProductSubType);
		context.put("assetClass", assetClass);
		context.put("netPercentage", netPercentageUpdated);
		context.put("assetClass1", assetClass1);
		context.put("netPercentage1", netPercentageUpdated1);
		context.put("assetClass2", assetClass2);
		context.put("netPercentage2", netPercentageUpdated2);
		context.put("assetClass3", assetClass3);
		context.put("netPercentage3", netPercentageUpdated3);
		context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
		context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
		context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
		context.put("netPercentage_PEA", netPercentage_Updated_PEA);
		context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
		context.put("netPercentage_PCA", netPercentage_Updated_PCA);
		context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
		context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));
		// Call Account service
		response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.isProductSuitable", equalTo(false))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.suitabilityStatus", equalTo("UNSUITABLE"))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
		                                equalTo(tamAssetClass))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.productSubType",
		                                equalTo(updatedProductSubType))

		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass + "'}.assetClass", equalTo(assetClass))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass + "'}.netPercentage", equalTo(netPercentageUpdated))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass1 + "'}.assetClass", equalTo(assetClass1))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass1 + "'}.netPercentage", equalTo(netPercentageUpdated1))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass2 + "'}.assetClass", equalTo(assetClass2))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass2 + "'}.netPercentage", equalTo(netPercentageUpdated2))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass3 + "'}.assetClass", equalTo(assetClass3))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass3 + "'}.netPercentage", equalTo(netPercentageUpdated3))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_Updated_T_ALTERNATIVE))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_Updated_PCA))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_Updated_PEA))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_Updated_PRAA));

	}

	/**
	 * Validate the updated Retail Account details.
	 * <p>
	 * Version V2
	 * <p>
	 * Add the EEDS header value as TRUE
	 */
	@Test(dependsOnMethods = "updateRetailAccountDetails")
	public void getRetailAccountDetailsAfterUpdate()
	{
		context.put("ppid", ppid);
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		                "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='"
		                                + accId + "'}.retailAccountDetail.isBrokerageLinkAccount",
		                notNullValue(),
		                "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.fidelityAccount",
		                notNullValue(),
		                "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.isPasAccount",
		                notNullValue())
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
		                                equalTo(tamAssetClass))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.isProductSuitable", equalTo(false))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.suitabilityStatus", equalTo("UNSUITABLE"))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.productSubType",
		                                equalTo(updatedProductSubType))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass + "'}.assetClass", equalTo(assetClass))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass + "'}.netPercentage", equalTo(netPercentageUpdated))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass1 + "'}.assetClass", equalTo(assetClass1))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass1 + "'}.netPercentage", equalTo(netPercentageUpdated1))

		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass2 + "'}.assetClass", equalTo(assetClass2))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass2 + "'}.netPercentage", equalTo(netPercentageUpdated2))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass3 + "'}.assetClass", equalTo(assetClass3))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass3 + "'}.netPercentage", equalTo(netPercentageUpdated3))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
		                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_Updated_T_ALTERNATIVE))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_Updated_PCA))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_Updated_PEA))
		                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId
		                                + "'}.retailAccountDetail.accountDetail.assetAllocation.allocation[4].allocation.find{it.assetClass=='"
		                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage",
		                                equalTo(netPercentage_Updated_PRAA));
		this.deleteRetailAccount();

	}

	/**
	 * Delete the account details for Retail account.
	 * <p>
	 * Version V2
	 * <p>
	 * Add the EEDS header value as TRUE
	 */
	private void deleteRetailAccount()
	{
		context.put("mnemonic", accRegCode);
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		context.put("institutionName", accountsCommonTestData.getInstitutionName1());
		context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
		context.put("ppid", ppid);
		context.put("value", updatedValue);
		context.put("accountNumber", accNumber);
		context.put("id", accId);
		context.put("emergencyFundAmount", 3500.0F);
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));
		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("isEmpty()",
				Matchers.is(true));

	}
}