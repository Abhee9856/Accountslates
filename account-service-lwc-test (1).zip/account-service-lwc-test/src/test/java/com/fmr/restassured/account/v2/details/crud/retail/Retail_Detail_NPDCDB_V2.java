/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.v2.composite.crud.retail.Retail_Composite_v2_AllDetails_ScenarioId;

import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Contains tests that validate NPDCDB flag for Account Details operation for Retail Accounts
 *
 * @author a631781
 */

@Test(groups = {Tags.RETAIL, Tags.DETAILS, Tags.V2})
public class Retail_Detail_NPDCDB_V2 extends PAPBaseServiceTest {

    protected Retail_Detail_NPDCDB_V2() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;
    private final String oAuth = AccountUtil.getOauthToken();

    private float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String source = "RETAIL";

    private final String asOfDate1 = "2014-10-31";

    private final String productSubType = "FIXED INCOME";


    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Composite_v2_AllDetails_ScenarioId.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;
    FilterableRequestSpecification frs = null;
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;
    private String mid;
    private String ssn;
    private String accId;

    private String accNumber;

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_createRetailAccount", oAuth);
        testDataUtil = new TestDataUtil();
        mid = accountsCommonTestData.getMid();
        ssn = accountsCommonTestData.getSsn();
        accountsCommonTestData.setAsOfDate1(asOfDate1);
        accountsCommonTestData.setValue1(value);

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", mid, oAuth));

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-retail-lid", ssn))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
        context = new VelocityContext();
        frs = (FilterableRequestSpecification) request;

    }

    /**
     * Create Retail account with different combination of Regcodes from DataProvider.
     * <p>
     * Version V2
     */
    @Test(dataProvider = "getNPDCDBRetailAccountData",
            dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void performCrudOperations(final AccountRegCodeTestData data) {
        getRetailAccount(data);
        createRetailAccount(data);
        createRetailAccountDetails(data);
        getRetailAccountDetailsAfterCreate(data);
        updateRetailAccountDetails(data);
        getRetailAccountDetailsAfterUpdate(data);
        deleteRetailAccount(data);
        getRetailAccountAfterDelete(data);

    }


    //Get account info from the backend.
    private void getRetailAccount(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("source", source);
        frs.removeHeader("excludeExternalDataSources");
        request.header(new Header("excludeExternalDataSources", "false"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accountList", not(emptyArray()));

        //Get Account number based on the regCode
        if (null != response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1() + "'}.accountId.accountNumber")) {
            accNumber = response.path("accountList.find{it.regCode.mnemonic=='" + data.getRegCode1() + "'}.accountId.accountNumber");
        } else {
            accNumber = response.path("accountList[0].accountId.accountNumber");

        }
    }

    //Create Retail Account
    private void createRetailAccount(final AccountRegCodeTestData data) {
        // Generate request body
        frs.removeHeader("excludeExternalDataSources");
        request.header(new Header("excludeExternalDataSources", "true"));

        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", String.valueOf(value));
        context.put("mnemonic", data.getRegCode1());
        context.put("accountNumber", accNumber);
        context.put("id", "");
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);
        // Assert on response
        response.then().log().ifValidationFails().statusCode(200)
                .body("accountList.find{it.accountId.accountNumber=='" + accNumber + "'}.accountId.accountNumber",
                        equalTo(accNumber))
                .body("accountList.find{it.accountId.accountNumber=='" + accNumber + "'}.accountId.id", notNullValue());

        accId = response.path("accountList.find{it.accountId.accountNumber=='" + accNumber + "'}.accountId.id");
    }

    // Create Retail account Details V2.
    private void createRetailAccountDetails(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", value);
        context.put("accountNumber", accNumber);
        context.put("accId", accId);
        context.put("type", "retailAccountDetail");
        context.put("_type", "RetailAccountDetails");
        context.put("isInherited", false);
        context.put("isProductSuitable", "true");
        context.put("isPreviousEmployersAccount", false);
        context.put("emergencyFundAmount", 2500.0F);
        context.put("externalDataSources", "false");
        context.put("productSubType", productSubType);
        context.put("isNpDCDBComplied", "true");

        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));
        // Call Account service
        response =
                request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.isProductSuitable", equalTo(true),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.sourceSystem", equalTo(source),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.accountNumber", equalTo(accNumber),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.id", equalTo(accId),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.isNpDCDBComplied", equalTo(true));
    }


    // Get Retail account details V2
    private void getRetailAccountDetailsAfterCreate(final AccountRegCodeTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

        // Assert on response
        response.prettyPrint();
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.isProductSuitable", equalTo(true),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.sourceSystem", equalTo(source),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.accountNumber", equalTo(accNumber),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.id", equalTo(accId),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.isNpDCDBComplied", equalTo(true));
    }

    // Update Retail account Details V2.
    private void updateRetailAccountDetails(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", updatedValue);
        context.put("accountNumber", accNumber);
        context.put("accId", accId);
        context.put("type", "retailAccountDetail");
        context.put("_type", "RetailAccountDetails");
        context.put("isInherited", false);
        context.put("isProductSuitable", "true");
        context.put("isPreviousEmployersAccount", false);
        context.put("emergencyFundAmount", 2500.0F);
        context.put("externalDataSources", "false");
        context.put("productSubType", productSubType);
        context.put("isNpDCDBComplied", "true");
        // Generate request body
        request.body(
                IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.isProductSuitable", equalTo(true),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.sourceSystem", equalTo(source),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.accountNumber", equalTo(accNumber),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.id", equalTo(accId),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.isNpDCDBComplied", equalTo(true));
    }

    // Get Retail account details V2 after updating Details
    private void getRetailAccountDetailsAfterUpdate(final AccountRegCodeTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

        // Assert on response
        response.prettyPrint();
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.isProductSuitable", equalTo(true),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.sourceSystem", equalTo(source),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.accountNumber", equalTo(accNumber),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.accountId.id", equalTo(accId),
                        "accountDetails.find{it.retailAccountDetail.accountDetail.accountId.id=='" + accId + "'}.retailAccountDetail.accountDetail.isNpDCDBComplied", equalTo(true));
    }

    // Delete Account
    private void deleteRetailAccount(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("mnemonic", data.getRegCode1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", updatedValue);
        context.put("accountNumber", accNumber);
        context.put("id", accId);
        context.put("emergencyFundAmount", 3500.0F);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("isEmpty()",
                Matchers.is(true));

    }

    //Get account info after Delete.
    private void getRetailAccountAfterDelete(final AccountRegCodeTestData data) {
        // Generate request body
        context.put("source", source);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("isEmpty()",
                        Matchers.is(true));
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        testDataUtil.closeSQLiteConnection();
    }
}