/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.workplace.masking;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;

import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.containsString;

/**
 * Tests the masking of Display Name. Each step of the test flow will validate the displayName is still masked.
 *
 * Test Flow:
 *  1. Get accounts with EEDS=false
 *  2. Create account with out a display name (displayName = null)
 *  3. Get accounts V1 with EEDS=true
 *  4. Get composite V1 with EEDS=true
 *  5. Get accounts V2 with EEDS=true
 *  6. Get composite V2 with EEDS=true
 *  7. Update account with account number saved as display name (displayName = accountNumber)
 *  8. Get accounts V1 with EEDS=true
 *  9. Get composite V1 with EEDS=true
 *  10. Get accounts V2 with EEDS=true
 *  11. Get composite V2 with EEDS=true
 *
 * @author a601767
 */
@Test(groups = {
        Tags.WORKPLACE,
        Tags.ACCOUNT,
        Tags.V1})
public class DisplayNameMasking_EEDSTrue extends PAPBaseServiceTest
{

    /**
     * The constructor
     */
    protected DisplayNameMasking_EEDSTrue()
    {
        super(Services.Account);
    }

    /** The accountsCommonTestData */
    private AccountsCommonTestData testData = null;

    /** The Velocity context */
    private VelocityContext context;

    /** The sourceMarketValue */
    private final float value = 120.0F;

    /** The testDataUtil */
    private TestDataUtil testDataUtil;

    /** The accId */
    private String accId;

    /** The accNumber */
    private String accNumber;

    /** The planNumber */
    private String planNumber;

    /** The masked account number */
    private String maskedAccountNumber;

    /** The displayName from the response */
    private String responseDisplayName;

    /**
     * Initialization method
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
        final String oAuth = AccountUtil.getOauthToken();
        testData = TestDataUtil.populateRegressionTestData("account_get_PRDC", oAuth);
        testDataUtil = new TestDataUtil();
        testData.setMid(testData.getMid());
        testData.setAsOfDate1("2014-10-31");
        testData.setValue1(value);
        DataCleanup.deleteCustomerDataFromCP("mid", testData.getMid(), oAuth, "true");

        testData.setPpid(Identity.createHouseholdIdentity("mid", testData.getMid(), oAuth));

        setDefaultRequestHeaders(oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", testData.getMid());
        context.put("fescoLid", testData.getSsn());
        context.put("ppid", testData.getPpid());
        context.put("value", String.valueOf(value));

        request.given().header(new Header("return-prdc-accounts", "true"));

    }

    /**
     * Get account info from the backend.
     */
    @Test
    public void getWorkplaceAccount()
    {
        // Generate request body
        context.put("source", "WORKPLACE");
        context.put("externalDataSources", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode", equalTo(true));

        accNumber = response.path("accounts[0].account.accountId.accountNumber");
        planNumber = response.path("accounts[0].details.planId.planNumber");
        testData.setMnemonic1(response.path("accounts[0].account.regCode.mnemonic"));
        testData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
        testData.setInstitutionName1(response.path("accounts[0].account.institutionName"));
        testData.setDisplayName1(response.path("accounts[0].account.displayName"));
        testData.setAsOfDate1(response.path("accounts[0].account.sourceMarketValue.asOfDate"));
        responseDisplayName = "accountList[0].displayName";

        maskedAccountNumber = TestDataUtil.getMaskedAccountNumber(accNumber);

        response.then().log().ifValidationFails()
                .body("accounts[0].account.displayName", containsString(maskedAccountNumber));

    }

    /**
     * Create Workplace Account
     */
    @Test(dependsOnMethods = "getWorkplaceAccount")
    public void createWorkplaceAccount()
    {
        // Generate request body
        context.put("value", String.valueOf(value));
        context.put("mnemonic", testData.getMnemonic1());
        context.put("institutionName", testData.getInstitutionName1());
        context.put("asOfDate", testData.getAsOfDate1());
        context.put("accountNumber", accNumber);
        context.put("excludeExternalDataSources", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_NULL_DISPLAY_NAME_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true));

        accId = response.path("accountList[0].accountId.id");

    }


    /**
     * Validate the display name.
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void v1AccountGet()
    {
        // Exclude external data sources
        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(planNumber));
    }

    /**
     * Validate the display name.
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void v1CompositeGet()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Call Account service
        response = request.log().all().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accounts.find{it.account.accountId.id=='" + accId + "'}.account.displayName",
                        equalTo(planNumber));
    }

    /**
     * Validate the display name.
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void v2AccountGet()
    {
        // Generate request body
        request.given().body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2))
                .header("user-fesco-lid", testData.getSsn())
                .header("user-mid", testData.getMid())
                .header("user-poe", "RETAIL")
                .header("excludeExternalDataSources", true);

        // Call Account service
        response = request.log().all().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", equalTo(planNumber));
    }

    /**
     * Validate the display name.
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void v2CompositeGet()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().all().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accounts.find{it.account.accountId.id=='" + accId + "'}.account.displayName",
                        equalTo(planNumber));
    }

    /**
     * Update workplace account's display name
     */
    @Test(dependsOnMethods = {"v1AccountGet", "v1CompositeGet", "v2AccountGet", "v2CompositeGet"})
    public void updateWorkplaceAccountDisplayName()
    {
        // Generate request body
        context.put("displayName", testData.getDisplayName1());
        context.put("accountId", accId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_NULL_DISPLAY_NAME_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body(responseDisplayName, containsString(maskedAccountNumber));

        accId = response.path("accountList[0].accountId.id");

    }

    /**
     * Validate the updated display name.
     */
    @Test(dependsOnMethods = "updateWorkplaceAccountDisplayName")
    public void v1AccountGet2()
    {
        // Exclude external data sources
        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", containsString(maskedAccountNumber));
    }

    /**
     * Validate the updated display name.
     */
    @Test(dependsOnMethods = "updateWorkplaceAccountDisplayName")
    public void v1CompositeGet2()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Call Account service
        response = request.log().all().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accounts.find{it.account.accountId.id=='" + accId + "'}.account.displayName",
                        containsString(maskedAccountNumber));
    }

    /**
     * Validate the updated display name.
     */
    @Test(dependsOnMethods = "updateWorkplaceAccountDisplayName")
    public void v2AccountGet2()
    {
        // Generate request body
        request.given().body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2))
                .header("user-fesco-lid", testData.getSsn())
                .header("user-mid", testData.getMid())
                .header("user-poe", "RETAIL")
                .header("excludeExternalDataSources", true);

        // Call Account service
        response = request.log().all().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList.find{it.accountId.id=='" + accId + "'}.displayName", containsString(maskedAccountNumber));
    }

    /**
     * Validate the updated display name.
     */
    @Test(dependsOnMethods = "updateWorkplaceAccountDisplayName")
    public void v2CompositeGet2()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().all().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accounts.find{it.account.accountId.id=='" + accId + "'}.account.displayName",
                        containsString(maskedAccountNumber));
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
        testDataUtil.closeSQLiteConnection();
    }
}
