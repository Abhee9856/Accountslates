/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.contributions.crud.manual;

import com.fmr.ast.platform.account.model.Contribution;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsContributionsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.utilities.ContributionsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountContributionsTestData;
import io.restassured.http.Header;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;
import static org.junit.Assert.assertFalse;

import java.util.List;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operation for Manual contributions against V2.
 *
 * @author a514676 Updated by a608077 on 10/13/2021 to include changes for 'scenario-id' header(PFCP-6168) Updated by
 *         a631781 to include changes for "Set method" (PFCP-9562)
 */
@Test(groups = {Tags.CRITICAL, Tags.MANUAL, Tags.CONTRIBUTIONS, Tags.V2})
public class Manual_CRUD_V2 extends PAPBaseServiceTest
{

	protected Manual_CRUD_V2()
	{
		super(Services.Account);
	}

	private String ppid;

	private String accountNumber;

	private String accountId;

	private VelocityContext context;

	private TestDataUtil testDataUtil;

	private static final String MONEY = "MONEY";

	private static final String PERCENT = "PERCENT";

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private static final String CALLING_APP_ID = "AP136091";

	private static final String APP_ID = "AP136091";

	private static final String LOG_TRACKING_ID = Manual_CRUD_V2.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{

		final String oAuthToken = AccountUtil.getOauthToken();
		testDataUtil = new TestDataUtil();

		// Data setup
		AccountsCommonTestData accountsCommonTestData = TestDataUtil
				.populateRegressionTestData("account_contributions_CRUD_Manual_401K", oAuthToken);

		String mid = "ManualContributionV2TestMid";
	    mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(mid);
		// Set default request headers
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);

		// Data cleanup
		DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuthToken);

		// Set ppid
		ppid = Identity.createPrincipalWithScenario(AccountConstants.MID, mid, SCENARIO_PRODUCT_CODE,
				SCENARIO_CATEGORY_CODE, oAuthToken);
		accountsCommonTestData.setPpid(ppid);

		String scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE,
				SCENARIO_CATEGORY_CODE, oAuthToken);

		Identity.createHouseholdIdentityWithProductCode(mid, oAuthToken, SCENARIO_PRODUCT_CODE,
				SCENARIO_CATEGORY_CODE);
		
		this.request.given().header(new Header("user-poe", "RETAIL"))
		.header(new Header("user-mid", mid))
		.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
		.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
		// optional header scenario-id
		.header(new Header("scenario-id", scenarioId));

		context = new VelocityContext();
		context.put("ppid", ppid);
		context.put("source", AccountConstants.MANUAL);
	}

	/**
	 * Create the Manual account. Save the account id.
	 * <p>
	 * Version V2
	 */
	@Test
	public void createManualAccount()
	{

		float value = 100.0f;
		context.put("value", value);
		String sourceSystem = "MANUAL";
		context.put("source", sourceSystem);

		String displayName = "Display_Name";
		context.put("displayName", displayName);
		String institutionName = "InstitutionalName";
		context.put("institutionName", institutionName);
		String asOfDate = "2014-10-31";
		context.put("asOfDate", asOfDate);

		String mnemonic = "401K";
		context.put("mnemonic", mnemonic);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList",
				Matchers.not(empty()), "accountList[0].regCode.mnemonic", Matchers.notNullValue(),
				"accountList[0].accountId.accountNumber", Matchers.notNullValue());

		// Gets and saves the CFP account ID
		accountId = response.path("accountList[0].accountId.id");
		accountNumber = response.path("accountList[0].accountId.accountNumber");
		context.put("accId", accountId);
		context.put("accountNumber", accountNumber);
	}

	/**
	 * Validate the account was created correctly.
	 */
	@Test(dependsOnMethods = "createManualAccount")
	public void getManualAccountAfterCreate()
	{
		// Generate request body

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList",
				Matchers.not(empty()));

	}

	@Test(dependsOnMethods = "getManualAccountAfterCreate", dataProvider = "getManualContributionData", dataProviderClass = ContributionsDataProviderUtil.class)
	public void performCrudOperations(final AccountContributionsTestData data)
	{
		this.createAccountContributions(data);
		this.getContributionsAfterCreate(data);
		this.updateAccountContributions(data);
		this.getContributionsAfterUpdate(data);
		this.setAccountContributions(data);
		this.getContributionsAfterSet(data);
		this.deleteAccountContributions(data);
		this.getContributionsAfterDelete();
	}

	/**
	 * Create the account contributions.
	 * <p>
	 * Version V2
	 */
	private void createAccountContributions(final AccountContributionsTestData data)
	{

		// Generate request body
		context.put("contribValue", data.getContributionValue());
		context.put("valueType", data.getValueType());
		context.put("contribType", data.getContributionType());
		context.put("contribTaxType", data.getContributionTaxType());
		context.put("contribLevelType", data.getContributionLevelType());
		context.put("frequency", data.getFrequency());
		context.put("contributor", data.getContributor());
		context.put("isDetailed", data.getIsDetailed());

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
				not(empty()), "accountContributions[0].isDetailed ", equalTo(data.getIsDetailed()),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ data.getContributionValue() + "f}.contributionType",
						Matchers.equalTo(data.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ data.getContributionValue() + "f}.contributionTaxType",
								Matchers.equalTo(data.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ data.getContributionValue() + "f}.contributionLevelType",
										Matchers.equalTo(data.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ data.getContributionValue() + "f}.contributor",
												Matchers.equalTo(data.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ data.getContributionValue() + "f}.contribution.value",
														Matchers.equalTo(Float.valueOf(data.getContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ data.getContributionValue() + "f}.frequency",
																Matchers.equalTo(data.getFrequency()));

	}

	/**
	 * Validate the contributions.
	 * <p>
	 * Version V2
	 */
	private void getContributionsAfterCreate(final AccountContributionsTestData data)
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
				not(empty()), "accountContributions[0].isDetailed ", equalTo(data.getIsDetailed()),
				"accountContributions[0].accountId.accountNumber", Matchers.equalTo(accountNumber),
				"accountContributions[0].accountId.id", Matchers.equalTo(accountId),
				"accountContributions[0].accountId.owner.id", Matchers.equalTo(ppid),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ data.getContributionValue() + "f}.contributionType",
						Matchers.equalTo(data.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ data.getContributionValue() + "f}.contributionTaxType",
								Matchers.equalTo(data.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ data.getContributionValue() + "f}.contributionLevelType",
										Matchers.equalTo(data.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ data.getContributionValue() + "f}.contributor",
												Matchers.equalTo(data.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ data.getContributionValue() + "f}.contribution.value",
														Matchers.equalTo(Float.valueOf(data.getContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ data.getContributionValue() + "f}.frequency",
																Matchers.equalTo(data.getFrequency()));

	}

	/**
	 * Update the contribution.
	 * <p>
	 * Version V2
	 */
	private void updateAccountContributions(final AccountContributionsTestData data)
	{

		// Generate request body
		context.put("contribType", data.getContributionType());
		context.put("contribTaxType", data.getContributionTaxType());
		context.put("contribLevelType", data.getContributionLevelType());
		context.put("frequency", data.getFrequency());
		context.put("contributor", data.getContributor());
		context.put("valueType", PERCENT);
		context.put("contribValue", data.getUpdatedContributionValue());
		context.put("isDetailed", data.getUpdatedIsDetailed());

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_UPDATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.UPDATE_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
				Matchers.not(empty()), "accountContributions[0].isDetailed ",
				equalTo(data.getUpdatedIsDetailed()),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ data.getUpdatedContributionValue() + "f}.contributionType",
						Matchers.equalTo(data.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ data.getUpdatedContributionValue() + "f}.contributionTaxType",
								Matchers.equalTo(data.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ data.getUpdatedContributionValue() + "f}.contributionLevelType",
										Matchers.equalTo(data.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ data.getUpdatedContributionValue() + "f}.contributor",
												Matchers.equalTo(data.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ data.getUpdatedContributionValue() + "f}.contribution.value",
														Matchers.equalTo(Float.valueOf(data.getUpdatedContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ data.getUpdatedContributionValue() + "f}.contribution.valueType",
																Matchers.equalTo(PERCENT),
																"accountContributions[0].contributions.find{it.contribution.value=="
																		+ data.getUpdatedContributionValue() + "f}.frequency",
																		Matchers.equalTo(data.getFrequency()));
	}

	/**
	 * Validate the contribution was updated.
	 * <p>
	 * Version V2
	 */
	private void getContributionsAfterUpdate(final AccountContributionsTestData data)
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
				Matchers.not(empty()), "accountContributions[0].isDetailed ",
				equalTo(data.getUpdatedIsDetailed()), "accountContributions[0].accountId.accountNumber",
				Matchers.equalTo(accountNumber), "accountContributions[0].accountId.id",
				Matchers.equalTo(accountId), "accountContributions[0].accountId.owner.id",
				Matchers.equalTo(ppid),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ data.getUpdatedContributionValue() + "f}.contributionType",
						Matchers.equalTo(data.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ data.getUpdatedContributionValue() + "f}.contributionTaxType",
								Matchers.equalTo(data.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ data.getUpdatedContributionValue() + "f}.contributionLevelType",
										Matchers.equalTo(data.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ data.getUpdatedContributionValue() + "f}.contributor",
												Matchers.equalTo(data.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ data.getUpdatedContributionValue() + "f}.contribution.value",
														Matchers.equalTo(Float.valueOf(data.getUpdatedContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ data.getUpdatedContributionValue() + "f}.contribution.valueType",
																Matchers.equalTo(PERCENT),
																"accountContributions[0].contributions.find{it.contribution.value=="
																		+ data.getUpdatedContributionValue() + "f}.frequency",
																		Matchers.equalTo(data.getFrequency()));

		final List<String> list = response.jsonPath()
				.getList("accountContributions[0].contributions.contribution.valueType");
		assertFalse(list.contains(MONEY));
	}

	/**
	 * Set the account contributions.
	 * <p>
	 * Version V2
	 */
	private void setAccountContributions(final AccountContributionsTestData data)
	{

		// Generate request body
		context.put("contribValue", data.getContributionValue());
		context.put("valueType", data.getValueType());
		context.put("contribType", data.getContributionType());
		context.put("contribTaxType", data.getContributionTaxType());
		context.put("contribLevelType", data.getContributionLevelType());
		context.put("frequency", data.getFrequency());
		context.put("contributor", data.getContributor());

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountConstants.SET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
				Matchers.not(empty()),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ data.getContributionValue() + "f}.contributionType",
						Matchers.equalTo(data.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ data.getContributionValue() + "f}.contributionTaxType",
								Matchers.equalTo(data.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ data.getContributionValue() + "f}.contributionLevelType",
										Matchers.equalTo(data.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ data.getContributionValue() + "f}.contributor",
												Matchers.equalTo(data.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ data.getContributionValue() + "f}.contribution.value",
														Matchers.equalTo(Float.valueOf(data.getContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ data.getContributionValue() + "f}.frequency",
																Matchers.equalTo(data.getFrequency()));

	}

	/**
	 * Validate the contributions after set.
	 * <p>
	 * Version V2
	 */
	private void getContributionsAfterSet(final AccountContributionsTestData data)
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
				"accountContributions[0].accountId.accountNumber", Matchers.equalTo(accountNumber),
				"accountContributions[0].accountId.id", Matchers.equalTo(accountId),
				"accountContributions[0].accountId.owner.id", Matchers.equalTo(ppid),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ data.getContributionValue() + "f}.contributionType",
						Matchers.equalTo(data.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ data.getContributionValue() + "f}.contributionTaxType",
								Matchers.equalTo(data.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ data.getContributionValue() + "f}.contributionLevelType",
										Matchers.equalTo(data.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ data.getContributionValue() + "f}.contributor",
												Matchers.equalTo(data.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ data.getContributionValue() + "f}.contribution.value",
														Matchers.equalTo(Float.valueOf(data.getContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ data.getContributionValue() + "f}.frequency",
																Matchers.equalTo(data.getFrequency()));

	}

	/**
	 * Delete the contribution
	 * <p>
	 * Version V2
	 */
	private void deleteAccountContributions(final AccountContributionsTestData data)
	{
		// Generate request body
		context.put("contribType", data.getContributionType());
		context.put("contribTaxType", data.getContributionTaxType());
		context.put("contribLevelType", data.getContributionLevelType());
		context.put("frequency", data.getFrequency());
		context.put("contributor", data.getContributor());
		context.put("valueType", PERCENT);
		context.put("contribValue", data.getUpdatedContributionValue());
		context.put("isDetailed", data.getUpdatedIsDetailed());

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_DELETE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.DELETE_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);

		try
		{
			final List<Contribution> contributions = response.jsonPath()
					.getList("accountContributions[0].contributions", Contribution.class);
			contributions.forEach(contribution -> {
				if (contribution.getContributionType().name().equals(data.getContributionType())
						&& contribution.getContributionTaxType().name()
						.equals(data.getContributionTaxType()))
				{
					Assert.fail();
				}
			});
		}
		catch (IllegalArgumentException e)
		{
			response.then().body("isEmpty()", Matchers.is(true));
		}

	}

	/**
	 * Validate the contributions were deleted.
	 * <p>
	 * Version V2
	 */
	private void getContributionsAfterDelete()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("isEmpty()",
				Matchers.is(true));

	}

	@AfterClass(alwaysRun = true)
	public void closeDBConnections()
	{
		testDataUtil.closeSQLiteConnection();
	}
}
