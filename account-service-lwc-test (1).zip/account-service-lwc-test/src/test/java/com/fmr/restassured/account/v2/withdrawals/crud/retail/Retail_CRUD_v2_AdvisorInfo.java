/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.withdrawals.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.emptyArray;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsWithdrawalsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;

/**
 * Tests CRUD operation for Retail withdrawals against V2.
 *
 * @author a703000
 * 
 */
@Test(groups = {Tags.CRITICAL, Tags.RETAIL, Tags.WITHDRAWALS, Tags.V2, "PFCP-18051"})

public class Retail_CRUD_v2_AdvisorInfo extends PAPBaseServiceTest
{

	protected Retail_CRUD_v2_AdvisorInfo()
	{
		super(Services.Account);
	}

	// Data setup
	private String ppid;

	private String mnemonic;

	private String accountNumber;

	private String accountId;

	private String sourceSystem;

	private String displayName;

	private float value;

	private String institutionName;

	private String asOfDate;

	private VelocityContext context;

	private String poe = "FRIAG";

	private String advisorLoginId = "7690041287";

	private String advisorRealmType = "FRIAG";

	private String advisorPlanNumber = "500958";

	private String gnumber = "G07492038";

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private static final String USD = "USD";

	private static final String LOG_TRACKING_ID = Retail_CRUD_v2_AdvisorInfo.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private static final String REGULAR = "Regular";

	
	FilterableRequestSpecification frs = null;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{

		final String oAuth = AccountUtil.getOauthToken();

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
		                FSREQID, oAuth);

		this.request.given().header(new Header("user-poe", poe))
		                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
		                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
		                .header(new Header("advisor-login-id", advisorLoginId))
		                .header(new Header("advisor-realm-type", advisorRealmType))
		                .header(new Header("advisor-plan-number", advisorPlanNumber))
		                .header(new Header("gnumber", gnumber))
		                .header(new Header("excludeExternalDataSources", "false"));

		// Populate request context with user IDs
		context = new VelocityContext();

		context.put("source", "RETAIL");

	}

	/**
	 * Get Retail account info from the backend. Save the account number.
	 */
	@Test
	public void getRetailAccountInfo()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList", not(emptyArray()));
		ppid = response.path("accountList[0].accountId.owner.id");
		context.put("ppid", ppid);
		mnemonic = response.path("accountList[0].regCode.mnemonic");
		accountNumber = response.path("accountList[0].accountId.accountNumber");
		sourceSystem = response.path("accountList[0].accountId.sourceSystem");
		displayName = response.path("accountList[0].displayName");
		value = response.path("accountList[0].sourceMarketValue.amount.value");
		institutionName = response.path("accountList[0].institutionName");
		asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
		// Gets and saves the CFP account ID
		accountId = response.path("accountList[0].accountId.id");
		context.put("accId", accountId);
	}

	/**
	 * Create the Retail account. Save the account id.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "getRetailAccountInfo")
	public void createRetailAccount()
	{
		context.put("mnemonic", mnemonic);
		context.put("value", value);
		context.put("source", sourceSystem);
		context.put("accountNumber", accountNumber);
		context.put("displayName", displayName);
		context.put("institutionName", institutionName);
		context.put("asOfDate", asOfDate);
		context.put("ppid", ppid);
		
		if(accountId != null)
		{
			//Data cleanup - delete the retail account before creating Retail account
			this.deleteRetailAccount();
			frs.removeHeader("accId");
			context.remove("accId");

		}
		

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
		                "accountList[0].regCode.mnemonic", equalTo(mnemonic),
		                "accountList[0].accountId.accountNumber", equalTo(accountNumber));

		// Gets and saves the CFP account ID
		accountId = response.path("accountList[0].accountId.id");
		context.put("accId", accountId);
	}

	/**
	 * Validate the account was created correctly.
	 */
	@Test(dependsOnMethods = "createRetailAccount")
	public void getRetailAccountAfterCreate()
	{
		// Generate request body
		context.put("externalDataSources", true);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList",
		                not(empty()));

	}

	/**
	 * The is the test flow. It iterates through the data provider, performing CRUD operations for each use case.
	 *
	 * @param data
	 *                the test cases
	 */
	@Test(dependsOnMethods = "getRetailAccountAfterCreate")
	public void performCrudOperations()
	{
		this.createAccountWithdrawals();
		this.getWithdrawalsAfterCreate();
		this.updateAccountWithdrawals();
		this.getWithdrawalsAfterUpdate();
		this.deleteAccountWithdrawals();
		this.getWithdrawalsAfterDelete();
	}

	/**
	 * Create the account withdrawals.
	 */
	private void createAccountWithdrawals()
	{
		// Generate request body
		context.put("withdrawalType", REGULAR);
		context.put("withdrawalValue", "30");
		context.put("valueType", "MONEY");
		context.put("frequency", "DAILY");

		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_V2_TEMPLATE)).log().ifValidationFails();

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
		                .body("accountWithdrawals", not(empty()))
		                .body("accountWithdrawals[0].withdrawals[0].withdrawalType", equalTo(REGULAR),
		                                "accountWithdrawals[0].withdrawals[0].amount.amount.value",
		                                equalTo(Float.valueOf(30)),
		                                "accountWithdrawals[0].withdrawals[0].amount.amount.currency",
		                                equalTo(USD), "accountWithdrawals[0].withdrawals[0].amount.frequency",
		                                equalTo("DAILY"));
	}

	/**
	 * Validate the withdrawals.
	 */
	private void getWithdrawalsAfterCreate()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountWithdrawals",
		                not(empty()), "accountWithdrawals[0].withdrawals[0].withdrawalType", equalTo(REGULAR),
		                "accountWithdrawals[0].withdrawals[0].amount.amount.value", equalTo(Float.valueOf(30)),
		                "accountWithdrawals[0].withdrawals[0].amount.amount.currency", equalTo(USD),
		                "accountWithdrawals[0].withdrawals[0].amount.frequency", equalTo("DAILY"));

	}

	/**
	 * Update the withdrawal.
	 */
	private void updateAccountWithdrawals()
	{
		// Generate request body
		context.put("withdrawalType", REGULAR);
		context.put("withdrawalValue", "10000");
		context.put("valueType", "MONEY");
		context.put("frequency", "MONTHLY");

		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_WITHDRAWALS_UPDATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsWithdrawalsPaths.UPDATE_ACCOUNTWITHDRAWALS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountWithdrawals",
		                not(empty()), "accountWithdrawals[0].withdrawals[0].withdrawalType", equalTo(REGULAR),
		                "accountWithdrawals[0].withdrawals[0].amount.amount.value",
		                equalTo(Float.valueOf(10000)),
		                "accountWithdrawals[0].withdrawals[0].amount.amount.currency", equalTo(USD),
		                "accountWithdrawals[0].withdrawals[0].amount.frequency", equalTo("MONTHLY"));
	}

	/**
	 * Validate the withdrawal was updated.
	 */
	private void getWithdrawalsAfterUpdate()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountWithdrawals",
		                not(empty()), "accountWithdrawals[0].withdrawals[0].withdrawalType", equalTo(REGULAR),
		                "accountWithdrawals[0].withdrawals[0].amount.amount.value",
		                equalTo(Float.valueOf(10000)),
		                "accountWithdrawals[0].withdrawals[0].amount.amount.currency", equalTo(USD),
		                "accountWithdrawals[0].withdrawals[0].amount.frequency", equalTo("MONTHLY"));

	}

	/**
	 * Delete the withdrawal
	 */
	private void deleteAccountWithdrawals()
	{
		// Generate request body
		context.put("withdrawalType", REGULAR);
		context.put("withdrawalValue", "10000");
		context.put("valueType", "MONEY");
		context.put("frequency", "MONTHLY");

		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_WITHDRAWALS_DELETE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsWithdrawalsPaths.DELETE_ACCOUNTWITHDRAWALS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountWithdrawals",
		                nullValue());

	}

	/**
	 * Validate the withdrawals were deleted.
	 */
	private void getWithdrawalsAfterDelete()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountWithdrawals",
		                nullValue());
		
		this.deleteRetailAccount();

	}

	/**
	 * Delete the account details for Retail account.
	 * <p>
	 * Version V2
	 * <p>
	 * Add the EEDS header value as TRUE
	 */
	private void deleteRetailAccount()
	{
		context.put("mnemonic", mnemonic);
		context.put("value", value);
		context.put("source", sourceSystem);
		context.put("accountNumber", accountNumber);
		context.put("id", accountId);
		context.put("displayName", displayName);
		context.put("institutionName", institutionName);
		context.put("asOfDate", asOfDate);
		context.put("ppid", ppid);
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));
		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("isEmpty()",
		                Matchers.is(true));

	}

}
