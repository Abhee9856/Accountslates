/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

/**
 * Tests account/CRUD operation for manual account with Rep Info. Tests will run against V2.
 *
 * @author a608077
 * Updated by a608077 on 10/13/2021 to include changes for 'scenario-id' header(PFCP-6168)
 * updated by A631781 on 06/20/2024 to remove validation for the headers "rep-id" and "rep-workstation-id".
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.ACCOUNT,
        Tags.V2,
        Tags.CRUD})
public class Manual_With_RepInfo extends PAPBaseServiceTest {

    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private final float updatedValue = 426.85f;
    private String accId;
    private final String workstationId = "4321";
    private final String repId = "1234";
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Manual_With_RepInfo.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private String mid;// = "ManualAccountV2TestMid";

    protected Manual_With_RepInfo() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        String oAuthToken = AccountUtil.getOauthToken();

        accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_manual", oAuthToken);

        //Set default request headers
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuthToken);

        testDataUtil = new TestDataUtil();

        this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuthToken);

        //Set ppid
        accountsCommonTestData.setPpid(Identity.createPrincipalWithScenario(AccountConstants.MID, mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE, oAuthToken));

        String scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE, oAuthToken);

        Identity.createHouseholdIdentityWithProductCode(mid, oAuthToken, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE);

        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", mid))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("scenario-category-code", "DEF"))
                //optional header scenario-id
                .header(new Header("scenario-id", scenarioId))
                .header(new Header("rep-id", repId))
                .header(new Header("rep-workstation-id", workstationId));

        context = new VelocityContext();
        context.put("source", "MANUAL");


    }

    /**
     * Create a manual account
     */
    @Test
    public void createManualAccount() {
        //Generate request body
        float value = 818.89f;
        context.put("pointOfEntry", "RETAIL");
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "IRA");
        context.put("value", value);
        String asOfDate1 = "2014-10-31";
        context.put("asOfDate", asOfDate1);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        //Run test
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        accId = response.path("accountList[0].accountId.id");

    }

    /**
     * Tests that account data is brought back for manual account.
     * Version V2
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void verifyAfterCreate() {
        //Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Set URL to V2 before running again
        response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo("MANUAL"));
    }


    /**
     * Update the account
     */
    @Test(dependsOnMethods = "verifyAfterCreate")
    public void updateManualAccount() {
        //Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("id", accId);
        context.put("mnemonic", "IRA");
        context.put("value", updatedValue);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

        response = request.post(AccountsPaths.UPDATE_ACCOUNT_V2);

        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));
    }

    /**
     * Tests that updated data is brought back from account/get
     * Version V2
     */
    @Test(dependsOnMethods = "updateManualAccount")
    public void verifyAfterUpdate() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue));

    }

    /**
     * Deletes the manual account
     */
    @Test(dependsOnMethods = "verifyAfterUpdate")
    public void deleteManualAccount() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().
                statusCode(200)
                // No accounts are returned
                .body("isEmpty()", Matchers.is(true));
    }

    /**
     * Tests that updated data is brought back from account/get
     * Version V2
     */
    @Test(dependsOnMethods = "deleteManualAccount")
    public void verifyAfterDelete() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().
                statusCode(200)
                // No accounts are returned
                .body("isEmpty()", Matchers.is(true));

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
