/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.crud.workplace;

import static org.hamcrest.Matchers.equalTo;

import com.fmr.ast.platform.account.model.Account;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.http.Header;

/**
 * Tests CRUD operations of account details V2 for Workplace Accounts. First, retrieves workplace account, then loops
 * through all accounts and creates account details for each account.
 *
 * @author a560878
 */
@Test(groups = {
		Tags.WORKPLACE,
		Tags.DETAILS,
		Tags.V2})

public class Workplace_Details_V2_Crud extends PAPBaseServiceTest
{

    Logger logger = LogManager.getLogger(getClass());

    protected Workplace_Details_V2_Crud()
    {
	super(Services.Account);
    }

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private String ppid;

    private VelocityContext context;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Workplace_Details_V2_Crud.class.getSimpleName();

    private static final String fsreqid = logTrackingId;

    // Test data
    private String mid;

    private String accId;

    private String accountNum;

    private String sourceSystem = AccountConstants.WORKPLACE;

    private String displayName;

    private String mnemonic;

    private String institutionName;

    private String asOfDate;

    private float value = 818.89f;

    private final float updatedValue = 426.85f;

    private final Map<String, String> accIdRegCodeMap = new TreeMap<>();

    private final Map<String, String> accNumberRegCodeMap = new TreeMap<>();

    private final Map<String, String> accNumberAccIdMap = new TreeMap<>();

    private String accountId;

    private String ownerId;

    private String accNum;

    private String assertAccId;

    private String assertAccNum;

	private static final String TRUSTEE_TYPE = "FPTC";
	private static final String TRUSTEE_TYPE_UPDATE = "ABCD";

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	p2TestDataUtil = new TestDataUtil();

	final String oAuth = AccountUtil.getOauthToken();
	accountsCommonTestData =
			TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_WORKPLACE, oAuth);
	accountsCommonTestData =
			TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_WORKPLACE, oAuth);
	mid = Identity.getUserIdentifier("lid", accountsCommonTestData.getSsn(), oAuth).get("mid");
	DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


	ppid = Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth);

	// Data setup
	accountsCommonTestData.setPpid(ppid);

	// Endpoint setup
	setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

	request.given().header(new Header("user-poe", AccountConstants.RETAIL))
			.header(new Header("user-mid", accountsCommonTestData.getMid()))
			.header(new Header("user-sid", accountsCommonTestData.getSid()))
			.header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
			.header(new Header("excludeExternalDataSources", "false"));

	// Populate request variables
	context = new VelocityContext();
	context.put("source", sourceSystem);

    }

    /**
     * Tests that account data is brought back for Workplace account.
     * <p>
     * Version V2
     */
    @Test
    public void getWorkplaceAccountInfo()
    {

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	// Call Account service v2
	response = request.post(AccountsPaths.GET_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200).body("accountList[0].accountId.sourceSystem",
			equalTo(sourceSystem));
	final int size = response.getBody().jsonPath().getList("accountList").size();
	if (size > 0)
	{
	    for (int i = 0; i < size; i++)
	    {
		accountId = response.path("accountList[" + i + "].accountId.id");

		accountNum = response.path("accountList[" + i + "].accountId.accountNumber");

		sourceSystem = response.path("accountList[" + i + "].accountId.sourceSystem");
		displayName = response.path("accountList[" + i + "].displayName");
		mnemonic = response.path("accountList[" + i + "].regCode.mnemonic");

		if (null != response.path("accountList[" + i + "].sourceMarketValue.amount.value"))
		{
		    value = response.path("accountList[" + i + "].sourceMarketValue.amount.value");
		}
		institutionName = response.path("accountList[" + i + "].institutionName");
		asOfDate = response.path("accountList[" + i + "].sourceMarketValue.asOfDate");
		ownerId = response.path("accountList[" + i + "].accountId.owner.id");

		if (null != accountId)
		{
		    accIdRegCodeMap.put(mnemonic, accountId);
		}
		accNumberRegCodeMap.put(accountNum, mnemonic);
		accNumberAccIdMap.put(accountNum, accountId);

	    }
	}

    }

    /**
     * Creates a new Workplace account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount()
    {
		List<Account> accountList = null;
		final int numberOfAccounts = accNumberRegCodeMap.size();
		int index = 0;
	for (final Map.Entry<String, String> entry : accNumberRegCodeMap.entrySet())
	{

	    context.put("accountNumber", entry.getKey());
	    context.put("ppid", accountsCommonTestData.getPpid());
	    context.put("mnemonic", entry.getValue());
	    context.put("value", value);
	    context.put("source", sourceSystem);
	    context.put("displayName", displayName);
	    context.put("institutionName", institutionName);
	    context.put("asOfDate", asOfDate);

	    assertAccNum = entry.getKey();
		final String path = ".find{it.accountId.accountNumber='" + assertAccNum + "'}.";
	    // Generate request body
	    request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

	    // Call Account service
	    response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

	    // Assert on response
	    response.then().log().all().statusCode(AccountConstants.HTTP_200).body(
			    "accountList" + path + "accountId.accountNumber", equalTo(assertAccNum),
			    "accountList" + path + "accountId.sourceSystem", equalTo("WORKPLACE"));

		index++;
	    if (index >= numberOfAccounts)
		{
			accountList = response.getBody().jsonPath().getList("accountList", Account.class);
			for (final Account account : accountList)
			{
				accNumberAccIdMap.put(account.getAccountId().getAccountNumber(), account.getAccountId().getId());
			}
		}
	}
    }

    /**
     * Create Workplace account Details Request.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void createAccountDetails()
    {
	for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet())
	{
	    if (null != entry.getValue())
	    {
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("value", value);
		context.put("source", sourceSystem);
		context.put("accountNumber", entry.getKey());
		context.put("accId", entry.getValue());
		context.put("isInherited", false);
		context.put("isPreviousEmployersAccount", false);
		context.put("state", "NC");
		context.put("type", "workplaceAccountDetail");
		context.put("_type", "workplaceAccountDetail");
		context.put("assetClass", "TOTAL_EQUITY");
		context.put("originalOwnerBirthDate", "1960-11-30");
		context.put("originalOwnerSpouse", true);
		context.put("originalOwnerDeceasedDate", "2022-11-30");
		context.put("federalTaxWithholdingPercent", "0.5");
		context.put("stateTaxWithholdingPercent", "0.3");
			context.put("assetClass", "TOTAL_EQUITY");
			context.put("netPercentage", 1.0f);
			context.put("assetClass1", "BOND");
			context.put("netPercentage1", 0.5f);
			context.put("assetClass2", "CASH");
			context.put("netPercentage2", 0.3f);
			context.put("assetClass3", "OTHER");
			context.put("netPercentage3", 0.4f);
			context.put("assetClass_TOTAL_ALTERNATIVE", "TOTAL_ALTERNATIVE");
			context.put("netPercentage_T_ALTERNATIVE", 0.8f);
			context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", "PRIVATE_EQUITY_ALTERNATIVE");
			context.put("netPercentage_PEA", 0.4f);
			context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", "PRIVATE_CREDIT_ALTERNATIVE");
			context.put("netPercentage_PCA", 0.2f);
			context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", "PRIVATE_REAL_ASSETS_ALTERNATIVE");
			context.put("netPercentage_PRAA", 0.2f);
			context.put("netPercentage", "1.0");
			context.put("trusteeType", TRUSTEE_TYPE);

		// Generate request body
		request.body(
				IOUtil.generateJsonRequest(context,
						AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));

		// Call Account service
		response =
				request.log().ifValidationFails()
						.post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);
		assertAccNum = entry.getKey();
			final String path = ".find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber='" + assertAccNum + "'}.";
		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
				.body("accountDetails" + path + "workplaceAccountDetail.accountDetail.accountId.sourceSystem",
						equalTo("WORKPLACE"),
						"accountDetails" + path + "workplaceAccountDetail.accountDetail.fidelityAccount",
						equalTo(true),
						"accountDetails" + path + "workplaceAccountDetail.accountDetail.trusteeType",
						equalTo(TRUSTEE_TYPE),
						"accountDetails" + path + "workplaceAccountDetail.accountDetail.accountId.id",
						Matchers.notNullValue());
	    }
	}
    }

	/**
	 * Create Workplace account Details Request.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "createAccountDetails")
	public void updateAccountDetails()
	{
		for (final Map.Entry<String, String> entry : accNumberAccIdMap.entrySet())
		{
			if (null != entry.getValue())
			{
				context.put("accId", entry.getValue());
				context.put("accountNumber", entry.getKey());
				context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

				// Generate request body
				request.body(
						IOUtil.generateJsonRequest(context,
								AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));

				// Call Account service
				response =
						request.log().ifValidationFails()
								.post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);
				assertAccNum = entry.getKey();
				final String path = ".find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber='" + assertAccNum + "'}.";
				// Assert on response
				response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
						.body("accountDetails" + path + "workplaceAccountDetail.accountDetail.accountId.sourceSystem",
								equalTo("WORKPLACE"),
								"accountDetails" + path + "workplaceAccountDetail.accountDetail.fidelityAccount",
								equalTo(true),
								"accountDetails" + path + "workplaceAccountDetail.accountDetail.trusteeType",
								equalTo(TRUSTEE_TYPE_UPDATE),
								"accountDetails" + path + "workplaceAccountDetail.accountDetail.accountId.id",
								Matchers.notNullValue());
			}
		}
	}


    /**
     * Validate the Workplace account details after create.
     * <p>
     * Version V2
     */
    //    @Test(dependsOnMethods = "createAccountDetails")
    //    public void getDetailsAfterCreate() {
    //        for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet()) {
    //            this.context.put("ppid", this.accountsCommonTestData.getPpid());
    //            this.context.put("source", this.sourceSystem);
    //            this.context.put("accountNumber", entry.getKey());
    //            this.context.put("accId", entry.getValue());
    //
    //            assertAccId = entry.getValue();
    //            assertAccNum = entry.getKey();
    //
    //            // Generate request body
    //            this.request
    //                    .body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));
    //
    //            // Call Account service
    //            this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
    //            // Assert on response
    //            this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
    //                    .body(
    //                            "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.sourceSystem",
    //                            equalTo("WORKPLACE"),
    //                            "accountDetails[0].workplaceAccountDetail.accountDetail.fidelityAccount",
    //                            equalTo(true), "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.id",
    //                            Matchers.notNullValue());
    //
    //
    //        }
    //    }
    //
    //    /**
    //     * Update the account details for Workplace account.
    //     * <p>
    //     * Version V2
    //     */
    //    @Test(dependsOnMethods = "getDetailsAfterCreate")
    //    public void updateAccountDetails() {
    //
    //        for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet()) {
    //            this.context.put("ppid", this.accountsCommonTestData.getPpid());
    //            this.context.put("value", this.updatedValue);
    //            this.context.put("source", this.sourceSystem);
    //            this.context.put("accountNumber", entry.getKey());
    //            this.context.put("accId", entry.getValue());
    //            this.context.put("isInherited", false);
    //            this.context.put("isPreviousEmployersAccount", false);
    //            this.context.put("state", "NC");
    //            this.context.put("type", "WorkplaceAccountDetails");
    //            this.context.put("_type", "WorkplaceAccountDetails");
    //            // Generate request body
    //            this.request.body(
    //                    IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_UPDATE_V2_TEMPLATE));
    //
    //            // Call Account service
    //            this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);
    //
    //            // Assert on response
    //            this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
    //                    .body(
    //                            "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.sourceSystem",
    //                            equalTo("WORKPLACE"),
    //                            "accountDetails[0].workplaceAccountDetail.accountDetail.fidelityAccount",
    //                            equalTo(true), "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.id",
    //                            Matchers.notNullValue());
    //        }
    //    }
    //
    //    /**
    //     * Validate the updated Workplace account details.
    //     * <p>
    //     * Version V2
    //     */
    //    @Test(dependsOnMethods = "updateAccountDetails")
    //    public void getDetailsAfterUpdate() {
    //
    //        for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet()) {
    //            this.context.put("ppid", this.accountsCommonTestData.getPpid());
    //            this.context.put("source", this.sourceSystem);
    //            this.context.put("accountNumber", entry.getKey());
    //            this.context.put("accId", entry.getValue());
    //
    //            assertAccId = entry.getValue();
    //            assertAccNum = entry.getKey();
    //
    //            // Generate request body
    //            this.request
    //                    .body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));
    //
    //            // Call Account service
    //            this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
    //            // Assert on response
    //            this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
    //                    .body(
    //                            "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.sourceSystem",
    //                            equalTo("WORKPLACE"),
    //                            "accountDetails[0].workplaceAccountDetail.accountDetail.fidelityAccount",
    //                            equalTo(true), "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.id",
    //                            Matchers.notNullValue());
    //        }
    //
    //    }
    //
    //    /**
    //     * Delete the Workplace account details.
    //     * <p>
    //     * Version V2
    //     */
    //    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    //    public void deleteAccountDetails() {
    //        for (final Map.Entry<String, String> entry : this.accNumberAccIdMap.entrySet()) {
    //            this.context.put("ppid", this.accountsCommonTestData.getPpid());
    //            this.context.put("value", this.updatedValue);
    //            this.context.put("source", this.sourceSystem);
    //            this.context.put("accountNumber", entry.getKey());
    //            this.context.put("accId", entry.getValue());
    //            this.context.put("isInherited", false);
    //            this.context.put("isPreviousEmployersAccount", false);
    //            this.context.put("state", "NC");
    //            this.context.put("type", "WorkplaceAccountDetails");
    //            this.context.put("_type", "WorkplaceAccountDetails");
    //            // Generate request body
    //            this.request.body(
    //                    IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_DELETE_V2_TEMPLATE));
    //            // Call Account service
    //            this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V2);
    //            // Assert on response
    //            this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
    //                    "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.sourceSystem",
    //                    equalTo("WORKPLACE"), "accountDetails[0].workplaceAccountDetail.accountDetail.fidelityAccount",
    //                    equalTo(true), "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.id",
    //                    Matchers.notNullValue());
    //
    //        }
    //    }
    //
    //    /**
    //     * Validate the workplace account was deleted.
    //     * <p>
    //     * Version V2
    //     */
    //    @Test(dependsOnMethods = "deleteAccountDetails")
    //    public void getDetailsAfterDelete() {
    //        // context.put("externalDataSources", "true");
    //        // Generate request body
    //        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));
    //
    //        // Call Account service
    //        this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
    //        // Assert on response
    //        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
    //                "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.sourceSystem", equalTo("WORKPLACE"),
    //                "accountDetails[0].workplaceAccountDetail.accountDetail.fidelityAccount", equalTo(true),
    //                "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.id", Matchers.notNullValue());
    //
    //    }
    //
    //    @AfterClass(alwaysRun = true)
    //    public void closeDBConnections() {
    //        this.p2TestDataUtil.closeSQLiteConnection();
    //    }

}