/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.relations.crud.fili;

import com.fmr.ast.platform.account.relation.model.RelatedEntity;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsRelationsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.utilities.RelationsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRelationsTestData;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.not;

/**
 * Tests CRUD operation for retail relations against V2.
 *
 * @author a601767
 *
 */
@Test(groups = {
        Tags.FILI,
        Tags.RELATIONS,
        Tags.V2})
public class FILI_Relations_CRUD_V2 extends PAPBaseServiceTest
{

    private String ppid;

    private String mnemonic;

    private String accountNumber;

    private String accountId;

    private String sourceSystem;

    private String displayName;

    private float value;

    private String institutionName;

    private String asOfDate;

    private final VelocityContext context= new VelocityContext();
    private final TestDataUtil testDataUtil= new TestDataUtil();

    private static final String IGE = "IGE";
    private static final String DEF = "DEF";

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String OWNER = "OWNER";
    private static final String LOG_TRACKING_ID = FILI_Relations_CRUD_V2.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;


    protected FILI_Relations_CRUD_V2()
    {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object based on the SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
        final String oAuth = AccountUtil.getOauthToken();
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_FILI_70", oAuth);

        final String mid = accountsCommonTestData.getMid();

        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");

        ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fili-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", IGE))
                .header(new Header("scenario-category-code", DEF));
        // Populate request variables
        context.put(AccountConstants.MID, mid);
        context.put("filiLid", accountsCommonTestData.getSsn());
        context.put("source", "FILI");
        context.put("ppid", ppid);

    }

    /**
     * Get FILI account info from the backend. Save the account number.
     */
    @Test
    public void getFiliAccountInfo()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Create the FILI account.
     *
     * Version V2
     */
    @Test(dependsOnMethods="getFiliAccountInfo")
    public void createFiliAccount()
    {
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList[0].regCode.mnemonic", equalTo(mnemonic),
                        "accountList[0].accountId.accountNumber", equalTo(accountNumber));

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        context.put("accId", accountId);
        this.request.given().header(new Header("excludeExternalDataSources", "true"));
    }

    /**
     * Create account relations.
     */
    @Test(dependsOnMethods="createFiliAccount", dataProvider = "getFiliRelationsData",
            dataProviderClass = RelationsDataProviderUtil.class)
    public void createAccountRelations(final AccountRelationsTestData data)
    {
        // Generate request body
        context.put("beneficiaryAllocation", data.getBeneficiaryAllocationPct());
        context.put("roleType", data.getRoleType());
        context.put("entityType", data.getEntityType());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_CREATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.CREATE_ACCOUNT_RELATIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountRelations", not(empty()),
                        "accountRelations[0].accountId", equalTo(accountId),
                        "accountRelations[0].relatedEntities[0].planningPartyId", equalTo(ppid));

        //Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
        // so assertions need to be handled differently.
        if (data.getEntityType().equals(OWNER))
        {
            response.then().body(
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
                        equalTo(data.getBeneficiaryAllocationPct()),
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.roleType",
                        equalTo(data.getRoleType()),
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.type",
                        equalTo(data.getEntityType()));
        }
        else
        {
            response.then().body(
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.ownershipPercent",
                        equalTo(Float.valueOf(data.getBeneficiaryAllocationPct())),
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.roleType",
                        equalTo(data.getRoleType()),
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.type",
                        equalTo(data.getEntityType()));
        }

    }

    /**
     * Validate the relations after create.
     *
     * Version V2
     */
    @Test(dependsOnMethods="createAccountRelations", dataProvider = "getFiliRelationsData",
            dataProviderClass = RelationsDataProviderUtil.class)
    public void getRelationsAfterCreate(final AccountRelationsTestData data)
    {
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200).body(
                "accountRelations[0].accountId", equalTo(accountId),
                "accountRelations[0].relatedEntities[0].planningPartyId", equalTo(ppid));

        //Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
        // so assertions need to be handled differently.
        if (data.getEntityType().equals(OWNER))
        {
            response.then().body(
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
                        equalTo(data.getBeneficiaryAllocationPct()),
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.roleType",
                        equalTo(data.getRoleType()),
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.type",
                        equalTo(data.getEntityType()));
        }
        else
        {
            response.then().body(
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.ownershipPercent",
                        equalTo(Float.valueOf(data.getBeneficiaryAllocationPct())),
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.roleType",
                        equalTo(data.getRoleType()),
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.type",
                        equalTo(data.getEntityType()));
        }
    }

    /**
     * Update the account relations.
     *
     * Version V2
     */
    @Test(dependsOnMethods="getRelationsAfterCreate", dataProvider = "getFiliRelationsData",
            dataProviderClass = RelationsDataProviderUtil.class)
    public void updateAccountRelations(final AccountRelationsTestData data)
    {
        // Generate request body
        context.put("beneficiaryAllocation", data.getUpdatedBeneficiaryAllocationPct());
        context.put("roleType", data.getRoleType());
        context.put("entityType", data.getEntityType());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_UPDATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.UPDATE_ACCOUNT_RELATIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountRelations[0].accountId", equalTo(accountId),
                        "accountRelations[0].relatedEntities[0].planningPartyId", equalTo(ppid));

        //Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
        // so assertions need to be handled differently.
        if (data.getEntityType().equals(OWNER))
        {
            response.then().body(
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
                        equalTo(data.getUpdatedBeneficiaryAllocationPct()),
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.roleType",
                        equalTo(data.getRoleType()),
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.type",
                        equalTo(data.getEntityType()));
        }
        else
        {
            response.then().body(
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.ownershipPercent",
                        equalTo(Float.valueOf(data.getUpdatedBeneficiaryAllocationPct())),
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.roleType",
                        equalTo(data.getRoleType()),
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.type",
                        equalTo(data.getEntityType()));
        }

    }

    /**
     * Validate the updated relations.
     *
     * Version V2
     */
    @Test(dependsOnMethods="updateAccountRelations", dataProvider = "getFiliRelationsData",
            dataProviderClass = RelationsDataProviderUtil.class)
    public void getRelationsAfterUpdate(final AccountRelationsTestData data)
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountRelations[0].accountId", equalTo(accountId),
                        "accountRelations[0].relatedEntities[0].planningPartyId", equalTo(ppid));

        //Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
        // so assertions need to be handled differently.
        if (data.getEntityType().equals(OWNER))
        {
            response.then().body(
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
                        equalTo(data.getUpdatedBeneficiaryAllocationPct()),
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.roleType",
                        equalTo(data.getRoleType()),
                    "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.type",
                        equalTo(data.getEntityType()));
        }
        else
        {
            response.then().body(
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.ownershipPercent",
                        equalTo(Float.valueOf(data.getUpdatedBeneficiaryAllocationPct())),
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.roleType",
                        equalTo(data.getRoleType()),
                    "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.type",
                        equalTo(data.getEntityType()));
        }

    }

    /**
     * Delete the account relations.
     *
     * Version V2
     */
    @Test(dependsOnMethods="getRelationsAfterUpdate", dataProvider = "getFiliRelationsData",
            dataProviderClass = RelationsDataProviderUtil.class)
    public void deleteAccountRelations(final AccountRelationsTestData data)
    {
        // Generate request body
        context.put("beneficiaryAllocation", data.getUpdatedBeneficiaryAllocationPct());
        context.put("roleType", data.getRoleType());
        context.put("entityType", data.getEntityType());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_DELETE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.DELETE_ACCOUNT_RELATIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

        //Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
        // so assertions need to be handled differently.
        try
        {
            final List<RelatedEntity> relatedEntities =
                    response.jsonPath().getList("accountRelations[0].relatedEntities", RelatedEntity.class);
            relatedEntities.forEach(relatedEntity -> {
                if (data.getEntityType().equals(OWNER) && relatedEntity.getType().name().equals(OWNER))
                {
                    Assert.fail();
                }
                else if (!relatedEntity.getType().name().equals(OWNER) &&
                        relatedEntity.getRoleType().name().equals(data.getRoleType()))
                {
                    Assert.fail();
                }
            });
        }
        catch (IllegalArgumentException e)
        {
            response.then().body("isEmpty()", Matchers.is(true));
        }
    }

    /**
     * Validate the relations were deleted.
     *
     * Version V2
     */
    @Test(dependsOnMethods="deleteAccountRelations")
    public void getRelationsAfterDelete()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("isEmpty()", Matchers.is(true));

    }
    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
        this.testDataUtil.closeSQLiteConnection();
    }
}
