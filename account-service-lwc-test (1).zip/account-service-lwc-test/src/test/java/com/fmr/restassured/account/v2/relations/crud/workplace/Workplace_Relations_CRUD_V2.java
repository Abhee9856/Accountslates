/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.relations.crud.workplace;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.not;

import com.fmr.ast.platform.account.relation.model.RelatedEntity;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsRelationsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.utilities.RelationsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRelationsTestData;

import java.util.List;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.http.Header;

/**
 * Tests CRUD operation for workplace relations against V2.
 *
 * @author a653510
 *
 */
@Test(groups = {Tags.WORKPLACE, Tags.RELATIONS, Tags.V2})
public class Workplace_Relations_CRUD_V2 extends PAPBaseServiceTest
{

	// Data setup
	private AccountsCommonTestData accountsCommonTestData ;

	private String ppid;

	private String accountId;

	private final VelocityContext context = new VelocityContext();
	private final TestDataUtil testDataUtil = new TestDataUtil();

	private static final String IGE = "IGE";
	private static final String DEF = "DEF";

	private static final String CALLING_APP_ID = "AP136091";
	private static final String APP_ID = "AP136091";
	private static final String OWNER = "OWNER";
	private static final String LOG_TRACKING_ID = Workplace_Relations_CRUD_V2.class.getSimpleName();
	private static final String FSREQID = LOG_TRACKING_ID;

	protected Workplace_Relations_CRUD_V2()
	{
		super(Services.Account);
	}

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the SSN, set up the endpoint for the
	 * test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
		accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Workplace_69",oAuth);
		String mid = this.accountsCommonTestData.getMid();
		DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");

		this.ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);

		this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

		this.request.given().header(new Header("user-poe", "NETBENEFITS"))
		        .header(new Header("user-mid", this.accountsCommonTestData.getMid()))
		        .header(new Header("user-fesco-lid", this.accountsCommonTestData.getSsn()))
		        .header(new Header("scenario-product-code", IGE))
				.header(new Header("scenario-category-code", DEF));


		// Populate request variables
		this.context.put(AccountConstants.MID, mid);
		this.context.put("source", AccountConstants.WORKPLACE);
		this.context.put("ppid", this.ppid);

	}

	/**
	 * Get account info from the backend. Save the account number.
	 */
	@Test
	public void getWorkplaceAccountInfo()
	{
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

		this.accountsCommonTestData.setMnemonic1(this.response.path("accountList[0].regCode.mnemonic"));
		this.accountsCommonTestData.setAccountNumber1(this.response.path("accountList[0].accountId.accountNumber"));
		this.accountsCommonTestData.setSourceSystem1(this.response.path("accountList[0].accountId.sourceSystem"));
		this.accountsCommonTestData.setDisplayName1(this.response.path("accountList[0].displayName"));
		this.accountsCommonTestData.setValue1(this.response.path("accountList[0].sourceMarketValue.amount.value"));
		this.accountsCommonTestData.setInstitutionName1(this.response.path("accountList[0].institutionName"));
		this.accountsCommonTestData.setAsOfDate1(this.response.path("accountList[0].sourceMarketValue.asOfDate"));
	}

	/**
	 * Create the account.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "getWorkplaceAccountInfo")
	public void createWorkplaceAccount()
	{
		this.context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
		this.context.put("value", this.accountsCommonTestData.getValue1());
		this.context.put("source", this.accountsCommonTestData.getSourceSystem1());
		this.context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
		this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
		this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
		this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		        "accountList[0].regCode.mnemonic", equalTo(this.accountsCommonTestData.getMnemonic1()),
		        "accountList[0].accountId.accountNumber", equalTo(this.accountsCommonTestData.getAccountNumber1()));

		// Gets and saves the CFP account ID
		this.accountId = this.response.path("accountList[0].accountId.id");
		this.context.put("accId", this.accountId);
		this.request.given().header(new Header("excludeExternalDataSources", "true"));
	}

	/**
	 * Create account relations.
	 */
	@Test(dependsOnMethods = "createWorkplaceAccount", dataProvider = "getWorkplaceRelationsData", dataProviderClass = RelationsDataProviderUtil.class)
	public void createAccountRelations(final AccountRelationsTestData data)
	{
		// Generate request body
		this.context.put("beneficiaryAllocation", data.getBeneficiaryAllocationPct());
		this.context.put("roleType", data.getRoleType());
		this.context.put("entityType", data.getEntityType());

		this.request
		        .body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_RELATIONS_CREATE_V2_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsRelationsPaths.CREATE_ACCOUNT_RELATIONS_V2);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("accountRelations",
		        not(empty()), "accountRelations[0].accountId", equalTo(this.accountId),
		        "accountRelations[0].relatedEntities[0].planningPartyId", equalTo(this.ppid));

		// Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
		// so assertions need to be handled differently.
		if (data.getEntityType().equals(OWNER))
		{
			this.response.then().body("accountRelations[0].relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
			        equalTo(data.getBeneficiaryAllocationPct()),
			        "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.roleType", equalTo(data.getRoleType()),
			        "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.type", equalTo(data.getEntityType()));
		}
		else
		{
			this.response.then().body(
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType()
			                + "'}.ownershipPercent",
			        equalTo(Float.valueOf(data.getBeneficiaryAllocationPct())),
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.roleType",
			        equalTo(data.getRoleType()),
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.type",
			        equalTo(data.getEntityType()));
		}

	}

	/**
	 * Validate the relations after create.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "createAccountRelations", dataProvider = "getWorkplaceRelationsData", dataProviderClass = RelationsDataProviderUtil.class)
	public void getRelationsAfterCreate(final AccountRelationsTestData data)
	{
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		        "accountRelations[0].accountId", equalTo(this.accountId),
		        "accountRelations[0].relatedEntities[0].planningPartyId", equalTo(this.ppid));

		// Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
		// so assertions need to be handled differently.
		if (data.getEntityType().equals(OWNER))
		{
			this.response.then().body("accountRelations[0].relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
			        equalTo(data.getBeneficiaryAllocationPct()),
			        "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.roleType", equalTo(data.getRoleType()),
			        "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.type", equalTo(data.getEntityType()));
		}
		else
		{
			this.response.then().body(
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType()
			                + "'}.ownershipPercent",
			        equalTo(Float.valueOf(data.getBeneficiaryAllocationPct())),
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.roleType",
			        equalTo(data.getRoleType()),
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.type",
			        equalTo(data.getEntityType()));
		}
	}

	/**
	 * Update the account relations.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "getRelationsAfterCreate", dataProvider = "getWorkplaceRelationsData", dataProviderClass = RelationsDataProviderUtil.class)
	public void updateAccountRelations(final AccountRelationsTestData data)
	{
		// Generate request body
		this.context.put("beneficiaryAllocation", data.getUpdatedBeneficiaryAllocationPct());
		this.context.put("roleType", data.getRoleType());
		this.context.put("entityType", data.getEntityType());
		this.request
		        .body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_RELATIONS_UPDATE_V2_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsRelationsPaths.UPDATE_ACCOUNT_RELATIONS_V2);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		        "accountRelations[0].accountId", equalTo(this.accountId),
		        "accountRelations[0].relatedEntities[0].planningPartyId", equalTo(this.ppid));

		// Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
		// so assertions need to be handled differently.
		if (data.getEntityType().equals(OWNER))
		{
			this.response.then().body("accountRelations[0].relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
			        equalTo(data.getUpdatedBeneficiaryAllocationPct()),
			        "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.roleType", equalTo(data.getRoleType()),
			        "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.type", equalTo(data.getEntityType()));
		}
		else
		{
			this.response.then().body(
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType()
			                + "'}.ownershipPercent",
			        equalTo(Float.valueOf(data.getUpdatedBeneficiaryAllocationPct())),
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.roleType",
			        equalTo(data.getRoleType()),
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.type",
			        equalTo(data.getEntityType()));
		}

	}

	/**
	 * Validate the updated relations.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "updateAccountRelations", dataProvider = "getWorkplaceRelationsData", dataProviderClass = RelationsDataProviderUtil.class)
	public void getRelationsAfterUpdate(final AccountRelationsTestData data)
	{
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		        "accountRelations[0].accountId", equalTo(this.accountId),
		        "accountRelations[0].relatedEntities[0].planningPartyId", equalTo(this.ppid));

		// Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
		// so assertions need to be handled differently.
		if (data.getEntityType().equals(OWNER))
		{
			this.response.then().body("accountRelations[0].relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
			        equalTo(data.getUpdatedBeneficiaryAllocationPct()),
			        "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.roleType", equalTo(data.getRoleType()),
			        "accountRelations[0].relatedEntities.find{it.type=='OWNER'}.type", equalTo(data.getEntityType()));
		}
		else
		{
			this.response.then().body(
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType()
			                + "'}.ownershipPercent",
			        equalTo(Float.valueOf(data.getUpdatedBeneficiaryAllocationPct())),
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.roleType",
			        equalTo(data.getRoleType()),
			        "accountRelations[0].relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}.type",
			        equalTo(data.getEntityType()));
		}

	}

	/**
	 * Delete the account relations.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "getRelationsAfterUpdate", dataProvider = "getWorkplaceRelationsData", dataProviderClass = RelationsDataProviderUtil.class)
	public void deleteAccountRelations(final AccountRelationsTestData data)
	{
		// Generate request body
		this.context.put("beneficiaryAllocation", data.getUpdatedBeneficiaryAllocationPct());
		this.context.put("roleType", data.getRoleType());
		this.context.put("entityType", data.getEntityType());
		this.request
		        .body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_RELATIONS_DELETE_V2_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsRelationsPaths.DELETE_ACCOUNT_RELATIONS_V2);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

		// Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
		// so assertions need to be handled differently.
		try
		{
			final List<RelatedEntity> relatedEntities =
			        this.response.jsonPath().getList("accountRelations[0].relatedEntities", RelatedEntity.class);
			relatedEntities.forEach(relatedEntity -> {
				if (data.getEntityType().equals(OWNER) && relatedEntity.getType().name().equals(OWNER))
				{
					Assert.fail();
				}
				else if (!relatedEntity.getType().name().equals(OWNER)
				        && relatedEntity.getRoleType().name().equals(data.getRoleType()))
				{
					Assert.fail();
				}
			});
		}
		catch (final IllegalArgumentException e)
		{
			this.response.then().body("isEmpty()", Matchers.is(true));
		}
	}

	/**
	 * Validate the relations were deleted.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "deleteAccountRelations")
	public void getRelationsAfterDelete()
	{
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("isEmpty()",
		        Matchers.is(true));

	}
	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}
}