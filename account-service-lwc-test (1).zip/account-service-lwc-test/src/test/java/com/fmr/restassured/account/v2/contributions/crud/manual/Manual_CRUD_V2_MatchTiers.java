/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.contributions.crud.manual;

import com.fmr.ast.platform.account.model.MatchTier;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsContributionsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.utilities.ContributionsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountContributionsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.ContributionsMatchTiersTestData;

import io.restassured.http.Header;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operation for Manual contributions against V2.
 *
 * @author a514676
 */
@Test(groups = {
        Tags.CRITICAL,
        Tags.ASYNCHRONOUS,
        Tags.MANUAL,
        Tags.CONTRIBUTIONS,
        Tags.V2,
        Tags.MATCH_TIERS,
        "PFCP-3064"})
public class Manual_CRUD_V2_MatchTiers extends PAPBaseServiceTest {
    protected Manual_CRUD_V2_MatchTiers() {
        super(Services.Account);
    }

    private String mid;// = "ManualContributionV2TestMid";

    private String ppid;

    private String mnemonic = "401K";

    private String accountNumber;

    private String accountId;

    private String sourceSystem = "MANUAL";

    private String displayName = "Display_Name";

    private float value = 100.0f;

    private String institutionName = "InstitutionalName";

    private String asOfDate = "2014-10-31";

    private VelocityContext context;

    private static final String MONEY = "MONEY";

    private static final String PERCENT = "PERCENT";

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final Header EEDS = new Header("excludeExternalDataSources", "false");

    private static final String LOG_TRACKING_ID = Manual_CRUD_V2_MatchTiers.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Map Integer tier -> String ID
     */
    private Map<Integer, String> tierIdMap = new HashMap<>();


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("accountCRUD_Manual", oAuth);

       this.mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("log-tracking-id", "PAP_Smoke_RestAssured"))
                .header(EEDS);

        context = new VelocityContext();
        context.put("ppid", ppid);
        context.put("source", "MANUAL");
    }


    /**
     * Create the Manual account. Save the account id.
     * <p>
     * Version V2
     */
    @Test
    public void createManualAccount() {

        context.put("value", value);
        context.put("source", sourceSystem);

        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        context.put("mnemonic", mnemonic);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList", Matchers.not(empty()),
                        "accountList[0].regCode.mnemonic", Matchers.notNullValue(),
                        "accountList[0].accountId.accountNumber", Matchers.notNullValue());

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        context.put("accId", accountId);
        context.put("accountNumber", accountNumber);
    }

    /**
     * Validate the account was created correctly.
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void getManualAccountAfterCreate() {
        // Generate request body

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("accountList", not(empty()));


    }

    /**
     * Create the account contributions.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getManualAccountAfterCreate")
    public void createAccountContributions() {
        final AccountContributionsTestData data = new AccountContributionsTestData();

        // Generate request body
        context.put("contribValue", data.getContributionValue());
        context.put("valueType", data.getValueType());
        context.put("contribType", data.getContributionType());
        context.put("contribTaxType", data.getContributionTaxType());
        context.put("contribLevelType", data.getContributionLevelType());
        context.put("frequency", data.getFrequency());
        context.put("contributor", data.getContributor());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountContributions", not(empty()));

    }

    /**
     * Create the account contributions.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createAccountContributions", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void createAccountMatchTiers(final ContributionsMatchTiersTestData data) {
        // Generate request body
        context.put("matchTierTier", data.getTier());
        context.put("matchTierType", data.getType());
        context.put("matchTierRate", data.getRate());
        context.put("matchTierRateAmountLimit", data.getRateAmountLimit());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_CREATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountContributions", not(empty()),
                        "accountContributions[0].matchTiers.find{it.tier==" +
                                data.getTier() + "}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.tier==" +
                                data.getTier() + "}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.tier==" +
                                data.getTier() + "}.rateAmountLimit.value", equalTo(Float.valueOf(data.getRateAmountLimit())),
                        "accountContributions[0].matchTiers.find{it.tier==" +
                                data.getTier() + "}.ratePercentLimit", nullValue());

        tierIdMap.put(data.getTier(),
                response.path("accountContributions[0].matchTiers.find{it.tier==" + data.getTier() + "}.id"));

    }

    /**
     * Validate the contributions.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createAccountMatchTiers", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void getContributionsAfterCreate(final ContributionsMatchTiersTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
                        "accountContributions[0].accountId.id", equalTo(accountId),
                        "accountContributions[0].accountId.owner.id", equalTo(ppid),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit.value", equalTo(Float.valueOf(data.getRateAmountLimit())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit", nullValue());


    }

    /**
     * Update the contribution.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getContributionsAfterCreate", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void updateAccountContributions(final ContributionsMatchTiersTestData data) {
        // Generate request body
        context.put("matchTierTier", data.getTier());
        context.put("matchTierType", data.getType());
        context.put("matchTierRate", data.getRate());
        context.put("matchTierRateAmountLimit", null);
        context.put("matchTierRatePercentLimit", data.getRatePercentLimit());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_UPDATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.UPDATE_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountContributions", not(empty()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit", nullValue(),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit", equalTo(Float.valueOf(data.getRatePercentLimit())));
    }

    /**
     * Validate the contribution was updated.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateAccountContributions", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void getContributionsAfterUpdate(final ContributionsMatchTiersTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
                        "accountContributions[0].accountId.id", equalTo(accountId),
                        "accountContributions[0].accountId.owner.id", equalTo(ppid),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit", nullValue(),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit", equalTo(Float.valueOf(data.getRatePercentLimit())));
    }

    /**
     * Delete the contribution
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getContributionsAfterUpdate", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void deleteAccountContributions(final ContributionsMatchTiersTestData data) {
        //Generate request body
        context.put("matchTierId", tierIdMap.get(data.getTier()));
        context.put("matchTierTier", data.getTier());
        context.put("matchTierType", data.getType());
        context.put("matchTierRate", data.getRate());
        context.put("matchTierRatePercentLimit", data.getRatePercentLimit());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_DELETE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.DELETE_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK);

        final List<MatchTier> matchTiers =
                response.jsonPath().getList("accountContributions[0].matchTiers", MatchTier.class);
        matchTiers.forEach(tier -> {
            if (tier.getTier().equals(data.getTier())) {
                Assert.fail();
            }
        });

    }

    /**
     * Validate the contributions were deleted.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteAccountContributions")
    public void getContributionsAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountContributions[0].contributions", not(empty()),
                        "accountContributions[0].matchTiers", nullValue());

    }
}
