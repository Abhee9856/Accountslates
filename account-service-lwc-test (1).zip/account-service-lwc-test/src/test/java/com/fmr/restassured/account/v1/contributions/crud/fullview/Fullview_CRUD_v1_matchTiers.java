/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.contributions.crud.fullview;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

import com.fmr.ast.platform.workplaceplan.domain.MatchTier;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsContributionsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.utilities.ContributionsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountContributionsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.ContributionsMatchTiersTestData;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operation for Fullview contributions against V1.
 *
 * @author a601767
 */
@Test(groups = {
        Tags.CRITICAL,
        Tags.FULLVIEW,
        Tags.CONTRIBUTIONS,
        Tags.V1,
        Tags.MATCH_TIERS,
        "PFCP-3063"})
public class Fullview_CRUD_v1_matchTiers extends PAPBaseServiceTest {
    protected Fullview_CRUD_v1_matchTiers() {
        super(Services.Account);
    }

    private String mid;

    private String ppid;

    private String mnemonic;

    private String accountNumber;

    private String accountId;

    private String sourceSystem;

    private String displayName;

    private float value;

    private String institutionName;

    private String asOfDate;

    private VelocityContext context;

    /**
     * Map Integer tier -> String ID
     */
    private Map<Integer, String> tierIdMap = new HashMap<>();


    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_composite_CRUD_allDetails_Fullview", oAuth);
        mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(oAuth);

        // Populate request context with user IDs
        context = new VelocityContext();

        context.put("mid", mid);
        context.put("ppid", ppid);
        context.put("source", "FULLVIEW");
    }

    /**
     * Get Fullview account info from the backend. Save the account number.
     */
    @Test
    public void getFullviewAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("accountList",not(anyOf(nullValue(),empty())));

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Create the Fullview account. Save the account id.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void createFullviewAccount() {
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountList[0].regCode.mnemonic", equalTo(mnemonic),
                        "accountList[0].accountId.accountNumber", equalTo(accountNumber));

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        context.put("accId", accountId);
    }

    /**
     * Validate the account was created correctly.
     */
    @Test(dependsOnMethods = "createFullviewAccount")
    public void getFullviewAccountAfterCreate() {
        // Generate request body
        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "accountList", not(empty()));


    }

    /**
     * Create the account contributions.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountAfterCreate")
    public void createAccountContributions() {
        final AccountContributionsTestData data = new AccountContributionsTestData();

        // Generate request body
        context.put("contribValue", data.getContributionValue());
        context.put("valueType", data.getValueType());
        context.put("contribType", data.getContributionType());
        context.put("contribTaxType", data.getContributionTaxType());
        context.put("contribLevelType", data.getContributionLevelType());
        context.put("frequency", data.getFrequency());
        context.put("contributor", data.getContributor());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_TEMPLATE))
                .log().ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(mid))
                .body("accountContributions", not(empty()))
                .body("accountContributions[0].contributions.find{it.contribution.value='" +
                        data.getContributionValue() + "'}.contributionType", notNullValue());

    }

    /**
     * Validate the contributions.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountContributions", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void createAccountMatchTiers(final ContributionsMatchTiersTestData data) {
        // Generate request body
        context.put("matchTierTier", data.getTier());
        context.put("matchTierType", data.getType());
        context.put("matchTierRate", data.getRate());
        context.put("matchTierRateAmountLimit", data.getRateAmountLimit());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
                        "accountContributions[0].accountId.id", equalTo(accountId),
                        "accountContributions[0].accountId.owner.id", equalTo(ppid),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit.value", equalTo(Float.valueOf(data.getRateAmountLimit())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit", nullValue());

        tierIdMap.put(data.getTier(),
                response.path("accountContributions[0].matchTiers.find{it.tier==" + data.getTier() + "}.id"));

    }

    /**
     * Validate the contributions.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountContributions", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void getContributionsAfterCreate(final ContributionsMatchTiersTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
                        "accountContributions[0].accountId.id", equalTo(accountId),
                        "accountContributions[0].accountId.owner.id", equalTo(ppid),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit.value", equalTo(Float.valueOf(data.getRateAmountLimit())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit", nullValue());

    }

    /**
     * Update the contribution.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getContributionsAfterCreate", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void updateAccountContributions(final ContributionsMatchTiersTestData data) {
        // Generate request body
        context.put("matchTierTier", data.getTier());
        context.put("matchTierType", data.getType());
        context.put("matchTierRate", data.getRate());
        context.put("matchTierRateAmountLimit", null);
        context.put("matchTierRatePercentLimit", data.getRatePercentLimit());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_UPDATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.UPDATE_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "accountContributions", not(empty()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit", nullValue(),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit.value", equalTo(Float.valueOf(data.getRatePercentLimit())));
    }

    /**
     * Validate the contribution was updated.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountContributions", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void getContributionsAfterUpdate(final ContributionsMatchTiersTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(mid),
                        "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
                        "accountContributions[0].accountId.id", equalTo(accountId),
                        "accountContributions[0].accountId.owner.id", equalTo(ppid),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.type", equalTo(data.getType()),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rate.value", equalTo(Float.valueOf(data.getRate())),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.rateAmountLimit", nullValue(),
                        "accountContributions[0].matchTiers.find{it.id=='" +
                                data.getTier() + "'}.ratePercentLimit.value", equalTo(Float.valueOf(data.getRatePercentLimit())));

    }

    /**
     * Delete the contribution
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getContributionsAfterUpdate", dataProvider = "getMatchTiers",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void deleteAccountContributions(final ContributionsMatchTiersTestData data) {
        // Generate request body
        context.put("matchTierId", tierIdMap.get(data.getTier()));
        context.put("matchTierTier", data.getTier());
        context.put("matchTierType", data.getType());
        context.put("matchTierRate", data.getRate());
        context.put("matchTierRatePercentLimit", data.getRatePercentLimit());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_MATCH_TIERS_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.DELETE_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true));

        final List<MatchTier> matchTiers =
                response.jsonPath().getList("accountContributions[0].matchTiers", MatchTier.class);
        matchTiers.forEach(tier -> {
            if (tier.getTier() == data.getTier()) {
                Assert.fail();
            }
        });

    }

    /**
     * Validate the contributions were deleted.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccountContributions")
    public void getContributionsAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "accountContributions[0].contributions", not(empty()),
                        "accountContributions[0].matchTiers", empty());

    }
}
