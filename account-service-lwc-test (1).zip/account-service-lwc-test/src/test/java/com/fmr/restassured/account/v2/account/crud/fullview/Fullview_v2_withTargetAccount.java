package com.fmr.restassured.account.v2.account.crud.fullview;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;

import com.fmr.pap.restassured.common.module.Scenario;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;

/**
 * Tests account CRUD operation for Fullview account V2.
 *
 * @author a601767
 * Updated by a608077 on 10/13/2021 to include changes for 'scenario-id' header(PFCP-6168)
 * Updated by a608077 on 08/26/2022 to include unknown funding amount changes(PFCP-9908)
 */
@Test(groups = {
        Tags.FULLVIEW,
        Tags.ACCOUNT,
        Tags.V2,
        Tags.TARGET_ACCOUNT})
public class Fullview_v2_withTargetAccount extends PAPBaseServiceTest {
    private AccountsCommonTestData accountsCommonTestData;

    private String accId;

    private String accountNum;

    private String sourceSystem;

    private String displayName;

    private String mnemonic;

    private float value;

    private String institutionName;

    private String asOfDate;

    private final float fundingAccountAmount = 5.55f;
    private final float newFundingAmount = 6.66f;

    private final float unknownAmount = 20.0f;

    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";
    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";
    
    private static final String TARGET_ACCOUNT_NAME = "NewTargetAccount";

    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Fullview_v2_withTargetAccount.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    //Velocity Context
    private VelocityContext context;

    protected Fullview_v2_withTargetAccount() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the UserIdentifiers object
     * based on the default SSN, set up the endpoint for the test, and
     * build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {

        final String oAuth = AccountUtil.getOauthToken();

        //Data Setup
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_Fullview_131", oAuth);

        String mid = accountsCommonTestData.getMid();

        //Set default REST header with authorization token
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


        //Set ppid
        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth));

        // Get/Create ScenarioId
         Response allScenarioIDs = Scenario.getAllScenarios(mid, oAuth);
        String scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null)
        {
            scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE,
                    oAuth);
        }

        this.request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", mid))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                //optional header scenario-id
                .header(new Header("scenario-id", scenarioId));

        //Populate request variables
        context = new VelocityContext();
        context.put("source", AccountConstants.FULLVIEW);

        //Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

    }

    /**
     * Tests that account data is brought back for Fullview account.
     * <p>
     * Version V2
     */
    @Test
    public void getFullviewAccountInfo() {

        //Call Account service v2
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId", notNullValue());

        accountNum = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        mnemonic = response.path("accountList[0].regCode.mnemonic");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Creates a new Fullview account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void createFullviewAccount() {

        context.put("accountNumber", accountNum);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        //Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        //Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", notNullValue())
                .body("accountList[0].accountId.sourceSystem", equalTo(AccountConstants.FULLVIEW))
                .body("accountList[0].accountId", notNullValue());

        accId = response.path("accountList[0].accountId.id");
    }

    /**
     * Create target account
     */
    @Test(dependsOnMethods = "createFullviewAccount")
    public void createTargetAccount() {

	context.remove("displayName");
        context.put("fundingAccountNumber", accountNum);
        context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
        context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("category", "INVESTOR_SELECTED_STRATEGY");
        this.context.put("unknownAmount", String.valueOf(unknownAmount));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount),
                        "targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME),
                        "targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountNum),
                        "targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount),
                        "targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"));

        accountsCommonTestData.set(TARGET_ACCOUNT_NUMBER_KEY, response.path("targetAccounts[0].accountId.accountNumber"));
        accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
    }

    /**
     * Validates that the account was created
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void verifyFullviewAccountAfterCreate() {

        //Call Account service v2
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()),
                        "accountList[0].accountId.accountNumber", equalTo(accountNum),
                        "accountList[0].accountId.id", equalTo(accId),
                        "targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount),
                        "targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME),
                        "targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountNum),
                        "targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"));
    }

    /**
     * Updates the account with new mnemonic
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "verifyFullviewAccountAfterCreate")
    public void updateFullviewAccount() {

        context.put("id", accId);
        context.put("accountNumber", accountNum);
        context.put("value", "10000.0");
        context.put("source", sourceSystem);
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", "IRA");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

        //Set resource path
        response = request.post(AccountsPaths.UPDATE_ACCOUNT_V2);

        //Call service
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].regCode.mnemonic", equalTo("IRA"))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(10000f))
                .body("accountList[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()));
    }

    /**
     * Update target account
     */
    @Test(enabled = false, dependsOnMethods = "updateFullviewAccount")
    // THIS IS DISABLED BECAUSE UPDATE IS NOT IMPLEMENTED FOR V2 AT THIS TIME.
    // Simply remove 'enabled=false' and this will run.
    public void updateTargetAccount() {

        context.put(TARGET_ACCOUNT_NUMBER_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
        context.put(TARGET_ACCOUNT_ID_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
        context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
        context.put("fundingAccountAmount", String.valueOf(newFundingAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(newFundingAmount));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_UPDATE_V2_TEMPLATE));

        // Call Account service
        response = request.post(AccountsPaths.UPDATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value", equalTo(newFundingAmount),
                        "targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountNum),
                        "targetAccounts[0].fundingAccounts[0].amount.value", equalTo(newFundingAmount),
                        "targetAccounts[0].complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"));


    }

    /**
     * Validates that the account was updated correctly
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateFullviewAccount")
    public void verifyFullviewAccountAfterUpdate() {

        //Call Account service v2
        response = request.post(AccountsPaths.GET_ACCOUNT_V2);

        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList[0].accountId.accountNumber", equalTo(accountNum))
                .body("accountList[0].accountId.id", equalTo(accId))
                .body("accountList[0].sourceMarketValue.amount.value", equalTo(value))
                .body("targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount),
                        "targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountNum),
                        "targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME),
                        "targetAccounts[0].fundingAccounts[0].amount.value", equalTo(fundingAccountAmount),
                        "targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"));
    }

    /**
     * Deletes the account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "verifyFullviewAccountAfterUpdate")
    public void deleteFullviewAccount() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        //Set resource path
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("isEmpty()", Matchers.is(true));
    }

}

