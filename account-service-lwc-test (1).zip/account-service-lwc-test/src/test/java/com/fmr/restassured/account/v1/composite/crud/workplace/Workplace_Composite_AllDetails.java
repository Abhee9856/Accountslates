/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.workplace;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.HashMap;

import io.restassured.http.Header;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * Contains tests that validate the Account Composite operation for Workplace Accounts - includes CRUD validations
 *
 * @author a623549
 * Updated by a608077 on 08/18/2022 to include asset allocation changes(PFCP-9501)
 * Updated by a608077 on 08/30/2023 to include include-suitability-details header(PFCP-12115)
 */
@Test(groups = {Tags.WORKPLACE, Tags.COMPOSITE, Tags.V1, Tags.CRITICAL})
public class Workplace_Composite_AllDetails extends PAPBaseServiceTest
{
    
    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Workplace_Composite_AllDetails.class);
    
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;
    
    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;
    
    /**
     * Global variable holding workplaceAccount information
     */
    private HashMap<String, String> workplaceAccountMap;
    
    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountTestData;

    private String accNum;

    private String acctRoot;
    
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Workplace_Composite_AllDetails.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    
    /**
     * Constructor
     */
    protected Workplace_Composite_AllDetails()
    {
        super(Services.Account);
    }
    
    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass()
    {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        workplaceAccountMap = new HashMap<>();
        
        accountTestData = TestDataUtil.populateRegressionTestData("default_ssn_workplace", oAuth);
        workplaceAccountMap = getWorkplaceAccountInformation(accountTestData, oAuth);
        
        DataCleanup.deleteCustomerDataFromCP("mid", accountTestData.getMid(), oAuth, "true");

        final String ppid = Identity.createHouseholdIdentity(accountTestData.getMid(), oAuth);
        accountTestData.setPpid(ppid);
    }
    
    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init()
    {
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
    }
    
    /**
     * Description: Validates an empty account list when calling get account composite workplace before creation of
     * an account
     */
    @Test
    public void getCompositeAccountWorkplaceBeforeCreate()
    {
        if (workplaceAccountMap.isEmpty())
        {
            throw new SkipException(
                    "'getCompositeAccountWorkplaceBeforeCreate' test scenario cannot run due to failure to retrieve "
                            + "retail account information!");
        }
        
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("externalDataSources", true);
        context.put("source", workplaceAccountMap.get("sourceSystem"));
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }
    
    /**
     * Description: Validates the account composite response after create
     */
    @Test(dependsOnMethods = "getCompositeAccountWorkplaceBeforeCreate")
    public void createCompositeAccountWorkplace()
    {
        final VelocityContext context = new VelocityContext();
        accNum = workplaceAccountMap.get("accountNumber");
        context.put("mid", accountTestData.getMid());
        context.put("fescoLid", accountTestData.getSsn());
        context.put("accountNumber", accNum);
        context.put("source", workplaceAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", workplaceAccountMap.get("displayName"));
        context.put("mnemonic", workplaceAccountMap.get("mnemonic"));
        context.put("sourceSystem2", workplaceAccountMap.get("sourceSystem"));
        context.put("institutionName", workplaceAccountMap.get("institutionName"));
        context.put("value", workplaceAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", workplaceAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "111111.11");
        context.put("emergencyFundAmount", "111111.11");
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.177);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.0f);
        context.put("_type", "com.fmr.ast.platform.account.domain.WorkplaceAccountDetails");
        context.put("type", "WorkplaceAccountDetails");
        context.put("withdrawAmount", "500");
        context.put("withdrawFreq", "HOURLY");
        context.put("riskTolerance", 2);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", 2055);
        context.put("withdrawalEndYear", 2085);
        context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
        context.put("federalTaxWithholding", 0.15);
        context.put("stateTaxWithholding", 0.05);
        context.put("TAM_name", "Growth with Income");
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
        
        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(workplaceAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(workplaceAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(workplaceAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(workplaceAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(
                        Float.valueOf(workplaceAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details.emergencyFundAmount.value", equalTo(111111.11f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
                .body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.15f))
                .body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.05f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.42f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.18f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.35f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.05f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category", equalTo("FINAL"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo("Growth with Income"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(179))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(60))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(500.0f))
                .body(acctRoot + "withdrawals[0].amount.frequency", equalTo("HOURLY"));
        
        accountTestData
                .setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
    }
    
    /**
     * Description: Validates the account composite response after create (get)
     */
    @Test(dependsOnMethods = "createCompositeAccountWorkplace")
    public void getCompositeAccountWorkplaceAfterCreate()
    {
        this.request.given()
                .header(new Header("include-suitability-details", "true"));
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("fescoLid", accountTestData.getSsn());
        context.put("externalDataSources", true);
        context.put("source", workplaceAccountMap.get("sourceSystem"));
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(workplaceAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(workplaceAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(workplaceAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(workplaceAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(workplaceAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(
                        Float.valueOf(workplaceAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details.emergencyFundAmount.value", equalTo(111111.11f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"))
                .body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.15f))
                .body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.05f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.42f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.18f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.35f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.05f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category", equalTo("FINAL"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo("Growth with Income"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(179))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(60))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(500.0f))
                .body(acctRoot + "withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }
    
    /**
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "getCompositeAccountWorkplaceAfterCreate")
    public void updateCompositeAccountWorkplace()
    {
        final VelocityContext context = new VelocityContext();
        context.put("externalDataSources", true);
        context.put("mid", accountTestData.getMid());
        context.put("fescoLid", accountTestData.getSsn());
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", workplaceAccountMap.get("accountNumber"));
        context.put("source", workplaceAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", workplaceAccountMap.get("displayName"));
        context.put("mnemonic", workplaceAccountMap.get("mnemonic"));
        context.put("sourceSystem2", workplaceAccountMap.get("sourceSystem"));
        context.put("institutionName", workplaceAccountMap.get("institutionName"));
        context.put("value", workplaceAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", workplaceAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "211111.11");
        context.put("emergencyFundAmount", "211111.11");
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.4f);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 1.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.70f);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.30f);
        context.put("_type", "com.fmr.ast.platform.account.domain.WorkplaceAccountDetails");
        context.put("type", "WorkplaceAccountDetails");
        context.put("withdrawAmount", "800");
        context.put("withdrawFreq", "BIWEEKLY");
        context.put("riskTolerance", 3);
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_25_AND_50");
        context.put("withdrawalStartYear", 2056);
        context.put("withdrawalEndYear", 2086);
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("federalTaxWithholding", 0.16);
        context.put("stateTaxWithholding", 0.06);
        context.put("TAM_total_equity", 0.5);
        context.put("TAM_domestic_equity", 0.4);
        context.put("TAM_foreign_equity", 0.1);
        context.put("TAM_bond", 0.5);
        context.put("TAM_cash", 0.0);
        context.put("TAM_category", "INVESTOR_SELECTED_STRATEGY");
        context.put("TAM_name", "Aggressive Growth");
        context.put("TAM_repositoryTamId", 181);
        context.put("TAM_assetAllocationId", 85);
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));
        System.out.println(request);
        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(workplaceAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(workplaceAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(workplaceAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(workplaceAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(workplaceAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(
                        Float.valueOf(workplaceAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details.emergencyFundAmount.value", equalTo(211111.11f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.85f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.25f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.15f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo("Aggressive Growth"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(181))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(85))
                .body(acctRoot + "details.complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.16f))
                .body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.06f))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(3))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(800.0f))
                .body(acctRoot + "withdrawals[0].amount.frequency", equalTo("BIWEEKLY"));
    }
    
    /**
     * Description: Validates the account composite response after an update (get)
     */
    @Test(dependsOnMethods = "updateCompositeAccountWorkplace")
    public void getCompositeAccountWorkplaceAfterUpdate()
    {
        this.request.given()
                .header(new Header("include-suitability-details", "true"));
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("fescoLid", accountTestData.getSsn());
        context.put("externalDataSources", true);
        context.put("source", workplaceAccountMap.get("sourceSystem"));
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(workplaceAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(workplaceAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(workplaceAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(workplaceAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(workplaceAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(
                        Float.valueOf(workplaceAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + "details", notNullValue())
                .body(acctRoot + "details.emergencyFundAmount.value", equalTo(211111.11f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(3))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(800.0f))
                .body(acctRoot + "withdrawals[0].amount.frequency", equalTo("BIWEEKLY"));
    }
    
    /**
     * Description: Validates the account composite response after delete
     */
    @Test(dependsOnMethods = "getCompositeAccountWorkplaceAfterUpdate")
    public void deleteCompositeAccountWorkplace()
    {
        final VelocityContext context = new VelocityContext();
        context.put("externalDataSources", true);
        context.put("mid", accountTestData.getMid());
        context.put("fescoLid", accountTestData.getSsn());
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", workplaceAccountMap.get("accountNumber"));
        context.put("source", workplaceAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", workplaceAccountMap.get("displayName"));
        context.put("mnemonic", workplaceAccountMap.get("mnemonic"));
        context.put("sourceSystem2", workplaceAccountMap.get("sourceSystem"));
        context.put("institutionName", workplaceAccountMap.get("institutionName"));
        context.put("value", workplaceAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", workplaceAccountMap.get("sourceMarketAsOfDate"));
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));
        
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("accountList", hasSize(0));
    }
    
    /**
     * Description: Validates an empty account list when calling get account composite workplace after delete
     */
    @Test(dependsOnMethods = "deleteCompositeAccountWorkplace")
    public void getCompositeAccountWorkplaceAfterDelete()
    {
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("fescoLid", accountTestData.getSsn());
        context.put("externalDataSources", true);
        context.put("source", workplaceAccountMap.get("sourceSystem"));
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Returns the response of retrieving a workplace account
     *
     * @param accountsCommonTestData the test data
     * @return workplaceAccountMap
     */
    private static HashMap<String, String> getWorkplaceAccountInformation(
            final AccountsCommonTestData accountsCommonTestData,
            final String oAuth)
    {
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("fescoLid", accountsCommonTestData.getSsn());
        context.put("source", "WORKPLACE");
        
        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();
        
        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        
        final Response response = request.post(AccountsPaths.GET_ACCOUNT_V1);
        
        if (response.statusCode() != HTTPStatusCodes.STATUS_200)
        {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));
            
            return null;
        }
        
        final JsonPath workplaceResponseJP = response.jsonPath();
        
        final HashMap<String, String> workplaceAccountMap = new HashMap<String, String>();
        workplaceAccountMap.put("accountNumber",
                workplaceResponseJP.getString("accountList[0].accountId.accountNumber"));
        workplaceAccountMap.put("sourceSystem",
                workplaceResponseJP.getString("accountList[0].accountId.sourceSystem"));
        workplaceAccountMap.put("displayName", workplaceResponseJP.getString("accountList[0].displayName"));
        workplaceAccountMap.put("mnemonic", workplaceResponseJP.getString("accountList[0].regCode.mnemonic"));
        workplaceAccountMap.put("institutionName",
                workplaceResponseJP.getString("accountList[0].institutionName"));
        workplaceAccountMap.put("sourceMarketAmountType",
                workplaceResponseJP.getString("accountList[0].sourceMarketValue.amount._type"));
        workplaceAccountMap.put("sourceMarketAmountValue",
                workplaceResponseJP.getString("accountList[0].sourceMarketValue.amount.value"));
        workplaceAccountMap.put("sourceMarketAmountValueType",
                workplaceResponseJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        workplaceAccountMap.put("sourceMarketAmountCurrency",
                workplaceResponseJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        workplaceAccountMap.put("sourceMarketAsOfDate",
                workplaceResponseJP.getString("accountList[0].sourceMarketValue.asOfDate"));
        
        return workplaceAccountMap;
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown()
    {
        testDataUtil.closeSQLiteConnection();
    }

}
