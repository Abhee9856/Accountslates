package com.fmr.restassured.account.v2.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.Matchers.*;

/**
 * Tests for Target Account Account Preferences when EEDS is false
 *
 * @author a631781
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.COMPOSITE,
		Tags.V2,
		Tags.TARGET_ACCOUNT})
public class Retail_Composite_V2_Target_AccountPreferences extends PAPBaseServiceTest
{

    protected Retail_Composite_V2_Target_AccountPreferences()
    {
	super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private TestDataUtil testDataUtil;

    private static final String SCENARIO_CATEGORY_CODE = "POR";

    private static final String SCENARIO_PRODUCT_CODE = "PASW";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private String ppid;

    private static final String LOG_TRACKING_ID =
		    Retail_Composite_V2_Target_AccountPreferences.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String displayNameTargetAct = "TargetAccount_DisplayName_for_CompositeV2";

    private static String targetAccountId;

    private final float fundingAccountAmount = 5.55f;

    private final float unknownAmount = 20.0f;

    int startYear = ZonedDateTime.now().plusYears(1).getYear();

    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    private static String withdrawalNeeds = "TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6";

    private static String stockMarketDeclinePercent = "SELL_BETWEEN_51_AND_75";

    private static Integer riskTolerance = 8;

    private FilterableRequestSpecification frs;

    //Financial Instrument IDs and their symbols
    private FinancialInstrumentIds finstIds;

    //Context
    private final VelocityContext context = new VelocityContext();

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	String oAuth = AccountUtil.getOauthToken();
	testDataUtil = new TestDataUtil();
	accountsCommonTestData =
			TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68", oAuth);
	//Data setup
	accountsCommonTestData.set("detailValue", "42619.85");
	accountsCommonTestData.set("contribAmount", "6000.0");
	accountsCommonTestData.set("contribFreq", "YEARLY");
	accountsCommonTestData.set("withdrawAmount", "500.0");
	accountsCommonTestData.set("withdrawFreq", "YEARLY");
	accountsCommonTestData.set("updatedDetailValue", "81819.89");
	accountsCommonTestData.set("updatedAmount", "15000.0");
	accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
	accountsCommonTestData.set("updatedContribAmount", "500.0");
	accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
	accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");

	DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


	ppid = Identity.createPrincipalWithScenario("mid", accountsCommonTestData.getMid(), SCENARIO_PRODUCT_CODE,
			SCENARIO_CATEGORY_CODE, oAuth);

	accountsCommonTestData.setPpid(ppid);

	String scenarioId = Scenario
			.createScenarioWithProductCode(accountsCommonTestData.getMid(), SCENARIO_PRODUCT_CODE,
					SCENARIO_CATEGORY_CODE, oAuth);

	Identity.createHouseholdIdentityWithProductCode(accountsCommonTestData.getMid(), oAuth, SCENARIO_PRODUCT_CODE,
			SCENARIO_CATEGORY_CODE);

	this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	//Resolve finstIds
	finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

	this.request.given()
			.header(new Header("user-poe", AccountConstants.RETAIL))
			.header(new Header("user-mid", accountsCommonTestData.getMid()))
			.header(new Header("user-sid", accountsCommonTestData.getSid()))
			.header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));

	frs = (FilterableRequestSpecification) request;

    }

    /**
     * Get Retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo()
    {
	// Generate request body
	context.put("source", AccountConstants.RETAIL);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accountList", not(empty()));

	accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
	accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
	accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
	accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
	accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
	accountsCommonTestData.setAccountNumber2(response.path("accountList[1].accountId.accountNumber"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void getCompositeAccount()
    {
	// Exclude external data
	context.put("sourceBasedRegistrationFilter", AccountConstants.RETAIL);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

	// Make post request
	response = request.log().ifValidationFails()
			.given()
			.header(new Header("excludeExternalDataSources", "true"))
			.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", empty());

    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccount")
    public void createCompositeAccount()
    {
	// Generate request body
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
	context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
	context.put("GBOND", finstIds.getFinstId("GBOND"));
	context.put("GCASH", finstIds.getFinstId("GCASH"));
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());
	context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
	context.put("contribValue", accountsCommonTestData.get("contribAmount"));
	context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
	context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
	context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
	context.put("detailValue", accountsCommonTestData.get("detailValue"));

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

	// Make post request
	response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", not(empty()));

	//Save account number and ID
	accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
	accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void getCompositeAccountAfterCreate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
					"accounts[0].account.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accounts[0].account.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()),
					"accounts[0].account.displayName",
					equalTo(accountsCommonTestData.getDisplayName1()),
					"accounts[0].account.regCode.mnemonic",
					equalTo(accountsCommonTestData.getMnemonic1()),
					"accounts[0].account.regCode.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accounts[0].account.institutionName",
					equalTo(accountsCommonTestData.getInstitutionName1()),
					"accounts[0].account.sourceMarketValue.amount.value",
					equalTo(accountsCommonTestData.getValue1()));
    }

    /**
     * Create a Target Account..
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterCreate")
    public void createTargetAccount()
    {
	// Generate request body
	context.put("targetAccountNumber", accountsCommonTestData.getAccountNumber2());
	context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
	context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
	context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
	context.put("targetDisplayName", displayNameTargetAct);
	context.put("unknownAmount", String.valueOf(unknownAmount));
	context.put("withdrawalNeeds", withdrawalNeeds);
	context.put("withdrawalStartYear", startYear);
	context.put("withdrawalEndYear", endYear);
	context.put("stockMarketDeclinePercent", stockMarketDeclinePercent);
	context.put("riskTolerance", riskTolerance);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

	// Call Account service
	response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("targetAccounts", not(empty()),
					"targetAccounts[0].accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber2()),
					"targetAccounts[0].accountId.id", notNullValue(),
					"targetAccounts[0].displayName", equalTo(displayNameTargetAct),
					"targetAccounts[0].sourceMarketValue.amount.value",
					equalTo(fundingAccountAmount),
					"targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
					"targetAccounts[0].fundingAccounts[0].accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"targetAccounts[0].fundingAccounts[0].amount.value",
					equalTo(fundingAccountAmount),
					"targetAccounts[0].targetAccountPreferences.riskTolerance",
					equalTo(riskTolerance),
					"targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
					equalTo(withdrawalNeeds),
					"targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
					equalTo(stockMarketDeclinePercent),
					"targetAccounts[0].targetAccountPreferences.withdrawalStartYear",
					equalTo(startYear),
					"targetAccounts[0].targetAccountPreferences.withdrawalEndYear",
					equalTo(endYear));

	targetAccountId = response.path("targetAccounts[0].accountId.id");

    }

    /**
     * Gets composite account with EEDS as true and verifies there is targetAccountPreferences in the response.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void getCompositeAccountAfterTargetAccountCreate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("targetAccounts", not(empty()),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId
							+ "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber2()),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.accountId.id",
					equalTo(targetAccountId),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId + "'}.displayName",
					equalTo(displayNameTargetAct),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId
							+ "'}.sourceMarketValue.amount.value",
					equalTo(fundingAccountAmount),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId
							+ "'}.accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId
							+ "'}.fundingAccounts[0].accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId
							+ "'}.fundingAccounts[0].amount.value",
					equalTo(fundingAccountAmount),

					"targetAccounts.find{it.accountId.id=='" + targetAccountId
							+ "'}.targetAccountPreferences.riskTolerance",
					equalTo(riskTolerance),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId
							+ "'}.targetAccountPreferences.withdrawalNeeds",
					equalTo(withdrawalNeeds),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId
							+ "'}.targetAccountPreferences.stockMarketDeclinePercent",
					equalTo(stockMarketDeclinePercent),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId
							+ "'}.targetAccountPreferences.withdrawalStartYear",
					equalTo(startYear),
					"targetAccounts.find{it.accountId.id=='" + targetAccountId
							+ "'}.targetAccountPreferences.withdrawalEndYear",
					equalTo(endYear));
    }

    /**
     * Gets composite account with EEDS as false and verifies there is targetAccountPreferences in the response.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterTargetAccountCreate")
    public void getCompositeAccountAfterWithEDSFalse()
    {
	//Exclude external data sources
	this.frs.removeHeader("excludeExternalDataSources");
	this.request.given()
			.header(new Header("excludeExternalDataSources", "false"));
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts.find{it.account.accountId.id=='" + targetAccountId + "'}.account.accountId.id",
					equalTo(targetAccountId),
					"accounts.find{it.account.accountId.id=='" + targetAccountId
							+ "'}.account.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber2()),
					"accounts.find{it.account.accountId.id=='" + targetAccountId
							+ "'}.account.displayName", equalTo(displayNameTargetAct),
					"accounts.find{it.account.accountId.id=='" + targetAccountId
							+ "'}.suitability.accountPreferencesIA.riskTolerance",
					equalTo(riskTolerance),
					"accounts.find{it.account.accountId.id=='" + targetAccountId
							+ "'}.suitability.accountPreferencesIA.withdrawalNeeds",
					equalTo(withdrawalNeeds),
					"accounts.find{it.account.accountId.id=='" + targetAccountId
							+ "'}.suitability.accountPreferencesIA.stockMarketDeclinePercent",
					equalTo(stockMarketDeclinePercent),
					"accounts.find{it.account.accountId.id=='" + targetAccountId
							+ "'}.suitability.accountPreferencesIA.withdrawalStartYear",
					equalTo(startYear),
					"accounts.find{it.account.accountId.id=='" + targetAccountId
							+ "'}.suitability.accountPreferencesIA.withdrawalEndYear",
					equalTo(endYear));

    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterWithEDSFalse")
    public void deleteCompositeAccount()
    {
	//Exclude external data sources
	this.frs.removeHeader("excludeExternalDataSources");
	this.request.given()
			.header(new Header("excludeExternalDataSources", "true"));
	// Generate new request body
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("id", accountsCommonTestData.getAccountId1());
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

	response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(200)
			.body("isEmpty()", Matchers.is(true));
    }

    /**
     * Call delete and confirm that no accounts come back in the response.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void getCompositeAccountAfterDelete()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

	// Make post request
	response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("accounts", empty());
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}
