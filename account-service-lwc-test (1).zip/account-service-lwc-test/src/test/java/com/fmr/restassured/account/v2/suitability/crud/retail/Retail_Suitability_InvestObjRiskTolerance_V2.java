/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.suitability.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsSuitabilityPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountSuitabilityTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.SuitabilityDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;

/**
 * Tests CRUD operations for Account Suitability V2 for Retail accounts when riskTolerance is provided in the investment objective for Create and Update then service should return TAM(not RiskTolerance) based on the riskTolerance mapping.
 *
 * @author a631781
 * <p>
 * Test flow:
 * 1. Create Principal
 * 2. Search for Retail accounts owned by the Principal
 * 3. Create then get Manual account
 * 4. Create then get account suitability for the account created
 * 5. Update then get account suitability created in step 4
 * 6. Delete the account then get accountsuitability to validate Manual accounts and
 * suitabililty were deleted
 */
@Test(groups = {
        Tags.RETAIL,
        Tags.SUITABILITY,
        Tags.V2})
public class Retail_Suitability_InvestObjRiskTolerance_V2 extends PAPBaseServiceTest {

    protected Retail_Suitability_InvestObjRiskTolerance_V2() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private String mid;

    private String ppid;

    private String mnemonic;

    private String accountNumber;

    private String accountId;

    private String sourceSystem;

    private String displayName;

    private float value;

    private String institutionName;

    private String asOfDate;

    private VelocityContext context;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Suitability_InvestObjRiskTolerance_V2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String investObjId = "26";
    private static final Integer investObjRiskTolerance = 2;
    private static final String tamName = "Conservative";
    private static final Integer investObjRiskToleranceUpdate = 5;
    private static final String tamNameUpdated = "Balanced";

    FilterableRequestSpecification frs;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();

        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_suitability_CRUD_Retail", oAuth);

        mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.given().header(new Header("user-poe", "RETAIL")).header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("excludeExternalDataSources", "false"));

        // Populate request context with user IDs
        context = new VelocityContext();
        context.put("ppid", ppid);
        context.put("source", "RETAIL");
        frs = (FilterableRequestSpecification) request;

    }

    /**
     * Get Retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    // Create the Retail account. Save the account id.
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount() {
        frs.removeHeader("excludeExternalDataSources");
        request.given().header(new Header("excludeExternalDataSources", "true"));
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList[0].regCode.mnemonic",
                equalTo(mnemonic), "accountList[0].accountId.accountNumber", equalTo(accountNumber));

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        context.put("accId", accountId);
    }

    // Validate the account was created correctly.
    @Test(dependsOnMethods = "createRetailAccount")
    public void getRetailAccountAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList[0].regCode.mnemonic",
                equalTo(mnemonic), "accountList[0].accountId.accountNumber", equalTo(accountNumber));

    }

    //Create the account suitability in ICS.
    @Test(dependsOnMethods = "getRetailAccountAfterCreate")
    public void createAccountSuitability() {
        // Generate request body
        frs.removeHeader("excludeExternalDataSources");
        request.given().header(new Header("excludeExternalDataSources", "false"));
        context.put("investObj_riskTolerance", investObjRiskTolerance);
        context.put("investObj_Id", investObjId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_CREATE_TEMPLATE_V2)).log()
                .ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.CREATE_ACCOUNTS_SUITABILITY_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", not(empty()));
    }

    // Validate the suitability information in ICS
    @Test(dependsOnMethods = "createAccountSuitability")
    public void getSuitabilityAfterCreate() {
        // Generate request body
        frs.removeHeader("excludeExternalDataSources");

        request.given().header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("clear-retail-cache", "true"));
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", not(empty()))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix", not(empty()),
                        "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix.name", equalTo(tamName),
                        "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.id", equalTo(investObjId));
    }

    // Update the suitability just created.
    @Test(dependsOnMethods = "getSuitabilityAfterCreate")
    public void updateAccountSuitability() {
        // Generate request body
        frs.removeHeader("excludeExternalDataSources");
        request.given().header(new Header("excludeExternalDataSources", "false"));
        context.put("investObj_riskTolerance", investObjRiskToleranceUpdate);
        context.put("investObj_Id", investObjId);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_UPDATE_TEMPLATE_V2));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.UPDATE_ACCOUNTS_SUITABILITY_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", not(empty()))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix", not(empty()),
                        "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix.name", equalTo(tamNameUpdated),
                        "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.id", equalTo(investObjId));
    }


    //Validate the suitability was updated in ICS.
    @Test(dependsOnMethods = "updateAccountSuitability")
    public void getSuitabilityAfterUpdate() throws InterruptedException {
        // Generate request body
        frs.removeHeader("excludeExternalDataSources");
        request.given().header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("clear-retail-cache", "true"));
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("accountSuitability", not(empty()))
                .body("accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix", not(empty()),
                        "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.targetAssetMix.name", equalTo(tamNameUpdated),
                        "accountSuitability.find{it.accountId.id=='" + accountId + "'}.investmentObjective.id", equalTo(investObjId));
    }

    // Delete the account.
    @Test(dependsOnMethods = "getSuitabilityAfterUpdate")
    public void deleteAccountSuitability() {
        context.put("ppid", ppid);
        context.put("source", "RETAIL");
        context.put("id", accountId);
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountSuitability",
                equalTo(null));

    }

    // Validate no suitability is returned.
    @Test(dependsOnMethods = "deleteAccountSuitability")
    public void getSuitabilityAfterDelete() {
        context.put("id", null);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);

    }

}
