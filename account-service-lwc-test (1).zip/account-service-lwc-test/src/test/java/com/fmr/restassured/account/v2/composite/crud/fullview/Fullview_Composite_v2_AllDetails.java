/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.fullview;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * Contains tests that validate the Account Composite operation for Fullview Accounts - includes CRUD validations
 *
 * @author a623549
 * Updated by a608077 on 05/23/2023 to include backdoor IRA changes(PFCP-12448)
 * Updated by a608077 on 10/11/2023 to include 3 new asset classes: Private Equity, Private Credit,
 * and Real Assets(PFCP-13826)
 * 
 */
@Test(groups = {Tags.FULLVIEW, Tags.COMPOSITE, Tags.V2, Tags.CRITICAL})
public class Fullview_Composite_v2_AllDetails extends PAPBaseServiceTest
{
    
    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Fullview_Composite_v2_AllDetails.class);
    
    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;
    
    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountsCommonTestData;
    
    private String accNum;
    
    private String acctRoot;

    final String catchupPath = ".contributions.find{it.contributionType=='CATCHUP'}";
    final String regularPath = ".contributions.find{it.contributionType=='REGULAR'}";

    private final String details = "details.fullviewAccountDetail.accountDetail.";
    
    /**
     * Financial Instrument IDs and their symbols
     */
    private FinancialInstrumentIds finstIds;
    
    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";
    
    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";

    private static final String LOG_TRACKING_ID = Fullview_Composite_v2_AllDetails.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private VelocityContext context;
    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
    private final float netPercentage_T_ALTERNATIVE = 0.8f;
    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
    private final float netPercentage_PEA = 0.4f;
    private final float netPercentage_Updated_PEA = 0.2f;
    private final float netPercentage_PCA = 0.2f;
    private final float netPercentage_Updated_PCA = 0.3f;
    private final float netPercentage_PRAA = 0.2f;
    private final float netPercentage_Updated_PRAA = 0.1f;
    
    /**
     * Constructor
     */
    protected Fullview_Composite_v2_AllDetails()
    {
        super(Services.Account);
    }
    
    /**
     * Initialization method used to: </br>
     * 1. Get the default SSN and use it to retrieve the MID. </br>
     * 2. Set the Base URI </br>
     * 3. Get the account service operation paths. </br>
     * 4. Build the request header (with OAuth token).
     */
    @BeforeClass(alwaysRun = true)
    public void initClass()
    {
        oAuth = AccountUtil.getOauthToken();
        // Data setup
        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Fullview",oAuth);
        
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("contribFreq", "YEARLY");
        accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        accountsCommonTestData.set("contribAmount", "6000");
        accountsCommonTestData.set("updatedContribAmount", "500");
        accountsCommonTestData.set("withdrawAmount", "500");
        accountsCommonTestData.set("updatedWithdrawAmount", "1000");
        accountsCommonTestData.set("withdrawFreq", "YEARLY");
        accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");
        accountsCommonTestData.set("emergencyFundAmountValue", "111111.11");
        accountsCommonTestData.set("updatedEmergencyFundAmountValue", "211111.11");
        
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");

        
        accountsCommonTestData.setPpid(
                Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));
        
        // Resolve finstIds
        finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

        context = new VelocityContext();
    }
    
    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init()
    {
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"));
    }
    
    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates an empty account list when calling get account composite Fullview before creation of
     * an account (v2)
     */
    @Test
    public void getCompositeAccountFullviewV2BeforeCreate()
    {
        // Retrieve fullview test data
        accountsCommonTestData = getFullviewAccountInformationV2(accountsCommonTestData, oAuth);
        assert this.accountsCommonTestData != null;
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
        
    }
    
    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after a create
     */
    @Test(dependsOnMethods = "getCompositeAccountFullviewV2BeforeCreate")
    public void createCompositeAccountFullviewV2()
    {
        // Generate request body
        accNum = accountsCommonTestData.getAccountNumber1();
        context.put("accountNumber", accNum);
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("emergencyFundAmountValue", accountsCommonTestData.get("emergencyFundAmountValue"));
        context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", finstIds.getFinstId("GBOND"));
        context.put("GCASH", finstIds.getFinstId("GCASH"));
        context.put("riskTolerance", 2);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", 2055);
        context.put("withdrawalEndYear", 2085);
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.177);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.0f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_PRAA);
        context.put("contribFreq", "YEARLY");
        context.put("contribValue", "500");
        context.put("contributionTaxType", "POST_TAX");
        context.put("contributionType", "CATCHUP");
        context.put("contributor", "EMPLOYER");
        context.put("contribBasisTypeCd", "BASE");
        context.put("contribFreq2", "BIMONTHLY");
        context.put("contribValue2", "900");
        context.put("contributionTaxType2", "AGGREGATE");
        context.put("contributionType2", "REGULAR");
        context.put("contributor2", "INDIVIDUAL");
        context.put("contribBasisTypeCd2", "BASEBONUS");
        context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
        context.put("equityPercent", 0.35);
        context.put("originalOwnerBirthDate", "1958-11-09");
        context.put("originalOwnerDeceasedDate", "2022-11-09");
        context.put("withdrawalEligibilityStartDate", "2022-11-09");
        context.put("withdrawalEligibilityEndDate", "2052-11-09");
        context.put("originalOwnerSpouse", "false");
        context.put("federalTaxWithholding", 0.15);
        context.put("stateTaxWithholding", 0.05);
        context.put("isBackdoorRoth", "true");

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        // Make post request
        response = request.log().ifValidationFails()
                .post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PCA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PEA))
                 .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PRAA))
                .body(acctRoot + details + "equityPercent", equalTo(0.35f))
                .body(acctRoot + details + "originalOwnerBirthDate", equalTo("1958-11-09T00:00:00.000+0000"))
                .body(acctRoot + details + "originalOwnerDeceasedDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body(acctRoot + details + "withdrawalEligibilityStartDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body(acctRoot + details + "withdrawalEligibilityEndDate", equalTo("2052-11-09T00:00:00.000+0000"))
                .body(acctRoot + details + "originalOwnerSpouse", equalTo(false))
                .body(acctRoot + details + "federalTaxWithholdingPercent", equalTo(0.15f))
                .body(acctRoot + details + "stateTaxWithholdingPercent", equalTo(0.05f))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
                .body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "contributions" +".isBackdoorRoth", equalTo(true))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))))
                .body(acctRoot + "withdrawals[0].amount.frequency",
                        equalTo(accountsCommonTestData.get("withdrawFreq")));
        
        accountsCommonTestData.set(TARGET_ACCOUNT_NUMBER_KEY,
                response.path("targetAccounts[0].accountId.accountNumber"));
        accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
        accountsCommonTestData
                .setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
    }
    
    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after a create
     */
    @Test(dependsOnMethods = "createCompositeAccountFullviewV2")
    public void getCompositeAccountFullviewV2AfterCreate()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PCA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PEA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_PRAA))
                .body(acctRoot + details + "equityPercent", equalTo(0.35f))
                .body(acctRoot + details + "originalOwnerBirthDate", equalTo("1958-11-09T00:00:00.000+0000"))
                .body(acctRoot + details + "originalOwnerDeceasedDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body(acctRoot + details + "withdrawalEligibilityStartDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body(acctRoot + details + "withdrawalEligibilityEndDate", equalTo("2052-11-09T00:00:00.000+0000"))
                .body(acctRoot + details + "originalOwnerSpouse", equalTo(false))
                .body(acctRoot + details + "federalTaxWithholdingPercent", equalTo(0.15f))
                .body(acctRoot + details + "stateTaxWithholdingPercent", equalTo(0.05f))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
                .body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "contributions" +".isBackdoorRoth", equalTo(true))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))))
                .body(acctRoot + "withdrawals[0].amount.frequency",
                        equalTo(accountsCommonTestData.get("withdrawFreq")));
    }
    
    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "getCompositeAccountFullviewV2AfterCreate")
    public void updateCompositeAccountFullviewV2()
    {
        // Generate request body
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
        context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
        context.put("emergencyFundAmountValue", accountsCommonTestData.get("updatedEmergencyFundAmountValue"));
        context.put("riskTolerance", 3);
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_25_AND_50");
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.4f);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 1.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.70f);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.30f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_Updated_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_Updated_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
        context.put("withdrawalStartYear", 2056);
        context.put("withdrawalEndYear", 2086);
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("equityPercent", 0.25);
        context.put("originalOwnerBirthDate", "1958-12-09");
        context.put("originalOwnerDeceasedDate", "2022-12-09");
        context.put("contribValue", "600");
        context.put("contribFreq", "YEARLY");
        context.put("contribValue2", "700");
        context.put("contribFreq2", "BIMONTHLY");
        context.put("withdrawalEligibilityStartDate", "2022-12-09");
        context.put("withdrawalEligibilityEndDate", "2052-12-09");
        context.put("originalOwnerSpouse", true);
        context.put("federalTaxWithholding", 0.16);
        context.put("stateTaxWithholding", 0.06);
        context.put("TAM_total_equity", 0.5);
        context.put("TAM_domestic_equity", 0.4);
        context.put("TAM_foreign_equity", 0.1);
        context.put("TAM_bond", 0.5);
        context.put("TAM_cash", 0.0);
        context.put("TAM_category", "INVESTOR_SELECTED_STRATEGY");
        context.put("TAM_name", "Aggressive Growth");
        context.put("TAM_repositoryTamId", 181);
        context.put("TAM_assetAllocationId", 85);
        context.put("isBackdoorRoth","false");
       
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        // Make post request
        response = request.log().ifValidationFails()
                .post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PRAA))
                .body(acctRoot + details + "equityPercent", equalTo(0.25f))
                .body(acctRoot + details + "originalOwnerBirthDate", equalTo("1958-12-09T00:00:00.000+0000"))
                .body(acctRoot + details + "originalOwnerDeceasedDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body(acctRoot + details + "withdrawalEligibilityStartDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body(acctRoot + details + "withdrawalEligibilityEndDate", equalTo("2052-12-09T00:00:00.000+0000"))
                .body(acctRoot + details + "originalOwnerSpouse", equalTo(true))
                .body(acctRoot + details + "federalTaxWithholdingPercent", equalTo(0.16f))
                .body(acctRoot + details + "stateTaxWithholdingPercent", equalTo(0.06f))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(700.0f))
                .body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "contributions" +".isBackdoorRoth", equalTo(false))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(3))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(
                                accountsCommonTestData.get("updatedWithdrawAmount"))))
                .body(acctRoot + "withdrawals[0].amount.frequency",
                        equalTo(accountsCommonTestData.get("updatedWithdrawFreq")));
    }
    
    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "updateCompositeAccountFullviewV2")
    public void getCompositeAccountFullviewV2AfterUpdate()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body(acctRoot + "account.accountId.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
                .body(acctRoot + "account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + details + "assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + details + "assetAllocation.allocation.find{it.assetClass=='"+ assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_CREDIT_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_EQUITY_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + details + "assetAllocation.allocation[2].allocation.find{it.assetClass=='"+ assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE +"'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PRAA))
                .body(acctRoot + details + "equityPercent", equalTo(0.25f))
                .body(acctRoot + details + "originalOwnerBirthDate", equalTo("1958-12-09T00:00:00.000+0000"))
                .body(acctRoot + details + "originalOwnerDeceasedDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body(acctRoot + details + "withdrawalEligibilityStartDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body(acctRoot + details + "withdrawalEligibilityEndDate", equalTo("2052-12-09T00:00:00.000+0000"))
                .body(acctRoot + details + "originalOwnerSpouse", equalTo(true))
                .body(acctRoot + details + "federalTaxWithholdingPercent", equalTo(0.16f))
                .body(acctRoot + details + "stateTaxWithholdingPercent", equalTo(0.06f))
                .body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
                .body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
                .body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
                .body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
                .body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(700.0f))
                .body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
                .body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
                .body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
                .body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "contributions" +".isBackdoorRoth", equalTo(false))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(3))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
                .body(acctRoot + "withdrawals", notNullValue())
                .body(acctRoot + "withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(
                                accountsCommonTestData.get("updatedWithdrawAmount"))))
                .body(acctRoot + "withdrawals[0].amount.frequency",
                        equalTo(accountsCommonTestData.get("updatedWithdrawFreq")));
    }
    
    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after a delete
     */
    @Test(dependsOnMethods = "getCompositeAccountFullviewV2AfterUpdate")
    public void deleteCompositeAccountFullviewV2()
    {
        final VelocityContext context = new VelocityContext();
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()));
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));
        
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);
        
        final String emptyResponse = response.jsonPath().getString("$");
        assertThat(emptyResponse, equalTo("[:]"));
    }
    
    /**
     * JIRA Item: PFCP-3074 RA Regression Conversion: accountComposite CRUD- Fili and Fullview Accounts V1&V2
     * <p>
     * Description: Validates an empty account list when calling get account composite Fullview after delete
     */
    @Test(dependsOnMethods = "deleteCompositeAccountFullviewV2")
    public void getCompositeAccountFullviewV2AfterDelete()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", accountsCommonTestData.getSourceSystem1());
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));
        
        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
        
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }
    
    /**
     * Returns the response of retrieving a fullview account
     *
     * @param accountsCommonTestData
     * @param oAuth
     * @return accountsCommonTestData
     */
    private static AccountsCommonTestData getFullviewAccountInformationV2(
            final AccountsCommonTestData accountsCommonTestData, final String oAuth)
    {
        final VelocityContext context = new VelocityContext();
        context.put("source", "FULLVIEW");
        context.put("mnemonicFilter", "IRA");
        
        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();
        
        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);
        
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-sid", accountsCommonTestData.getSid()))
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        
        final Response response = request.post(AccountsPaths.GET_ACCOUNT_V2);
        
        if (response.statusCode() != HTTPStatusCodes.STATUS_200)
        {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));
            
            return null;
        }
        
        final JsonPath filiAccountJP = response.jsonPath();
        
        final HashMap<String, String> filiAccountMap = new HashMap<String, String>();
        filiAccountMap.put("accountNumber", filiAccountJP.getString("accountList[0].accountId.accountNumber"));
        filiAccountMap.put("sourceSystem", filiAccountJP.getString("accountList[0].accountId.sourceSystem"));
        filiAccountMap.put("displayName", filiAccountJP.getString("accountList[0].displayName"));
        filiAccountMap.put("mnemonic", filiAccountJP.getString("accountList[0].regCode.mnemonic"));
        filiAccountMap.put("institutionName", filiAccountJP.getString("accountList[0].institutionName"));
        filiAccountMap.put("sourceMarketAmountValue",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
        filiAccountMap.put("sourceMarketAmountValueType",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        filiAccountMap.put("sourceMarketAmountCurrency",
                filiAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        filiAccountMap.put("sourceMarketAsOfDate",
                filiAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));
        
        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
        
        return accountsCommonTestData;
    }
    
}
