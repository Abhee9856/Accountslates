/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.v1.composite.crud.retail;


import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;

import static org.hamcrest.Matchers.*;

/**
 * We convert retail account to real account as part of target account create when we have targetAccountIndicator as false and scenario category code POR. In this sceanrio, we are not currently returning the created account back as part of create response. We need to return the newly created account back as part of create response for Simple Switch Case sceanrio.
 * PFCP-18208
 *
 * @author a631781
 */
@Test(groups = {
        Tags.RETAIL,
        Tags.COMPOSITE,
        Tags.V1,
        Tags.TARGET_ACCOUNT})
public class Retail_Composite_V1_Target2Real_SimpleSwitchTest extends PAPBaseServiceTest {

    protected Retail_Composite_V1_Target2Real_SimpleSwitchTest() {
        super(Services.Account);
    }

    //Context
    private VelocityContext context;

    int startYear = ZonedDateTime.now().plusYears(1).getYear();

    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    private final float fundingAccountAmount = 5.55f;

    private static final String isProductSuitable = "true";

    private AccountsCommonTestData accountsCommonTestData;
    private TestDataUtil testDataUtil;
    private static final String LOG_TRACKING_ID = Retail_Composite_V1_Target2Real_SimpleSwitchTest.class.getSimpleName() + LocalDateTime.now();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String SCENARIO_CATEGORY_CODE = "POR";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    private static String scenarioId;
    private static final String displayNameTargetAct = "Simple Switch TargetAccount DisplayName for Composite V1";

    private static String targetAccountId;

    //Financial Instrument IDs and their symbols
    private FinancialInstrumentIds finstIds;

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init() {
        String oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();

        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_contributions_CRUD_RK_Retail_Principal_104", oAuth);
        String mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(mid);
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");

        String ppid = Identity.createPrincipalWithScenario("mid", accountsCommonTestData.getMid(), SCENARIO_PRODUCT_CODE,
                SCENARIO_CATEGORY_CODE, oAuth);
        accountsCommonTestData.setPpid(ppid);

       scenarioId = Scenario
                .createScenarioWithProductCode(accountsCommonTestData.getMid(), SCENARIO_PRODUCT_CODE,
                        SCENARIO_CATEGORY_CODE, oAuth);

        Identity.createHouseholdIdentityWithProductCode(accountsCommonTestData.getMid(), oAuth, SCENARIO_PRODUCT_CODE,
                SCENARIO_CATEGORY_CODE);

        //Data setup
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("contribFreq", "YEARLY");
        accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        accountsCommonTestData.set("contribAmount", "6000.0");
        accountsCommonTestData.set("updatedContribAmount", "500.0");
        accountsCommonTestData.set("withdrawAmount", "500.0");
        accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
        accountsCommonTestData.set("withdrawFreq", "YEARLY");
        accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        //Resolve finstIds
        finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("mid", accountsCommonTestData.getMid());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", "RETAIL");
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);
    }

    /**
     * Get retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
                response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode) {
            Assert.assertEquals(dssResultCode, false);
        }

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
        accountsCommonTestData.setAccountNumber2(response.path("accountList[1].accountId.accountNumber"));
        accountsCommonTestData.setMnemonic2(response.path("accountList[1].regCode.mnemonic"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void getCompositeAccount() {
        // Exclude external data
        context.put("externalDataSources", "true");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());
    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getCompositeAccount"})
    public void createCompositeAccount() {
        // Generate request body
        String accNum = accountsCommonTestData.getAccountNumber1();
        String acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";
        context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", finstIds.getFinstId("GBOND"));
        context.put("GCASH", finstIds.getFinstId("GCASH"));
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accNum);
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("contribValue", accountsCommonTestData.get("contribAmount"));
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("_type", AccountConstants.RETAIL_ACCOUNT_DETAILS_TYPE);
        context.put("type", AccountConstants.RETAIL_ACCOUNT_DETAILS);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

        //Save account number and ID
        accountsCommonTestData.setAccountId1(response.path(acctRoot + "account.accountId.id"));
    }

    /**
     * Create target account with targetAccountIndicator as false. Target account should return as real account.
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void createTargetAccount() {
        // Generate request body
        context.put("targetAccountNumber", accountsCommonTestData.getAccountNumber2());
        context.put("targetAccountSourceSystem", accountsCommonTestData.getSourceSystem1());
        context.put("targetAccountPpid", accountsCommonTestData.getPpid());
        context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("fundingAccountValue", String.valueOf(fundingAccountAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("category", "INVESTOR_SELECTED_STRATEGY");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
        context.put("riskTolerance", "8");
        context.put("withdrawalNeeds", "TIME_TO_TIME_WITHDRAWAL_LESS_THAN_EQUAL_TO_6");
        context.put("isProductSuitable", isProductSuitable);
        float unknownAmount = 20.0f;
        context.put("unknownAmount", String.valueOf(unknownAmount));
        context.put("targetDisplayName", displayNameTargetAct);
        context.put("assetAllocation", "0.05");
        context.put("targetAccountIndicator", "false");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts.find{it.account.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber2() + "'}.account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber2()),
                        "accounts.find{it.account.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber2() + "'}.account.displayName", equalTo(displayNameTargetAct));

        targetAccountId = response.path("accounts.find{it.account.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber2() + "'}.account.accountId.id");

    }


    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void deleteCompositeAccount() {
        // Exclude external data sources
        context.put("externalDataSources", "true");
        // Generate request body
        context.put("scenarioId", scenarioId);
        context.put("accountNumber", accountsCommonTestData.getAccountNumber2());
        context.put("accId", targetAccountId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

    }

    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void deleteSecondCompositeAccount() {
        // Exclude external data sources
        context.put("externalDataSources", "true");
        // Generate request body
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("accId", accountsCommonTestData.getAccountId1());
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));

        // Make post request
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));

    }

    /**
     * Call delete and confirm that no accounts come back in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void getCompositeAccountAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}