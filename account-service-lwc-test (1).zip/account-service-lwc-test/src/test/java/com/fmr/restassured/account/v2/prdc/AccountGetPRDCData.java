package com.fmr.restassured.account.v2.prdc;
/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

import com.fmr.ast.platform.account.domain.Account;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.soap.SOAPBackendUtil;
import com.fmr.pap.restassured.common.soap.SOAPSecureHeader;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.SOAPOauthUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.w3c.dom.Document;

import java.util.List;
import java.util.Map;

import static com.fmr.restassured.account.helpers.SOAPOauthUtil.callVMPlanSoapAPI;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

/**
 * Tests Account Get and compares it with PRDC Account API response.
 * @author a608077
 *
 * Updated by a783909 on 02/20/2025 (PFCP-18287)
 * To verify the displayName with nickName or ShortName from SoapAPI VMPlan for PRDC and Non PRDC.
 */

@Test(groups = {Tags.PRDC_DATA, Tags.V2})
public class AccountGetPRDCData extends PAPBaseServiceTest {

    private static final Logger LOGGER = LogManager.getLogger(AccountGetPRDCData.class);

    protected AccountGetPRDCData()
    {
        super(Services.Account);
    }

    private VelocityContext context;

    public String mid;

    public String ssn;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = AccountGetPRDCData.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private FilterableRequestSpecification frs;

    private String wid,accNumber,retailLid;
    private String planNumber;
    final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;

    private AccountsCommonTestData accountsCommonTestData = null;

    private String vMPlanShortName;

    private SOAPSecureHeader secureHeader;

    @BeforeTest
    public void init()
    {
        accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_get_PRDC", oAuth);

        this.ssn = accountsCommonTestData.getSsn();
        StringBuilder builder = new StringBuilder(ssn);
        builder.insert(3, '-');
        builder.insert(6, '-');
        retailLid = builder.toString();

        mid = accountsCommonTestData.getMid();

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        frs = (FilterableRequestSpecification) request;

        testDataUtil = new TestDataUtil();

        context = new VelocityContext();
        context.put("source", AccountConstants.WORKPLACE);

    }
    /**
     * Get WID from CDS API by passing fescoLid
     */
    @Test
    public void getWIDFromCDS()
    {
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        this.request.header(new Header("fid-user-id", "couldBeAnything"))
                .header(new Header("fid-log-tracking-id", "TestQA"))
                .header(new Header("fid-principal-role", "PART"))
                .header(new Header("fid-user-id-type", "FidCust"))
                .header(new Header("Authorization", oAuth))
                .header(new Header("Content-Type", "application/json"));

        context.put("id",retailLid);
        context.put("idIssuer", "SSA");
        context.put("idType", "SSN");

        this.request.baseUri(AccountConstants.WDS_BASE_URI);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.WDS_GET_TEMPLATE));

        response = this.request.post(AccountConstants.WDS_GET_PATH);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(anyOf(is(200)))
                .body("id", not(empty()));

        wid= response.path("id");

    }
    /**
     * Get PRDC accounts from PRDC API by passing WID
     */
    @Test(dependsOnMethods = {"getWIDFromCDS","getAccounts_V2_PRDC_False"})
    public void getAccNumberFromPRDC()
    {
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();

        request.given().header(new Header("Authorization", oAuth));

       request.baseUri(AccountConstants.PRDC_BASE_URI);
       request.given()
                .pathParam("wid", wid);
        response = request.given().get(AccountConstants.PRDC_GET_PATH);

        // Assert on response
       response.then().log().ifValidationFails().statusCode(200)
                .body("accountDetails", not(empty()));

       accNumber= response.path("accountDetails.find{it.planNbr=='" + planNumber
                                    + "'}.accountNbr");

    }
    /**
     * Tests that PRDC account data is brought back with return-prdc-accounts=false
     * Version V2
     */
    @Test(dependsOnMethods = "getWIDFromCDS")
    public void getAccounts_V2_PRDC_False()
    {
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

        this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);

        this.request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-fesco-lid", this.ssn))
                .header(new Header("user-mid", mid))
                .header(new Header("return-prdc-accounts","false"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(200)
                .body("accountList", not(emptyArray()));
        planNumber= response.path("accountList[0].accountId.accountNumber");

        //verify the displayName with nickName or ShortName in VM Plan
        verifyDisplayNameInResponse(false);

    }
    /**
     * Tests that PRDC account data is brought back with return-prdc-accounts=true
     * Version V2
     */
    @Test(dependsOnMethods = {"getAccNumberFromPRDC"})
    public void getAccounts_V2_PRDC_True()
    {
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

        this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);

        this.request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-fesco-lid", ssn))
                .header(new Header("user-mid", mid))
                .header(new Header("return-prdc-accounts","true"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        response = this.request.post(AccountsPaths.GET_ACCOUNT_V2);

        //verify the displayName with nickName or ShortName in VM Plan
        verifyDisplayNameInResponse(true);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(200)
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.accountNumber=='" + accNumber
                        + "'}.accountId.sourceSystem", equalTo(AccountConstants.WORKPLACE));

    }
    /**
     * Tests that PRDC account data is brought back with return-prdc-accounts=true/false
     * Version V2
     */
    @Test(dependsOnMethods = {"getAccounts_V2_PRDC_True"})
    public void getDetails_V2_PRDC_True() {
        getDetails_V2_PRDC(true);
    }

    @Test(dependsOnMethods = {"getDetails_V2_PRDC_True"})
    public void getDetails_V2_PRDC_False() {
        getDetails_V2_PRDC(false);
    }

    @Test(dependsOnMethods = {"getDetails_V2_PRDC_False"})
    public void getComposite_details_V2_PRDC_TRUE() {
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("return-prdc-accounts", "true"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(200)
                .body("accounts", not(emptyArray()));

        validateCompositeAccountResponse(response, true);
    }
    @Test(dependsOnMethods = {"getComposite_details_V2_PRDC_TRUE"} )
    public void getComposite_details_V2_PRDC_FALSE() {
        request.header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "false"))
                .header(new Header("return-prdc-accounts", "false"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(200)
                .body("accounts", not(emptyArray()));

        validateCompositeAccountResponse(response, false);
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown()
    {
        this.testDataUtil.closeSQLiteConnection();
    }

    private void verifyDisplayNameInResponse(Boolean prdcFlag) {
        setShortNameFromVMPlan();
        List<Account> actList = response.jsonPath().getList("accountList");
        Boolean isNickNameVerified = false;
        Boolean isShortNameVerified = false;

        for(int count=0;count< actList.size();count++){
            String accNumber = response.path("accountList["+count+"].accountId.accountNumber");
            if(prdcFlag)
                accNumber = TestDataUtil.getMaskedAccountNumber(accNumber);

            String displayName = response.path("accountList["+count+"].displayName");
            String nickName = response.path("accountList["+count+"].nickName");

            if (nickName != null && !isNickNameVerified) {
                Assert.assertEquals(displayName, nickName+"-"+accNumber);
                isNickNameVerified = true;
            } else if(!isShortNameVerified) {
                Assert.assertEquals(displayName,  vMPlanShortName+"-"+accNumber);
                isShortNameVerified = true;
            }

            if(isShortNameVerified && isNickNameVerified) break;
        }
    }

    private void setShortNameFromVMPlan()
    {
        this.secureHeader = SOAPOauthUtil.getSecureHeader();
        final Document defDoc = callVMPlanSoapAPI(
                this.secureHeader,
                accountsCommonTestData.getSsn(), planNumber);
       String s = SOAPBackendUtil.convertDocumentToString(defDoc);

        vMPlanShortName = SOAPBackendUtil.getXmlValue(defDoc,   "/Envelope/Body/GetRetirementPlanInfoResponse/" +
                "GetRetirementPlanInfoResult/Accounts/Account/ShortName");
    }

    private void getDetails_V2_PRDC(boolean returnPrdcAccounts) {
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

        this.request.baseUri(AccountConstants.PAP_QA_BASE_URI);

        this.request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-fesco-lid", this.ssn))
                .header(new Header("user-mid", mid));

        if (returnPrdcAccounts) {
            this.request.header(new Header("return-prdc-accounts", "true"));
        }

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        response = this.request.post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

        // Base response validation
        response.then().log().ifValidationFails().statusCode(200)
                .body("accountDetails", not(emptyArray()));

        if (returnPrdcAccounts) {
            // Validate accountNumber and planNumber separately
            response.then()
                    .body("accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='" + accNumber
                            + "'}.workplaceAccountDetail.planId.planNumber", equalTo(planNumber))
                    .body("accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='" + accNumber
                            + "'}.workplaceAccountDetail.accountDetail.accountId.sourceSystem", equalTo(AccountConstants.WORKPLACE));
            String durableAccountNumber = response.jsonPath().getString("accountDetails.find{it.workplaceAccountDetail.accountId.accountNumer=='"
         + accNumber + "'}.workplaceAccountDetail.durableAccountNumber");
            if(durableAccountNumber != null) {
                response.then()
                        .body("accountDetails.find{it.workplaceAccountDetail.accountId.accountNumber ==' "
                            + accNumber + "'}.workplaceAccountDetail.durableAccountNumber", equalTo(accNumber));

            }
        } else {
            // Validate accountNumber == planNumber when PRDC flag is false
            response.then()
                    .body("accountDetails.find{it.workplaceAccountDetail.planId.planNumber=='" + planNumber
                            + "'}.workplaceAccountDetail.accountDetail.accountId.accountNumber", equalTo(planNumber));
        }
        // Always check for durableAccountNumber presence
        if (!checkDurableAccountNumberPresence(response)) {
            response.then()
                    .body("responseDiagnostic.find { it.message.contains('Durable account number not found for plan number : " + planNumber + "') }.resultCode", equalTo(true));

        }
    }

    private Boolean checkDurableAccountNumberPresence(Response response) {
        List<Map<String, Object>> accountDetails = response.jsonPath().getList("accountDetails");

        for (Map<String, Object> account : accountDetails) {
            Object workplaceAccountDetailObj = account.get("workplaceAccountDetail");
            if(!(workplaceAccountDetailObj instanceof Map)) {
                return false;
            }
            Map<?, ?> workplaceDetail = (Map<?, ?>) workplaceAccountDetailObj;
            if (workplaceDetail.get("durableAccountNumber") == null) {
                return false; // durableAccountNumber is missing
            }
        }
        return true; // all accounts have durableAccountNumber
    }

    private void validateCompositeAccountResponse(Response response, Boolean returnPrdcAccounts) {
        Object rawAccounts = response.jsonPath().get("accounts");
        if (!(rawAccounts instanceof List)) return;
        List<?> accountsList = (List<?>) rawAccounts;
        for (Object rawAccount : accountsList) {
            if (!(rawAccount instanceof Map)) continue;
            Map<?, ?> account = (Map<?, ?>) rawAccount;
            Object accountObj = account.get("account");

            if (!(accountObj instanceof Map)) continue;
            Map<?, ?> accountInfo = (Map<?, ?>) accountObj;

            Object accountIdObj = accountInfo.get("accountId");
            if (!(accountIdObj instanceof Map)) continue;
            Map<?, ?> accountId = (Map<?, ?>) accountIdObj;
            String accountNumber = safeString(accountId.get("accountNumber"));

            Object detailsObj = account.get("details");
            if (!(detailsObj instanceof Map)) continue;
            Map<?, ?> details = (Map<?, ?>) detailsObj;

            Object workplaceObj = details.get("workplaceAccount");
            if (!(workplaceObj instanceof Map)) continue;
            Map<?, ?> workplaceDetail = (Map<?, ?>) workplaceObj;

            Object planIdObj = workplaceDetail.get("planId");
            if (!(planIdObj instanceof Map)) continue;
            Map<?, ?> planId = (Map<?, ?>) planIdObj;

            String planNumber = safeString(planId.get("planNumber"));
            String durableAccountNumber = safeString(workplaceDetail.get("durableAccountNumber"));

            if (returnPrdcAccounts) {
                // Validate durableAccountNumber is present and matches accountNumber
                 if (durableAccountNumber == null || durableAccountNumber.isEmpty()) {
                     response.then().body("responseDiagnostic.find { it.message.contains('Durable account number not found for plan number : " + planNumber + "') }.resultCode", equalTo(true));
                 } else {
                     response.then().body("accounts.find { it.account.accountId.accountNumber == '" + accountNumber + "' }.details.durableAccountNumber", Matchers.equalTo(accountNumber));
                 }
            } else {
                // Validate accountNumber equals planNumber
                if (planNumber != null) {
                    response.then().body("accounts.find { it.details.planId.planNumber == '" + planNumber + "' }.account.accountId.accountNumber", Matchers.equalTo(planNumber));
                }
            }
        }

    }
    private String safeString(Object obj) {
        return (obj instanceof String) ? (String) obj : null;
    }


}
