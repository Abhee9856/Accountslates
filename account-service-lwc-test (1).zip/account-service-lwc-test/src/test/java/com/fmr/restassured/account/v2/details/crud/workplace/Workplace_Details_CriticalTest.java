/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.details.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;
@Test(groups = {
		Tags.TAM})
public class Workplace_Details_CriticalTest extends PAPBaseServiceTest
{

    protected Workplace_Details_CriticalTest()
    {
	super(Services.Account);
    }

    /**
     * Instance to the p2 test data utility class
     */
    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private String ppid;

    private VelocityContext context;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Workplace_Details_CriticalTest.class.getSimpleName();

    private static final String fsreqid = logTrackingId;

    // Test data
    private String mid;//= "WorkplaceDetailsV2TestMid";

    private String accId;

    private String sourceSystem = AccountConstants.WORKPLACE;

    private String displayName;

    private String mnemonic;

    private String institutionName;

    private String asOfDate;

    private float value = 818.89f;

    private final float updatedValue = 426.85f;

    FilterableRequestSpecification frs = null;

    private static final String FEDERAL_TAX_WITHHOLDING_PCT = "federalTaxWithholdingPercent";

    private static final String STATE_TAX_WITHHOLDING_PCT = "stateTaxWithholdingPercent";

    private static final String WITHDRAWAL_START_DATE = "withdrawalEligibilityStartDate";

    private static final String WITHDRAWAL_END_DATE = "withdrawalEligibilityEndDate";

    private String originalOwnerBirthDate = "1960-11-30T00:00:00.000+0000";

    private String originalOwnerDeceasedDate = "2022-12-30T00:00:00.000+0000";

    private String tamName = "Short Term";

    private String originalOwnerSpouse = "false";

    private String accNum;

    private String tamAssetClass = "TOTAL_EQUITY";

    private String assetClass = "TOTAL_EQUITY";

    private float netPercentage = 1.0f;

    private float netPercentageUpdated = 0.9f;

    private String assetClass1 = "BOND";

    private float netPercentage1 = 0.5f;

    private float netPercentageUpdated1 = 0.2f;

    private String assetClass2 = "CASH";

    private float netPercentage2 = 0.3f;

    private float netPercentageUpdated2 = 0.8f;

    private String assetClass3 = "OTHER";

    private float netPercentage3 = 0.4f;

    private float netPercentageUpdated3 = 0.7f;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	p2TestDataUtil = new TestDataUtil();

	final String oAuth = AccountUtil.getOauthToken();
	accountsCommonTestData =
			TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_WORKPLACE, oAuth);
	accountsCommonTestData =
			TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_WORKPLACE, oAuth);
	mid = accountsCommonTestData.getMid();
	accountsCommonTestData.setMid(mid);
	DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


	ppid = Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth);

	// Data setup
	accountsCommonTestData.setPpid(ppid);

	// Endpoint setup
	setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

	accountsCommonTestData.set(FEDERAL_TAX_WITHHOLDING_PCT, "0.8");
	accountsCommonTestData.set(STATE_TAX_WITHHOLDING_PCT, "0.8");
	accountsCommonTestData.set(WITHDRAWAL_START_DATE, "2020-01-01T00:00:00.000+0000");
	accountsCommonTestData.set(WITHDRAWAL_END_DATE, "2020-01-01T00:00:00.000+0000");

	request.given().header(new Header("user-poe", AccountConstants.RETAIL))
			.header(new Header("user-mid", accountsCommonTestData.getMid()))
			.header(new Header("user-sid", accountsCommonTestData.getSid()))
			.header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
			.header(new Header("excludeExternalDataSources", "false"));

	// Populate request variables
	context = new VelocityContext();
	context.put("source", sourceSystem);

    }

    /**
     * Tests that account data is brought back for Workplace account.
     * <p>
     * Version V2
     */
    @Test
    public void getWorkplaceAccountInfo()
    {

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

	// Call Account service v2
	response = request.post(AccountsPaths.GET_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200).body("accountList[0].accountId.sourceSystem",
			equalTo(sourceSystem));
	accNum = response.path("accountList[0].accountId.accountNumber");
	displayName = response.path("accountList.find{it.accountId.accountNumber=='" + accNum + "'}.displayName");
	institutionName =
			response.path("accountList.find{it.accountId.accountNumber=='" + accNum + "'}.institutionName");
	asOfDate = response.path("accountList.find{it.accountId.accountNumber=='" + accNum
			+ "'}.sourceMarketValue.asOfDate");
	mnemonic = response.path("accountList.find{it.accountId.accountNumber=='" + accNum + "'}.regCode.mnemonic");

    }

    /**
     * Creates a new Workplace account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount()
    {

	context.put("accountNumber", accNum);
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("mnemonic", mnemonic);
	context.put("value", value);
	context.put("source", sourceSystem);
	context.put("displayName", displayName);
	context.put("institutionName", institutionName);
	context.put("asOfDate", asOfDate);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

	// Call Account service
	response = request.post(AccountsPaths.CREATE_ACCOUNT_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
			"accountList[0].accountId.accountNumber", equalTo(accNum),
			"accountList[0].accountId.sourceSystem", equalTo("WORKPLACE"));

	accId = response.path("accountList[0].accountId.id");

    }

    /**
     * Create Workplace account Details Request.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void createAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", value);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "workplaceAccountDetail");
	context.put("_type", "workplaceAccountDetail");
	context.put("tamAssetClass", tamAssetClass);
	context.put("originalOwnerBirthDate", originalOwnerBirthDate);
	context.put("originalOwnerSpouse", "false");
	context.put("originalOwnerDeceasedDate", originalOwnerDeceasedDate);
	context.put(FEDERAL_TAX_WITHHOLDING_PCT, accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT));
	context.put(STATE_TAX_WITHHOLDING_PCT, accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT));
	context.put(WITHDRAWAL_START_DATE, accountsCommonTestData.get(WITHDRAWAL_START_DATE));
	context.put(WITHDRAWAL_END_DATE, accountsCommonTestData.get(WITHDRAWAL_END_DATE));
	context.put("assetClass", assetClass);
	context.put("netPercentage", netPercentage);
	context.put("assetClass1", assetClass1);
	context.put("netPercentage1", netPercentage1);
	context.put("assetClass2", assetClass2);
	context.put("netPercentage2", netPercentage2);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentage3);
	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_V2_TEMPLATE));

	// Call Account service
	response =
			request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum + "'}.workplaceAccountDetail.accountDetail.fidelityAccount",
					equalTo(true),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo("WORKPLACE"),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum + "'}.workplaceAccountDetail.planId.planNumber",
					equalTo(accNum),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					equalTo(assetClass),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					equalTo(netPercentage),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					equalTo(assetClass1),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					equalTo(netPercentage1),

					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					equalTo(assetClass2),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					equalTo(netPercentage2),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					equalTo(assetClass3),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					equalTo(netPercentage3));
    }

    /**
     * Validate the Workplace account details after create.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate()
    {

	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);

	// Generate request body
	request
			.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum + "'}.workplaceAccountDetail.accountDetail.fidelityAccount",
					equalTo(true),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo("WORKPLACE"),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum + "'}.workplaceAccountDetail.planId.planNumber",
					equalTo(accNum),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					equalTo(assetClass),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					equalTo(netPercentage),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					equalTo(assetClass1),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					equalTo(netPercentage1),

					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					equalTo(assetClass2),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					equalTo(netPercentage2),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					equalTo(assetClass3),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					equalTo(netPercentage3));
    }

    /**
     * Update the account details for Workplace account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", updatedValue);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "WorkplaceAccountDetails");
	context.put("_type", "WorkplaceAccountDetails");
	context.put("assetClass", assetClass);
	context.put("netPercentage", netPercentageUpdated);
	context.put("assetClass1", assetClass1);
	context.put("netPercentage1", netPercentageUpdated1);
	context.put("assetClass2", assetClass2);
	context.put("netPercentage2", netPercentageUpdated2);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentageUpdated3);
	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_UPDATE_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V2);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum + "'}.workplaceAccountDetail.accountDetail.fidelityAccount",
					equalTo(true),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo("WORKPLACE"),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum + "'}.workplaceAccountDetail.planId.planNumber",
					equalTo(accNum),

					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.assetClass",
					equalTo(assetClass),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage",
					equalTo(netPercentage),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.assetClass",
					equalTo(assetClass1),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass1 + "'}.netPercentage",
					equalTo(netPercentage1),

					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.assetClass",
					equalTo(assetClass2),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass2 + "'}.netPercentage",
					equalTo(netPercentage2),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.assetClass",
					equalTo(assetClass3),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.id=='"
							+ accId
							+ "'}.workplaceAccountDetail.accountDetail.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage",
					equalTo(netPercentage3));
    }

    /**
     * Validate the updated Workplace account details.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate()
    {

	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);

	// Generate request body
	request
			.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum + "'}.workplaceAccountDetail.accountDetail.fidelityAccount",
					equalTo(true),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.accountId.sourceSystem",
					equalTo("WORKPLACE"),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.targetAssetMixes[0].assetAllocation.allocation[0].assetClass",
					equalTo(tamAssetClass),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(FEDERAL_TAX_WITHHOLDING_PCT))),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum
							+ "'}.workplaceAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(Float.valueOf(accountsCommonTestData.get(STATE_TAX_WITHHOLDING_PCT))),
					"accountDetails.find{it.workplaceAccountDetail.accountDetail.accountId.accountNumber=='"
							+ accNum + "'}.workplaceAccountDetail.planId.planNumber",
					equalTo(accNum));
    }

    /**
     * Delete the Workplace account details.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteAccountDetails()
    {

	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", updatedValue);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "WorkplaceAccountDetails");
	context.put("_type", "WorkplaceAccountDetails");
	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_DELETE_V2_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
			"accountDetails[0].workplaceAccountDetail.accountDetail.accountId.sourceSystem",
			equalTo("WORKPLACE"), "accountDetails[0].workplaceAccountDetail.accountDetail.fidelityAccount",
			equalTo(true), "accountDetails[0].workplaceAccountDetail.accountDetail.accountId.id",
			Matchers.notNullValue());

    }

    /**
     * Validate the workplace account was deleted.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "deleteAccountDetails")
    public void getDetailsAfterDelete()
    {
	// context.put("externalDataSources", "true");
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_V2_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
			"accountDetails[0].workplaceAccountDetail.accountDetail.accountId.sourceSystem",
			equalTo("WORKPLACE"),
			"accountDetails[0].workplaceAccountDetail.accountDetail.fidelityAccount", equalTo(true),
			"accountDetails[0].workplaceAccountDetail.accountDetail.accountId.id", Matchers.notNullValue());

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	p2TestDataUtil.closeSQLiteConnection();
    }

}