/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.get.fili.regcode;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import org.apache.commons.collections.CollectionUtils;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.config.HeaderConfig.headerConfig;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.equalTo;

/**
 * Tests for v2/account/get operation for FILI accounts using DataProvider (for handling multiiple regCodes).
 *
 * @author a653510
 */
@Test(groups = {"pipeline", "fili", "get", "v2"})
public class FiliRegCodeGetV2 extends PAPBaseServiceTest {

    protected FiliRegCodeGetV2() {
        super(Services.Account);
    }

    // Data setup
    private VelocityContext context;

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String oAuth;

    private String accNumber;

    private String maskedAccNumber;

    private String displayName;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {

        this.oAuth = AccountUtil.getOauthToken();
        this.testDataUtil = new TestDataUtil();
        this.setDefaultRequestHeaders(this.oAuth);
        this.request.given().header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("log-tracking-id", "AP136091"))
                .header(new Header("excludeExternalDataSources", "false"));
        this.request.given().
                config(RestAssured.config()
                        .headerConfig(headerConfig().overwriteHeadersWithName(
                                "user-fili-lid",
                                "Content-Type")));
    }

    /**
     * Test for getting Retail Accounts using data provider.
     * <p>
     * Version V1
     */
    @Test(dataProvider = "getFiliRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
    public void getFiliRegCodeData(final AccountRegCodeTestData data) {

        request.given()
                .header(new Header("user-fili-lid", data.getSsn()));

        this.context = new VelocityContext();
        this.context.put("mnemonicFilter", data.getRegCode1());
        this.context.put("mnemonicFilter2", data.getRegCode2());
        this.context.put("mnemonicFilter3", data.getRegCode3());
        this.context.put("source", data.getSrcFilter());

        this.request = this.request
                .body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        this.request.log().uri();

        this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

        if (CollectionUtils.isNotEmpty(response.path("accountList"))
                && (response.jsonPath().getList("accountList").size() > 0)) {

            accNumber = response.path("accountList[0].accountId.accountNumber");
            maskedAccNumber = TestDataUtil.getMaskedAccountNumber(accNumber);

            displayName = response.path("accountList[0].nickName") != null ?
                    response.path("accountList[0].nickName") + maskedAccNumber : maskedAccNumber;

            response.then().body("accountList[0].accountId", notNullValue())
                    .body("accountList[0].accountId.owner.id", notNullValue())
                    .body("accountList[0].accountId.accountNumber", notNullValue())
                    .body("accountList[0].regCode.mnemonic", Matchers
                            .isOneOf(new String[]{data.getRegCode1(), data.getRegCode2(), data.getRegCode3()}))
                    .body("accountList[0].displayName", equalTo(displayName));
        }

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        this.testDataUtil.closeSQLiteConnection();
    }

}
