/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.get.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.Matchers.empty;

/**
 * Tests Account composite/get operation for a Workplace account for PRDC account numbers, with allPlans=true.
 * PFCP-18182
 *
 * @author a608077
 */
@Test(groups = {
		Tags.REGRESSION,
		Tags.WORKPLACE,
		Tags.COMPOSITE,
		Tags.V2,
		Tags.PRDC_DATA})
public class WP_Get_Composite_v2_with_AllPlans_PRDC extends PAPBaseServiceTest
{

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private TestDataUtil testDataUtil;

	private final String oAuth = AccountUtil.getOauthToken();

	//Context
	private final VelocityContext context = new VelocityContext();

	private static final String LOG_TRACKING_ID = WP_Get_Composite_v2_with_AllPlans_PRDC.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	protected WP_Get_Composite_v2_with_AllPlans_PRDC()
	{
		super(Services.Account);
	}

	/**
	 * Initialization method used to:
	 * 1. Get the default SSN and use it to retrieve the MID.
	 * 2. Set the Base URI
	 * 3. Get the account service operation paths.
	 * 4. Build the request header (with OAuth token).
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{
		testDataUtil = new TestDataUtil();

		// Data setup
		AccountsCommonTestData accountsCommonTestData =
				TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Workplace 2",
						oAuth);

		this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
				FSREQID, oAuth);

		DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


		accountsCommonTestData.setPpid(
				Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));
		this.request.given()
				.header(new Header("user-poe", AccountConstants.RETAIL))
				.header(new Header("user-mid", accountsCommonTestData.getMid()))
				.header(new Header("user-sid", accountsCommonTestData.getSid()))
				.header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
				.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
				.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
				.header(new Header("allPlans", "true"))
				.header(new Header("return-prdc-accounts", "true"));

	}

	/**
	 * Get Workplace account info from the backend. Save the account number.
	 */
	@Test
	public void getWorkplaceAccountInfo()
	{
		// Generate request body
		context.put("source", AccountConstants.WORKPLACE);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accountList", not(anyOf(nullValue(), empty())))
				.body("accountList[0].accountId.accountNumber", containsString("DCA"));
	}

	/**
	 * Gets composite account and verifies there is content in the response. Version V2
	 */
	@Test(dependsOnMethods = "getWorkplaceAccountInfo")
	public void getCompositeAccountAfterCreate()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Make post request
		response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("accounts[0].account.accountId.accountNumber", containsString("DCA"));
	}

	@AfterClass(alwaysRun = true)
	public void closeDBConnections()
	{
		testDataUtil.closeSQLiteConnection();
	}
}

