/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.v1.composite.get.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.is;

/**
 * Tests Account Composite get(v1) operation for an account that returns positions
 * 
 * @author a725710
 */
@Test(groups = {Tags.RETAIL, Tags.COMPOSITE, Tags.V1})
public class Retail_Composite_Position_Get_v1 extends PAPBaseServiceTest
{

	protected Retail_Composite_Position_Get_v1()
	{
		super(Services.Account);
	}

	// Velocity Context
	private VelocityContext context;

	// Instance to the test data utility class
	private TestDataUtil testDataUtil;

	// Logging Details
	private static final String LOG_TRACKING_ID = Retail_Composite_Get_serviceModelCode.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private String acctRoot;

	private String sid;

	private static final String APP_NAME = "Advice and Planning Platform";

	private String internalAccountNumberDSS;

	public static final String acctSubTypeDescInt = "Brokerage General Investing Person";

	public static final String acctSubTypeDescExt = "External Digital Currency";

	public static final String acctTypeDSS = "Brokerage";

	private Response dssPositionResponse;

	private int portfolioPositionCount;

	private String ssn;

	private String mid;

	private FilterableRequestSpecification frs;

	private final String oAuth = AccountUtil.getOauthToken();

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
		testDataUtil = new TestDataUtil();

		// Data setup
		final AccountsCommonTestData accountsCommonTestData =
		                TestDataUtil.populateRegressionTestData("account_positions_get_Retail_100", oAuth);

		accountsCommonTestData.setMid(accountsCommonTestData.getMid());
		// Set default REST header with authorization token
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
		                FSREQID, oAuth);
		ssn = accountsCommonTestData.getSsn();
		mid = accountsCommonTestData.getMid();

		// Data cleanup
		DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuth,
		                "true");

		accountsCommonTestData.setPpid(
		                Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

		// Populate common variables for tests into context
		context = new VelocityContext();
		context.put("retailLid", accountsCommonTestData.getSsn());
		context.put("mid", accountsCommonTestData.getMid());
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("source", "RETAIL");
	}

	/**
	 * Get composite account info
	 */
	@Test(dependsOnMethods = "getDSS_AccountPositions_V2")
	public void getComposite()
	{
		// Set Account Headers
		frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
		                FSREQID, oAuth);
		setRequestHeadersForAccount();

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Call Account service
		response = request.log().all().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("accounts",
				Matchers.not(Matchers.empty()));
		
		acctRoot = "accounts.find{it.account.accountId.accountNumber=='" + internalAccountNumberDSS + "'}.";
		for (int i = 0; i < portfolioPositionCount; i++)
		{
			if (!(dssPositionResponse
			                .path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i
			                                + "].securityType")).toString().equals("Core"))
			{
				Float quantity = dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].quantity");
				Float endOfQuantity = dssPositionResponse.path("position.acctDetails.acctDetail[0].positionDetails.positionDetail[" + i + "].endOfDaySettledShareQuantity");
				Float unsettledQuantity = quantity - endOfQuantity;
				Assert.assertEquals(response
				                .path(acctRoot + "positions.position[" + i + "].unsettledQuantity"), unsettledQuantity);
			}
		}
	}

	/**
	 * Test to get the DSS v2
	 * <p>
	 * Version V2
	 */
	@Test
	public void getDSS_V2()
	{
		// Set DSS Headers
		frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeadersForDSS();

		// Generate request body
		context.put("acctCategory", "Brokerage");

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

		request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
		response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)));
		internalAccountNumberDSS = response
		                .path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescInt + "'}.acctNum");
	}

	/**
	 * Test to get the DSS account positions v2
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "getDSS_V2")
	public void getDSS_AccountPositions_V2()
	{
		// Generate request body
		context.put("returnAvailabilityStatus", "true");
		context.put("returnAccountGainLossDetail", "true");
		context.put("returnPositionMarketValDetail", "true");
		context.put("accountNumber", internalAccountNumberDSS);
		context.put("acctType", acctTypeDSS);

		this.request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_POSITION_V2));

		dssPositionResponse = this.request.post(AccountConstants.DSS_ACCOUNT_POSITIONS_V2_PATH);
		portfolioPositionCount = dssPositionResponse.path("position.portfolioDetail.portfolioPositionCount");

		// Assert on response
		dssPositionResponse.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
		                .body("position.acctDetails.acctDetail", not(emptyArray()))
		                .body("position.acctDetails.acctDetail[0].acctNum",
		                                CoreMatchers.equalTo(internalAccountNumberDSS));
	}

	/**
	 * Setting default headers for DSS Services
	 */
	private void setDefaultRequestHeadersForDSS()
	{
		this.request.given().header(new Header("AppId", "AP106532")).header(new Header("fsreqid", FSREQID))
		                .header(new Header("Authorization", oAuth)).header(new Header("AppName", APP_NAME))
		                .header(new Header("rtazlid", this.ssn))
		                .header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
		                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
		                .header(new Header("FACMC", "MID=" + this.mid))
		                .header(new Header("FACFC", "SESSION_KEY=1"))
		                .header(new Header("Content-Type", "application/json"));
	}

	/**
	 * Setting headers for Account Service
	 */
	private void setRequestHeadersForAccount()
	{
		// Account headers setup
		this.request.given().header(new Header("user-poe", AccountConstants.RETAIL))
		                .header(new Header("user-mid", mid)).header(new Header("user-retail-lid", ssn))
		                .header(new Header("excludeExternalDataSources", "false"))
		                .header(new Header("realTimeData", "true")).header(new Header("mauiCache", "no"))
		                .header(new Header("user-digital-lid", ssn));
	}

	@AfterClass(alwaysRun = true)
	public void closeDBConnections()
	{
		testDataUtil.closeSQLiteConnection();
	}

}
