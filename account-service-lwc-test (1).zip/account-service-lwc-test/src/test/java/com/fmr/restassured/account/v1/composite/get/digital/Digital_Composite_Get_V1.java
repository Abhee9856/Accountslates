/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.get.digital;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.is;

import com.fmr.restassured.account.helpers.Tags;

/**
 * Tests for Digital Composite Account
 *
 * @author a631781
 */

@Test(groups = {Tags.REGRESSION, Tags.DIGITAL, Tags.V1})

public class Digital_Composite_Get_V1 extends PAPBaseServiceTest {

    protected Digital_Composite_Get_V1() {
        super(Services.Account);
    }

    private static final String sourceSystem = "DIGITAL";

    public static final String ACCOUNT_CATEGORY = "InternalDigital, ExternalDigital";
    public static final String acctSubTypeDescInt = "Internal Digital Currency";
    public static final String acctSubTypeDescExt = "External Digital Currency";

    private String ssn;
    private String mid;
    private String sid;
    private String internalAccountNumber;
    private String externalAccountNumber;
    private String internalAccountNumberDSS;
    private String externalAccountNumberDSS;
    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Digital_Composite_Get_V1.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String APP_NAME = "Advice and Planning Platform";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private Response accountResponse;
    private final String oAuth = AccountUtil.getOauthToken();
    private TestDataUtil testDataUtil;
    private VelocityContext context;
    private FilterableRequestSpecification frs;

    private String linkedAccountsIntDSS;
    private String linkedAccountsExtDSS;

    private String sourceSystemInt;
    private String mnemonicInt;
    private String regCodeSourceSystemInt;
    private String linkedAccountsInt;
    private Boolean externalDigitalAccountInt;
    private String sourceSystemExt;
    private String mnemonicExt;
    private String regCodeSourceSystemExt;
    private String linkedAccountsExt;
    private Boolean externalDigitalAccountExt;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("account_digital", oAuth);

        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid().replace("-", "");

        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ssn = accountsCommonTestData.getSsn();
        testDataUtil = new TestDataUtil();

        // Populate request context with user IDs
        context = new VelocityContext();

        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Tests that account data is brought back for Digital account.
     * <p>
     * Version V1
     */
    @Test
    public void getDigitalAccountInfo() {
        // Generate request body
        setRequestHeadersForAccount();
        context.put("source", sourceSystem);
        context.put("mid", mid);
        context.put("excludeExternalDataSources", "false");
        context.put("retailLid", ssn);
        context.put("digitalLid", ssn);
        context.put("pointOfEntry", "RETAIL");
        context.put("role", "FidCust");
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);
        request =
                request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Call Account service
        accountResponse = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        accountResponse.then().statusCode(200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(mid))
                .body("accounts", not(empty()));

    }

    /**
     * Test to get the DSS digital account
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDigitalAccountInfo"})
    public void getDSS_V2() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);
        context.put("returnPortfolioGainLossBalanceDetail", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        // Assert on response
        response.then().statusCode(anyOf(is(200), is(206)));
        internalAccountNumberDSS = response.path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescInt + "'}.acctNum");
        externalAccountNumberDSS = response.path("acctDetails.find{it.acctSubTypeDesc=='" + acctSubTypeDescExt + "'}.acctNum");
        linkedAccountsIntDSS = response.path("acctDetails.find{it.acctNum=='" + internalAccountNumberDSS + "'}.linkedAcctDetails[0].acctNum");
        linkedAccountsExtDSS = response.path("acctDetails.find{it.acctNum=='" + externalAccountNumberDSS + "'}.linkedAcctDetails[0].acctNum");

    }

    /**
     * Test to validate Digital Composite Account
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void validateResponse() {
        //Digital Account elements
        internalAccountNumber = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + internalAccountNumberDSS + "'}.account.accountId.accountNumber");
        sourceSystemInt = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + internalAccountNumber + "'}.account.accountId.sourceSystem");
        mnemonicInt = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + internalAccountNumber + "'}.account.regCode.mnemonic");
        regCodeSourceSystemInt = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + internalAccountNumber + "'}.account.regCode.sourceSystem");
        linkedAccountsInt = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + internalAccountNumber + "'}.details.linkedAccounts[0].accountNumber");
        externalDigitalAccountInt = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + internalAccountNumber + "'}.account.externalDigitalAccount");

        externalAccountNumber = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + externalAccountNumberDSS + "'}.account.accountId.accountNumber");
        sourceSystemExt = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + externalAccountNumber + "'}.account.accountId.sourceSystem");
        mnemonicExt = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + externalAccountNumber + "'}.account.regCode.mnemonic");
        regCodeSourceSystemExt = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + externalAccountNumber + "'}.account.regCode.sourceSystem");
        linkedAccountsExt = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + internalAccountNumber + "'}.details.linkedAccounts[0].accountNumber");
        externalDigitalAccountExt = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + externalAccountNumber + "'}.account.externalDigitalAccount");

        //Validating Account Digital elements
        Assert.assertEquals(internalAccountNumber, internalAccountNumberDSS);
        Assert.assertEquals(sourceSystemInt, sourceSystem);
        Assert.assertEquals(mnemonicInt, "I");
        Assert.assertEquals(regCodeSourceSystemInt, sourceSystem);
        Assert.assertEquals(externalDigitalAccountInt, false);
        if (linkedAccountsIntDSS != null) {
            Assert.assertEquals(linkedAccountsInt, linkedAccountsIntDSS);
        }
        if (externalAccountNumberDSS != null) {
            Assert.assertEquals(externalAccountNumber, externalAccountNumberDSS);
            Assert.assertEquals(mnemonicExt, "UNKN");
            Assert.assertEquals(regCodeSourceSystemExt, sourceSystem);
            Assert.assertEquals(externalDigitalAccountExt, true);
            if (linkedAccountsExtDSS != null) {
                Assert.assertEquals(linkedAccountsExt, linkedAccountsExtDSS);
            }
        }
    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS() {
        this.request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", this.ssn))
                .header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
                .header(new Header("FACMC", "MID=" + this.mid))
                .header(new Header("FACFC", "SESSION_KEY=1"))
                .header(new Header("Content-Type", "application/json"));

    }

    /**
     * Setting headers for Account Service
     */
    private void setRequestHeadersForAccount() {
        // Account headers setup
        this.request.given()
                .header(new Header("realTimeData", "true"))
                .header(new Header("mauiCache", "no"));
    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections() {
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        testDataUtil.closeSQLiteConnection();
    }
}