package com.fmr.restassured.account.v2.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.MatcherAssert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

import static io.restassured.config.HeaderConfig.headerConfig;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.empty;

public class Retail_Composite_V2_HiddenAccount extends PAPBaseServiceTest {

    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Retail_Composite_V2_HiddenAccount.class);

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    /**
     * Global variable holding retailAccount information
     */
    private HashMap<String, String> retailAccountMap;

    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountTestData;

    private String accNum;

    private String acctRoot;

    private static final String LOG_TRACKING_ID = Retail_Composite_V2_HiddenAccount.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private VelocityContext context;

    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
    private final float netPercentage_T_ALTERNATIVE = 0.8f;
    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
    private final float netPercentage_PEA = 0.4f;
    private final float netPercentage_Updated_PEA = 0.2f;
    private final float netPercentage_PCA = 0.2f;
    private final float netPercentage_Updated_PCA = 0.3f;
    private final float netPercentage_PRAA = 0.2f;
    private final float netPercentage_Updated_PRAA = 0.1f;

    /**
     * Constructor
     */
    protected Retail_Composite_V2_HiddenAccount()
    {
        super(Services.Account);
    }

    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass()
    {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        retailAccountMap = new HashMap<>();

        request.given().
                config(RestAssured.config().headerConfig(headerConfig().overwriteHeadersWithName("return-hidden-accounts"
                        , "Content-Type")));

        accountTestData = TestDataUtil.populateRegressionTestData("retail_is_hidden_account", oAuth);
        retailAccountMap = getRetailAccountInformationV2(accountTestData, oAuth);

        DataCleanup.deleteCustomerDataFromCP("mid", accountTestData.getMid(), oAuth,"true");
        final String ppid = Identity.createHouseholdIdentity(accountTestData.getMid(), oAuth);
        accountTestData.setPpid(ppid);

        context = new VelocityContext();
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init()
    {
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"));
    }

    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates an empty account list when calling get account composite retail before creation of an
     * account
     */
    @Test
    public void getCompositeAccountRetailV2BeforeCreate()
    {
        if (retailAccountMap.isEmpty())
        {
            throw new SkipException(
                    "'getCompositeAccountRetailV2BeforeCreate' test scenario cannot run due to failure to retrieve "
                            + "retail account information!");
        }

        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", retailAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"))
                .header(new Header("return-hidden-accounts", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after create
     */
    @Test(dependsOnMethods = "getCompositeAccountRetailV2BeforeCreate")
    public void createCompositeAccountRetailV2()
    {
        accNum = retailAccountMap.get("accountNumber");
        context.put("accountNumber", accNum);
        context.put("source", retailAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", retailAccountMap.get("sourceSystem"));
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "111111.11");
        context.put("asdr", false);
        context.put("isProductSuitable", "false");
        context.put("emergencyFundAmountValue", "111111.11");
        context.put("contribFreq", "YEARLY");
        context.put("contribValue", "500");
        context.put("contributionTaxType", "POST_TAX");
        context.put("contributionType", "CATCHUP");
        context.put("contributor", "EMPLOYER");
        context.put("contribBasisTypeCd", "BASE");
        context.put("contribFreq2", "BIMONTHLY");
        context.put("contribValue2", "900");
        context.put("contributionTaxType2", "AGGREGATE");
        context.put("contributionType2", "REGULAR");
        context.put("contributor2", "INDIVIDUAL");
        context.put("contribBasisTypeCd2", "BASEBONUS");
        context.put("withdrawAmount", "500");
        context.put("withdrawFreq", "HOURLY");
        context.put("riskTolerance", 2);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", 2055);
        context.put("withdrawalEndYear", 2085);
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.177);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.0f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_PRAA);
        context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
        context.put("equityPercent", 0.35);
        context.put("originalOwnerBirthDate", "1958-11-09");
        context.put("originalOwnerDeceasedDate", "2022-11-09");
        context.put("withdrawalEligibilityStartDate", "2022-11-09");
        context.put("withdrawalEligibilityEndDate", "2052-11-09");
        context.put("originalOwnerSpouse", "false");
        context.put("federalTaxWithholding", 0.15);
        context.put("stateTaxWithholding", 0.05);
        context.put("isBackdoorRoth", true);

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";

        response = request.log().all().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(retailAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        retailAccountMap.get("sourceMarketAmountValue"))));

        accountTestData
                .setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
    }

    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after create (get)
     */
    @Test(dependsOnMethods = "createCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterCreate()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", retailAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(retailAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        retailAccountMap.get("sourceMarketAmountValue"))));

    }

    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "getCompositeAccountRetailV2AfterCreate")
    public void updateCompositeAccountRetailV2()
    {
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", retailAccountMap.get("accountNumber"));
        context.put("source", retailAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", retailAccountMap.get("sourceSystem"));
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "211111.11");
        context.put("emergencyFundAmountValue", "211111.11");
        context.put("contribFreq", "MONTHLY");
        context.put("contribValue", "600");
        context.put("withdrawAmount", "800");
        context.put("withdrawFreq", "HOURLY");
        context.put("isProductSuitable", "true");
        context.put("riskTolerance", 3);
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_25_AND_50");
        context.put("withdrawalStartYear", 2056);
        context.put("withdrawalEndYear", 2086);
        context.put("contribFreq", "MONTHLY");
        context.put("contribValue", "600");
        context.put("contribFreq2", "WEEKLY");
        context.put("contribValue2", "700");
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.5);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0.4);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.1f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.3f);
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("equityPercent", 0.25);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_Updated_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_Updated_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
        context.put("originalOwnerBirthDate", "1958-12-09");
        context.put("originalOwnerDeceasedDate", "2022-12-09");
        context.put("withdrawalEligibilityStartDate", "2022-12-09");
        context.put("withdrawalEligibilityEndDate", "2052-12-09");
        context.put("originalOwnerSpouse", true);
        context.put("federalTaxWithholding", 0.16);
        context.put("stateTaxWithholding", 0.06);
        context.put("isBackdoorRoth", false);


        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()));

        request.log().ifValidationFails().body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(retailAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        retailAccountMap.get("sourceMarketAmountValue"))));

    }

    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after an update (get)
     */
    @Test(dependsOnMethods = "updateCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterUpdate()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", retailAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(retailAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        retailAccountMap.get("sourceMarketAmountValue"))));

    }

    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates the account composite response after a delete
     */
    @Test(dependsOnMethods = "getCompositeAccountRetailV2AfterUpdate")
    public void deleteCompositeAccountRetailV2()
    {
        final VelocityContext context = new VelocityContext();
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", retailAccountMap.get("accountNumber"));
        context.put("source", retailAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = response.jsonPath().getString("$");
        MatcherAssert.assertThat(emptyResponse, equalTo("[:]"));
    }

    /**
     * JIRA Item: PFCP-3077 RA Regression Conversion: accountComposite CRUD Retail\Manual\Workplace Accounts V1&V2
     * <p>
     * Description: Validates an empty account list when calling get account composite retail after delete
     */
    @Test(dependsOnMethods = "deleteCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterDelete()
    {
        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", retailAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown()
    {
        testDataUtil.closeSQLiteConnection();
    }

    /**
     * Returns the response of retrieving a retail account
     *
     * @param accountsCommonTestData test data
     * @return retailAccountMap
     */
    private static HashMap<String, String> getRetailAccountInformationV2(
            final AccountsCommonTestData accountsCommonTestData,
            final String oAuth)
    {
        final VelocityContext context = new VelocityContext();
        context.put("source", "RETAIL");


        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();

        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);

        request.header(new Header("user-mid", accountsCommonTestData.getMid())).header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("return-hidden-accounts", "true"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        final Response response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
        response.then().log().ifValidationFails()
                        .body("accountList", not(anyOf(nullValue(),empty())));
        if (response.statusCode() != HTTPStatusCodes.STATUS_200)
        {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));

            return null;
        }

        final JsonPath retailAccountJP = response.jsonPath();

        final HashMap<String, String> retailAccountMap = new HashMap<>();
        retailAccountMap.put("accountNumber",
                retailAccountJP.getString("accountList[0].accountId.accountNumber"));
        retailAccountMap.put("sourceSystem",
                retailAccountJP.getString("accountList[0].accountId.sourceSystem"));
        retailAccountMap.put("displayName", retailAccountJP.getString("accountList[0].displayName"));
        retailAccountMap.put("mnemonic", retailAccountJP.getString("accountList[0].regCode.mnemonic"));
        retailAccountMap.put("institutionName", retailAccountJP.getString("accountList[0].institutionName"));
        retailAccountMap.put("sourceMarketAmountValue",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
        retailAccountMap.put("sourceMarketAmountValueType",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        retailAccountMap.put("sourceMarketAmountCurrency",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        retailAccountMap.put("sourceMarketAsOfDate",
                retailAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));

        return retailAccountMap;
    }
}
