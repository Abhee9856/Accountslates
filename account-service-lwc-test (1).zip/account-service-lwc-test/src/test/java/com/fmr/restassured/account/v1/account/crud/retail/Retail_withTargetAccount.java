/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.crud.retail;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;

import io.restassured.response.Response;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

/**
 * Tests CRUD operations for Retail accounts with Target accounts against V1.
 *
 * @author a601767
 * a608077 Updated for Target Preferences
 * a609599 Updated for changes to productSubType
 * Updated by a608077 on 10/13/2021 to include changes for 'scenario-id' header(PFCP-6168)
 * Updated by a608077 on 08/26/2022 to include unknown funding amount changes(PFCP-9908)
 * Updated by a608077 on 10/17/2024 to update Validation for trustType and trustTypeInd(PFCP-17321)
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.ACCOUNT,
		Tags.V1, Tags.TAM,
		Tags.TARGET_ACCOUNT, "PFCP-3938", "PFCP-4608", "PFCP-7957"})

public class Retail_withTargetAccount extends PAPBaseServiceTest
{

	protected Retail_withTargetAccount()
	{
		super(Services.Account);
	}

	// Data setup
	private AccountsCommonTestData accountsCommonTestData;

	private VelocityContext context;

	private final float updatedValue = 426.85f;

	private final float fundingAccountAmount = 5.55f;

	private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";

	private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";

	private static final String TARGET_ACCOUNT_NAME = "NewTargetAccount";

	private static final String isProductSuitable = "true";

	private static final String isProductSuitableUpdate = "false";

	private static final String productSubType = "FIXED INCOME";

	private static final String updatedProductSubType = "EQUITY";

	private final float unknownAmount = 20.0f;

	private final float updatedUnknownAmount = 26.0f;

	private String mid;// = "RetailAccountV1TestMid";

	/**
	 * Instance to the test data utility class
	 */
	private TestDataUtil testDataUtil;

	/**
	 * Start and End years for targetAccountPreferences - both should be greater than the current year.
	 */
	int startYear = ZonedDateTime.now().plusYears(1).getYear();

	int updatedStartYear = ZonedDateTime.now().plusYears(5).getYear();

	int endYear = ZonedDateTime.now().plusYears(2).getYear();

	int updatedEndYear = ZonedDateTime.now().plusYears(6).getYear();

	private static final String LOG_TRACKING_ID = Retail_withTargetAccount.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();

		//Data Setup
		accountsCommonTestData = TestDataUtil.populateRegressionTestData("retail_critical_regcode", oAuth);
		this.testDataUtil = new TestDataUtil();

		this.mid = this.accountsCommonTestData.getMid();
		this.accountsCommonTestData.setMid(this.mid);

		//Set default REST header with authorization token
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
				FSREQID, oAuth);

		//Data cleanup
		DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


		//Set ppid
		accountsCommonTestData.setPpid(Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth));
		// Get/Create ScenarioId
		Response allScenarioIDs = Scenario.getAllScenarios(mid, oAuth);
		String scenarioId = allScenarioIDs.path("scenario[0].id").toString();
		if (scenarioId == null)
		{
			scenarioId = Scenario.createScenarioWithProductCode(mid, "IGE", "DEF", oAuth);
		}
		// Populate request variables
		context = new VelocityContext();
		context.put("mid", accountsCommonTestData.getMid());
		context.put("retailLid", accountsCommonTestData.getSsn());
		context.put("source", AccountConstants.RETAIL);
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("scenarioId", scenarioId);

	}

	/**
	 * Get retail account info from the backend. Save the account number.
	 */
	@Test
	public void getRetailAccountInfo()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200);

		Boolean resultCode = response.path("resultCode");
		Boolean dssResultCode =
				response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
		if (!resultCode)
		{
			Assert.assertEquals(dssResultCode, false);
		}
		response.then().log().ifValidationFails()
				.body("accountList", not(anyOf(nullValue(),empty())));

		accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
		accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
		accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
		accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
		accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
		accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
		accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));

	}

	/**
	 * Create the retail account.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "getRetailAccountInfo")
	public void createRetailAccount()
	{

		context.put("mnemonic", accountsCommonTestData.getMnemonic1());
		context.put("value", accountsCommonTestData.getValue1());
		context.put("source", accountsCommonTestData.getSourceSystem1());
		context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		context.put("institutionName", accountsCommonTestData.getInstitutionName1());
		context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CREATE_WITH_SCENARIO_ID_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true))
				.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
				.body("userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()))
				.body("accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("accountList[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("accountList[0].accountId.owner.relationship", equalTo("PRINCIPAL"))
				.body("accountList[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
				.body("accountList[0].regCode.mnemonic",
						equalTo(accountsCommonTestData.getMnemonic1()))
				.body("accountList[0].displayName", equalTo(accountsCommonTestData.getDisplayName1()))
				.body("accountList[0].institutionName",
						equalTo(accountsCommonTestData.getInstitutionName1()));

		// Gets and saves the CFP account ID
		accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
	}

	/**
	 * Create target account
	 */
	@Test(dependsOnMethods = "createRetailAccount")
	public void createTargetAccount()
	{
		context.remove("displayName");
		context.put("targetAccountSourceSystem", accountsCommonTestData.getSourceSystem1());
		context.put("targetAccountPpid", accountsCommonTestData.getPpid());
		context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
		context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
		context.put("fundingAccountValue", String.valueOf(fundingAccountAmount));
		context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
		context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
		context.put("category", "INVESTOR_SELECTED_STRATEGY");
		context.put("riskTolerance", "8");
		context.put("withdrawalStartYear", startYear);
		context.put("withdrawalEndYear", endYear);
		context.put("investmentObjectiveIA", "CONSERVATIVE");
		context.put("withdrawalNeeds", "CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5");
		context.put("anticipatedExpenses", "NOT_LIKELY");
		context.put("annualWithdrawalPercent", 0.2f);
		context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
		context.put("assetAllocation", 0.4);
		context.put("isProductSuitable", isProductSuitable);
		context.put("productSubType", productSubType);
		context.put("unknownAmount", String.valueOf(unknownAmount));
		context.put("irrevocableTrust", "false");
		context.put("trustType", null);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
				.body("userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()))
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].accountId.owner.relationship", equalTo("PRINCIPAL"))
				.body("targetAccounts[0].accountId.owner.id",
						equalTo(accountsCommonTestData.getPpid()))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].sourceMarketValue.amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].regCode.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption",
						equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
				.body("targetAccounts[0].isProductSuitable",
						equalTo(Boolean.valueOf(isProductSuitable)))
				.body("targetAccounts[0].productSubType", equalTo(productSubType))
				.body("targetAccounts[0].targetAccountPreferences.riskTolerance", equalTo(8))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalStartYear",
						equalTo(startYear))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalEndYear",
						equalTo(endYear))
				.body("targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
						equalTo("SELL_BETWEEN_51_AND_75"))
				.body("targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
						equalTo("CONSERVATIVE"))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
						equalTo("CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5"))
				.body("targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
						equalTo(0.2f))
				.body("targetAccounts[0].targetAccountPreferences.anticipatedExpenses",
						equalTo("NOT_LIKELY"))
				.body("targetAccounts[0].equityPercent", equalTo(0.5f))
				.body("targetAccounts[0].assetAllocation.allocation", hasSize(4))
				.body("targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.4f))
				.body("targetAccounts[0].annualContribution.value", equalTo(999.55f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
						equalTo(0.5f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
						equalTo(0.35f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
						equalTo(0.15f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.4f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
						equalTo(0.1f))
				.body("targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
						equalTo(0.45f))
				.body("targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
						equalTo(0.54f))
				.body("targetAccounts[0].targetAssetMixes[0].category",
						equalTo("INVESTOR_SELECTED_STRATEGY"))
				.body("targetAccounts[0].irrevocableTrust", equalTo(false))
				.body("targetAccounts[0].trustType", equalTo(null))
				.body("targetAccounts[0].targetAssetMixes[0].repositoryTamId", equalTo(3))
				.body("targetAccounts[0].targetAssetMixes[0].assetAllocationId", equalTo(50))
				.body("targetAccounts[0].targetAssetMixes[0].context", equalTo("Standard"));

		accountsCommonTestData
				.set(TARGET_ACCOUNT_NUMBER_KEY,
						response.path("targetAccounts[0].accountId.accountNumber"));
		accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
	}

	/**
	 * Validate the retail account.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "createTargetAccount")
	public void getRetailAccountAfterCreate()
	{

		// Exclude external data sources
		context.put("externalDataSources", "true");

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
				.body("userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()))
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].accountId.owner.relationship", equalTo("PRINCIPAL"))
				.body("targetAccounts[0].accountId.owner.id",
						equalTo(accountsCommonTestData.getPpid()))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].sourceMarketValue.amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].regCode.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption",
						equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
				.body("targetAccounts[0].isProductSuitable",
						equalTo(Boolean.valueOf(isProductSuitable)))
				.body("targetAccounts[0].productSubType", equalTo(productSubType))
				.body("targetAccounts[0].targetAccountPreferences.riskTolerance", equalTo(8))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalStartYear",
						equalTo(startYear))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalEndYear",
						equalTo(endYear))
				.body("targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
						equalTo("SELL_BETWEEN_51_AND_75"))
				.body("targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
						equalTo("CONSERVATIVE"))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
						equalTo("CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5"))
				.body("targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
						equalTo(0.2f))
				.body("targetAccounts[0].targetAccountPreferences.anticipatedExpenses",
						equalTo("NOT_LIKELY"))
				.body("targetAccounts[0].equityPercent", equalTo(0.5f))
				.body("targetAccounts[0].assetAllocation.allocation", hasSize(4))
				.body("targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.4f))
				.body("targetAccounts[0].annualContribution.value", equalTo(999.55f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
						equalTo(0.5f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
						equalTo(0.35f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
						equalTo(0.15f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.4f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
						equalTo(0.1f))
				.body("targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
						equalTo(0.45f))
				.body("targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
						equalTo(0.54f))
				.body("targetAccounts[0].targetAssetMixes[0].category",
						equalTo("INVESTOR_SELECTED_STRATEGY"))
				.body("targetAccounts[0].irrevocableTrust", equalTo(false))
				.body("targetAccounts[0].trustType", equalTo(null))
				.body("targetAccounts[0].targetAssetMixes[0].repositoryTamId", equalTo(3))
				.body("targetAccounts[0].targetAssetMixes[0].assetAllocationId", equalTo(50))
				.body("targetAccounts[0].targetAssetMixes[0].context", equalTo("Standard"));

	}

	/**
	 * Update target account
	 */
	@Test(dependsOnMethods = "getRetailAccountAfterCreate")
	public void updateTargetAccount()
	{

		context.put(TARGET_ACCOUNT_NUMBER_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
		context.put(TARGET_ACCOUNT_ID_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
		context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
		context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
		context.put("category", "FINAL");
		context.put("riskTolerance", "5");
		context.put("withdrawalStartYear", updatedStartYear);
		context.put("withdrawalEndYear", updatedEndYear);
		context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
		context.put("assetAllocation", 0.5);
		context.put("isProductSuitable", isProductSuitableUpdate);
		context.put("investmentObjectiveIA", "NONE");
		context.put("withdrawalNeeds", "TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6");
		context.put("anticipatedExpenses", "LIKELY");
		context.put("annualWithdrawalPercent", "0.002");
		context.put("productSubType", updatedProductSubType);
		context.put("unknownAmount", String.valueOf(updatedUnknownAmount));

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].accountId.owner.relationship", equalTo("PRINCIPAL"))
				.body("targetAccounts[0].accountId.owner.id",
						equalTo(accountsCommonTestData.getPpid()))
				.body("targetAccounts[0].sourceMarketValue.amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].regCode.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount",
						equalTo(updatedUnknownAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption",
						equalTo("MOVE_TO_MANAGED_ACCOUNT"))
				.body("targetAccounts[0].isProductSuitable",
						equalTo(Boolean.valueOf(isProductSuitableUpdate)))
				.body("targetAccounts[0].productSubType", equalTo(updatedProductSubType))
				.body("targetAccounts[0].irrevocableTrust", equalTo(false))
				.body("targetAccounts[0].trustType", equalTo(null))
				.body("targetAccounts[0].targetAccountPreferences.riskTolerance", equalTo(5))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalStartYear",
						equalTo(updatedStartYear))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalEndYear",
						equalTo(updatedEndYear))
				.body("targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
						equalTo("SELL_BETWEEN_51_AND_75"))
				.body("targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
						equalTo("NONE"))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
						equalTo("TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6"))
				.body("targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
						equalTo(0.002f))
				.body("targetAccounts[0].targetAccountPreferences.anticipatedExpenses",
						equalTo("LIKELY"))
				.body("targetAccounts[0].equityPercent", equalTo(0.5f))
				.body("targetAccounts[0].assetAllocation.allocation", hasSize(4))
				.body("targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.5f))
				.body("targetAccounts[0].annualContribution.value", equalTo(999.55f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
						equalTo(0.5f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
						equalTo(0.35f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
						equalTo(0.15f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.4f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
						equalTo(0.1f))
				.body("targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
						equalTo(0.45f))
				.body("targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
						equalTo(0.54f))
				.body("targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"))
				.body("targetAccounts[0].targetAssetMixes[0].repositoryTamId", equalTo(3))
				.body("targetAccounts[0].targetAssetMixes[0].assetAllocationId", equalTo(50))
				.body("targetAccounts[0].targetAssetMixes[0].context", equalTo("Standard"));

	}

	/**
	 * Update the account.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "updateTargetAccount")
	public void updateRetailAccount()
	{

		context.remove("displayName");
		// Change the amount of the account
		context.put("value", updatedValue);
		context.put("accId", accountsCommonTestData.getAccountId1());
		context.put("displayName", accountsCommonTestData.getDisplayName1());
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_UPDATE_WITH_SCENARIO_ID_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true))
				.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
				.body("userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()))
				.body("accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
				.body("accountList[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("accountList[0].accountId.owner.relationship", equalTo("PRINCIPAL"))
				.body("accountList[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()))
				.body("accountList[0].regCode.mnemonic",
						equalTo(accountsCommonTestData.getMnemonic1()))
				.body("accountList[0].displayName", equalTo(accountsCommonTestData.getDisplayName1()))
				.body("accountList[0].institutionName",
						equalTo(accountsCommonTestData.getInstitutionName1()))
				.body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue))
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].accountId.owner.relationship", equalTo("PRINCIPAL"))
				.body("targetAccounts[0].accountId.owner.id",
						equalTo(accountsCommonTestData.getPpid()))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].sourceMarketValue.amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].regCode.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption",
						equalTo("MOVE_TO_MANAGED_ACCOUNT"))
				.body("targetAccounts[0].isProductSuitable",
						equalTo(Boolean.valueOf(isProductSuitableUpdate)))
				.body("targetAccounts[0].productSubType", equalTo(updatedProductSubType))
				.body("targetAccounts[0].irrevocableTrust", equalTo(false))
				.body("targetAccounts[0].trustType", equalTo(null))
				.body("targetAccounts[0].equityPercent", equalTo(0.5f))
				.body("targetAccounts[0].annualContribution.value", equalTo(999.55f))
				.body("targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
						equalTo("SELL_BETWEEN_51_AND_75"))
				.body("targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
						equalTo("NONE"))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
						equalTo("TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6"))
				.body("targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
						equalTo(0.002f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
						equalTo(0.5f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
						equalTo(0.35f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
						equalTo(0.15f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.4f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
						equalTo(0.1f))
				.body("targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
						equalTo(0.45f))
				.body("targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
						equalTo(0.54f))
				.body("targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"))
				.body("targetAccounts[0].targetAssetMixes[0].repositoryTamId", equalTo(3))
				.body("targetAccounts[0].targetAssetMixes[0].assetAllocationId", equalTo(50))
				.body("targetAccounts[0].targetAssetMixes[0].context", equalTo("Standard"));

	}

	/**
	 * Validate the updated retail account.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "updateRetailAccount")
	public void getRetailAccountAfterUpdate()
	{

		context.put("externalDataSources", "true");
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true))
				.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
				.body("accountList[0].regCode.mnemonic",
						equalTo(accountsCommonTestData.getMnemonic1()))
				.body("accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
				.body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue))
				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].accountId.owner.relationship", equalTo("PRINCIPAL"))
				.body("targetAccounts[0].accountId.owner.id",
						equalTo(accountsCommonTestData.getPpid()))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].sourceMarketValue.amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].regCode.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].fundingAccounts[0].unknownAmount",
						equalTo(updatedUnknownAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption",
						equalTo("MOVE_TO_MANAGED_ACCOUNT"))
				.body("targetAccounts[0].isProductSuitable",
						equalTo(Boolean.valueOf(isProductSuitableUpdate)))
				.body("targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
						equalTo("SELL_BETWEEN_51_AND_75"))
				.body("targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
						equalTo("NONE"))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
						equalTo("TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6"))
				.body("targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
						equalTo(0.002f))
				.body("targetAccounts[0].productSubType", equalTo(updatedProductSubType))
				.body("targetAccounts[0].irrevocableTrust", equalTo(false))
				.body("targetAccounts[0].trustType", equalTo(null))
				.body("targetAccounts[0].equityPercent", equalTo(0.5f))
				.body("targetAccounts[0].annualContribution.value", equalTo(999.55f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
						equalTo(0.5f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
						equalTo(0.35f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
						equalTo(0.15f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.4f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
						equalTo(0.1f))
				.body("targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
						equalTo(0.45f))
				.body("targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
						equalTo(0.54f))
				.body("targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"))
				.body("targetAccounts[0].targetAssetMixes[0].repositoryTamId", equalTo(3))
				.body("targetAccounts[0].targetAssetMixes[0].assetAllocationId", equalTo(50))
				.body("targetAccounts[0].targetAssetMixes[0].context", equalTo("Standard"));

	}

	/**
	 * Validate the updated retail account.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "getRetailAccountAfterUpdate")
	public void getRetailAccountAfterUpdateWhenEEDSIsFalse()
	{

		context.put("externalDataSources", "false");
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200);
		Boolean resultCode = response.path("resultCode");
		Boolean dssResultCode =
				response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2'}.result");
		if (dssResultCode != null)
		{
			Assert.assertEquals(resultCode, false);
		}
		else
		{
			Assert.assertEquals(resultCode, true);
		}
		response.then().log().ifValidationFails()
				.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
				.body("accountList[0].regCode.mnemonic",
						equalTo(accountsCommonTestData.getMnemonic1()))
				.body("accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))

				.body("targetAccounts", not(empty()))
				.body("targetAccounts[0].accountId.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].accountId.owner.relationship", equalTo("PRINCIPAL"))
				.body("targetAccounts[0].accountId.owner.id",
						equalTo(accountsCommonTestData.getPpid()))
				.body("targetAccounts[0].displayName", equalTo(TARGET_ACCOUNT_NAME))
				.body("targetAccounts[0].sourceMarketValue.amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].regCode.sourceSystem",
						equalTo(accountsCommonTestData.getSourceSystem1()))
				.body("targetAccounts[0].fundingAccounts[0].accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("targetAccounts[0].fundingAccounts[0].amount.value",
						equalTo(fundingAccountAmount))
				.body("targetAccounts[0].complementaryAdjustmentOption",
						equalTo("MOVE_TO_MANAGED_ACCOUNT"))
				.body("targetAccounts[0].isProductSuitable",
						equalTo(Boolean.valueOf(isProductSuitableUpdate)))
				.body("targetAccounts[0].irrevocableTrust", equalTo(false))
				.body("targetAccounts[0].trustType", equalTo(null))
				.body("targetAccounts[0].equityPercent", equalTo(0.5f))
				.body("targetAccounts[0].assetAllocation.allocation", hasSize(4))
				.body("targetAccounts[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.5f))
				.body("targetAccounts[0].annualContribution.value", equalTo(999.55f))
				.body("targetAccounts[0].targetAccountPreferences.stockMarketDeclinePercent",
						equalTo("SELL_BETWEEN_51_AND_75"))
				.body("targetAccounts[0].targetAccountPreferences.investmentObjectiveIA",
						equalTo("NONE"))
				.body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
						equalTo("TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6"))
				.body("targetAccounts[0].targetAccountPreferences.annualWithdrawalPercent",
						equalTo(0.002f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
						equalTo(0.5f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
						equalTo(0.35f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}."
								+ "allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
						equalTo(0.15f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
						equalTo(0.4f))
				.body("targetAccounts[0].targetAssetMixes[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
						equalTo(0.1f))
				.body("targetAccounts[0].targetAssetMixes[0].lowerEquityPercentage.value",
						equalTo(0.45f))
				.body("targetAccounts[0].targetAssetMixes[0].upperEquityPercentage.value",
						equalTo(0.54f))
				.body("targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"))
				.body("targetAccounts[0].targetAssetMixes[0].repositoryTamId", equalTo(3))
				.body("targetAccounts[0].targetAssetMixes[0].assetAllocationId", equalTo(50))
				.body("targetAccounts[0].targetAssetMixes[0].context", equalTo("Standard"));

	}

	/**
	 * Delete target account
	 */
	@Test(dependsOnMethods = "getRetailAccountAfterUpdateWhenEEDSIsFalse")
	public void deleteTargetAccount()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("targetAccounts", empty());
	}

	/**
	 * Validate the updated retail account.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "deleteTargetAccount")
	public void getRetailAccountAfterTargetAccountDelete()
	{

		context.put("externalDataSources", "true");

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true))
				.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
				.body("accountList[0].regCode.mnemonic",
						equalTo(accountsCommonTestData.getMnemonic1()))
				.body("accountList[0].accountId.accountNumber",
						equalTo(accountsCommonTestData.getAccountNumber1()))
				.body("accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()))
				.body("accountList[0].sourceMarketValue.amount.value", equalTo(updatedValue))
				.body("targetAccounts", empty());

	}

	/**
	 * Delete the account.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "getRetailAccountAfterTargetAccountDelete")
	public void deleteRetailAccount()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true));
	}

	/**
	 * Validate the retail account was deleted.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "deleteRetailAccount")
	public void getRetailAccountAfterDelete()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true))
				.body("accountList", empty());

	}

	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}
}
