/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.manual;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.Assert.assertThat;

/**
 * Tests CRUD operation for composite (suitability) against V2 for Manual accounts,
 * only with account level preferences and not other suitability questions (PFCP-6920)
 *
 * @author a608077
 */
@Test(groups = {Tags.COMPOSITE, Tags.MANUAL, Tags.V2})
public class Manual_Composite_Suitability_Only_Preferences_v2 extends PAPBaseServiceTest {


    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    // Paths
    private String accountCompositeGetPath;

    private String accountCompositeCreatePath;

    private String accountCompositeUpdatePath;

    private String accountDeletePath;

    // Financial Instrument IDs and their symbols
    private FinancialInstrumentIds finstIds;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Manual_Composite_Suitability_Only_Preferences_v2.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    //Start and End years for accountPreferencesIA - both should be greater than the current year.
    int startYear = ZonedDateTime.now().plusYears(1).getYear();
    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    /**
     * Constructor
     */
    protected Manual_Composite_Suitability_Only_Preferences_v2() {
        super(Services.Account);
    }

    /**
     * Initialization method used to: </br>
     * 1. Retrieve the oAuth token </br>
     * 2. Retrieve the test data from SQLite DB & set up any other test data </br>
     * 3. Set operation paths </br>
     * 4. Build partial contents of the velocity context
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {

        this.oAuth = AccountUtil.getOauthToken();

        this.accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN, this.oAuth);
        DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), this.oAuth);

        // Data setup
        this.accountsCommonTestData.set("updatedAmount", "15000.0");
        this.accountsCommonTestData.set("contribFreq", "YEARLY");
        this.accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        this.accountsCommonTestData.set("contribValue", "6000.0");
        this.accountsCommonTestData.set("updatedContribAmount", "500.0");
        this.accountsCommonTestData.set("withdrawAmount", "500.0");
        this.accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
        this.accountsCommonTestData.set("withdrawFreq", "YEARLY");
        this.accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");
        this.accountsCommonTestData.set("detailValue", "42619.85");
        this.accountsCommonTestData.set("updatedDetailValue", "81819.89");
        this.accountsCommonTestData.set("value", "52619.85");
        this.accountsCommonTestData.set("updatedValue", "62619.85");
        this.accountsCommonTestData.setMnemonic1("IBRKFUND");
        this.accountsCommonTestData.setDisplayName1("Manual Composite CRUD RestAssured");
        this.accountsCommonTestData.setInstitutionName1("RETAIL");
        this.accountsCommonTestData.setSourceSystem1("MANUAL");
        this.accountsCommonTestData.setPpid(
                String.valueOf(Identity.createHouseholdIdentity(this.accountsCommonTestData.getMid(), this.oAuth)));

        // Resolve finstIds
        this.finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

        // Set operation paths
        this.accountCompositeGetPath = AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2;
        this.accountCompositeCreatePath = AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2;
        this.accountCompositeUpdatePath = AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2;
        this.accountDeletePath = AccountsPaths.DELETE_ACCOUNT_V2;
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);
        this.request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"));
    }

    /**
     * Description: Validates an empty account list when calling get account composite manual before creation of an
     * account (v2)
     */
    @Test
    public void getCompositeAccountManualV2BeforeCreate() {

        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", this.accountsCommonTestData.getSourceSystem1());

        this.request.header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()));

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        this.response = this.request.log().ifValidationFails().post(this.accountCompositeGetPath);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));

    }

    /**
     * Description: Validates the account composite response after create
     */
    @Test(dependsOnMethods = {"getCompositeAccountManualV2BeforeCreate"})
    public void createCompositeAccountManualV2() {

        // Generate request body
        final VelocityContext context = new VelocityContext();
        context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
        context.put("source", this.accountsCommonTestData.getSourceSystem1());
        context.put("ppid", this.accountsCommonTestData.getPpid());
        context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", this.accountsCommonTestData.getSourceSystem1());
        context.put("value", this.accountsCommonTestData.get("value"));
        context.put("detailValue", this.accountsCommonTestData.get("detailValue"));
        context.put("contribValue", this.accountsCommonTestData.get("contribValue"));
        context.put("contribFreq", this.accountsCommonTestData.get("contribFreq"));
        context.put("withdrawAmount", this.accountsCommonTestData.get("withdrawAmount"));
        context.put("withdrawFreq", this.accountsCommonTestData.get("withdrawFreq"));
        context.put("GDSTOCK", this.finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", this.finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", this.finstIds.getFinstId("GBOND"));
        context.put("GCASH", this.finstIds.getFinstId("GCASH"));
        context.put("riskTolerance", 1);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V2));

        this.request.header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()));

        // Make post request
        this.response = this.request.log().ifValidationFails().post(this.accountCompositeCreatePath);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body(
                "accounts[0].account.accountId.owner.id", equalTo(this.accountsCommonTestData.getPpid()),
                "accounts[0].account.displayName", equalTo(this.accountsCommonTestData.getDisplayName1()),
                "accounts[0].account.regCode.mnemonic", equalTo(this.accountsCommonTestData.getMnemonic1()),
                "accounts[0].account.regCode.sourceSystem", equalTo(this.accountsCommonTestData.getSourceSystem1()),
                "accounts[0].account.institutionName", equalTo(this.accountsCommonTestData.getInstitutionName1()),
                "accounts[0].account.sourceMarketValue.amount.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("value"))),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GDSTOCK")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GFSTOCK")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GBOND")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GCASH")),
                "accounts[0].details.manualAccountDetail.accountDetail.costBasis.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("detailValue"))),
                "accounts[0].details.manualAccountDetail.state", equalTo("AK"),
                "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(1),
                "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),

                "accounts[0].contributions.contributions[0].contribution.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("contribValue"))),
                "accounts[0].contributions.contributions[0].frequency",
                equalTo(this.accountsCommonTestData.get("contribFreq")),
                "accounts[0].withdrawals[0].amount.amount.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("withdrawAmount"))),
                "accounts[0].withdrawals[0].amount.frequency",
                equalTo(this.accountsCommonTestData.get("withdrawFreq")));

        // Save account number and ID
        this.accountsCommonTestData.setAccountId1(this.response.path("accounts[0].account.accountId.id"));
        this.accountsCommonTestData.setAccountNumber1(this.response.path("accounts[0].account.accountId.accountNumber"));
        this.accountsCommonTestData.set("asOfDate", this.response.path("accounts[0].account.sourceMarketValue.asOfDate"));
    }

    /**
     * Description: Validates the account composite response after create
     */
    @Test(dependsOnMethods = "createCompositeAccountManualV2")
    public void getCompositeAccountManualV2AfterCreate() {

        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", this.accountsCommonTestData.getSourceSystem1());

        this.request.header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()));

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        this.response = this.request.log().ifValidationFails().post(this.accountCompositeGetPath);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "accounts[0].account.accountId.id", equalTo(this.accountsCommonTestData.getAccountId1()),
                "accounts[0].account.accountId.accountNumber",
                equalTo(this.accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                equalTo(this.accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                equalTo(this.accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                equalTo(this.accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                equalTo(this.accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                equalTo(this.accountsCommonTestData.getInstitutionName1()),
                "accounts[0].account.sourceMarketValue.amount.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("value"))),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GDSTOCK")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GFSTOCK")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GBOND")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GCASH")),
                "accounts[0].details.manualAccountDetail.accountDetail.costBasis.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("detailValue"))),
                "accounts[0].details.manualAccountDetail.state", equalTo("AK"),
                "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(1),
                "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),

                "accounts[0].contributions.contributions[0].contribution.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("contribValue"))),
                "accounts[0].contributions.contributions[0].frequency",
                equalTo(this.accountsCommonTestData.get("contribFreq")),
                "accounts[0].withdrawals[0].amount.amount.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("withdrawAmount"))),
                "accounts[0].withdrawals[0].amount.frequency",
                equalTo(this.accountsCommonTestData.get("withdrawFreq")));
    }

    /**
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "getCompositeAccountManualV2AfterCreate")
    public void updateCompositeAccountManualV2() {

        // Generate request body
        final VelocityContext context = new VelocityContext();
        context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
        context.put("accId", this.accountsCommonTestData.getAccountId1());
        context.put("source", this.accountsCommonTestData.getSourceSystem1());
        context.put("ppid", this.accountsCommonTestData.getPpid());
        context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", this.accountsCommonTestData.getSourceSystem1());
        context.put("value", this.accountsCommonTestData.get("updatedValue"));
        context.put("detailValue", this.accountsCommonTestData.get("updatedDetailValue"));
        context.put("contribValue", this.accountsCommonTestData.get("updatedContribAmount"));
        context.put("contribFreq", this.accountsCommonTestData.get("updatedContribFreq"));
        context.put("withdrawAmount", this.accountsCommonTestData.get("updatedWithdrawAmount"));
        context.put("withdrawFreq", this.accountsCommonTestData.get("updatedWithdrawFreq"));
        context.put("GDSTOCK", this.finstIds.getFinstId("GDSTOCK"));
        context.put("GFSTOCK", this.finstIds.getFinstId("GFSTOCK"));
        context.put("GBOND", this.finstIds.getFinstId("GBOND"));
        context.put("GCASH", this.finstIds.getFinstId("GCASH"));
        context.put("riskTolerance", 2);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V2));

        this.request.header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()));

        // Make post request
        this.response = this.request.log().ifValidationFails().post(this.accountCompositeUpdatePath);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body(
                "accounts[0].account.accountId.id", equalTo(this.accountsCommonTestData.getAccountId1()),
                "accounts[0].account.accountId.accountNumber",
                equalTo(this.accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                equalTo(this.accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                equalTo(this.accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                equalTo(this.accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                equalTo(this.accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                equalTo(this.accountsCommonTestData.getInstitutionName1()),
                "accounts[0].account.sourceMarketValue.amount.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedValue"))),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GDSTOCK")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GFSTOCK")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GBOND")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GCASH")),
                "accounts[0].details.manualAccountDetail.accountDetail.costBasis.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedDetailValue"))),
                "accounts[0].details.manualAccountDetail.state", equalTo("AK"),
                "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(2),
                "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),

                "accounts[0].contributions.contributions[0].contribution.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedContribAmount"))),
                "accounts[0].contributions.contributions[0].frequency",
                equalTo(this.accountsCommonTestData.get("updatedContribFreq")),
                "accounts[0].withdrawals[0].amount.amount.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedWithdrawAmount"))),
                "accounts[0].withdrawals[0].amount.frequency",
                equalTo(this.accountsCommonTestData.get("updatedWithdrawFreq")));
    }

    /**
     * Description: Validates the account composite response after an update
     */
    @Test(dependsOnMethods = "updateCompositeAccountManualV2")
    public void getCompositeAccountManualV2AfterUpdate() {

        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", this.accountsCommonTestData.getSourceSystem1());

        this.request.header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()));

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        this.response = this.request.log().ifValidationFails().post(this.accountCompositeGetPath);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
                "accounts[0].account.accountId.id", equalTo(this.accountsCommonTestData.getAccountId1()),
                "accounts[0].account.accountId.accountNumber",
                equalTo(this.accountsCommonTestData.getAccountNumber1()), "accounts[0].account.accountId.owner.id",
                equalTo(this.accountsCommonTestData.getPpid()), "accounts[0].account.displayName",
                equalTo(this.accountsCommonTestData.getDisplayName1()), "accounts[0].account.regCode.mnemonic",
                equalTo(this.accountsCommonTestData.getMnemonic1()), "accounts[0].account.regCode.sourceSystem",
                equalTo(this.accountsCommonTestData.getSourceSystem1()), "accounts[0].account.institutionName",
                equalTo(this.accountsCommonTestData.getInstitutionName1()),
                "accounts[0].account.sourceMarketValue.amount.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedValue"))),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GDSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GDSTOCK")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GFSTOCK'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GFSTOCK")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GBOND'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GBOND")),
                "accounts[0].positions.allPositions.find{it.financialAssetPosition.financialInstrumentId.symbol=='GCASH'}.financialAssetPosition.financialInstrumentId.finstId",
                equalTo(this.finstIds.getFinstId("GCASH")),
                "accounts[0].details.manualAccountDetail.accountDetail.costBasis.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedDetailValue"))),
                "accounts[0].details.manualAccountDetail.state", equalTo("AK"),
                "accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(2),
                "accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                "accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                "accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),

                "accounts[0].contributions.contributions[0].contribution.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedContribAmount"))),
                "accounts[0].contributions.contributions[0].frequency",
                equalTo(this.accountsCommonTestData.get("updatedContribFreq")),
                "accounts[0].withdrawals[0].amount.amount.value",
                equalTo(Float.valueOf(this.accountsCommonTestData.get("updatedWithdrawAmount"))),
                "accounts[0].withdrawals[0].amount.frequency",
                equalTo(this.accountsCommonTestData.get("updatedWithdrawFreq")));
    }

    /**
     * Description: Validates the account composite response after delete
     */
    @Test(dependsOnMethods = "getCompositeAccountManualV2AfterUpdate")
    public void deleteCompositeAccountManualV2() {

        final VelocityContext context = new VelocityContext();
        context.put("accountNumber", this.accountsCommonTestData.getAccountNumber1());
        context.put("accId", this.accountsCommonTestData.getAccountId1());
        context.put("source", this.accountsCommonTestData.getSourceSystem1());
        context.put("ppid", this.accountsCommonTestData.getPpid());
        context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        context.put("mnemonic", this.accountsCommonTestData.getMnemonic1());
        context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        context.put("value", this.accountsCommonTestData.get("updatedValue"));
        context.put("asOfDate", this.accountsCommonTestData.get("asOfDate"));

        this.request.header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()));

        // Generate request body
        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        // Make post request
        this.response = this.request.post(this.accountDeletePath);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = this.response.jsonPath().getString("$");
        assertThat(emptyResponse, equalTo("[:]"));
    }

    /**
     * Description: Validates an empty account list when calling get account composite manual after delete
     */
    @Test(dependsOnMethods = "deleteCompositeAccountManualV2")
    public void getCompositeAccountManualV2AfterDelete() {

        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", this.accountsCommonTestData.get("sourceSystem"));

        this.request.header(new Header("user-mid", this.accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", this.accountsCommonTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        this.request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        this.response = this.request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        this.response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

}
