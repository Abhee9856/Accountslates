/*
 * Copyright 2018, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.positions.crud.manual;

import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;

import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;

import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.pap.restassured.utilities.IOUtil;


import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;

import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operation for manual positions against V1.
 *
 * @author a601767
 * Updated by a608077 on 05/08/2024 to include EEDS=null(PFCP-15874)
 */
@Test(groups = {
        Tags.POSITIONS,
        Tags.MANUAL,
        Tags.V1,
        Tags.CRITICAL})
public class Manual_Positions_CRUD extends PAPBaseServiceTest {

    protected Manual_Positions_CRUD() {
        super(Services.Account);
    }

    private VelocityContext context;
    private FinancialInstrumentIds finstIds;
    private AccountsCommonTestData accountsCommonTestData;
    private static final String LOG_TRACKING_ID = Manual_Positions_CRUD.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Initialization method used to populate the test data, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN, oAuth);

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        String mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        accountsCommonTestData.setPpid(String.valueOf(Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth)));

        // Resolve finst ids
        finstIds = new FinancialInstrumentIds("GBOND", "GFSTOCK", "GCASH", "GDSTOCK");

        //Data Setup
        accountsCommonTestData.set("gCashValue", "0.25");
        accountsCommonTestData.set("gBondValue", "0.25");
        accountsCommonTestData.set("gdStockValue", "0.25");
        accountsCommonTestData.set("gfStockValue", "0.25");
        accountsCommonTestData.setSourceSystem1("MANUAL");
        accountsCommonTestData.setMnemonic1("401K");
        String asOfDate = "2014-10-31";
        accountsCommonTestData.setAsOfDate1(asOfDate);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());

    }

    /**
     * Create the manual account.
     * <p>
     * Version V1
     */
    @Test
    public void createManualAccount() {

        float value = 818.89f;
        context.put("value", value);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
                .body("accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()));

        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("accId", accountsCommonTestData.getAccountNumber1());
    }

    /**
     * Validate the manual account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createManualAccount")
    public void getAccountAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.id", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()));

    }

    /**
     * Create the positions
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getAccountAfterCreate")
    public void createAccountPositions() {

        context.put("externalDataSources", "null");
        // Position data points
        context.put("gCashValue", accountsCommonTestData.get("gCashValue"));
        context.put("gBondValue", accountsCommonTestData.get("gBondValue"));
        context.put("gdStockValue", accountsCommonTestData.get("gdStockValue"));
        context.put("gfStockValue", accountsCommonTestData.get("gfStockValue"));
        context.put("GBOND", finstIds.getFinstId("GBOND"));
        context.put("GFSTOCK", finstIds.getFinstId("GFSTOCK"));
        context.put("GCASH", finstIds.getFinstId("GCASH"));
        context.put("GDSTOCK", finstIds.getFinstId("GDSTOCK"));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_POSITIONS_SET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountPositions[0].account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountPositions[0].account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountPositions[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountPositions[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GDSTOCK")),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GFSTOCK")),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.quantity", equalTo(1.5f),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GBOND")),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GCASH")),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gdStockValue"))),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gfStockValue"))),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gBondValue"))),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gCashValue"))));

    }

    /**
     * Validate the positions.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountPositions")
    public void getPositionsAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_POSITIONS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList[0].account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountList[0].account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountList[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GDSTOCK")),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GFSTOCK")),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GBOND")),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GCASH")),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gdStockValue"))),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gfStockValue"))),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gBondValue"))),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gCashValue"))));

    }

    /**
     * Update the positions.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getPositionsAfterCreate")
    public void updateAccountPositions() {
        // Generate request body
        accountsCommonTestData.set("gCashValue", "0.15");
        accountsCommonTestData.set("gBondValue", "0.35");
        accountsCommonTestData.set("gdStockValue", "0.45");
        accountsCommonTestData.set("gfStockValue", "0.05");

        context.put("gCashValue", accountsCommonTestData.get("gCashValue"));
        context.put("gBondValue", accountsCommonTestData.get("gBondValue"));
        context.put("gdStockValue", accountsCommonTestData.get("gdStockValue"));
        context.put("gfStockValue", accountsCommonTestData.get("gfStockValue"));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_POSITIONS_SET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountPositions[0].account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountPositions[0].account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountPositions[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountPositions[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GDSTOCK")),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GFSTOCK")),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GBOND")),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GCASH")),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gdStockValue"))),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gfStockValue"))),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gBondValue"))),
                        "accountPositions[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gCashValue"))));

    }

    /**
     * Validate the positions were updated.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountPositions")
    public void getPositionsAfterUpdate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_POSITIONS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountList[0].account.accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountList[0].account.accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountList[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountList[0].account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GDSTOCK")),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GFSTOCK")),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GBOND")),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.financialInstrumentId.finstId", equalTo(finstIds.getFinstId("GCASH")),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GDSTOCK'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gdStockValue"))),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GFSTOCK'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gfStockValue"))),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GBOND'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gBondValue"))),
                        "accountList[0].positions.position.find{it.financialInstrumentId.symbol=='GCASH'}.marketValue.value", equalTo(Float.valueOf(accountsCommonTestData.get("gCashValue"))));

    }

    /**
     * Delete the account with positions.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getPositionsAfterUpdate")
    public void deleteManualAccount() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountList", empty());

    }

    /**
     * Validate no positions are returned after delete.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteManualAccount")
    public void getPositionsAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_POSITIONS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountList", empty());

    }
}
