/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.equalTo;

/**
 * Tests CRUD operations of account details V1 for Workplace Accounts.
 *
 * @author a631781
 */
@Test(groups = {
		Tags.CRITICAL,
		Tags.WORKPLACE,
		Tags.DETAILS,
		Tags.V1, Tags.TAM})
public class Workplace_Details_CriticalTest_V1 extends PAPBaseServiceTest
{

    protected Workplace_Details_CriticalTest_V1()
    {
	super(Services.Account);
    }

    private TestDataUtil p2TestDataUtil;

    private AccountsCommonTestData accountsCommonTestData;

    private VelocityContext context;

    private FilterableRequestSpecification frs;

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Workplace_Details_V1_Crud.class.getSimpleName();

    private static final String fsreqid = logTrackingId;

    private String ppid;

    // Test data
    private String mid;//= "WorkplaceDetailsV1TestMid";

    private String accId;

    private String accountNum;

    private String sourceSystem = AccountConstants.WORKPLACE;

    private String displayName;

    private String mnemonic;

    private String institutionName;

    private String asOfDate;

    private float value = 818.89f;

    private final float updatedValue = 426.85f;

    private String accountId;

    private String ownerId;

    private String accNum;

    private String assertRegCode;

    private String tamAssetClass = "TOTAL_EQUITY";

    // AssetAllocation
    private String assetClass = "CASH";

    private float netPercentageValue = 1.0f;

    private float netPercentageUpdatedValue = 0.7f;

    private String assetClass_T_Equity = "TOTAL_EQUITY";

    private String foreignEquity = "FOREIGN_EQUITY";

    private String domesticEquity = "DOMESTIC_EQUITY";

    private float netPercentage_T_Equity = 1.0f;

    private float netPercentage_FE = 0.5f;

    private float netPercentage_DE = 0.5f;

    private String assetClass3 = "BOND";

    private String assetClass4 = "OTHER";

    private float netPercentage3 = 0.3f;

    private float netPercentage4 = 0.2f;

    private float netPercentageUpdated3 = 0.5f;

    private float netPercentageUpdated4 = 0.7f;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	p2TestDataUtil = new TestDataUtil();

	final String oAuth = AccountUtil.getOauthToken();
	accountsCommonTestData =
			TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_WORKPLACE, oAuth);
	this.mid = accountsCommonTestData.getMid();
	accountsCommonTestData.setMid(this.mid);
	DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


	ppid = Identity.createHouseholdIdentity(accountsCommonTestData.getMid(), oAuth);
	// Data setup
	accountsCommonTestData.setPpid(ppid);

	// Endpoint setup
	setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

	// Populate request variables
	context = new VelocityContext();
	context.put("mid", accountsCommonTestData.getMid());
	context.put("sid", accountsCommonTestData.getSid());
	context.put("source", sourceSystem);
	context.put("poe", "NETBENEFITS");
	context.put("fescoLid", accountsCommonTestData.getSsn());

	frs = (FilterableRequestSpecification) request;

    }

    /**
     * Tests that account data is brought back for Workplace account.
     * <p>
     * Version V1
     */
    @Test
    public void getWorkplaceAccountInfo()
    {

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	// Call Account service v1
	response = request.post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

	accountId = response.path("accountList[0].accountId.id");
	accountsCommonTestData.setAccountId1(accountId);
	accountNum = response.path("accountList[0].accountId.accountNumber");
	sourceSystem = response.path("accountList[0].accountId.sourceSystem");
	displayName = response.path("accountList[0].displayName");
	mnemonic = response.path("accountList[0].regCode.mnemonic");
	value = response.path("accountList[0].sourceMarketValue.amount.value");
	accountsCommonTestData.setValue1(value);
	institutionName = response.path("accountList[0].institutionName");
	asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
	ownerId = response.path("accountList[0].accountId.owner.id");
	accountsCommonTestData.setPpid(ownerId);
    }

    /**
     * Creates a new Workplace account
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount()
    {

	context.put("mid", accountsCommonTestData.getMid());
	context.put("sid", accountsCommonTestData.getSid());
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("mnemonic", mnemonic);
	context.put("value", value);
	context.put("source", sourceSystem);
	context.put("accountNumber", accountNum);
	context.put("displayName", displayName);
	context.put("institutionName", institutionName);
	context.put("asOfDate", asOfDate);

	accNum = accountNum;
	assertRegCode = mnemonic;

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.post(AccountsPaths.CREATE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
			.body("accountList[0].accountId.accountNumber", equalTo(accNum))
			.body("accountList[0].regCode.mnemonic", equalTo(assertRegCode))
			.body("accountList[0].displayName", equalTo(displayName))
			.body("accountList[0].institutionName", equalTo(institutionName))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

	accId = response.path("accountList[0].accountId.id");
	accNum = response.path("accountList[0].accountId.accountNumber");

    }

    /**
     * Create Workplace account Details Request.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void createAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", value);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "WorkplaceAccountDetails");
	context.put("_type", "WorkplaceAccountDetails");
	context.put("tamAssetClass", tamAssetClass);
	context.put("assetClass", assetClass);
	context.put("netPercentageValue", netPercentageValue);
	context.put("assetClass_T_Equity", assetClass_T_Equity);
	context.put("netPercentage_T_Equity", netPercentage_T_Equity);
	context.put("assetClass_FOREIGN_EQUITY", foreignEquity);
	context.put("netPercentage_FE", netPercentage_FE);
	context.put("assetClass_DOMESTIC_EQUITY", domesticEquity);
	context.put("netPercentage_DE", netPercentage_DE);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentage3);
	context.put("assetClass4", assetClass4);
	context.put("netPercentage4", netPercentage4);

	// Generate request body
	request.body(
			IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

	// Call Account service
	response =
			request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id", equalTo(accId))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.relationship",
					equalTo("PRINCIPAL"))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.planId.planNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.targetAssetMixes.targetAssetMix[0].allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentage3))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentage4))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
					equalTo(netPercentage_FE));

    }

    /**
     * Validate the Workplace account details after create.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountDetails")
    public void getDetailsAfterCreate()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id", equalTo(accId))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.relationship",
					equalTo("PRINCIPAL"))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.planId.planNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.targetAssetMixes.targetAssetMix[0].allocation[0].assetClass",
					equalTo(tamAssetClass))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageValue))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentage3))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentage4))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
					equalTo(netPercentage_FE));
    }

    /**
     * Update the account details for Workplace account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterCreate")
    public void updateAccountDetails()
    {
        // Generate request body
	context.put("ppid", this.accountsCommonTestData.getPpid());
	context.put("value", updatedValue);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "WorkplaceAccountDetails");
	context.put("_type", "WorkplaceAccountDetails");
	context.put("assetClass", assetClass);
	context.put("netPercentageValue", netPercentageUpdatedValue);
	context.put("assetClass_T_Equity", assetClass_T_Equity);
	context.put("netPercentage_T_Equity", netPercentage_T_Equity);
	context.put("assetClass_FOREIGN_EQUITY", foreignEquity);
	context.put("netPercentage_FE", netPercentage_FE);
	context.put("assetClass_DOMESTIC_EQUITY", domesticEquity);
	context.put("netPercentage_DE", netPercentage_DE);
	context.put("assetClass3", assetClass3);
	context.put("netPercentage3", netPercentageUpdated3);
	context.put("assetClass4", assetClass4);
	context.put("netPercentage4", netPercentageUpdated4);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id", equalTo(accId))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.relationship",
					equalTo("PRINCIPAL"))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.planId.planNumber",
					equalTo(accNum))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageUpdatedValue))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated3))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated4))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
					equalTo(netPercentage_FE));

    }

    /**
     * Validate the updated Workplace account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountDetails")
    public void getDetailsAfterUpdate()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber",
					equalTo(accNum))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.id", equalTo(accId))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.relationship",
					equalTo("PRINCIPAL"))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()))
			.body("accountDetails.find{it.accountId.id=='" + accId + "'}.planId.planNumber",
					equalTo(accNum))
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass + "'}.netPercentage.value",
					equalTo(netPercentageUpdatedValue))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass3 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated3))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass4 + "'}.netPercentage.value",
					equalTo(netPercentageUpdated4))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.netPercentage.value",
					equalTo(netPercentage_T_Equity))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ domesticEquity + "'}.netPercentage.value",
					equalTo(netPercentage_DE))
			.body("accountDetails.find{it.accountId.id=='" + accId
							+ "'}.assetAllocation.allocation.find{it.assetClass=='"
							+ assetClass_T_Equity + "'}.allocation.find{it.assetClass=='"
							+ foreignEquity + "'}.netPercentage.value",
					equalTo(netPercentage_FE));
    }

    /**
     * Delete the Workplace account details.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getDetailsAfterUpdate")
    public void deleteAccountDetails()
    {
	context.put("ppid", accountsCommonTestData.getPpid());
	context.put("value", updatedValue);
	context.put("source", sourceSystem);
	context.put("accountNumber", accNum);
	context.put("accId", accId);
	context.put("isInherited", false);
	context.put("isPreviousEmployersAccount", false);
	context.put("state", "NC");
	context.put("type", "WorkplaceAccountDetails");
	context.put("_type", "WorkplaceAccountDetails");
	// Generate request body
	request
			.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

    }

    /**
     * Validate the workplace account was deleted.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccountDetails")
    public void getDetailsAfterDelete()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
			equalTo(true), "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
			"accountDetails.find{it.accountId.id=='" + accId + "'}.costBasis",
			nullValue());

    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	p2TestDataUtil.closeSQLiteConnection();
    }

}
