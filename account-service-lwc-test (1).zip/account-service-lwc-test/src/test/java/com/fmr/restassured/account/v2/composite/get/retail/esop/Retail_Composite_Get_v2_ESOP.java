/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.get.retail.esop;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.is;

/**
 * Tests for ESOP Composite Account
 *
 * @author a631781
 */

@Test(groups = {Tags.REGRESSION, Tags.COMPOSITE, Tags.V2})
public class Retail_Composite_Get_v2_ESOP extends PAPBaseServiceTest
{

    protected Retail_Composite_Get_v2_ESOP()
    {
	super(Services.Account);
    }

    private static final String sourceSystem = "RETAIL";

    public static final String ACCOUNT_CATEGORY = "StockPlans";

    private String ssn;

    private String mid;

    private String sid;

    private String ppid;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Composite_Get_v2_ESOP.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String APP_NAME = "Advice and Planning Platform";

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private Response accountResponse;

    private String mnemonic = "ESOP";

    private Integer totalNumOfAcctDSS;

    private Integer totalNumOfAcct;

    private List<String> accountESOPList;

    private final String oAuth = AccountUtil.getOauthToken();

    private TestDataUtil testDataUtil;

    private VelocityContext context;

    private FilterableRequestSpecification frs;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
	// Data setup
	AccountsCommonTestData accountsCommonTestData = TestDataUtil
			.populateRegressionTestData("retail_esop_account", oAuth);

	mid = accountsCommonTestData.getMid();
	sid = accountsCommonTestData.getSid().replace("-", "");
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


	ppid = Identity.createHouseholdIdentity(mid, oAuth);

	ssn = accountsCommonTestData.getSsn();
	testDataUtil = new TestDataUtil();

	// Populate request context with user IDs
	context = new VelocityContext();

	// Common headers setup
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Test to get the DSS StockPlans account
     * <p>
     * Version V2
     */
    @Test
    public void getDSS_V2()
    {
	//Set DSS Headers
	frs = (FilterableRequestSpecification) request;
	frs.removeHeaders();
	setDefaultRequestHeadersForDSS();

	// Generate request body
	context.put("acctCategory", ACCOUNT_CATEGORY);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

	request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
	response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)));
	totalNumOfAcctDSS = response.path("totalNumOfAcct");
	accountESOPList = response.path("acctDetails.parentBrokAcctNum");
    }

    /**
     * Tests that account data is brought back for ESOP composite account.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = {"getDSS_V2"})
    public void getCompositeAccountInfo()
    {
	// Generate request body
	frs = (FilterableRequestSpecification) request;
	frs.removeHeaders();
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
	setRequestHeadersForAccount();
	context.put("sourceBasedRegistrationFilter", sourceSystem);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

	// Call Account service v2
	accountResponse = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

	// Assert on response
	accountResponse.then().log().ifValidationFails().statusCode(200);
	if (null != accountResponse.path("accountList"))
	{
	    ArrayList<String> accountList;
	    accountList = accountResponse.path("accounts.account.accountId.accountNumber");
	    totalNumOfAcct = accountList.size();
	    Assert.assertEquals(totalNumOfAcct, totalNumOfAcctDSS);
	    ArrayList<String> finalAccountList = new ArrayList<>();
	    for (String items : accountList)
	    {
		String[] acctNumbers = items.split("_", 2);
		finalAccountList.add(acctNumbers[0]);
	    }
	    Assert.assertEquals(finalAccountList, accountESOPList);
	}

    }

    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS()
    {
	this.request.given().header(new Header("AppId", "AP106532"))
			.header(new Header("fsreqid", FSREQID))
			.header(new Header("Authorization", oAuth))
			.header(new Header("AppName", APP_NAME))
			.header(new Header("rtazlid", this.ssn))
			.header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
			.header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
			.header(new Header("FACMC", "MID=" + this.mid))
			.header(new Header("FACFC", "SESSION_KEY=1"))
			.header(new Header("Content-Type", "application/json"));

    }

    /**
     * Setting headers for Account Service
     */
    private void setRequestHeadersForAccount()
    {
	// Account headers setup
	this.request.given()
			.header(new Header("user-poe", AccountConstants.RETAIL))
			.header(new Header("user-mid", mid))
			.header(new Header("user-retail-lid", ssn))
			.header(new Header("exclude-external-data-sources", "true"))
			.header(new Header("realTimeData", "false"))
			.header(new Header("calculate-manual-esop-balances", "true"))
			.header(new Header("return-current-asset-allocation", "true"))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("Content-Type", "application/json"));

    }

    /**
     * Clean up method for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


	this.testDataUtil.closeSQLiteConnection();
    }

}
