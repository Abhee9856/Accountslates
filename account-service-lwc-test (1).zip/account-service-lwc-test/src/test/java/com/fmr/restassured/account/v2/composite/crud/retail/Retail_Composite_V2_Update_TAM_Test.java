/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.MatcherAssert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

/**
 * Class to test TAM is created successfully via UPDATE method.
 *
 * @author a631781
 */
@Test(groups = {Tags.REGRESSION, Tags.RETAIL, Tags.COMPOSITE, Tags.V2})
public class Retail_Composite_V2_Update_TAM_Test extends PAPBaseServiceTest {
    /**
     * Constructor
     */
    protected Retail_Composite_V2_Update_TAM_Test() {
        super(Services.Account);
    }

    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Retail_Composite_V2_Update_TAM_Test.class);

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    /**
     * Global variable holding retailAccount information
     */
    private HashMap<String, String> retailAccountMap;

    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountTestData;
    private static final String LOG_TRACKING_ID = Retail_Composite_V2_Update_TAM_Test.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;
    private static final String CALLING_APP_ID = "AP106564";
    private static final String APP_ID = "AP106564";
    private String accNum;
    private String acctRoot;
    private final String details = "details.retailAccountDetail.";
    private static String tamName = "Growth with Income";
    private static float tamTotalEquity = 0.60F;
    private static float tamDomesticEquity = 0.42F;
    private static float tamForeignEquity = 0.18F;
    private static float tamBond = 0.35F;
    private static float tamCash = 0.05F;
    private static String tamCategory = "INVESTOR_SELECTED_STRATEGY";
    private static Integer tamRepositoryTamId = 179;
    private static Integer tamAssetAllocationId = 60;
    private VelocityContext context;

    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {
        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        retailAccountMap = new HashMap<>();

        accountTestData = TestDataUtil.populateRegressionTestData("retail_critical_regcode", oAuth);
        retailAccountMap = getRetailAccountInformationV2(accountTestData, oAuth);

        DataCleanup.deleteCustomerDataFromCP("mid", accountTestData.getMid(), oAuth, "true");

        final String ppid = Identity.createHouseholdIdentity(accountTestData.getMid(), oAuth);
        accountTestData.setPpid(ppid);
        context = new VelocityContext();
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        request.header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"));
    }

    //Get composite call before Create
    @Test
    public void getCompositeAccountRetailV2BeforeCreate() {
        if (retailAccountMap.isEmpty()) {
            throw new SkipException(
                    "'getCompositeAccountRetailV2BeforeCreate' test scenario cannot run due to failure to retrieve "
                            + "retail account information!");
        }

        final VelocityContext context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", retailAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    //Create composite account
    @Test(dependsOnMethods = "getCompositeAccountRetailV2BeforeCreate")
    public void createCompositeAccountRetailV2() {
        //Generate Request body
        accNum = retailAccountMap.get("accountNumber");
        context.put("accountNumber", accNum);
        context.put("source", retailAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", retailAccountMap.get("sourceSystem"));
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "111111.11");
        context.put("isProductSuitable", "false");
        context.put("suitabilityStatus", "UNSUITABLE");
        context.put("emergencyFundAmountValue", "111111.11");


        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";

        response = request.log().all().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(retailAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "accountDetail.emergencyFundAmount.value",
                        equalTo(111111.11f))
                .body(acctRoot + details + "isProductSuitable", equalTo(false));

        accountTestData
                .setAccountId1(response.jsonPath().getString(acctRoot + "account.accountId.id"));
    }

    //Get Composite Account after create
    @Test(dependsOnMethods = "createCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterCreate() {
        //Generate Request body
        context.put("sourceBasedRegistrationFilter", retailAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(retailAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "accountDetail.emergencyFundAmount.value",
                        equalTo(111111.11f))
                .body(acctRoot + details + "isProductSuitable", equalTo(false))
                .body(acctRoot + details + "suitabilityStatus", equalTo("UNSUITABLE"));

    }

    //Update TAM
    @Test(dependsOnMethods = "getCompositeAccountRetailV2AfterCreate")
    public void updateCompositeAccountRetailV2() {
        //Generate Request body
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", retailAccountMap.get("accountNumber"));
        context.put("source", retailAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("sourceSystem2", retailAccountMap.get("sourceSystem"));
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));
        context.put("detailValue", "211111.11");
        context.put("emergencyFundAmountValue", "211111.11");
        context.put("TAM_name", tamName);
        context.put("TAM_total_equity", tamTotalEquity);
        context.put("TAM_domestic_equity", tamDomesticEquity);
        context.put("TAM_foreign_equity", tamForeignEquity);
        context.put("TAM_bond", tamBond);
        context.put("TAM_cash", tamCash);
        context.put("TAM_category", tamCategory);
        context.put("TAM_repositoryTamId", tamRepositoryTamId);
        context.put("TAM_assetAllocationId", tamAssetAllocationId);


        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()));

        request.log().ifValidationFails().body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(retailAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "accountDetail.emergencyFundAmount.value",
                        equalTo(211111.11f))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].name", equalTo(tamName))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage", equalTo(tamTotalEquity))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage", equalTo(tamDomesticEquity))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage", equalTo(tamForeignEquity))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage", equalTo(tamBond))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage", equalTo(tamCash));
    }

    //Get call after update to validate TAM
    @Test(dependsOnMethods = "updateCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterUpdate() {
        //Generate Request body
        context.put("sourceBasedRegistrationFilter", retailAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber", equalTo(retailAccountMap.get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(retailAccountMap.get("sourceSystem")))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get("mnemonic")))
                .body(acctRoot + "account.institutionName", equalTo(retailAccountMap.get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(
                        retailAccountMap.get("sourceMarketAmountValue"))))
                .body(acctRoot + details + "accountDetail.emergencyFundAmount.value",
                        equalTo(211111.11f))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].name", equalTo(tamName))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage", equalTo(tamTotalEquity))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage", equalTo(tamDomesticEquity))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage", equalTo(tamForeignEquity))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='BOND'}.netPercentage", equalTo(tamBond))
                .body(acctRoot + details + "accountDetail.targetAssetMixes[0].assetAllocation.allocation.find{it.assetClass=='CASH'}.netPercentage", equalTo(tamCash));

    }

    //Delete composite account
    @Test(dependsOnMethods = "getCompositeAccountRetailV2AfterUpdate")
    public void deleteCompositeAccountRetailV2() {
        //Generate Request body
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", retailAccountMap.get("accountNumber"));
        context.put("source", retailAccountMap.get("sourceSystem"));
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get("displayName"));
        context.put("mnemonic", retailAccountMap.get("mnemonic"));
        context.put("institutionName", retailAccountMap.get("institutionName"));
        context.put("value", retailAccountMap.get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get("sourceMarketAsOfDate"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200);

        final String emptyResponse = response.jsonPath().getString("$");
        MatcherAssert.assertThat(emptyResponse, equalTo("[:]"));
    }

    //Get composite after delete
    @Test(dependsOnMethods = "deleteCompositeAccountRetailV2")
    public void getCompositeAccountRetailV2AfterDelete() {
        //Generate Request body
        context.put("sourceBasedRegistrationFilter", retailAccountMap.get("sourceSystem"));

        request.header(new Header("user-mid", accountTestData.getMid()))
                .header(new Header("user-retail-lid", accountTestData.getSsn()))
                .header(new Header("excludeExternalDataSources", "true"));

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown() {
        testDataUtil.closeSQLiteConnection();
    }

    /**
     * Returns the response of retrieving a retail account
     *
     * @param accountsCommonTestData test data
     * @return retailAccountMap
     */
    private static HashMap<String, String> getRetailAccountInformationV2(
            final AccountsCommonTestData accountsCommonTestData,
            final String oAuth) {
        final VelocityContext context = new VelocityContext();
        context.put("source", "RETAIL");
        context.put("mnemonicFilter", "IRA");

        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();

        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);

        request.header(new Header("user-mid", accountsCommonTestData.getMid())).header(new Header("user-poe", "RETAIL"))
                .header(new Header("scenario-category-code", "DEF"))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()));

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        final Response response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        if (response.statusCode() != HTTPStatusCodes.STATUS_200) {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));

            return null;
        }

        final JsonPath retailAccountJP = response.jsonPath();

        final HashMap<String, String> retailAccountMap = new HashMap<>();
        retailAccountMap.put("accountNumber",
                retailAccountJP.getString("accountList[0].accountId.accountNumber"));
        retailAccountMap.put("sourceSystem",
                retailAccountJP.getString("accountList[0].accountId.sourceSystem"));
        retailAccountMap.put("displayName", retailAccountJP.getString("accountList[0].displayName"));
        retailAccountMap.put("mnemonic", retailAccountJP.getString("accountList[0].regCode.mnemonic"));
        retailAccountMap.put("institutionName", retailAccountJP.getString("accountList[0].institutionName"));
        retailAccountMap.put("sourceMarketAmountValue",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.value"));
        retailAccountMap.put("sourceMarketAmountValueType",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.valueType"));
        retailAccountMap.put("sourceMarketAmountCurrency",
                retailAccountJP.getString("accountList[0].sourceMarketValue.amount.currency"));
        retailAccountMap.put("sourceMarketAsOfDate",
                retailAccountJP.getString("accountList[0].sourceMarketValue.asOfDate"));

        return retailAccountMap;
    }
}