/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.get.fili;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import static com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.APP_ID;
import static com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.CALLING_APP_ID;

import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.is;

/**
 * Contains tests that validate additional data elements for the FILI Account
 * Composite operation
 *
 * @author a631781 Updated by a608077 for Defaulting SDPA/FDRA positions to
 *         bond.(PFCP-16920)
 */
@Test(groups = { Tags.FILI, Tags.ACCOUNT, Tags.V1 })
public class FILI_AdditionalAnnuityDataPoints extends PAPBaseServiceTest {

	protected FILI_AdditionalAnnuityDataPoints() {
		super(Services.Account);
	}

	private String accountNumber;
	private String ssn;
	public static final String ACCOUNT_CATEGORY = "Annuity";
	private static final String LOG_TRACKING_ID = FILI_AdditionalAnnuityDataPoints.class.getSimpleName();
	private static final String FSREQID = LOG_TRACKING_ID;
	private static final String APP_NAME = "Advice and Planning Platform";
	private Response accountResponse;
	private final String oAuth = AccountUtil.getOauthToken();
	private TestDataUtil testDataUtil;
	private VelocityContext context;
	private String deferredAnnuityIndicatorDSS;
	private Boolean isTaxQualifiedDSS;
	private Long maturityDateDSS;
	private Integer surrenderChargeFreeDateDSS;
	private Float guaranteedInterestRateDSS;
	private String guaranteePeriodDSS;
	private Integer guaranteedInterestRateEndDateDSS;
	private String productNameDSS;
	private String insuranceCompanyNameDSS;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on
	 * the default SSN, set up the endpoint for the test, and build the request body
	 * from Velocity.
	 */
	@BeforeClass
	public void init() {
		// Data setup
		AccountsCommonTestData accountsCommonTestData = TestDataUtil
				.populateRegressionTestData("account_get_FILI_Reg_Code_T_85", oAuth);

		String mid = accountsCommonTestData.getMid();
		DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


		ssn = accountsCommonTestData.getSsn();
		testDataUtil = new TestDataUtil();

		this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

		// Populate request context with user IDs
		context = new VelocityContext();
		context.put("source", AccountConstants.FILI);
		context.put("mid", mid);

	}

	/**
	 * Test to get the DSS FILI account
	 * <p>
	 * Version V1
	 */
	@Test
	public void getDSS_FILIAccount_V2() {

		FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeadersForDSS();

		context.put("acctCategory", ACCOUNT_CATEGORY);

		request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

		response = request.log().ifValidationFails().post(AccountConstants.DSS_ACCOUNT_V2_PATH);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
				.body("acctDetails", not(emptyArray()))
				.body("acctDetails.find{it.annuityProductDetail.productName == 'Principal SPDA Plus'}.annuityProductDetail.productCode",
						equalTo("SPDA"));

		String acctSubTypeDSSAccount = "Fixed Deferred Annuity";
		accountNumber = response.path("acctDetails.find{it.acctSubType=='" + acctSubTypeDSSAccount + "'}.acctNum");

	}

	/**
	 * Test to get the DSS FILI Details
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = { "getDSS_FILIAccount_V2" })
	public void getDSS_FILIDetails_V2() {

		context.put("acctCategory", ACCOUNT_CATEGORY);
		context.put("accountNumber", accountNumber);
		String acctSubType = "Fixed Annuity";
		context.put("acctSubType", acctSubType);
		String filiSystem = "OCI";
		context.put("filiSystem", filiSystem);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_DETAILS_V2));

		request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

		response = request.log().ifValidationFails().post(AccountConstants.DSS_ACCOUNT_DETAILS_V2_PATH);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(200).body("balances", not(emptyArray()));

		accountNumber = response.path("balances[0].acctNum");
		deferredAnnuityIndicatorDSS = response.path("balances[0].annuityContractDetail.fixedVarInd");
		isTaxQualifiedDSS = response.path("balances[0].annuityContractDetail.taxQualifiedInd");
		maturityDateDSS = response.path("balances[0].annuityContractDetail.maturityDate");
		surrenderChargeFreeDateDSS = response
				.path("balances[0].annuityContractDetail.spdaContractDetail.surrenderChargeEndDate");
		guaranteedInterestRateDSS = response
				.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteedInterestRate");
		guaranteePeriodDSS = response.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteePeriod");
		guaranteedInterestRateEndDateDSS = response
				.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteedinterestRateEndDate");
		productNameDSS = response.path("balances[0].annuityContractDetail.productName");
		insuranceCompanyNameDSS = response.path("balances[0].annuityContractDetail.insuranceCompanyName");
	}

	/**
	 * Tests that Additional Annuity details data is brought back for Composite Fili
	 * account.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = { "getDSS_FILIDetails_V2" })
	public void getCompositeAccounts_V1() {
		FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		this.setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, this.oAuth);

		// Generate request body
		context.put("excludeExternalDataSources", "false");
		context.put("filiLid", ssn);
		context.put("pointOfEntry", "RETAIL");
		context.put("role", "FidCust");
		context.put("productCode", "IGE");
		context.put("categoryCode", "DEF");
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Call Account service
		accountResponse = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		accountResponse.then().log().ifValidationFails().statusCode(200).body("accounts", not(emptyArray()))
				.body("accounts[0].account.accountId.accountNumber", notNullValue())
				.body("accounts.find{it.details.productCode == 'SPDA'}.positions.position.financialInstrumentId.symbol.get(0)",
						equalTo("GBOND"))
				.body("accounts.find{it.details.productCode == 'SPDA'}.positions.position.financialInstrumentId.finstId.get(0)",
						equalTo(999999993));

	}

	/**
	 * Test to validate Account Details Annuity additional elements
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = { "getDSS_FILIDetails_V2" })
	public void validateResponse() {
		// Account Composite Details elements
		String deferredAnnuityIndicator = accountResponse.path("accounts.find{it.details.accountId.accountNumber=='"
				+ accountNumber + "'}.details.deferredAnnuityIndicator");
		Boolean isTaxQualified = accountResponse.path(
				"accounts.find{it.details.accountId.accountNumber=='" + accountNumber + "'}.details.isTaxQualified");
		String maturityDate = accountResponse.path(
				"accounts.find{it.details.accountId.accountNumber=='" + accountNumber + "'}.details.maturityDate");
		String surrenderChargeFreeDate = accountResponse.path("accounts.find{it.details.accountId.accountNumber=='"
				+ accountNumber + "'}.details.surrenderChargeFreeDate");
		Float guaranteedInterestRate = accountResponse.path("accounts.find{it.details.accountId.accountNumber=='"
				+ accountNumber + "'}.details.guaranteedInterestRate.value");
		String guaranteePeriod = accountResponse.path(
				"accounts.find{it.details.accountId.accountNumber=='" + accountNumber + "'}.details.guaranteePeriod");
		String guaranteedInterestRateEndDate = accountResponse
				.path("accounts.find{it.details.accountId.accountNumber=='" + accountNumber
						+ "'}.details.guaranteedInterestRateEndDate");
		String productName = accountResponse
				.path("accounts.find{it.details.accountId.accountNumber=='" + accountNumber + "'}.details.productName");
		String insuranceCompanyName = accountResponse.path("accounts.find{it.details.accountId.accountNumber=='"
				+ accountNumber + "'}.details.insuranceCompanyName");

		// Comparing Account Composite Details elements with DSS Details elements
		Assert.assertEquals(productName, productNameDSS);
		Assert.assertEquals(deferredAnnuityIndicator, deferredAnnuityIndicatorDSS);
		Assert.assertEquals(isTaxQualified, isTaxQualifiedDSS);
		Assert.assertEquals(maturityDate, (AccountUtil.parseDSSDate(maturityDateDSS)));
		Assert.assertEquals(insuranceCompanyName, insuranceCompanyNameDSS);
		Assert.assertEquals(guaranteedInterestRate, (guaranteedInterestRateDSS / 100));
		Assert.assertEquals(guaranteePeriod, guaranteePeriodDSS);
		Assert.assertEquals(guaranteedInterestRateEndDate,
				AccountUtil.parseDSSDate(guaranteedInterestRateEndDateDSS.longValue()));
		Assert.assertEquals(surrenderChargeFreeDate,
				(AccountUtil.parseDSSDate(surrenderChargeFreeDateDSS.longValue())));
	}

	/**
	 * Setting default headers for DSS Services
	 */
	private void setDefaultRequestHeadersForDSS() {
		this.request.given().header(new Header("AppId", "AP106532")).header(new Header("fsreqid", FSREQID))
				.header(new Header("Authorization", oAuth)).header(new Header("AppName", APP_NAME))
				.header(new Header("rtazlid", this.ssn)).header(new Header("rtazallrealmslids", "FILI=" + this.ssn))
				.header(new Header("FACSC", "ROLE=FidCust")).header(new Header("Content-Type", "application/json"));
	}

	/**
	 * Clean up method for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void closeDBConnections() {
		this.testDataUtil.closeSQLiteConnection();
	}
}
