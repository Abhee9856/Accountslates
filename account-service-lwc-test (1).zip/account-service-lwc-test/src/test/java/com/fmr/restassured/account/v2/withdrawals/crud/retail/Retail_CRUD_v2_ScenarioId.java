/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.withdrawals.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.empty;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsWithdrawalsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountWithdrawalsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.WithdrawalsDataProviderUtil;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;
import io.restassured.response.Response;

/**
 * Tests ScenarioID header implementation for Retail withdrawals against V2.
 *
 * @author a631781
 */
@Test(groups = {
        Tags.RETAIL,
        Tags.WITHDRAWALS,
        Tags.V2})
public class Retail_CRUD_v2_ScenarioId extends PAPBaseServiceTest {

    protected Retail_CRUD_v2_ScenarioId() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private String mid;

    private String ppid;

    private String mnemonic;

    private String accountNumber;

    private String accountId;

    private String sourceSystem;

    private String displayName;

    private float value;

    private String institutionName;

    private String asOfDate;

    private VelocityContext context;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String USD = "USD";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_CRUD_v2_ScenarioId.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private String scenarioId;
    private TestDataUtil testDataUtil;

    Response allScenarioIDs;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_CRUD_RK_Retail_68",oAuth);
        testDataUtil = new TestDataUtil();
        mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);
        // Get/Create ScenarioId
        allScenarioIDs = Scenario.getAllScenarios(mid, oAuth);
        scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null) {
            scenarioId = Scenario.createScenarioWithProductCode(mid, SCENARIO_PRODUCT_CODE, SCENARIO_CATEGORY_CODE,
                    oAuth);
        }

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-id", scenarioId))
                .header(new Header("excludeExternalDataSources", "false"));

        // Populate request context with user IDs
        context = new VelocityContext();

        context.put("ppid", ppid);
        context.put("source", "RETAIL");

    }

    /**
     * Get Retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);

        mnemonic = response.path("accountList[0].regCode.mnemonic");
        accountNumber = response.path("accountList[0].accountId.accountNumber");
        sourceSystem = response.path("accountList[0].accountId.sourceSystem");
        displayName = response.path("accountList[0].displayName");
        value = response.path("accountList[0].sourceMarketValue.amount.value");
        institutionName = response.path("accountList[0].institutionName");
        asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Create the Retail account. Save the account id.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount() {
        context.put("mnemonic", mnemonic);
        context.put("value", value);
        context.put("source", sourceSystem);
        context.put("accountNumber", accountNumber);
        context.put("displayName", displayName);
        context.put("institutionName", institutionName);
        context.put("asOfDate", asOfDate);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList[0].regCode.mnemonic", equalTo(mnemonic),
                        "accountList[0].accountId.accountNumber", equalTo(accountNumber));

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        context.put("accId", accountId);
    }

    /**
     * Validate the account was created correctly.
     */
    @Test(dependsOnMethods = "createRetailAccount")
    public void getRetailAccountAfterCreate() {
        // Generate request body
        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("accountList", not(empty()));

    }

    /**
     * The is the test flow. It iterates through the data provider, performing CRUD operations for each use case.
     *
     * @param data the test cases
     */
    @Test(dependsOnMethods = "createRetailAccount", dataProvider = "getRetailWithdrawalData",
            dataProviderClass = WithdrawalsDataProviderUtil.class)
    public void performCrudOperations(final AccountWithdrawalsTestData data) {
        this.createAccountWithdrawals(data);
        this.getWithdrawalsAfterCreate(data);
        this.updateAccountWithdrawals(data);
        this.getWithdrawalsAfterUpdate(data);
        this.deleteAccountWithdrawals(data);
        this.getWithdrawalsAfterDelete();
    }

    /**
     * Create the account withdrawals.
     */
    private void createAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("withdrawalType", data.getType());
        context.put("withdrawalValue", data.getAmountValue());
        context.put("valueType", data.getAmountValueType());
        context.put("frequency", data.getFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_V2_TEMPLATE))
                .log().ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()))
                .body("accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.withdrawalType", equalTo(data.getType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.value",
                        equalTo(Float.valueOf(data.getAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.currency", equalTo(USD),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.frequency", equalTo(data.getFrequency()));

    }

    /**
     * Validate the withdrawals.
     */
    private void getWithdrawalsAfterCreate(final AccountWithdrawalsTestData data) {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.withdrawalType", equalTo(data.getType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.value",
                        equalTo(Float.valueOf(data.getAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.amount.currency", equalTo(USD),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getFrequency() + "'}.amount.frequency", equalTo(data.getFrequency()));

    }

    /**
     * Update the withdrawal.
     */
    private void updateAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("withdrawalType", data.getUpdatedType());
        context.put("withdrawalValue", data.getUpdatedAmountValue());
        context.put("valueType", data.getUpdatedAmountValueType());
        context.put("frequency", data.getUpdatedFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_UPDATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.UPDATE_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.withdrawalType", equalTo(data.getUpdatedType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.value",
                        equalTo(Float.valueOf(data.getUpdatedAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.currency", equalTo(USD),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.frequency",
                        equalTo(data.getUpdatedFrequency()));
    }

    /**
     * Validate the withdrawal was updated.
     */
    private void getWithdrawalsAfterUpdate(final AccountWithdrawalsTestData data) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.withdrawalType", equalTo(data.getUpdatedType()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.value",
                        equalTo(Float.valueOf(data.getUpdatedAmountValue())),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.amount.currency", equalTo(USD),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                data.getUpdatedFrequency() + "'}.amount.frequency",
                        equalTo(data.getUpdatedFrequency()));

    }

    /**
     * Delete the withdrawal
     */
    private void deleteAccountWithdrawals(final AccountWithdrawalsTestData data) {
        // Generate request body
        context.put("withdrawalType", data.getUpdatedType());
        context.put("withdrawalValue", data.getUpdatedAmountValue());
        context.put("valueType", data.getUpdatedAmountValueType());
        context.put("frequency", data.getUpdatedFrequency());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_DELETE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.DELETE_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", nullValue());

    }

    /**
     * Validate the withdrawals were deleted.
     */
    private void getWithdrawalsAfterDelete() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", nullValue());

    }
    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
        this.testDataUtil.closeSQLiteConnection();
    }
}
