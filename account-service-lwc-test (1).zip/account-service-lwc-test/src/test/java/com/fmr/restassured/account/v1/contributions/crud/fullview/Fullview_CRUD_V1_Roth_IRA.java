/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.contributions.crud.fullview;

import com.fmr.ast.platform.account.domain.Contribution;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsContributionsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountContributionsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;


import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertFalse;

/**
 * Tests CRUD operation for Fullview contributions against V1 for isBackdoorRoth flag(PFCP-12448)
 *
 * @author a608077
 *
 */
@Test(groups = {Tags.FULLVIEW, Tags.CONTRIBUTIONS, Tags.V1})

public class Fullview_CRUD_V1_Roth_IRA extends PAPBaseServiceTest
{

	protected Fullview_CRUD_V1_Roth_IRA()
	{
		super(Services.Account);
	}

	private String mid;

	private String ppid;

	private String mnemonic;

	private String accountNumber;

	private String accountId;

	private String sourceSystem;

	private String displayName;

	private float value;

	private String institutionName;

	private String asOfDate;

	private VelocityContext context;

	private static final String MONEY = "MONEY";

	private static final String PERCENT = "PERCENT";

	private static final String CALLING_APP_ID = "AP136091";

	private static final String APP_ID = "AP136091";

	private static final String LOG_TRACKING_ID = Fullview_CRUD_V1_Roth_IRA.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();

		// Data setup
		AccountsCommonTestData accountsCommonTestData =
				TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Fullview", oAuth);

		mid = accountsCommonTestData.getMid();

		// Set default REST header with authorization token
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

		// Data cleanup
		DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


		// Set ppid
		ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);

		accountsCommonTestData.setPpid(ppid);

		// Populate request context with user IDs
		context = new VelocityContext();

		context.put(AccountConstants.MID, mid);
		context.put("ppid", ppid);
		context.put(AccountConstants.RETAIL_LID, accountsCommonTestData.getSsn());
		context.put("source", "FULLVIEW");
	}

	/**
	 * Get Fullview account info from the backend. Save the account number.
	 */
	@Test
	public void getFullviewAccountInfo()
	{
		context.put("mnemonicFilter", "IRA");
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", Matchers.equalTo(true))
                .body("accountList", not(emptyArray()));

		mnemonic = response.path("accountList[0].regCode.mnemonic");
		accountNumber = response.path("accountList[0].accountId.accountNumber");
		sourceSystem = response.path("accountList[0].accountId.sourceSystem");
		displayName = response.path("accountList[0].displayName");
		value = response.path("accountList[0].sourceMarketValue.amount.value");
		institutionName = response.path("accountList[0].institutionName");
		asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
	}

	/**
	 * Create the Fullview account. Save the account id.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "getFullviewAccountInfo")
	public void createFullviewAccount()
	{
		context.put("mnemonic", mnemonic);
		context.put("value", value);
		context.put("source", sourceSystem);
		context.put("accountNumber", accountNumber);
		context.put("displayName", displayName);
		context.put("institutionName", institutionName);
		context.put("asOfDate", asOfDate);

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode",
				Matchers.equalTo(true), "userIdentifier.mid", Matchers.equalTo(mid),
				"accountList[0].regCode.mnemonic", Matchers.equalTo(mnemonic),
				"accountList[0].accountId.accountNumber", Matchers.equalTo(accountNumber));

		// Gets and saves the CFP account ID
		accountId = response.path("accountList[0].accountId.id");
		context.put("accId", accountId);
	}

	/**
	 * Validate the account was created correctly.
	 */
	@Test(dependsOnMethods = "createFullviewAccount")
	public void getFullviewAccountAfterCreate()
	{
		// Generate request body
		context.put("externalDataSources", true);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode",
				Matchers.equalTo(true), "accountList", Matchers.not(empty()));

	}

	/**
	 * This is the test flow. It iterates through the data provider, performing CRUD operations for each use case.
	 *
	 */
	@Test(dependsOnMethods = "getFullviewAccountAfterCreate")
	public void performCrudOperations()
	{
		final AccountContributionsTestData data = new AccountContributionsTestData();
		this.createAccountContributions(data);
		this.getContributionsAfterCreate(data);
		this.updateAccountContributions(data);
		this.getContributionsAfterUpdate(data);
		this.deleteAccountContributions(data);
		this.getContributionsAfterDelete();
	}

	/**
	 * Create the account contributions.
	 * <p>
	 * Version V1
	 */
	private void createAccountContributions(final AccountContributionsTestData data)
	{

		// Generate request body
		context.put("contribValue", data.getContributionValue());
		context.put("valueType", data.getValueType());
		context.put("contribType", data.getContributionType());
		context.put("contribTaxType", data.getContributionTaxType());
		context.put("contribLevelType", data.getContributionLevelType());
		context.put("frequency", data.getFrequency());
		context.put("contributor", data.getContributor());
		context.put("isBackdoorRoth", "true");

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_TEMPLATE)).log().ifValidationFails();

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true))
		.body("userIdentifier.mid", equalTo(mid)).body("accountContributions", not(empty()))
		.body("accountContributions[0].isBackdoorRoth ", equalTo(true))
		.body("accountContributions[0].contributions.find{it.contribution.value=="
				+ data.getContributionValue() + "f}.contributionType",
				equalTo(data.getContributionType()),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ data.getContributionValue()
						+ "f}.contributionTaxType",
						equalTo(data.getContributionTaxType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ data.getContributionValue()
								+ "f}.contributionLevelType",
								equalTo(data.getContributionLevelType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ data.getContributionValue() + "f}.contributor",
										equalTo(data.getContributor()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ data.getContributionValue() + "f}.contribution.value",
												equalTo(Float.valueOf(data.getContributionValue())),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ data.getContributionValue() + "f}.frequency",
														equalTo(data.getFrequency()));

	}

	/**
	 * Validate the contributions.
	 * <p>
	 * Version V1
	 */
	private void getContributionsAfterCreate(final AccountContributionsTestData data)
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
				"userIdentifier.mid", equalTo(mid), "accountContributions[0].accountId.accountNumber",
				equalTo(accountNumber), "accountContributions[0].accountId.id", equalTo(accountId),
				"accountContributions[0].accountId.owner.id", equalTo(ppid),
				"accountContributions[0].isBackdoorRoth ", equalTo(true),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ data.getContributionValue() + "f}.contributionType",
						equalTo(data.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ data.getContributionValue() + "f}.contributionTaxType",
								equalTo(data.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ data.getContributionValue() + "f}.contributionLevelType",
										equalTo(data.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ data.getContributionValue() + "f}.contributor",
												equalTo(data.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ data.getContributionValue() + "f}.contribution.value",
														equalTo(Float.valueOf(data.getContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ data.getContributionValue() + "f}.frequency",
																equalTo(data.getFrequency()));

	}

	/**
	 * Update the contribution.
	 * <p>
	 * Version V1
	 */
	private void updateAccountContributions(final AccountContributionsTestData data)
	{
		// Generate request body
		context.put("contribType", data.getContributionType());
		context.put("contribTaxType", data.getContributionTaxType());
		context.put("contribLevelType", data.getContributionLevelType());
		context.put("frequency", data.getFrequency());
		context.put("contributor", data.getContributor());
		context.put("valueType", PERCENT);
		context.put("contribValue", data.getUpdatedContributionValue());
		context.put("isBackdoorRoth", "false");

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_UPDATE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.UPDATE_ACCOUNT_CONTRIBUTIONS_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
				"accountContributions[0].isBackdoorRoth ", equalTo(false),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ data.getUpdatedContributionValue() + "f}.contributionType",
						equalTo(data.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ data.getUpdatedContributionValue() + "f}.contributionTaxType",
								equalTo(data.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ data.getUpdatedContributionValue() + "f}.contributionLevelType",
										equalTo(data.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ data.getUpdatedContributionValue() + "f}.contributor",
												equalTo(data.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ data.getUpdatedContributionValue() + "f}.contribution.value",
														equalTo(Float.valueOf(data.getUpdatedContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ data.getUpdatedContributionValue() + "f}.contribution.valueType",
																equalTo(PERCENT),
																"accountContributions[0].contributions.find{it.contribution.value=="
																		+ data.getUpdatedContributionValue() + "f}.frequency",
																		equalTo(data.getFrequency()));
	}

	/**
	 * Validate the contribution was updated.
	 * <p>
	 * Version V1
	 */
	private void getContributionsAfterUpdate(final AccountContributionsTestData data)
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
				"accountContributions[0].isBackdoorRoth ", equalTo(false), "userIdentifier.mid",
				equalTo(mid), "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
				"accountContributions[0].accountId.id", equalTo(accountId),
				"accountContributions[0].accountId.owner.id", equalTo(ppid),
				"accountContributions[0].isBackdoorRoth ", equalTo(false),
				"accountContributions[0].contributions.find{it.contribution.value=="
						+ data.getUpdatedContributionValue() + "f}.contributionType",
						equalTo(data.getContributionType()),
						"accountContributions[0].contributions.find{it.contribution.value=="
								+ data.getUpdatedContributionValue() + "f}.contributionTaxType",
								equalTo(data.getContributionTaxType()),
								"accountContributions[0].contributions.find{it.contribution.value=="
										+ data.getUpdatedContributionValue() + "f}.contributionLevelType",
										equalTo(data.getContributionLevelType()),
										"accountContributions[0].contributions.find{it.contribution.value=="
												+ data.getUpdatedContributionValue() + "f}.contributor",
												equalTo(data.getContributor()),
												"accountContributions[0].contributions.find{it.contribution.value=="
														+ data.getUpdatedContributionValue() + "f}.contribution.value",
														equalTo(Float.valueOf(data.getUpdatedContributionValue())),
														"accountContributions[0].contributions.find{it.contribution.value=="
																+ data.getUpdatedContributionValue() + "f}.contribution.valueType",
																equalTo(PERCENT),
																"accountContributions[0].contributions.find{it.contribution.value=="
																		+ data.getUpdatedContributionValue() + "f}.frequency",
																		equalTo(data.getFrequency()));

		final List<String> list = response.jsonPath()
				.getList("accountContributions[0].contributions.contribution.valueType");
		assertFalse(list.contains(MONEY));

	}

	/**
	 * Delete the contribution
	 * <p>
	 * Version V1
	 */
	private void deleteAccountContributions(final AccountContributionsTestData data)
	{
		// Generate request body
		context.put("contribType", data.getContributionType());
		context.put("contribTaxType", data.getContributionTaxType());
		context.put("contribLevelType", data.getContributionLevelType());
		context.put("frequency", data.getFrequency());
		context.put("contributor", data.getContributor());
		context.put("valueType", PERCENT);
		context.put("contribValue", data.getUpdatedContributionValue());
		context.put("isBackdoorRoth", "false");

		request.body(IOUtil.generateJsonRequest(context,
				AccountConstants.ACCOUNT_CONTRIBUTIONS_DELETE_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.DELETE_ACCOUNT_CONTRIBUTIONS_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode",
				equalTo(true));

		final List<Contribution> contributions = response.jsonPath()
				.getList("accountContributions[0].contributions", Contribution.class);
		contributions.forEach(contribution -> {
			if (contribution.getContributionType().enumValue().equals(data.getContributionType())
					&& contribution.getContributionTaxType().enumValue()
					.equals(data.getContributionTaxType()))
			{
				Assert.fail();
			}
		});

	}

	/**
	 * Validate the contributions were deleted.
	 * <p>
	 * Version V1
	 */
	private void getContributionsAfterDelete()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
				.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
				"accountContributions", empty());

	}
}
