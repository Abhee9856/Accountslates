/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.suitability.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;

import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsSuitabilityPaths;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;

import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.pap.restassured.utilities.IOUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

/**
 * Tests CRUD operation for suitability against V1 for Retail accounts,
 * only with account level preferences and not other suitability questions (PFCP-6920)
 *
 * @author a608077
 * Updated by @author a631781 for story PFCP-10346
 */
@Test(groups = {Tags.RETAIL, Tags.SUITABILITY, Tags.V1, Tags.CRITICAL})
public class Retail_Suitability_Only_IAPreferences extends PAPBaseServiceTest {

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Suitability_CRUD.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;
    
    private String mid;// = "SuitabilityAccountV1TestMid";

    //Start and End years for accountPreferencesIA - both should be greater than the current year.
    int startYear = ZonedDateTime.now().plusYears(1).getYear();
    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    private static final String investmentObjectiveIA = "NONE";
    private static final String withdrawalNeeds = "NO_WITHDRAWAL";
    private static final String anticipatedExpenses = "LIKELY";
    private static final float annualWithdrawalPercent = 0.02f;
    private static final String updatedInvestmentObjectiveIA = "CONSERVATIVE";
    private static final String updatedWithdrawalNeeds = "CONSTANT_ANNUAL_WITHDRAWAL_LESS_THAN_EQUAL_TO_5";
    private static final String updatedAnticipatedExpenses = "SOMEWHAT_LIKELY";
    private static final float updatedAnnualWithdrawalPercent = 0.05f;


    private VelocityContext context;

    protected Retail_Suitability_Only_IAPreferences() {
        super(Services.Account);
    }

    /**
     * Initialization method used to populate the TestData object based on the  SSN, set up the endpoint
     * for the test, and initialize the request context for Velocity with global data.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_suitability_CRUD_Retail", oAuth);

       this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


        // create identity
        String ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);

        accountsCommonTestData.setPpid(ppid);
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        accountsCommonTestData.setSourceSystem1("RETAIL");

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("ppid", accountsCommonTestData.getPpid());

    }

    /**
     * Get retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
        		response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
        	Assert.assertEquals(dssResultCode, false);
        }

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
    }

    /**
     * Create the retail account in CFP. Save the account ID.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount() {
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()));

        // Gets and saves the CFP account ID
        accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
        context.put("accId", accountsCommonTestData.getAccountId1());
    }

    /**
     * Create the account suitability.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createRetailAccount")
    public void createAccountSuitability() {
        context.put("riskTolerance", 1);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("investmentObjectiveIA", investmentObjectiveIA);
        context.put("withdrawalNeeds", withdrawalNeeds);
        context.put("anticipatedExpenses", anticipatedExpenses);
        context.put("annualWithdrawalPercent", annualWithdrawalPercent);
        context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V1));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.CREATE_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()),
                        "accountSuitability[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountSuitability[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountSuitability[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accountSuitability[0].accountPreferencesIA", not(empty()),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.riskTolerance", equalTo(1),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.investmentObjectiveIA", equalTo(investmentObjectiveIA),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.withdrawalNeeds", equalTo(withdrawalNeeds),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.anticipatedExpenses", equalTo(anticipatedExpenses),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.annualWithdrawalPercent", equalTo(annualWithdrawalPercent));


    }

    /**
     * Validate the suitability.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountSuitability")
    public void getSuitabilityAfterCreate() {

        // Generate request body
        context.put("externalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()),
                        "accountSuitability[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountSuitability[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountSuitability[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accountSuitability[0].accountPreferencesIA", not(empty()),
                        "accountSuitability.find{it.accountId.id == '"+ accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.riskTolerance", equalTo(1),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.investmentObjectiveIA", equalTo(investmentObjectiveIA),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.withdrawalNeeds", equalTo(withdrawalNeeds),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.anticipatedExpenses", equalTo(anticipatedExpenses),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.annualWithdrawalPercent", equalTo(annualWithdrawalPercent));
    }

    /**
     * Update the suitability
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getSuitabilityAfterCreate")
    public void updateAccountSuitability() {
        // Update variables
        context.put("riskTolerance", 2);
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_25_AND_50");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("investmentObjectiveIA", updatedInvestmentObjectiveIA);
        context.put("withdrawalNeeds", updatedWithdrawalNeeds);
        context.put("anticipatedExpenses", updatedAnticipatedExpenses);
        context.put("annualWithdrawalPercent", updatedAnnualWithdrawalPercent);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_ONLY_PREFERENCES_CREATE_TEMPLATE_V1));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.UPDATE_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "accountSuitability[0].accountId.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accountSuitability[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountSuitability[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountSuitability[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accountSuitability[0].accountPreferencesIA", not(empty()),
                        "accountSuitability[0].accountPreferencesIA.riskTolerance", equalTo(2),
                        "accountSuitability[0].accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"),
                        "accountSuitability[0].accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.investmentObjectiveIA", equalTo(updatedInvestmentObjectiveIA),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.withdrawalNeeds", equalTo(updatedWithdrawalNeeds),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.anticipatedExpenses", equalTo(updatedAnticipatedExpenses),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.annualWithdrawalPercent", equalTo(updatedAnnualWithdrawalPercent));
    }

    /**
     * Validate the updated suitability.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountSuitability")
    public void getSuitabilityAfterUpdate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
                        "userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()),
                        "accountSuitability[0].accountId.accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accountSuitability[0].accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accountSuitability[0].accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        "accountSuitability[0].accountPreferencesIA", not(empty()),
                        "accountSuitability[0].accountPreferencesIA.riskTolerance", equalTo(2),
                        "accountSuitability[0].accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"),
                        "accountSuitability[0].accountPreferencesIA.withdrawalStartYear", equalTo(startYear),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.withdrawalEndYear", equalTo(endYear),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.investmentObjectiveIA", equalTo(updatedInvestmentObjectiveIA),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.withdrawalNeeds", equalTo(updatedWithdrawalNeeds),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.anticipatedExpenses", equalTo(updatedAnticipatedExpenses),
                        "accountSuitability.find{it.accountId.id == '" + accountsCommonTestData.getAccountId1() + "'}.accountPreferencesIA.annualWithdrawalPercent", equalTo(updatedAnnualWithdrawalPercent));
    }

    /**
     * Delete the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getSuitabilityAfterUpdate")
    public void deleteAccount() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

    }

    /**
     * Validate no suitability is returned.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccount")
    public void getSuitabilityAfterDelete() {

        context.put("externalDataSources", true);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountSuitability", empty());

    }
}
