/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.relations.crud.workplace;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.not;

import com.fmr.ast.platform.account.domain.RelatedEntityType;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsRelationsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.utilities.RelationsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRelationsTestData;

import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.http.Header;

/**
 * Tests CRUD operation for workplace relations for multiple accounts against V2.
 *
 * @author a653510
 *
 */
@Test(groups = {Tags.WORKPLACE, Tags.RELATIONS, Tags.V2})
public class Workplace_Relations_CRUD_V2_multiple_accounts extends PAPBaseServiceTest
{

	// Data setup
	private AccountsCommonTestData accountsCommonTestData;

	private String accountId;

	private final VelocityContext context = new VelocityContext();
	private final TestDataUtil testDataUtil = new TestDataUtil();

	private static final String IGE = "IGE";
	private static final String DEF = "DEF";

	private static final String CALLING_APP_ID = "AP136091";
	private static final String APP_ID = "AP136091";
	private static final String LOG_TRACKING_ID = Workplace_Relations_CRUD_V2_multiple_accounts.class.getSimpleName();
	private static final String FSREQID = LOG_TRACKING_ID;

	private String mnemonic;
	private String accountNumber;
	private String sourceSystem;
	private String displayName;
	private float value;
	private String institutionName;
	private String asOfDate;

	private String mid;// = "WorkplaceRelationsV2TestMid";

	protected Workplace_Relations_CRUD_V2_multiple_accounts()
	{
		super(Services.Account);
	}

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the SSN, set up the endpoint for the
	 * test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
		accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_CRUD_RK_Workplace_69",oAuth);
	  	mid = accountsCommonTestData.getMid();
  	this.accountsCommonTestData.setMid(mid);
		DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");

		String ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);

		this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

		this.request.given().header(new Header("user-poe", "NETBENEFITS"))
		        .header(new Header("user-mid", this.accountsCommonTestData.getMid()))
		        .header(new Header("user-fesco-lid", this.accountsCommonTestData.getSsn()))
		        .header(new Header("scenario-product-code", IGE))
				.header(new Header("scenario-category-code", DEF));

		// Populate request variables
		this.context.put(AccountConstants.MID, mid);
		this.context.put("source", AccountConstants.WORKPLACE);
		this.context.put("ppid", ppid);

	}

	/**
	 * Get account info from the backend. Save the account number.
	 */
	@Test
	public void getWorkplaceAccountInfo()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

		mnemonic = response.path("accountList[0].regCode.mnemonic");
		accountNumber = response.path("accountList[0].accountId.accountNumber");
		sourceSystem = response.path("accountList[0].accountId.sourceSystem");
		displayName = response.path("accountList[0].displayName");
		value = response.path("accountList[0].sourceMarketValue.amount.value");
		institutionName = response.path("accountList[0].institutionName");
		asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");

		// Using testData to hold data for 2nd account
		accountsCommonTestData.setMnemonic1(response.path("accountList[1].regCode.mnemonic"));
		accountsCommonTestData.setAccountNumber1(response.path("accountList[1].accountId.accountNumber"));
		accountsCommonTestData.setSourceSystem1(response.path("accountList[1].accountId.sourceSystem"));
		accountsCommonTestData.setDisplayName1(response.path("accountList[1].displayName"));
		accountsCommonTestData.setValue1(response.path("accountList[1].sourceMarketValue.amount.value"));
		accountsCommonTestData.setInstitutionName1(response.path("accountList[1].institutionName"));
		accountsCommonTestData.setAsOfDate1((null != response.path("accountList[1].sourceMarketValue.asOfDate"))
		        ? response.path("accountList[1].sourceMarketValue.asOfDate")
		        : asOfDate);
	}

	/**
	 * Create the account.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "getWorkplaceAccountInfo")
	public void createWorkplaceAccount()
	{
		// Account1
		context.put("mnemonic", mnemonic);
		context.put("value", value);
		context.put("source", sourceSystem);
		context.put("accountNumber", accountNumber);
		context.put("displayName", displayName);
		context.put("institutionName", institutionName);
		context.put("asOfDate", asOfDate);

		// Account 2
		context.put("mnemonic2", accountsCommonTestData.getMnemonic1());
		context.put("value2", accountsCommonTestData.getValue1());
		context.put("source2", accountsCommonTestData.getSourceSystem1());
		context.put("accountNumber2", accountsCommonTestData.getAccountNumber1());
		context.put("displayName2", accountsCommonTestData.getDisplayName1());
		context.put("institutionName2", accountsCommonTestData.getInstitutionName1());
		context.put("asOfDate2", accountsCommonTestData.getAsOfDate1());

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
				"accountList.find{it.accountId.accountNumber=='" + accountNumber + "'}.regCode.mnemonic", equalTo(mnemonic),
		        "accountList.find{it.accountId.accountNumber=='" + accountNumber + "'}.accountId.accountNumber",
		        not(nullValue()), "accountList.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1()
		                + "'}.accountId.accountNumber",
		        not(nullValue()));

		// Gets and saves the CFP account ID
		accountId = response.path("accountList.find{it.accountId.accountNumber=='" + accountNumber + "'}.accountId.id");
		accountsCommonTestData.setAccountId1(response.path(
		        "accountList.find{it.accountId.accountNumber=='" + accountsCommonTestData.getAccountNumber1() + "'}.accountId.id"));

		context.put("accId", accountId);
		context.put("accId2", accountsCommonTestData.getAccountId1());
		this.request.given().header(new Header("excludeExternalDataSources", "true"));
	}

	/**
	 * Create account relations.
	 */
	@Test(dependsOnMethods = "createWorkplaceAccount", dataProvider = "getWorkplaceRelationsData", dataProviderClass = RelationsDataProviderUtil.class)
	public void createAccountRelations(final AccountRelationsTestData data)
	{
		// Generate request body
		context.put("beneficiaryAllocation", data.getBeneficiaryAllocationPct());
		context.put("roleType", data.getRoleType());
		context.put("entityType", data.getEntityType());

		context.put("beneficiaryAllocation2", data.getBeneficiaryAllocationPct2());
		context.put("roleType2", data.getRoleType2());
		context.put("entityType2", data.getEntityType2());

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_CREATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsRelationsPaths.CREATE_ACCOUNT_RELATIONS_V2);
		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		        "accountRelations.find{it.accountId=='" + accountId + "'}", not(nullValue()),
		        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1() + "'}", not(nullValue()));

		this.assertOnCreate(data);

	}

	/**
	 * Validate the relations after create.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "createAccountRelations", dataProvider = "getWorkplaceRelationsData", dataProviderClass = RelationsDataProviderUtil.class)
	public void getRelationsAfterCreate(final AccountRelationsTestData data)
	{
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		        "accountRelations.find{it.accountId=='" + accountId + "'}", not(nullValue()),
		        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1() + "'}", not(nullValue()));

		this.assertOnCreate(data);
	}

	/**
	 * Update the account relations.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "getRelationsAfterCreate", dataProvider = "getWorkplaceRelationsData", dataProviderClass = RelationsDataProviderUtil.class)
	public void updateAccountRelations(final AccountRelationsTestData data)
	{
		// Account 1
		context.put("beneficiaryAllocation", data.getUpdatedBeneficiaryAllocationPct());
		context.put("roleType", data.getRoleType());
		context.put("entityType", data.getEntityType());

		// Account 2
		context.put("beneficiaryAllocation2", data.getUpdatedBeneficiaryAllocationPct2());
		context.put("roleType2", data.getRoleType2());
		context.put("entityType2", data.getEntityType2());

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_UPDATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsRelationsPaths.UPDATE_ACCOUNT_RELATIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		        "accountRelations.find{it.accountId=='" + accountId + "'}", not(nullValue()),
		        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1() + "'}", not(nullValue()));

		this.assertOnUpdate(data);

	}

	/**
	 * Validate the updated relations.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "updateAccountRelations", dataProvider = "getWorkplaceRelationsData", dataProviderClass = RelationsDataProviderUtil.class)
	public void getRelationsAfterUpdate(final AccountRelationsTestData data)
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body(
		        "accountRelations.find{it.accountId=='" + accountId + "'}", not(nullValue()),
		        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1() + "'}", not(nullValue()));

		this.assertOnUpdate(data);

	}

	/**
	 * Delete the account relations.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "getRelationsAfterUpdate", dataProvider = "getWorkplaceRelationsData", dataProviderClass = RelationsDataProviderUtil.class)
	public void deleteAccountRelations(final AccountRelationsTestData data)
	{
		// Generate request body
		context.put("beneficiaryAllocation", data.getUpdatedBeneficiaryAllocationPct());
		context.put("roleType", data.getRoleType());
		context.put("entityType", data.getEntityType());

		context.put("beneficiaryAllocation2", data.getUpdatedBeneficiaryAllocationPct2());
		context.put("roleType2", data.getRoleType2());
		context.put("entityType2", data.getEntityType2());

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_DELETE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsRelationsPaths.DELETE_ACCOUNT_RELATIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

		this.assertOnDelete(data);
	}

	/**
	 * Validate the relations were deleted.
	 *
	 * Version V2
	 */
	@Test(dependsOnMethods = "deleteAccountRelations")
	public void getRelationsAfterDelete()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_RELATIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsRelationsPaths.GET_ACCOUNT_RELATIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("isEmpty()",
		        Matchers.is(true));

	}

	/**
	 *
	 * @param data
	 *            the test case data
	 */
	private void assertOnCreate(final AccountRelationsTestData data)
	{
		// Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
		// so assertions need to be handled differently.
		if (data.getEntityType().equals(RelatedEntityType.OWNER.toString()))
		{
			response.then().body(

			        // Assert on BeneficiaryAllocation
			        "accountRelations.find{it.accountId=='" + accountId
			                + "'}.relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
			        equalTo(data.getBeneficiaryAllocationPct()),

			        // Assert on RoleType
			        "accountRelations.find{it.accountId=='" + accountId
			                + "'}.relatedEntities.find{it.type=='OWNER'}.roleType",
			        equalTo(data.getRoleType()),

			        // Assert on EntityType
			        "accountRelations.find{it.accountId=='" + accountId
			                + "'}.relatedEntities.find{it.type=='OWNER'}.type",
			        equalTo(data.getEntityType()));
		}
		else
		{
			response.then().body(

			        // Assert on BeneficiaryAllocation
			        "accountRelations.find{it.accountId=='" + accountId + "'}.relatedEntities.find{it.roleType=='"
			                + data.getRoleType() + "'}.ownershipPercent",
			        equalTo(Float.valueOf(data.getBeneficiaryAllocationPct())),

			        // Assert on RoleType
			        "accountRelations.find{it.accountId=='" + accountId + "'}.relatedEntities.find{it.roleType=='"
			                + data.getRoleType() + "'}.roleType",
			        equalTo(data.getRoleType()),

			        // Assert on EntityType
			        "accountRelations.find{it.accountId=='" + accountId + "'}.relatedEntities.find{it.roleType=='"
			                + data.getRoleType() + "'}.type",
			        equalTo(data.getEntityType()));
		}
		if (data.getEntityType2().equals(RelatedEntityType.OWNER.toString()))
		{
			response.then().body(

			        // Assert on BeneficiaryAllocation
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
			        equalTo(data.getBeneficiaryAllocationPct2()),

			        // Assert on RoleType
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.type=='OWNER'}.roleType",
			        equalTo(data.getRoleType2()),

			        // Assert on EntityType
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.type=='OWNER'}.type",
			        equalTo(data.getEntityType2()));
		}
		else
		{
			response.then().body(

			        // Assert on BeneficiaryAllocation
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.roleType=='" + data.getRoleType2() + "'}.ownershipPercent",
			        equalTo(Float.valueOf(data.getBeneficiaryAllocationPct2())),

			        // Assert on RoleType
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.roleType=='" + data.getRoleType2() + "'}.roleType",
			        equalTo(data.getRoleType2()),

			        // Assert on EntityType
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.roleType=='" + data.getRoleType2() + "'}.type",
			        equalTo(data.getEntityType2()));

		}
	}

	/**
	 *
	 * @param data
	 *            the test case data
	 */
	private void assertOnUpdate(final AccountRelationsTestData data)
	{
		// Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
		// so assertions need to be handled differently.
		if (data.getEntityType().equals(RelatedEntityType.OWNER.toString()))
		{
			response.then().body(

			        // Assert on BeneficiaryAllocation
			        "accountRelations.find{it.accountId=='" + accountId
			                + "'}.relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
			        equalTo(data.getUpdatedBeneficiaryAllocationPct()),

			        // Assert on RoleType
			        "accountRelations.find{it.accountId=='" + accountId
			                + "'}.relatedEntities.find{it.type=='OWNER'}.roleType",
			        equalTo(data.getRoleType()),

			        // Assert on EntityType
			        "accountRelations.find{it.accountId=='" + accountId
			                + "'}.relatedEntities.find{it.type=='OWNER'}.type",
			        equalTo(data.getEntityType()));
		}
		else
		{
			response.then().body(

			        // Assert on BeneficiaryAllocation
			        "accountRelations.find{it.accountId=='" + accountId + "'}.relatedEntities.find{it.roleType=='"
			                + data.getRoleType() + "'}.ownershipPercent",
			        equalTo(Float.valueOf(data.getUpdatedBeneficiaryAllocationPct())),

			        // Assert on RoleType
			        "accountRelations.find{it.accountId=='" + accountId + "'}.relatedEntities.find{it.roleType=='"
			                + data.getRoleType() + "'}.roleType",
			        equalTo(data.getRoleType()),

			        // Assert on EntityType
			        "accountRelations.find{it.accountId=='" + accountId + "'}.relatedEntities.find{it.roleType=='"
			                + data.getRoleType() + "'}.type",
			        equalTo(data.getEntityType()));
		}
		if (data.getEntityType2().equals(RelatedEntityType.OWNER.toString()))
		{
			response.then().body(

			        // Assert on BeneficiaryAllocation
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.type=='OWNER'}.ownershipPercent",
			        equalTo(data.getUpdatedBeneficiaryAllocationPct2()),

			        // Assert on RoleType
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.type=='OWNER'}.roleType",
			        equalTo(data.getRoleType2()),

			        // Assert on EntityType
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.type=='OWNER'}.type",
			        equalTo(data.getEntityType2()));
		}
		else
		{
			response.then().body(

			        // Assert on BeneficiaryAllocation
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.roleType=='" + data.getRoleType2() + "'}.ownershipPercent",
			        equalTo(Float.valueOf(data.getUpdatedBeneficiaryAllocationPct2())),

			        // Assert on RoleType
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.roleType=='" + data.getRoleType2() + "'}.roleType",
			        equalTo(data.getRoleType2()),

			        // Assert on EntityType
			        "accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			                + "'}.relatedEntities.find{it.roleType=='" + data.getRoleType2() + "'}.type",
			        equalTo(data.getEntityType2()));

		}
	}

	private void assertOnDelete(final AccountRelationsTestData data)
	{
		// Owner is a unique case, where the rest of the elements are null (the owner is not a relation to themself)
		// so assertions need to be handled differently.
		if (data.getEntityType().equals(RelatedEntityType.OWNER.toString()))
		{
			response.then().body(
			        "accountRelations.find{it.accountId=='" + accountId + "'}.relatedEntities.find{it.type=='OWNER'}",
			        nullValue());
		}
		else
		{
			response.then().body("accountRelations.find{it.accountId=='" + accountId
			        + "'}.relatedEntities.find{it.roleType=='" + data.getRoleType() + "'}", nullValue());
		}
		if (data.getEntityType2().equals(RelatedEntityType.OWNER.toString()))
		{
			response.then().body("accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			        + "'}.relatedEntities.find{it.type=='OWNER'}", nullValue());
		}
		else
		{
			response.then().body("accountRelations.find{it.accountId=='" + accountsCommonTestData.getAccountId1()
			        + "'}.relatedEntities.find{it.roleType=='" + data.getRoleType2() + "'}", nullValue());
		}

	}
	/**
	 * Cleanup operation for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}
}