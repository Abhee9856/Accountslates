/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.contributions.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;
import static org.junit.Assert.assertFalse;

import com.fmr.ast.platform.account.domain.Contribution;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsContributionsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.utilities.ContributionsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountContributionsTestData;

import java.util.List;

import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operation for Retail contributions against V1.
 *
 * @author a601767 Updated by a608077 on 10/13/2021 to include changes for "scenario-id" header(PFCP-6168) Updated by
 * a631781 on 09/19/2022 to include changes for "Set method" (PFCP-9562)
 */
@Test(groups = {Tags.CRITICAL, Tags.RETAIL, Tags.CONTRIBUTIONS, Tags.V1})
public class Retail_CRUD_V1 extends PAPBaseServiceTest
{

    protected Retail_CRUD_V1()
    {
	super(Services.Account);
    }

    private String mid;//= "RetailContributionV1TestMid";

    private String ppid;

    private String mnemonic;

    private String accountNumber;

    private String accountId;

    private String sourceSystem;

    private String displayName;

    private float value;

    private String institutionName;

    private String asOfDate;

    private VelocityContext context;

    private static final String MONEY = "MONEY";

    private static final String PERCENT = "PERCENT";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_CRUD_V1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
     * endpoint for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();

	// Data setup
	AccountsCommonTestData accountsCommonTestData =
			TestDataUtil.populateRegressionTestData("accountCRUD_Retail", oAuth);

	this.mid = accountsCommonTestData.getMid();
	accountsCommonTestData.setMid(this.mid);

	// Set default REST header with authorization token
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	// Data cleanup
	DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth,"true");

	// Set ppid
	ppid = Identity.createHouseholdIdentity(AccountConstants.MID, mid, oAuth);

	accountsCommonTestData.setPpid(ppid);
	// Get/Create ScenarioId
	Response allScenarioIDs = Scenario.getAllScenarios(mid, oAuth);
	String scenarioId = allScenarioIDs.path("scenario[0].id").toString();
	if (scenarioId == null)
	{
	    scenarioId = Scenario.createScenarioWithProductCode(mid, "IGE", "DEF", oAuth);
	}

	// Populate request context with user IDs
	context = new VelocityContext();

	context.put(AccountConstants.MID, mid);
	context.put("ppid", ppid);
	context.put(AccountConstants.RETAIL_LID, accountsCommonTestData.getSsn());
	context.put("source", AccountConstants.RETAIL);
	context.put("scenarioId", scenarioId);
    }

    /**
     * Get Retail account info from the backend. Save the account number.
     */
    @Test
    public void getRetailAccountInfo()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    org.testng.Assert.assertEquals(dssResultCode, false);
        }

	mnemonic = response.path("accountList[0].regCode.mnemonic");
	accountNumber = response.path("accountList[0].accountId.accountNumber");
	sourceSystem = response.path("accountList[0].accountId.sourceSystem");
	displayName = response.path("accountList[0].displayName");
	value = response.path("accountList[0].sourceMarketValue.amount.value");
	institutionName = response.path("accountList[0].institutionName");
	asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
    }

    /**
     * Create the Retail account. Save the account id.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void createRetailAccount()
    {
	context.put("mnemonic", mnemonic);
	context.put("value", value);
	context.put("source", sourceSystem);
	context.put("accountNumber", accountNumber);
	context.put("displayName", displayName);
	context.put("institutionName", institutionName);
	context.put("asOfDate", asOfDate);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_CREATE_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
			"userIdentifier.mid", equalTo(mid), "accountList[0].regCode.mnemonic",
			equalTo(mnemonic), "accountList[0].accountId.accountNumber", equalTo(accountNumber));

	// Gets and saves the CFP account ID
	accountId = response.path("accountList[0].accountId.id");
	context.put("accId", accountId);
    }

    /**
     * Validate the account was created correctly.
     */
    @Test(dependsOnMethods = "createRetailAccount")
    public void getRetailAccountAfterCreate()
    {
	// Generate request body
	context.put("externalDataSources", true);

	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
			"accountList", not(empty()));

    }

    /**
     * This is the test flow. It iterates through the data provider, performing CRUD operations for each use case.
     *
     * @param data the test cases
     */
    @Test(dependsOnMethods = "getRetailAccountAfterCreate", dataProvider = "getRetailContributionData", dataProviderClass = ContributionsDataProviderUtil.class)
    public void performCrudOperations(final AccountContributionsTestData data)
    {
	this.createAccountContributions(data);
	this.getContributionsAfterCreate(data);
	this.updateAccountContributions(data);
	this.getContributionsAfterUpdate(data);
	this.setAccountContributions(data);
	this.getContributionsAfterSet(data);
	this.deleteAccountContributions(data);
	this.getContributionsAfterDelete();
    }

    /**
     * Create the account contributions.
     * <p>
     * Version V1
     */
    private void createAccountContributions(final AccountContributionsTestData data)
    {
	// Generate request body
	context.put("contribValue", data.getContributionValue());
	context.put("valueType", data.getValueType());
	context.put("contribType", data.getContributionType());
	context.put("contribTaxType", data.getContributionTaxType());
	context.put("contribLevelType", data.getContributionLevelType());
	context.put("frequency", data.getFrequency());
	context.put("contributor", data.getContributor());
	context.put("isDetailed", data.getIsDetailed());

	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_TEMPLATE)).log().ifValidationFails();

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true))
			.body("userIdentifier.mid", equalTo(mid)).body("accountContributions", not(empty()))
			.body("accountContributions[0].isDetailed ", equalTo(data.getIsDetailed()),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue() + "f}.contributionType",
					equalTo(data.getContributionType()),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue()
							+ "f}.contributionTaxType",
					equalTo(data.getContributionTaxType()),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue()
							+ "f}.contributionLevelType",
					equalTo(data.getContributionLevelType()),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue() + "f}.contributor",
					equalTo(data.getContributor()),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue() + "f}.contribution.value",
					equalTo(Float.valueOf(data.getContributionValue())),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue() + "f}.frequency",
					equalTo(data.getFrequency()));

    }

    /**
     * Validate the contributions.
     * <p>
     * Version V1
     */
    private void getContributionsAfterCreate(final AccountContributionsTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
			not(empty()), "accountContributions[0].isDetailed ", equalTo(data.getIsDetailed()),
			"resultCode", equalTo(true), "userIdentifier.mid", equalTo(mid),
			"accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
			"accountContributions[0].accountId.id", equalTo(accountId),
			"accountContributions[0].accountId.owner.id", equalTo(ppid),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.contributionType",
			equalTo(data.getContributionType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.contributionTaxType",
			equalTo(data.getContributionTaxType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.contributionLevelType",
			equalTo(data.getContributionLevelType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.contributor",
			equalTo(data.getContributor()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.contribution.value",
			equalTo(Float.valueOf(data.getContributionValue())),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.frequency",
			equalTo(data.getFrequency()));

    }

    /**
     * Update the contribution.
     * <p>
     * Version V1
     */
    private void updateAccountContributions(final AccountContributionsTestData data)
    {
	// Generate request body
	context.put("contribType", data.getContributionType());
	context.put("contribTaxType", data.getContributionTaxType());
	context.put("contribLevelType", data.getContributionLevelType());
	context.put("frequency", data.getFrequency());
	context.put("contributor", data.getContributor());
	context.put("valueType", PERCENT);
	context.put("contribValue", data.getUpdatedContributionValue());
	context.put("isDetailed", data.getUpdatedIsDetailed());

	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_CONTRIBUTIONS_UPDATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsContributionsPaths.UPDATE_ACCOUNT_CONTRIBUTIONS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
			not(empty()), "accountContributions[0].isDetailed ",
			equalTo(data.getUpdatedIsDetailed()), "resultCode", equalTo(true),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contributionType",
			equalTo(data.getContributionType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contributionTaxType",
			equalTo(data.getContributionTaxType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contributionLevelType",
			equalTo(data.getContributionLevelType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contributor",
			equalTo(data.getContributor()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contribution.value",
			equalTo(Float.valueOf(data.getUpdatedContributionValue())),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contribution.valueType",
			equalTo(PERCENT),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.frequency",
			equalTo(data.getFrequency()));
    }

    /**
     * Validate the contribution was updated.
     * <p>
     * Version V1
     */
    private void getContributionsAfterUpdate(final AccountContributionsTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountContributions",
			not(empty()), "accountContributions[0].isDetailed ",
			equalTo(data.getUpdatedIsDetailed()), "resultCode", equalTo(true), "userIdentifier.mid",
			equalTo(mid), "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
			"accountContributions[0].accountId.id", equalTo(accountId),
			"accountContributions[0].accountId.owner.id", equalTo(ppid),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contributionType",
			equalTo(data.getContributionType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contributionTaxType",
			equalTo(data.getContributionTaxType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contributionLevelType",
			equalTo(data.getContributionLevelType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contributor",
			equalTo(data.getContributor()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contribution.value",
			equalTo(Float.valueOf(data.getUpdatedContributionValue())),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.contribution.valueType",
			equalTo(PERCENT),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getUpdatedContributionValue() + "f}.frequency",
			equalTo(data.getFrequency()));

	final List<String> list = response.jsonPath()
			.getList("accountContributions[0].contributions.contribution.valueType");
	assertFalse(list.contains(MONEY));

    }

    /**
     * Set the account contributions.
     * <p>
     * Version V1
     */
    private void setAccountContributions(final AccountContributionsTestData data)
    {
	// Generate request body
	context.put("contribValue", data.getContributionValue());
	context.put("valueType", data.getValueType());
	context.put("contribType", data.getContributionType());
	context.put("contribTaxType", data.getContributionTaxType());
	context.put("contribLevelType", data.getContributionLevelType());
	context.put("frequency", data.getFrequency());
	context.put("contributor", data.getContributor());
	context.put("excludeExternalDataSources", true);

	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_TEMPLATE)).log().ifValidationFails();

	// Call Account service
	response = request.log().ifValidationFails().post(AccountConstants.SET_ACCOUNT_CONTRIBUTIONS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
			.body("resultCode", Matchers.equalTo(true))
			.body("userIdentifier.mid", Matchers.equalTo(mid))
			.body("accountContributions", Matchers.not(empty()))
			.body("accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue() + "f}.contributionType",
					Matchers.equalTo(data.getContributionType()),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue()
							+ "f}.contributionTaxType",
					Matchers.equalTo(data.getContributionTaxType()),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue()
							+ "f}.contributionLevelType",
					Matchers.equalTo(data.getContributionLevelType()),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue() + "f}.contributor",
					Matchers.equalTo(data.getContributor()),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue() + "f}.contribution.value",
					Matchers.equalTo(Float.valueOf(data.getContributionValue())),
					"accountContributions[0].contributions.find{it.contribution.value=="
							+ data.getContributionValue() + "f}.frequency",
					Matchers.equalTo(data.getFrequency()));

    }

    /**
     * Validate the contributions after Set.
     * <p>
     * Version V1
     */
    private void getContributionsAfterSet(final AccountContributionsTestData data)
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
			"userIdentifier.mid", equalTo(mid), "accountContributions[0].accountId.accountNumber",
			equalTo(accountNumber), "accountContributions[0].accountId.id", equalTo(accountId),
			"accountContributions[0].accountId.owner.id", equalTo(ppid),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.contributionType",
			equalTo(data.getContributionType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.contributionTaxType",
			equalTo(data.getContributionTaxType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.contributionLevelType",
			equalTo(data.getContributionLevelType()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.contributor",
			equalTo(data.getContributor()),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.contribution.value",
			equalTo(Float.valueOf(data.getContributionValue())),
			"accountContributions[0].contributions.find{it.contribution.value=="
					+ data.getContributionValue() + "f}.frequency",
			equalTo(data.getFrequency()));

    }

    /**
     * Delete the contribution
     * <p>
     * Version V1
     */
    private void deleteAccountContributions(final AccountContributionsTestData data)
    {
	// Generate request body
	context.put("contribType", data.getContributionType());
	context.put("contribTaxType", data.getContributionTaxType());
	context.put("contribLevelType", data.getContributionLevelType());
	context.put("frequency", data.getFrequency());
	context.put("contributor", data.getContributor());
	context.put("valueType", PERCENT);
	context.put("contribValue", data.getUpdatedContributionValue());
	context.put("isDetailed", data.getUpdatedIsDetailed());

	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_CONTRIBUTIONS_DELETE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsContributionsPaths.DELETE_ACCOUNT_CONTRIBUTIONS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode",
			equalTo(true));

	final List<Contribution> contributions = response.jsonPath()
			.getList("accountContributions[0].contributions", Contribution.class);
	contributions.forEach(contribution -> {
	    if (contribution.getContributionType().enumValue().equals(data.getContributionType())
			    && contribution.getContributionTaxType().enumValue()
			    .equals(data.getContributionTaxType()))
	    {
		Assert.fail();
	    }
	});

    }

    /**
     * Validate the contributions were deleted.
     * <p>
     * Version V1
     */
    private void getContributionsAfterDelete()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context,
			AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails()
			.post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("resultCode", equalTo(true),
			"accountContributions", empty());

    }
}
