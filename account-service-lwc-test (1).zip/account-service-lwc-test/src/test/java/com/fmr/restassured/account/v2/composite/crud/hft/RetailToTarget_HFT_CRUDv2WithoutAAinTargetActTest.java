/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.hft;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;

import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;

import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import com.fmr.restassured.hypofundtransfer.helpers.AccountHelper;
import com.fmr.restassured.hypofundtransfer.helpers.HypotheticalFundTransferPaths;

import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;

import org.apache.velocity.VelocityContext;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;

/**
 * Creates funds transfer between retail and target account which doesn't have Asset Allocation and then fetches
 * postTransferBalances through get/composite call using header calculate-balances=FUND_TRANSFERS (PFCP-14340)
 *
 * @author a703000
 */
@Test(groups = {Tags.HYPO_FUND_TRANSFER, Tags.V2, Tags.TARGET_ACCOUNT, Tags.RETAIL, Tags.COMPOSITE})
public class RetailToTarget_HFT_CRUDv2WithoutAAinTargetActTest extends PAPBaseServiceTest {

    protected RetailToTarget_HFT_CRUDv2WithoutAAinTargetActTest() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private TestDataUtil testDataUtil;

    int startYear = ZonedDateTime.now().plusYears(1).getYear();

    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";

    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";

    private static final String isProductSuitable = "true";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID =
            RetailToTarget_HFT_CRUDv2WithoutAAinTargetActTest.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static float srcMktValFundingAccount, srcMktValDestAccount;

    private static final float domEquityAmount1 = 0;

    private static final float foreignEquityAmount1 = 0;

    private static final float bondAmount1 = 0;

    private static final float cashAmount1 = 10000;

    private static final float otherAmount1 = 0;

    private static final float unknownAmount = 20000;

    private final float totalAmount1 =
            domEquityAmount1 + foreignEquityAmount1 + bondAmount1 + cashAmount1 + otherAmount1 + unknownAmount;

    private FilterableRequestSpecification frs;

    //Context
    private final VelocityContext context = new VelocityContext();
    private final String host = AccountHelper.getQATestEnvHost();

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        String oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("retail_critical_regcode", oAuth);

        //Data setup
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("contribAmount", "6000.0");
        accountsCommonTestData.set("contribFreq", "YEARLY");
        accountsCommonTestData.set("withdrawAmount", "500.0");
        accountsCommonTestData.set("withdrawFreq", "YEARLY");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        accountsCommonTestData.set("updatedContribAmount", "500.0");
        accountsCommonTestData.set("updatedWithdrawAmount", "1000.0");
        accountsCommonTestData.set("updatedWithdrawFreq", "MONTHLY");

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        request.given()
                .header(new Header("user-poe", AccountConstants.RETAIL))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
        frs = (FilterableRequestSpecification) request;
    }

    /**
     * Get Retail account info from the backend. Save the account number.
     */
    public void getRetailAccountInfo() {
        //Setting Exclude external data sources flag
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "false"));

        // Generate request body
        context.put("source", AccountConstants.RETAIL);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(empty()));

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(50000);
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    /**
     * Get composite accounts for user.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getRetailAccountInfo")
    public void getCompositeAccount() {
        //Setting Exclude external data sources flag
        frs.removeHeader("excludeExternalDataSources");
        request.given()
                .header(new Header("excludeExternalDataSources", "true"));

        // Exclude external data
        context.put("sourceBasedRegistrationFilter", AccountConstants.RETAIL);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", empty());

    }

    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccount")
    public void createCompositeAccount() {
        // Generate request body
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("accId", "");
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("contribValue", accountsCommonTestData.get("contribAmount"));
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.50);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0);
        context.put("assetClass3", "CASH");
        context.put("netPercentage3", 0.25);
        context.put("assetClass4", "BOND");
        context.put("netPercentage4", 0.25);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

        // Make post request
        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", not(empty()));

        //Save account number and ID
        accountsCommonTestData.setAccountId1(response.path("accounts[0].account.accountId.id"));
        accountsCommonTestData.setAccountNumber1(response.path("accounts[0].account.accountId.accountNumber"));
        srcMktValFundingAccount = response.path("accounts[0].account.sourceMarketValue.amount.value");
    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void getCompositeAccountAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts[0].account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        "accounts[0].account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        "accounts[0].account.accountId.owner.id",
                        equalTo(accountsCommonTestData.getPpid()),
                        "accounts[0].account.displayName",
                        equalTo(accountsCommonTestData.getDisplayName1()),
                        "accounts[0].account.regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()),
                        "accounts[0].account.regCode.sourceSystem",
                        equalTo(accountsCommonTestData.getSourceSystem1()),
                        "accounts[0].account.institutionName",
                        equalTo(accountsCommonTestData.getInstitutionName1()),
                        "accounts[0].account.sourceMarketValue.amount.value",
                        equalTo(accountsCommonTestData.getValue1()),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation"
                                + ".find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation"
                                + ".find{it.assetClass='BOND'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.assetAllocation.allocation"
                                + ".find{it.assetClass='CASH'}.netPercentage.value",
                        equalTo(0f),
                        "accounts[0].suitability.investmentObjective.targetAssetMix.name",
                        equalTo("Short Term"),
                        "accounts[0].contributions.contributions[0].contribution.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("contribAmount"))),
                        "accounts[0].contributions.contributions[0].frequency",
                        equalTo(accountsCommonTestData.get("contribFreq")),
                        "accounts[0].withdrawals[0].amount.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
                        "accounts[0].withdrawals[0].amount.frequency",
                        equalTo(accountsCommonTestData.get("withdrawFreq")));
    }

    /**
     * Create a new target account. Save the account ID and account number.
     * <p>
     * Version V2
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterCreate")
    public void createTargetAccount() {

        final VelocityContext context = new VelocityContext();

        // Exclude external data
        context.put("sourceBasedRegistrationFilter", AccountConstants.RETAIL);
        // Generate request body
        context.put("source", AccountConstants.RETAIL);

        float fundingAccountAmount = totalAmount1;

        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("accId", "");
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("contribValue", accountsCommonTestData.get("contribAmount"));
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("contribFreq", accountsCommonTestData.get("contribFreq"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("fundingAccountAmount", String.valueOf(fundingAccountAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("category", "INVESTOR_SELECTED_STRATEGY");
        context.put("isProductSuitable", isProductSuitable);
        context.put("withdrawalNeeds", "TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6");
        context.put("withdrawalStartYear", startYear);
        context.put("withdrawalEndYear", endYear);
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_51_AND_75");
        context.put("riskTolerance", "8");
        context.put("cashAmount1", cashAmount1);
        context.put("unknownAmount", unknownAmount);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_V2_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts", empty())
                .body("targetAccounts", not(empty()))
                .body("targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount))
                .body("targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL))
                .body("targetAccounts[0].fundingAccounts[0].accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("targetAccounts[0].fundingAccounts[0].amount.value", equalTo(fundingAccountAmount))
                .body("targetAccounts[0].fundingAccounts[0].unknownAmount", equalTo(unknownAmount))
                .body("targetAccounts[0].targetAccountPreferences.withdrawalNeeds",
                        equalTo("TIME_TO_TIME_WITHDRAWAL_GREATER_THAN_6"))
                .body("targetAccounts[0].complementaryAdjustmentOption",
                        equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body("targetAccounts[0].isProductSuitable", equalTo(Boolean.valueOf(isProductSuitable)));

        //Save target account number and ID
        accountsCommonTestData
                .set(TARGET_ACCOUNT_NUMBER_KEY, response.path("targetAccounts[0].accountId.accountNumber"));
        accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
        srcMktValDestAccount = response.path("targetAccounts[0].sourceMarketValue.amount.value");
    }

    /**
     * Get details of Fund Transfer between Retail to Retail account after Create FT
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void getFundTransfersRetail2Retail() {
        response =
                request.baseUri(host).log().ifValidationFails()
                        .get(HypotheticalFundTransferPaths.HYPOFUNDTRNDFR_V1_PATH);
        validateResponse();

    }

    @Test(dependsOnMethods = "getFundTransfersRetail2Retail")
    public void getTransfersFromComposite() {
        FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
        frs.removeHeader("excludeExternalDataSources");

        context.put("sourceBasedRegistrationFilter", AccountConstants.RETAIL);
        context.put("includeFundTransferDetails", true);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Make post request
        response = request.log().ifValidationFails()
                .given()
                .header(new Header("excludeExternalDataSources", "true"))
                .header(new Header("calculate-balances", "fund-transfers"))
                .header(new Header("return-current-asset-allocation", "true"))
                .post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.HTTP_200)
                .body("accounts", CoreMatchers.not(Matchers.empty()))
                .body("transfers[0].fundingDetails[0].unknownAmount", CoreMatchers.equalTo(unknownAmount))
                .body("transfers[0].fundingDetails[0].cashAmount", CoreMatchers.equalTo(cashAmount1))
                .body("postTransferBalances", CoreMatchers.not(Matchers.empty()))
                .body("postTransferBalances[0].accountId.accountNumber",
                        CoreMatchers.equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("postTransferBalances[0].sourceMarketValue",
                        CoreMatchers.equalTo((srcMktValFundingAccount)))
                /*Target account transfer is already done when we create a target account and
                fund it via a funding account,so the value will remain same. **/
                .body("postTransferBalances[1].sourceMarketValue",
                        CoreMatchers.equalTo((srcMktValDestAccount)));
        validateResponse();

    }

    private void validateResponse() {

        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("transfers", CoreMatchers.not(Matchers.empty()))
                .body("transfers[0].fundingDetails[0].fundingAccountNumber", notNullValue())
                .body("transfers[0].fundingDetails[0].fundingAccountNumber",
                        CoreMatchers.equalTo(accountsCommonTestData.getAccountNumber1()))
                .body("transfers[0].destinationAccountNumber", notNullValue())
                .body("transfers[0].destinationAccountNumber",
                        CoreMatchers.equalTo(accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY)))
                .body("transfers[0].fundingDetails[0].cashAmount", notNullValue())
                .body("transfers[0].fundingDetails[0].transferType", CoreMatchers.equalTo("FULL_BALANCE"))
                .body("transfers[0].fundingDetails[0].totalAmount", notNullValue())
                .body("transfers[0].fundingDetails[0].unknownAmount", notNullValue());

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}