/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.contributions.crud.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsContributionsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountContributionsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.ContributionsDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.equalTo;
import static org.testng.AssertJUnit.assertFalse;

/**
 * Tests Workplace Contribution with different Contribution Basis Type
 *
 * @author a631781 | Sunita Arya
 */
@Test(groups = {
        Tags.CRITICAL,
        Tags.ASYNCHRONOUS,
        Tags.WORKPLACE,
        Tags.CONTRIBUTIONS,
        Tags.V2})
public class Workplace_Contribution_CriticalTests extends PAPBaseServiceTest {

    protected Workplace_Contribution_CriticalTests() {
        super(Services.Account);
    }

    private VelocityContext context;

    private TestDataUtil testDataUtil;

    private static final String callingAppId = "AP136091";

    private static final String appId = "AP136091";

    private static final String logTrackingId = Workplace_Contributions_WPP_CRUD_V2.class.getSimpleName();

    private static final String fsreqid = logTrackingId;

    private static final String MONEY = "MONEY";

    private static final String PERCENT = "PERCENT";

    private static final String updatedFrequency = "BIMONTHLY";
    private String mid;//= "WorkplaceContributionV2TestMid";

    // Data setup
    private AccountsCommonTestData accountsAccountsCommonTestData;

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {
        final String oAuth = AccountUtil.getOauthToken();

        accountsAccountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_contribution_Workplace", oAuth);
        mid = accountsAccountsCommonTestData.getMid();
        accountsAccountsCommonTestData.setMid(mid);
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsAccountsCommonTestData.getMid(), oAuth);

        accountsAccountsCommonTestData.setPpid(
                Identity.createHouseholdIdentity(AccountConstants.MID, accountsAccountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

        testDataUtil = new TestDataUtil();

        this.request.given()
                .header(new Header("user-poe", AccountConstants.NETBENEFITS))
                .header(new Header("user-mid", accountsAccountsCommonTestData.getMid()))
                .header(new Header("user-fesco-lid", accountsAccountsCommonTestData.getSsn()))
                .header(new Header("scenario-product-code", "IGE"))
                .header(new Header("scenario-category-code", "DEF"));

        //Populate request variables
        context = new VelocityContext();
        context.put("source", AccountConstants.WORKPLACE);
        request.header("return-workplace-overridden-contributions", true);
    }

    /**
     * Get Workplace account info from the backend. Save the account number.
     */
    @Test
    public void getWorkplaceAccountInfo() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList", not(empty()));

        accountsAccountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsAccountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsAccountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsAccountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsAccountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsAccountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsAccountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }

    @Test(dependsOnMethods = "getWorkplaceAccountInfo", dataProvider = "getWorkplaceContributionData",
            dataProviderClass = ContributionsDataProviderUtil.class)
    public void performCrudOperations(final AccountContributionsTestData testData) {
        this.createWorkplaceAccount();
        this.getWorkplaceAccountAfterCreate();
        this.createAccountContributions(testData);
        this.getContributionsAfterCreate(testData);
        this.updateAccountContributions(testData);
        this.getContributionsAfterUpdate(testData);
        this.deleteAccountContributions(testData);
        this.getContributionsAfterDelete();
        this.deleteWorkplaceAccount();
        this.getWorkplaceAccountAfterDelete();

    }


    /**
     * Create the Workplace account. Save the account id.
     * Version V2
     */

    private void createWorkplaceAccount() {
        context.put("mnemonic", accountsAccountsCommonTestData.getMnemonic1());
        context.put("value", accountsAccountsCommonTestData.getValue1());
        context.put("ppid", accountsAccountsCommonTestData.getPpid());
        context.put("source", accountsAccountsCommonTestData.getSourceSystem1());
        context.put("accountNumber", accountsAccountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsAccountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsAccountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsAccountsCommonTestData.getAsOfDate1());
        context.put("id", null);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList", not(empty()),
                        "accountList[0].accountId.accountNumber",
                        equalTo(accountsAccountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.owner.id", equalTo(accountsAccountsCommonTestData.getPpid()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsAccountsCommonTestData.getMnemonic1()),
                        "accountList[0].sourceMarketValue.amount.value",
                        equalTo(accountsAccountsCommonTestData.getValue1()));

        // Gets and saves the CFP account ID
        accountsAccountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
        context.put("accId", accountsAccountsCommonTestData.getAccountId1());
    }

    /**
     * Validate the account was created correctly.
     */

    private void getWorkplaceAccountAfterCreate() {
        //Setting Exclude external data sources flag
        this.request.given()
                .header(new Header("excludeExternalDataSources", "true"));
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList", not(empty()),
                        "accountList[0].accountId.accountNumber",
                        equalTo(accountsAccountsCommonTestData.getAccountNumber1()),
                        "accountList[0].accountId.owner.id", equalTo(accountsAccountsCommonTestData.getPpid()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsAccountsCommonTestData.getMnemonic1()),
                        "accountList[0].sourceMarketValue.amount.value",
                        equalTo(accountsAccountsCommonTestData.getValue1()));

    }

    /**
     * Create the account contributions.
     * Version V2
     */
    private void createAccountContributions(final AccountContributionsTestData testData) {
        // Generate request body
        context.put("contribValue", testData.getContributionValue());
        context.put("valueType", testData.getValueType());
        context.put("contribType", testData.getContributionType());
        context.put("contribTaxType", testData.getContributionTaxType());
        context.put("contribLevelType", testData.getContributionLevelType());
        context.put("frequency", testData.getFrequency());
        context.put("contributor", testData.getContributor());
        /** wpp contribution fields */
        context.put("contribBasisTypeCd", testData.getContribBasisTypeCd1());
        context.put("contributionName", testData.getContributionName());
        context.put("electionCd", testData.getElectionCd());
        context.put("contributionMaxRateValue", testData.getContributionMaxRateValue());
        context.put("contributionMaxRateValueType", testData.getContributionMaxRateValueType());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_V2_TEMPLATE));

        // Call Account service
        response =
                request.log().ifValidationFails().post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountContributions", not(empty()))
                .body("accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionType",
                        equalTo(testData.getContributionType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionTaxType",
                        equalTo(testData.getContributionTaxType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionLevelType",
                        equalTo(testData.getContributionLevelType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributor", equalTo(testData.getContributor()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contribution.value",
                        equalTo(Float.valueOf(testData.getContributionValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.frequency", equalTo(testData.getFrequency()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contribBasisTypeCd",
                        equalTo(testData.getContribBasisTypeCd1()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionName",
                        equalTo(testData.getContributionName()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.electionCd", equalTo(testData.getElectionCd()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionMaxRate.value",
                        equalTo(Float.valueOf(testData.getContributionMaxRateValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionMaxRate.valueType",
                        equalTo(testData.getContributionMaxRateValueType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionId", notNullValue());
        testData.setContributionId(response.path("accountContributions[0].contributions.find{it.contribution.value==" +
                testData.getContributionValue() + "f}.contributionId"));

    }

    /**
     * Validate the contributions.
     * <p>
     * Version V2
     */

    private void getContributionsAfterCreate(final AccountContributionsTestData testData) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountContributions[0].accountId.accountNumber",
                        equalTo(accountsAccountsCommonTestData.getAccountNumber1()),
                        "accountContributions[0].accountId.id", equalTo(accountsAccountsCommonTestData
                                .getAccountId1()),
                        "accountContributions[0].accountId.owner.id", equalTo(accountsAccountsCommonTestData
                                .getPpid()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionType",
                        equalTo(testData.getContributionType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionTaxType",
                        equalTo(testData.getContributionTaxType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionLevelType",
                        equalTo(testData.getContributionLevelType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributor", equalTo(testData
                                .getContributor()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contribution.value",
                        equalTo(Float.valueOf(testData.getContributionValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.frequency", equalTo(testData.getFrequency()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contribBasisTypeCd",
                        equalTo(testData.getContribBasisTypeCd1()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionName",
                        equalTo(testData.getContributionName()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.electionCd", equalTo(testData.getElectionCd()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionMaxRate.value",
                        equalTo(Float.valueOf(testData.getContributionMaxRateValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionMaxRate.valueType",
                        equalTo(testData.getContributionMaxRateValueType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionId", notNullValue());

    }

    /**
     * Update the contribution.
     * <p>
     * Version V2
     */
    private void updateAccountContributions(final AccountContributionsTestData testData) {
        // Generate request body
        context.put("contribType", testData.getContributionType());
        context.put("contribTaxType", testData.getContributionTaxType());
        context.put("contribLevelType", testData.getContributionLevelType());
        context.put("frequency", updatedFrequency);
        context.put("contributor", testData.getContributor());
        context.put("valueType", PERCENT);
        context.put("contribValue", testData.getUpdatedContributionValue());
        context.put("contributionMaxRateValue", testData.getUpdatedContributionMaxRateValue());
        context.put("contributionMaxRateValueType", testData.getContributionMaxRateValueType());
        /** The wpp contribution fields cannot be updated. but these fields are used in
         * procedure to get the record*/
        context.put("contribBasisTypeCd", testData.getContribBasisTypeCd1());
        context.put("contributionName", testData.getContributionName());
        context.put("electionCd", testData.getElectionCd());
        context.put("contributionId", testData.getContributionId());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_UPDATE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.UPDATE_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionType",
                        equalTo(testData.getContributionType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionTaxType",
                        equalTo(testData.getContributionTaxType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionLevelType",
                        equalTo(testData.getContributionLevelType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributor",
                        equalTo(testData.getContributor()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribution.value",
                        equalTo(Float.valueOf(testData.getUpdatedContributionValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribution.valueType", equalTo
                                (PERCENT),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.frequency", equalTo(updatedFrequency),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribBasisTypeCd",
                        equalTo(testData.getContribBasisTypeCd1()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionName",
                        equalTo(testData.getContributionName()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionMaxRate.value",
                        equalTo(Float.valueOf(testData.getUpdatedContributionMaxRateValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionMaxRate.valueType",
                        equalTo(testData.getContributionMaxRateValueType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.electionCd",
                        equalTo(testData.getElectionCd()));
    }

    /**
     * Validate the contribution was updated.
     * <p>
     * Version V2
     */

    private void getContributionsAfterUpdate(final AccountContributionsTestData testData) {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountContributions[0].accountId.accountNumber",
                        equalTo(accountsAccountsCommonTestData.getAccountNumber1()),
                        "accountContributions[0].accountId.id", equalTo(accountsAccountsCommonTestData
                                .getAccountId1()),
                        "accountContributions[0].accountId.owner.id", equalTo(accountsAccountsCommonTestData
                                .getPpid()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionType",
                        equalTo(testData.getContributionType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionTaxType",
                        equalTo(testData.getContributionTaxType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionLevelType",
                        equalTo(testData.getContributionLevelType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributor",
                        equalTo(testData.getContributor()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribution.value",
                        equalTo(Float.valueOf(testData.getUpdatedContributionValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribution.valueType", equalTo
                                (PERCENT),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.frequency", equalTo(updatedFrequency),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionId", notNullValue(),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionMaxRate.value",
                        equalTo(Float.valueOf(testData.getUpdatedContributionMaxRateValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionMaxRate.valueType",
                        equalTo(testData.getContributionMaxRateValueType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribBasisTypeCd",
                        equalTo(testData.getContribBasisTypeCd1()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionName",
                        equalTo(testData.getContributionName()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.electionCd",
                        equalTo(testData.getElectionCd()));

        final List<String> list =
                response.jsonPath().getList("accountContributions[0].contributions.contribution.valueType");
        assertFalse(list.contains(MONEY));

    }

    /**
     * Delete the contribution
     * <p>
     * Version V2
     */
    private void deleteAccountContributions(final AccountContributionsTestData testData) {
        // Generate request body
        context.put("contribType", testData.getContributionType());
        context.put("contribTaxType", testData.getContributionTaxType());
        context.put("contribLevelType", testData.getContributionLevelType());
        context.put("frequency", updatedFrequency);
        context.put("contributor", testData.getContributor());
        context.put("valueType", PERCENT);
        context.put("contribValue", testData.getUpdatedContributionValue());
        context.put("contribMaxRteVal", testData.getUpdatedContributionMaxRateValue());
        // context.put("contribMaxRteValUomCd", testData.getUpdatedContribMaxRteValUomCd());
        /** wpp contribution fields - SP deletes contribution tier data using these fields,
         * We don't have service to validate the tier data deletion. Let's assume, it deletes! */
        context.put("contribBasisTypeCd", testData.getContribBasisTypeCd1());
        context.put("contributionName", testData.getContributionName());
        context.put("electionCd", testData.getElectionCd());

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_DELETE_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.DELETE_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("isEmpty()", Matchers.is(true));

    }

    /**
     * Validate the contributions were deleted.
     * <p>
     * Version V2
     */

    private void getContributionsAfterDelete() {

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths
                .GET_ACCOUNT_CONTRIBUTIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("isEmpty()", Matchers.is(true));

    }

    /**
     * Delete the account.
     * <p>
     * Version V2
     */

    private void deleteWorkplaceAccount() {

        context.put("id", accountsAccountsCommonTestData.getAccountId1());
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("isEmpty()", Matchers.is(true));
    }

    /**
     * Validate the account was deleted.
     * Version V2
     */

    private void getWorkplaceAccountAfterDelete() {

        this.request.given()
                .header(new Header("excludeExternalDataSources", "true"));

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("isEmpty()", Matchers.is(true));
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}
