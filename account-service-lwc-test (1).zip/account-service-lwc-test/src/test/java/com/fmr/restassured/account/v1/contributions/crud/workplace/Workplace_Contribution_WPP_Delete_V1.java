/*
 * Copyright 2022, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.contributions.crud.workplace;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsContributionsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountContributionsTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;

/**
 * Tests Delete operation when multiple contribution are present and only only being deleted for Workplace
 * contributions against V2.
 *
 * @author a631781 | Sunita Arya
 */
@Test(groups = {
        Tags.ASYNCHRONOUS,
        Tags.WORKPLACE,
        Tags.CONTRIBUTIONS,
        Tags.V1})

public class Workplace_Contribution_WPP_Delete_V1 extends PAPBaseServiceTest
{
    
    protected Workplace_Contribution_WPP_Delete_V1()
    {
        super(Services.Account);
    }
    
    private VelocityContext context;
    
    private TestDataUtil testDataUtil;
    
    private static final String callingAppId = "AP136091";
    
    private static final String appId = "AP136091";
    
    private static final String logTrackingId = Workplace_Contributions_WPP_CRUD_V1.class.getSimpleName();
    
    private static final String fsreqid = logTrackingId;
    
    private static final String MONEY = "MONEY";
    
    private static final String PERCENT = "PERCENT";
    
    private static final String updatedFrequency = "BIMONTHLY";

    private String mid;//= "WorkplaceContributionV1TestMid";
   
    // Data setup
    private final AccountContributionsTestData testData = new AccountContributionsTestData();
    
    private AccountsCommonTestData accountsTestData;
    
    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
        final String oAuth = AccountUtil.getOauthToken();
        accountsTestData =
                TestDataUtil.populateRegressionTestData("account_contribution_Workplace", oAuth);
        mid = accountsTestData.getMid();
        accountsTestData.setMid(this.mid);
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsTestData.getMid(), oAuth, "true");
        
        accountsTestData
                .setPpid(Identity.createHouseholdIdentity(AccountConstants.MID, accountsTestData.getMid(), oAuth));
        
        setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);
        
        testDataUtil = new TestDataUtil();
        
        // Populate request context with user IDs
        context = new VelocityContext();
        
        context.put("mid", accountsTestData.getMid());
        context.put("ppid", accountsTestData.getPpid());
        context.put("source", AccountConstants.WORKPLACE);
        context.put("poe", AccountConstants.NETBENEFITS);
        context.put("mid", accountsTestData.getMid());
        context.put("fescoLid", accountsTestData.getSsn());
        request.header("return-workplace-overridden-contributions", true);
    }
    
    /**
     * Get Workplace account info from the backend. Save the account number.
     */
    @Test
    public void getWorkplaceAccountInfo()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("accountList", not(empty()));
        
        accountsTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }
    
    /**
     * Create the Workplace account. Save the account id.
     * Version V1
     */
    @Test(dependsOnMethods = "getWorkplaceAccountInfo")
    public void createWorkplaceAccount()
    {
        
        context.put("mnemonic", accountsTestData.getMnemonic1());
        context.put("value", accountsTestData.getValue1());
        context.put("source", accountsTestData.getSourceSystem1());
        context.put("accountNumber", accountsTestData.getAccountNumber1());
        context.put("displayName", accountsTestData.getDisplayName1());
        context.put("institutionName", accountsTestData.getInstitutionName1());
        context.put("asOfDate", accountsTestData.getAsOfDate1());
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsTestData.getMid()),
                        "accountList", not(empty()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsTestData.getAccountNumber1()),
                        "accountList[0].accountId.owner.id", equalTo(accountsTestData.getPpid()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsTestData.getMnemonic1()),
                        "accountList[0].sourceMarketValue.amount.value", equalTo(accountsTestData.getValue1()));
        
        // Gets and saves the CFP account ID
        accountsTestData.setAccountId1(response.path("accountList[0].accountId.id"));
        context.put("accId", accountsTestData.getAccountId1());
    }
    
    /**
     * Validate the account was created correctly.
     */
    @Test(dependsOnMethods = "createWorkplaceAccount")
    public void getWorkplaceAccountAfterCreate()
    {
        // Generate request body
        context.put("externalDataSources", true);
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true),
                        "userIdentifier.mid", equalTo(accountsTestData.getMid()),
                        "accountList", not(empty()),
                        "accountList[0].accountId.accountNumber", equalTo(accountsTestData.getAccountNumber1()),
                        "accountList[0].accountId.owner.id", equalTo(accountsTestData.getPpid()),
                        "accountList[0].regCode.mnemonic", equalTo(accountsTestData.getMnemonic1()),
                        "accountList[0].sourceMarketValue.amount.value", equalTo(accountsTestData.getValue1()));
        
    }
    
    /**
     * Create the account contributions.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getWorkplaceAccountAfterCreate")
    public void createAccountContributions()
    {
        // Generate request body
        context.put("excludeExternalDataSources", true);
        context.put("contribValue", testData.getContributionValue());
        context.put("pointOfEntry", AccountConstants.NETBENEFITS);
        context.put("fcpsId", accountsTestData.getFcpsId());
        context.put("valueType", testData.getValueType());
        context.put("contribType", testData.getContributionType());
        context.put("contribTaxType", testData.getContributionTaxType());
        context.put("contribLevelType", testData.getContributionLevelType());
        context.put("frequency", testData.getFrequency());
        context.put("contributor", testData.getContributor());
        /** wpp contribution fields */
        context.put("contribBasisTypeCd", testData.getContribBasisTypeCd());
        context.put("contributionName", testData.getContributionName());
        context.put("electionCd", testData.getElectionCd());
        context.put("contributionMaxRateValue", testData.getContributionMaxRateValue());
        context.put("contributionMaxRateValueType", testData.getContributionMaxRateValueType());
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsTestData.getMid()))
                .body("accountContributions", not(empty()))
                .body("accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionType",
                        equalTo(testData.getContributionType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionTaxType",
                        equalTo(testData.getContributionTaxType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionLevelType",
                        equalTo(testData.getContributionLevelType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributor", equalTo(testData.getContributor()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contribution.value",
                        equalTo(Float.valueOf(testData.getContributionValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.frequency", equalTo(testData.getFrequency()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contribBasisTypeCd",
                        equalTo(testData.getContribBasisTypeCd()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionName",
                        equalTo(testData.getContributionName()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.electionCd", equalTo(testData.getElectionCd()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionMaxRate.value",
                        equalTo(Float.valueOf(testData.getContributionMaxRateValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionMaxRate.valueType",
                        equalTo(testData.getContributionMaxRateValueType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getContributionValue() + "f}.contributionId", notNullValue());
        testData.setContributionId(response.path("accountContributions[0].contributions.find{it.contribution.value==" +
                testData.getContributionValue() + "f}.contributionId"));
    
    }
    
    /**
     * Create the account contributions to add another contribution.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountContributions")
    public void createAccountContributionsAgain()
    {
        // Generate request body
        context.put("excludeExternalDataSources", true);
        context.put("pointOfEntry", AccountConstants.NETBENEFITS);
        context.put("fcpsId", accountsTestData.getFcpsId());
        context.put("valueType", testData.getValueType());
        context.put("contribType", testData.getContributionType());
        context.put("contribTaxType", testData.getContributionTaxType());
        context.put("contribLevelType", testData.getContributionLevelType());
        context.put("frequency", updatedFrequency);
        context.put("contribValue", testData.getUpdatedContributionValue());
        context.put("contributor", testData.getContributor());
        /** wpp contribution fields */
        context.put("contribBasisTypeCd", testData.getContribBasisTypeCd2());
        context.put("contributionName", testData.getContributionName2());
        context.put("electionCd", testData.getElectionCd2());
        context.put("contributionMaxRateValue", testData.getUpdatedContributionMaxRateValue());
        context.put("contributionMaxRateValueType", testData.getContributionMaxRateValueType());
    
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("userIdentifier.mid", equalTo(accountsTestData.getMid()))
                .body("accountContributions", not(empty()))
                .body("accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribution.value",
                        equalTo(Float.valueOf(testData.getUpdatedContributionValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribBasisTypeCd",
                        equalTo(testData.getContribBasisTypeCd2()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionName",
                        equalTo(testData.getContributionName2()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.electionCd",
                        equalTo(testData.getElectionCd2()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionMaxRate.value",
                        equalTo(Float.valueOf(testData.getUpdatedContributionMaxRateValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionMaxRate.valueType",
                        equalTo(testData.getContributionMaxRateValueType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionId", notNullValue());
        testData.setContributionId(response.path("accountContributions[0].contributions.find{it.contribution.value==" +
                testData.getUpdatedContributionValue() + "f}.contributionId"));
    
    }
    
    /**
     * Delete one contribution
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountContributionsAgain")
    public void deleteAccountContributions()
    {
        // Generate request body
        context.put("excludeExternalDataSources", true);
        context.put("contribType", testData.getContributionType());
        context.put("contribTaxType", testData.getContributionTaxType());
        context.put("contribLevelType", testData.getContributionLevelType());
        context.put("frequency", updatedFrequency);
        context.put("contributor", testData.getContributor());
        context.put("valueType", PERCENT);
        context.put("contribValue", testData.getUpdatedContributionValue());
        /** wpp contribution fields - SP */
        context.put("contribBasisTypeCd", testData.getContribBasisTypeCd());
        context.put("contributionName", testData.getContributionName());
        context.put("electionCd", testData.getElectionCd());
        context.put("contributionMaxRateValue", testData.getContributionMaxRateValue());
        context.put("contributionMaxRateValueType", testData.getContributionMaxRateValueType());
        
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_DELETE_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.DELETE_ACCOUNT_CONTRIBUTIONS_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("accountContributions", not(empty()))
                .body("accountContributions[0].contributions.size", equalTo(1))
                .body("accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribution.value",
                        equalTo(Float.valueOf(testData.getUpdatedContributionValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribBasisTypeCd",
                        equalTo(testData.getContribBasisTypeCd2()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionName",
                        equalTo(testData.getContributionName2()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.electionCd",
                        equalTo(testData.getElectionCd2()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionMaxRate.value",
                        equalTo(Float.valueOf(testData.getUpdatedContributionMaxRateValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionMaxRate.valueType",
                        equalTo(testData.getContributionMaxRateValueType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionId", notNullValue());
    
    }
    
    /**
     * Validate the contribution deleted and other contribution is still there.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccountContributions")
    public void getContributionsAfterDelete()
    {
        
        context.put("fcpsId", accountsTestData.getFcpsId());
        context.put("externalDataSources", true);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("resultCode", equalTo(true))
                .body("accountContributions", not(empty()))
                .body("accountContributions[0].contributions.size", equalTo(1))
                .body("accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribution.value",
                        equalTo(Float.valueOf(testData.getUpdatedContributionValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contribBasisTypeCd",
                        equalTo(testData.getContribBasisTypeCd2()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionName",
                        equalTo(testData.getContributionName2()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.electionCd",
                        equalTo(testData.getElectionCd2()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionMaxRate.value",
                        equalTo(Float.valueOf(testData.getUpdatedContributionMaxRateValue())),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionMaxRate.valueType",
                        equalTo(testData.getContributionMaxRateValueType()),
                        "accountContributions[0].contributions.find{it.contribution.value==" +
                                testData.getUpdatedContributionValue() + "f}.contributionId", notNullValue());
        
    }
    
    /**
     * Delete the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getContributionsAfterDelete")
    public void deleteWorkplaceAccount()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountList", empty());
    }
    
    /**
     * Validate the account was deleted.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteWorkplaceAccount")
    public void getWorkplaceAccountAfterDelete()
    {
        context.put("externalDataSources", "true");
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accountList", empty());
        
    }
    
    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
        testDataUtil.closeSQLiteConnection();
    }
    
}

