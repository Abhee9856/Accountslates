/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.v1.accountsInGroup.composite;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.GroupsUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;

/**
 * Tests when group call is made to account service: i.e. if there is group id and group type in the request after the call to household identity if we identity that the mid in the request is the partners mid. park all accounts by default under the partner.
 *
 * @author a631781, Story# PFCP-18785
 */
@Test(groups = {
        Tags.REGRESSION,
        Tags.FILI,
        Tags.COMPOSITE,
        Tags.GROUP,
        Tags.V1})
public class Fili_Composite_Partner_GroupAccount_V1 extends PAPBaseServiceTest {

    protected Fili_Composite_Partner_GroupAccount_V1() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private TestDataUtil testDataUtil;
    private String principalMid, partnerMid;
    private String principalSsn, partnerSsn;
    private String product = "WM";
    private String poe = "RETAIL";
    private String groupId;
    private String groupType = "APO_WM";
    private String groupName = "FiliCompositeGroupPartnerTest" + GroupsUtil.generateRandomNumber();
    private int principalId, partnerId;
    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "WM";

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";
    private final String source = "FILI";

    //Velocity Context
    private final VelocityContext context = new VelocityContext();
    private String oAuth;

    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID for principal and Partner.
     * </br>2. Set the Group and Group Household
     * </br>3. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init() {
        oAuth = AccountUtil.getOauthToken();
        // Principal Mid
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_details_get_FILI_annuity_immediate_121", oAuth);
        testDataUtil = new TestDataUtil();
        principalMid = accountsCommonTestData.getMid();
        principalSsn = accountsCommonTestData.getSsn();
        // Partner Mid
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_get_FILI_Reg_Code_I_82", oAuth);
        partnerMid = accountsCommonTestData.getMid();
        partnerSsn = accountsCommonTestData.getSsn();
        //Set default REST header with authorization token
        setDefaultRequestHeaders(oAuth);
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");
        //Get Group and delete it
        response = GroupsUtil.getGroupId(oAuth, principalMid, poe, product);
        response.prettyPrint();
        int getGroupStatus = response.statusCode();
        if (200 == getGroupStatus) {
            String existingGroupId = response.path("groups.find{it.type=='" + groupType + "'}.id");
            GroupsUtil.deleteGroup(existingGroupId, groupType, oAuth, poe);
        }
        //Create Group
        response = GroupsUtil.createGroup(oAuth, groupName, principalSsn, partnerSsn, principalMid, partnerMid, poe, product);
        groupId = response.path("groups[0].id");
        // Create Group Household with Partner
        response = GroupsUtil.createHouseholdIdentityWithGroupId(oAuth, principalMid, groupId, groupType, partnerMid, poe, product);
        principalId = response.path("identities.find{it.relationship=='PRINCIPAL'}.planningPartyId");
        partnerId = response.path("identities.find{it.relationship=='PARTNER'}.planningPartyId");
    }

    /**
     * Get composite Fili account info for Partner and validate owner relationship and ID are of partner.
     */
    @Test
    public void getFiliCompositePartnerAccount() {
        // Populate request variables
        context.put("mid", partnerMid);
        context.put("filiLid", partnerSsn);
        context.put("source", source);
        context.put("groupId", groupId);
        context.put("groupType", groupType);
        context.put("externalDataSources", false);
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accounts[0].account.accountId.owner.relationship",
                        equalTo("PARTNER"),
                        "accounts[0].account.accountId.owner.id",
                        equalTo(String.valueOf(partnerId)),
                        "accounts[0].details.accountId.owner.relationship",
                        equalTo("PARTNER"),
                        "accounts[0].details.accountId.owner.id",
                        equalTo(String.valueOf(partnerId)));
    }

    /**
     * Delete GroupID
     */
    @Test(dependsOnMethods = "getFiliCompositePartnerAccount")
    public void deleteGroupId() {
        GroupsUtil.deleteGroup(groupId, groupType, oAuth, poe);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
