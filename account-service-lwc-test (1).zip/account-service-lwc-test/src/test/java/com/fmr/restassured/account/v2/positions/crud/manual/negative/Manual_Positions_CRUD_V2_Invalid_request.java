/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.v2.positions.crud.manual.negative;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.FinancialInstrumentIds;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;

/**
 * Test class for negative V2 manual positions use cases.
 *
 * @author a651454
 */
@Test(groups = {
        Tags.MANUAL,
        Tags.POSITIONS,
        Tags.V2,
        Tags.CRUD,
        "PFCP-4877"})
public class Manual_Positions_CRUD_V2_Invalid_request  extends PAPBaseServiceTest
{
    public static final String LOG_TRACKING_ID = Manual_Positions_CRUD_V2_Invalid_request.class.getSimpleName();
    
    protected Manual_Positions_CRUD_V2_Invalid_request()
    {
        super(Services.Account);
    }
    
    private TestDataUtil testDataUtil;
    private String principalPId;
    
    private String accountNumber;
    
    private String accountId;

    private final String sourceSystem = "MANUAL";

    private VelocityContext context;
    
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    
    private static final String SCENARIO_PRODUCT_CODE = "IGE";
    
    private static final Header EEDS = new Header("excludeExternalDataSources", "true");
    
    //Financial Instrument IDs and their symbols
    private FinancialInstrumentIds finstIds;
    
    
    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
        final String oAuth = AccountUtil.getOauthToken();

        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("accountCRUD_Manual", oAuth);

        String mid = accountsCommonTestData.getMid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        principalPId = Identity.createHouseholdIdentity("mid", mid, oAuth);
        finstIds = new FinancialInstrumentIds("FFIDX", "FENY","QPISQ", "FEDTX", "GDSTOCK");
        testDataUtil = new TestDataUtil();
        
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
                LOG_TRACKING_ID, oAuth );
        
        this.request.given()
                .header(new Header("user-poe", "RETAIL"))
                .header(new Header("user-mid", accountsCommonTestData.getMid()))
                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
                .header(new Header("log-tracking-id", LOG_TRACKING_ID))
                .header(EEDS);
        
        context = new VelocityContext();
        context.put("ppid", principalPId);
        context.put("source", "MANUAL");
    }
    
    @Before
    public void beforeTest()
    {
        clearAllPostitionsInContext();
    }
    
    /**
     * Create manual accounts.
     */
    @Test
    public void createManualAccounts()
    {
        float value = 5000.0f;
        context.put("value", value);
        context.put("source", sourceSystem);
        String displayName = "Display_Name";
        context.put("displayName", displayName);
        String institutionName = "InstitutionalName";
        context.put("institutionName", institutionName);
        String asOfDate = "2014-10-31";
        context.put("asOfDate", asOfDate);
        String mnemonic = "IRA";
        context.put("mnemonic", mnemonic);
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountList", Matchers.not(empty()),
                        "accountList", Matchers.hasSize(1),
                        "accountList[0].regCode.mnemonic", Matchers.notNullValue(),
                        "accountList[0].accountId.accountNumber", Matchers.notNullValue());
        
        // Gets and saves the CFP account ID
        accountId = response.path("accountList.accountId.find{it.owner.relationship=='PRINCIPAL'}.accountNumber");
        accountNumber = response.path("accountList.accountId.find{it.owner.relationship=='PRINCIPAL'}.accountNumber");
        
        context.put("id", accountId);
        context.put("accountNumber", accountNumber);
    }
    
    /**
     * Validate the accounts were created correctly.
     */
    @Test(dependsOnMethods="createManualAccounts")
    public void getManualAccountsAfterCreate()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
        
        // Assert on response
        response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK)
                .body("accountList", Matchers.hasSize(1));
    }
    
    /**
     * Get the positions before creation of positions
     */
    @Test(dependsOnMethods="getManualAccountsAfterCreate")
    public void getAccountPositionsBeforeCreatePosition()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body(
                        "accountList", Matchers.hasSize(1),
                        "accountList[0].account.accountId.sourceSystem", equalTo(sourceSystem),
                        "accountList.account.accountId.find{it.id==\""+accountId+"\"}.accountNumber", equalTo(accountNumber),
                        "accountList.account.accountId.find{it.id==\""+accountId+"\"}.id", equalTo(accountId),
                        "accountList.account.accountId.find{it.id==\""+accountId+"\"}.owner.id", equalTo(principalPId),
                        "accountList.account.accountId.find{it.id==\""+accountId+"\"}.positions", Matchers.nullValue()
                );
    }

    /**
     * Create positions
     */
    @Test(dependsOnMethods="getAccountPositionsBeforeCreatePosition")
    public void createAccountPositions()
    {
        this.initializeFirstPositionWithGenericFinstInContext();
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_NEGATIVE_VM));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("accountPositions", notNullValue(),
                        "accountPositions[0].account.accountId.sourceSystem", equalTo(sourceSystem),
                        "accountPositions.account.accountId.find{it.id==\""+accountId+"\"}.accountNumber", equalTo(accountNumber),
                        "accountPositions.account.accountId.find{it.id==\""+accountId+"\"}.id", equalTo(accountId),
                        "accountPositions.account.accountId.find{it.id==\""+accountId+"\"}.owner.id", equalTo(principalPId),
                        "accountPositions.find{it.account.accountId.id==\""+accountId+"\"}.positions.allPositions", Matchers.notNullValue()
                );
    }

    /**
     * Get the positions after creation of positions
     */
    @Test(dependsOnMethods="createAccountPositions")
    public void getAccountPositionsAfterCreate()
    {
        context.put("mnemonicFilter", "IRA");

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNTPOSITIONS_V2);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body(
                        "accountList", Matchers.hasSize(1),
                        "accountList[0].account.accountId.sourceSystem", equalTo(sourceSystem),
                        "accountList.account.accountId.find{it.owner.relationship=='PRINCIPAL'}.accountNumber", equalTo(accountNumber),
                        "accountList.account.accountId.find{it.owner.relationship=='PRINCIPAL'}.id", equalTo(accountId),
                        "accountList.account.accountId.find{it.owner.relationship=='PRINCIPAL'}.owner.id", equalTo(principalPId),
                        "accountList.find{it.account.accountId.owner.relationship=='PRINCIPAL'}.positions", Matchers.notNullValue()
                );
    }
    
    /**
     * Update account position with zero market value
     */
    @Test(dependsOnMethods="getAccountPositionsAfterCreate")
    public void updateAccountPositionsWithZeroMarketValue()
    {
        initializeFirstPositionWithSpecificFinstInContext();
        context.put("positionMarketVal1", 0.0f);
        context.put("positionMarketValType1", "MONEY");
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_NEGATIVE_VM));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(422)
                .body("responseDiagnostic[0].detail", equalTo("Market value of a postion is zero."));
    }
    
    /**
     * Update account position percent market value type for a specific finst
     */
    @Test(dependsOnMethods="updateAccountPositionsWithZeroMarketValue")
    public void updateAccountPositionsWithPercentMarketValueTypeForSpecificFinst()
    {
        initializeFirstPositionWithSpecificFinstInContext();
        context.put("positionMarketVal1", 1000.0f);
        context.put("positionMarketValType1", "PERCENT");
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_NEGATIVE_VM));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(422)
                .body("responseDiagnostic[0].detail", equalTo("The amount should be a dollar amount for a specific financial instruments."));
    }
    
    /**
     * Update account position for an invalid generic finst id
     */
    @Test(dependsOnMethods="updateAccountPositionsWithPercentMarketValueTypeForSpecificFinst")
    public void updateAccountPositionsWithInvalidSpecificFinstId()
    {
        initializeFirstPositionWithSpecificFinstInContext();
        context.put("finstId1", finstIds.getFinstId("GDSTOCK"));
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_NEGATIVE_VM));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(422)
                .body("responseDiagnostic[0].detail", equalTo("the  FINST ID is not one of the spec finstIDs"));
    }
    
    /**
     * Update account position for a generic finst and amount todal not 100%
     */
    @Test(dependsOnMethods="updateAccountPositionsWithInvalidSpecificFinstId")
    public void updateAccountPositionsWithGenericFinstAndAmountTotalNot100Percent()
    {
        initializeFirstPositionWithGenericFinstInContext();
        context.put("positionMarketVal1", 0.33f);
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_NEGATIVE_VM));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(422)
                .body("responseDiagnostic[0].detail", equalTo("The sum of the positions should equal 100% for a generic position."));
    }
    
    /**
     * Update account position for an invalid generic finst id
     */
    @Test(dependsOnMethods="updateAccountPositionsWithGenericFinstAndAmountTotalNot100Percent")
    public void updateAccountPositionsWithInvalidGenericFinstId()
    {
        initializeFirstPositionWithGenericFinstInContext();
        context.put("finstId1", 1);
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_NEGATIVE_VM));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(422)
                .body("responseDiagnostic[0].detail", equalTo("the  FINST ID is not one of the generic finstIDs"));
    }
    
    /**
     * Update account position with duplicate generic finst
     */
    @Test(dependsOnMethods="updateAccountPositionsWithInvalidGenericFinstId")
    public void updateAccountPositionsWithDuplicateGenericFinst()
    {
        initializeFirstPositionWithGenericFinstInContext();
        initializeSecondPositionWithGenericFinstInContext();
    
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_ACCOUNT_ACCOUNT_POSITION_SET_V_2_NEGATIVE_VM));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.SET_ACCOUNTPOSITIONS_V2);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(422)
                .body("responseDiagnostic[0].detail", equalTo("There should only be one position of each generic type for a single account"));
    }
    
    /**
     * Initializes first position with specific finst in context
     */
    private void initializeFirstPositionWithSpecificFinstInContext()
    {
        context.put("positiondesc1", "Description 1");
        context.put("positionMarketVal1", 5000.0f);
        context.put("positionMarketValType1", "MONEY");
        context.put("positionQuantity1", 100);
        context.put("positionPrice1", 50.0f);
        context.put("costBasis1", 222);
        context.put("finstId1", finstIds.getFinstId("FENY"));
        context.put("symbol1", "FENY");
        context.put("type1", finstIds.getType("FENY"));
        context.put("name1", finstIds.getName("FENY"));
    }
    
    /**
     * Initializes first position with generic finst in context
     */
    private void initializeFirstPositionWithGenericFinstInContext()
    {
        context.put("positiondesc1", "Description 1");
        context.put("positionMarketVal1", 1.0f);
        context.put("positionMarketValType1", "PERCENT");
        context.put("positionQuantity1", 3);
        context.put("positionPrice1", 100.0f);
        context.put("costBasis1", 222);
        context.put("finstId1", finstIds.getFinstId("GDSTOCK"));
        context.put("symbol1", "GDSTOCK");
        context.put("type1", finstIds.getType("GDSTOCK"));
        context.put("name1", finstIds.getName("GDSTOCK"));
    }
    
    /**
     * Initializes second position with generic finst in context
     */
    private void initializeSecondPositionWithGenericFinstInContext()
    {
        context.put("positiondesc2", "Description 2");
        context.put("positionMarketVal2", 0.67f);
        context.put("positionMarketValType2", "PERCENT");
        context.put("positionQuantity2", 3);
        context.put("positionPrice2", 100.0f);
        context.put("costBasis2", 222);
        context.put("finstId2", finstIds.getFinstId("GDSTOCK"));
        context.put("symbol2", "GDSTOCK");
        context.put("type2", finstIds.getType("GDSTOCK"));
        context.put("name2", finstIds.getName("GDSTOCK"));
    }
    
    /**
     * Clears all positions in context
     */
    private void clearAllPostitionsInContext()
    {
        this.context.remove("positiondesc1");
        this.context.remove("positionMarketVal1");
        this.context.remove("positionMarketValType1");
        this.context.remove("positionQuantity1");
        this.context.remove("positionPrice1");
        this.context.remove("costBasis1");
        this.context.remove("finstId1");
        this.context.remove("symbol1");
        this.context.remove("type1");
        this.context.remove("name1");
        
        this.context.remove("positiondesc2");
        this.context.remove("positionMarketVal2");
        this.context.remove("positionMarketValType2");
        this.context.remove("positionQuantity2");
        this.context.remove("positionPrice2");
        this.context.remove("costBasis2");
        this.context.remove("finstId2");
        this.context.remove("symbol2");
        this.context.remove("type2");
        this.context.remove("name2");
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }
}
