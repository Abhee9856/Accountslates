/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.accountsInGroup.withdrawals;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsWithdrawalsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.GroupsUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;

/**
 * Tests when group call is made to account service: i.e. if there is group id and group type in the request after the call to household identity if we identity that the mid in the request is the partners mid. park all accounts by default under the partner.
 *
 * @author a631781, Story# PFCP-18785
 */
@Test(groups = {
        Tags.REGRESSION,
        Tags.FULLVIEW,
        Tags.WITHDRAWALS,
        Tags.GROUP,
        Tags.V1})
public class Fullview_Withdrawals_Partner_GroupAccount_V1 extends PAPBaseServiceTest {

    protected Fullview_Withdrawals_Partner_GroupAccount_V1() {
        super(Services.Account);
    }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private String principalMid, partnerMid;
    private String principalSsn, partnerSsn;
    private String product = "WM";
    private String poe = "RETAIL";
    private String oAuth;
    private String groupId;
    private String groupType = "APO_WM";
    private String groupName = "FullviewGroupPartnerTest" + GroupsUtil.generateRandomNumber();

    private int principalId, partnerId;
    private final String source = "FULLVIEW";
    private static final String SCENARIO_PRODUCT_CODE = "WM";
    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private String accountId;
    private String withdrawalType = "Regular";
    private float withdrawalValue = 30f;
    private String valueType = "MONEY";
    private String frequency = "DAILY";
    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;


    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_details_get_FullView_principal_115", oAuth);
        testDataUtil = new TestDataUtil();
        principalMid = accountsCommonTestData.getMid();
        principalSsn = accountsCommonTestData.getSsn();
        // Partner
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_get_details_sdb", oAuth);
        partnerMid = accountsCommonTestData.getMid();
        partnerSsn = accountsCommonTestData.getSsn();

        //Set default REST header with authorization token
        setDefaultRequestHeaders(oAuth);
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP("mid", principalMid, oAuth, "true");

        // Call GET APO and delete any existing groupID
        response = GroupsUtil.getGroupId(oAuth, principalMid, poe, product);
        int getGroupStatus = response.statusCode();
        if (200 == getGroupStatus) {
            String existingGroupId = response.path("groups.find{it.type=='" + groupType + "'}.id");
            GroupsUtil.deleteGroup(existingGroupId, groupType, oAuth, poe);
        }

        // Create Group
        response = GroupsUtil.createGroup(oAuth, groupName, principalSsn, partnerSsn, principalMid, partnerMid, poe, product);
        groupId = response.path("groups[0].id");
        // Create Group Household with Partner
        response = GroupsUtil.createHouseholdIdentityWithGroupId(oAuth, principalMid, groupId, groupType, partnerMid, poe, product);
        principalId = response.path("identities.find{it.relationship=='PRINCIPAL'}.planningPartyId");
        partnerId = response.path("identities.find{it.relationship=='PARTNER'}.planningPartyId");
        // Populate request variables
        context = new VelocityContext();
        context.put("mid", partnerMid);
        context.put("fescolid", partnerSsn);
        context.put("source", source);
        context.put("productCode", SCENARIO_PRODUCT_CODE);
        context.put("categoryCode", SCENARIO_CATEGORY_CODE);
        context.put("groupId", groupId);
        context.put("groupType", groupType);
        context.put("relationship", "PARTNER");
        context.put("ppid", partnerId);

    }

    /**
     * Get Fullview account info from the backend. Save the account number.
     */
    @Test
    public void getAccountInfo() {
        // Populate request variables
        context.put("externalDataSources", false);
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
    }

    /**
     * Create the Fullview account in CFP. Save the account ID.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getAccountInfo")
    public void createFullviewAccount() {
        // Populate request variables
        context.put("excludeExternalDataSources", false);
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("userIdentifier.mid", equalTo(partnerMid),
                        "accountList[0].regCode.mnemonic",
                        equalTo(accountsCommonTestData.getMnemonic1()),
                        "accountList[0].accountId.owner.relationship",
                        equalTo("PARTNER"),
                        "accountList[0].accountId.owner.id",
                        equalTo(String.valueOf(partnerId)),
                        "accountList[0].accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()));

        // Gets and saves the CFP account ID
        accountId = response.path("accountList[0].accountId.id");
        context.put("accId", accountsCommonTestData.getAccountId1());
    }

    /**
     * Create Account withdrawals
     */
    @Test(dependsOnMethods = "createFullviewAccount")
    public void createAccountWithdrawals() {
        // Generate request body
        context.put("accId", accountId);
        context.put("withdrawalType", withdrawalType);
        context.put("withdrawalValue", withdrawalValue);
        context.put("valueType", valueType);
        context.put("frequency", frequency);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_CREATE_TEMPLATE))
                .log().ifValidationFails();

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.CREATE_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.withdrawalType", equalTo(withdrawalType),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.amount.amount.value", equalTo(withdrawalValue),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.amount.frequency", equalTo(frequency),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.accountId.owner.relationship", equalTo("PARTNER"),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.accountId.owner.id", equalTo(String.valueOf(partnerId)));

    }

    /**
     * Validate the withdrawals.
     */
    @Test(dependsOnMethods = "createAccountWithdrawals")
    public void getWithdrawalsAfterCreate() {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_WITHDRAWALS_GET_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsWithdrawalsPaths.GET_ACCOUNTWITHDRAWALS_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(HttpStatus.SC_OK)
                .body("accountWithdrawals", not(empty()),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.withdrawalType", equalTo(withdrawalType),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.amount.amount.value", equalTo(withdrawalValue),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.withdrawals.find{it.amount.frequency=='" +
                                frequency + "'}.amount.frequency", equalTo(frequency),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.accountId.owner.relationship", equalTo("PARTNER"),
                        "accountWithdrawals.find{it.accountId.id=='" + accountId + "'}.accountId.owner.id", equalTo(String.valueOf(partnerId)));

    }

    /**
     * Delete GroupID
     */
    @AfterClass(alwaysRun = true)
    public void deleteGroupId() {
        GroupsUtil.deleteGroup(groupId, groupType, oAuth, poe);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        //Close DB connection
        testDataUtil.closeSQLiteConnection();
    }
}