/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.crud.retail;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

/**
 * Tests Advisor Info for V2 CRUD operations for Composite Retail accounts
 *
 * @author a631781
 *  Updated by a608077 on 08/30/2023 to include include-suitability-details header(PFCP-12115)
 *  Updated by a608077 on 01/15/2025 to include -deleting an existing account before create
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.COMPOSITE,
		Tags.V2})
public class Retail_Composite_V2_AdvisorInfo extends PAPBaseServiceTest
{

    protected Retail_Composite_V2_AdvisorInfo()
    {
	super(Services.Account);
    }

    private VelocityContext context;

    private final float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String source = "RETAIL";

    private final String asOfDate1 = "2014-10-31";

    private final String displayName = "Retail Account Advisor Info";

    /**
     * Instance to the test data utility class
     */

    private String accId;

    private String accNumber;

    private String ppid;

    private String mnemonic;

    private String acctRoot;

    FilterableRequestSpecification frs = null;

    private static final String LOG_TRACKING_ID = Retail_Composite_V2_AdvisorInfo.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private final String catchupPath = ".contributions.find{it.contributionType=='CATCHUP'}";

    private final String regularPath = ".contributions.find{it.contributionType=='REGULAR'}";

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();
	// Set default headers
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	    String poe = "FRIAG";
	    String advisorLoginId = "7690041287";
	    String advisorRealmType = "FRIAG";
	    String advisorPlanNumber = "500958";
	    String gnumber = "G07492038";
	    request.given().header(new Header("user-poe", poe))
			.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
			.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
			.header(new Header("advisor-login-id", advisorLoginId))
			.header(new Header("advisor-realm-type", advisorRealmType))
			.header(new Header("advisor-plan-number", advisorPlanNumber))
			.header(new Header("gnumber", gnumber))
			.header(new Header("excludeExternalDataSources", "false"));

	// Populate request variables
	context = new VelocityContext();
	context.put("sourceBasedRegistrationFilter", source);

	frs = (FilterableRequestSpecification) request;
    }

    //Test Composite Account with Advisor Info
    @Test
    public void performCrudOperations()
    {
	this.getRetailAccountInfo();
	this.createRetailAccount();
	this.getCompositeAccountAfterCreate();
	this.updateCompositeRetailAccount();
	this.getCompositeAccountAfterUpdate();
	this.deleteCompositeRetailAccount();
    }

    // Get composite account info from the backend. Save the account number.
    private void getRetailAccountInfo()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body("accounts", not(emptyArray()));
	accNumber = response.path("accounts[0].account.accountId.accountNumber");
	ppid = response.path("accounts[0].account.accountId.owner.id");
	mnemonic = response.path("accounts[0].account.regCode.mnemonic");
	    // Gets and saves the CFP account ID
	    String accountId = response.path("accounts[0].account.accountId.id");

	    if(null != response.path("accounts[0].account.accountId.id"))
	    {
		    //Data cleanup - delete the retail account before creating Retail account
		    context.put("accId", accountId);
		    this.deleteCompositeRetailAccount();

	    }
    }

    //Create Composite account with Advisor Info
    private void createRetailAccount()
    {
	frs.removeHeader("excludeExternalDataSources");
	request.given().header(new Header("excludeExternalDataSources", "true"));

	// Generate request body
	context.put("ppid", ppid);
	context.put("value", String.valueOf(value));
	context.put("mnemonic", mnemonic);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("id", null);
	context.put("sourceSystem2", source);
	context.put("detailValue", "111111.11");
	context.put("asdr", false);
	context.put("isProductSuitable", "false");
	context.put("emergencyFundAmountValue", "111111.11");
	context.put("contribFreq", "YEARLY");
	context.put("contribValue", "500");
	context.put("contributionTaxType", "POST_TAX");
	context.put("contributionType", "CATCHUP");
	context.put("contributor", "EMPLOYER");
	context.put("contribBasisTypeCd", "BASE");
	context.put("contribFreq2", "BIMONTHLY");
	context.put("contribValue2", "900");
	context.put("contributionTaxType2", "AGGREGATE");
	context.put("contributionType2", "REGULAR");
	context.put("contributor2", "INDIVIDUAL");
	context.put("contribBasisTypeCd2", "BASEBONUS");
	context.put("withdrawAmount", "500");
	context.put("withdrawFreq", "HOURLY");
	context.put("riskTolerance", 2);
	context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
	context.put("withdrawalStartYear", 2055);
	context.put("withdrawalEndYear", 2085);
	context.put("assetClass1", "UNKNOWN");
	context.put("netPercentage1", 0.177);
	context.put("assetClass_T_Equity", "TOTAL_EQUITY");
	context.put("netPercentage_T_Equity", 0);
	context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
	context.put("netPercentage_FE", 0.0f);
	context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
	context.put("netPercentage_DE", 0.0f);
	context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
	context.put("equityPercent", 0.35);
	context.put("originalOwnerBirthDate", "1958-11-09");
	context.put("originalOwnerDeceasedDate", "2022-11-09");
	context.put("withdrawalEligibilityStartDate", "2022-11-09");
	context.put("withdrawalEligibilityEndDate", "2052-11-09");
	context.put("originalOwnerSpouse", "false");
	context.put("federalTaxWithholding", 0.15);
	context.put("stateTaxWithholding", 0.05);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

	// Call Account service
	response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V2);
	// Assert on response

	response.then().log().ifValidationFails().statusCode(200)
			.body("accounts[0].account.accountId.id", notNullValue())
			.body("accounts[0].account.accountId.accountNumber", equalTo(accNumber))
			.body("accounts[0].account.accountId.sourceSystem", equalTo(source))
			.body("accounts[0].account.accountId.owner.id", equalTo(ppid))
			.body("accounts[0].account.displayName", equalTo(displayName))
			.body("accounts[0].account.sourceMarketValue.amount.value", equalTo(Float.valueOf(value)))
			.body("accounts[0].details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
					equalTo(111111.11f))
			.body("accounts[0].details.retailAccountDetail.isProductSuitable", equalTo(false))
			.body("accounts[0].details.retailAccountDetail.accountDetail.complementaryAdjustmentOption",
					equalTo("MOVE_TO_MANAGED_ACCOUNT"))
			.body("accounts[0].details.retailAccountDetail.accountDetail.originalOwnerBirthDate",
					equalTo("1958-11-09T00:00:00.000+0000"))
			.body("accounts[0].details.retailAccountDetail.accountDetail.originalOwnerDeceasedDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body("accounts[0].details.retailAccountDetail.accountDetail.withdrawalEligibilityStartDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body("accounts[0].details.retailAccountDetail.accountDetail.withdrawalEligibilityEndDate",
					equalTo("2052-11-09T00:00:00.000+0000"))
			.body("accounts[0].details.retailAccountDetail.accountDetail.originalOwnerSpouse",
					equalTo(false))
			.body("accounts[0].details.retailAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(0.15f))
			.body("accounts[0].details.retailAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(0.05f))
			.body("accounts[0].details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
					equalTo(111111.11f))
			.body("accounts[0].contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
			.body("accounts[0].contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
			.body("accounts[0].contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
			.body("accounts[0].contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
			.body("accounts[0].contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
			.body("accounts[0].contributions" + catchupPath + ".contribBasisTypeCd", equalTo("BASE"))
			.body("accounts[0].contributions" + regularPath + ".contribution.value", equalTo(900.0f))
			.body("accounts[0].contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
			.body("accounts[0].contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
			.body("accounts[0].contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
			.body("accounts[0].contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
			.body("accounts[0].contributions" + regularPath + ".contribBasisTypeCd", equalTo("BASEBONUS"))
			.body("accounts[0].suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
			.body("accounts[0].suitability.investmentPurpose.values[0].value",
					equalTo("Save for education"))
			.body("accounts[0].suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
			.body("accounts[0].suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
			.body("accounts[0].suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
			.body("accounts[0].suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
			.body("accounts[0].suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
			.body("accounts[0].suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
			.body("accounts[0].suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
			.body("accounts[0].suitability.investmentTimeHorizon.values[0].value",
					equalTo("Near Term (0-1 year)"))
			.body("accounts[0].suitability.accountPreferencesIA.riskTolerance", equalTo(2))
			.body("accounts[0].suitability.accountPreferencesIA.stockMarketDeclinePercent",
					equalTo("SELL_LESS_THAN_25"))
			.body("accounts[0].suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
			.body("accounts[0].suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
			.body("accounts[0].suitability.accountId.accountNumber", equalTo(accNumber))
			.body("accounts[0].withdrawals", notNullValue())
			.body("accounts[0].withdrawals[0].amount.amount.value", equalTo(500.0f))
			.body("accounts[0].withdrawals[0].amount.frequency", equalTo("HOURLY"));

	accId = response.path("accounts[0].account.accountId.id");

    }

    // Get composite Account After Create
    private void getCompositeAccountAfterCreate()
    {
		this.request.given()
				.header(new Header("include-suitability-details", "true"));
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
	// Assert on response
	acctRoot = "accounts.find{it.account.accountId.id=='" + accId + "'}.";
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body(acctRoot + "account.accountId.id", notNullValue())
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
			.body(acctRoot + "account.displayName", equalTo(displayName))
			.body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(value)))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
					equalTo(111111.11f))
			.body(acctRoot + "details.retailAccountDetail.isProductSuitable", equalTo(false))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.complementaryAdjustmentOption",
					equalTo("MOVE_TO_MANAGED_ACCOUNT"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.originalOwnerBirthDate",
					equalTo("1958-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.originalOwnerDeceasedDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.withdrawalEligibilityStartDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.withdrawalEligibilityEndDate",
					equalTo("2052-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.originalOwnerSpouse",
					equalTo(false))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(0.15f))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(0.05f))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
					equalTo(111111.11f))
			.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
			.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
			.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
			.body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
			.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
			.body(acctRoot + "contributions" + catchupPath + ".contribBasisTypeCd", equalTo("BASE"))
			.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
			.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
			.body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
			.body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
			.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
			.body(acctRoot + "contributions" + regularPath + ".contribBasisTypeCd", equalTo("BASEBONUS"))
			.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
			.body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
			.body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
			.body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
			.body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
			.body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
			.body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
			.body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
			.body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
			.body(acctRoot + "suitability.investmentTimeHorizon.values[0].value",
					equalTo("Near Term (0-1 year)"))
			.body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
			.body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent",
					equalTo("SELL_LESS_THAN_25"))
			.body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
			.body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
			.body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "withdrawals", notNullValue())
			.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(500.0f))
			.body(acctRoot + "withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }

    //Update composite account
    private void updateCompositeRetailAccount()
    {
	// Generate request body
	context.put("ppid", ppid);
	context.put("value", String.valueOf(updatedValue));
	context.put("mnemonic", mnemonic);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("id", accId);
	context.put("sourceSystem2", source);
	context.put("accId", accId);
	context.put("detailValue", "111111.11");
	context.put("asdr", false);
	context.put("isProductSuitable", "false");
	context.put("emergencyFundAmountValue", "111111.11");
	context.put("contribFreq", "YEARLY");
	context.put("contribValue", "500");
	context.put("contributionTaxType", "POST_TAX");
	context.put("contributionType", "CATCHUP");
	context.put("contributor", "EMPLOYER");
	context.put("contribBasisTypeCd", "BASE");
	context.put("contribFreq2", "BIMONTHLY");
	context.put("contribValue2", "900");
	context.put("contributionTaxType2", "AGGREGATE");
	context.put("contributionType2", "REGULAR");
	context.put("contributor2", "INDIVIDUAL");
	context.put("contribBasisTypeCd2", "BASEBONUS");
	context.put("withdrawAmount", "500");
	context.put("withdrawFreq", "HOURLY");
	context.put("riskTolerance", 2);
	context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
	context.put("withdrawalStartYear", 2055);
	context.put("withdrawalEndYear", 2085);
	context.put("assetClass1", "UNKNOWN");
	context.put("netPercentage1", 0.177);
	context.put("assetClass_T_Equity", "TOTAL_EQUITY");
	context.put("netPercentage_T_Equity", 0);
	context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
	context.put("netPercentage_FE", 0.0f);
	context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
	context.put("netPercentage_DE", 0.0f);
	context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
	context.put("equityPercent", 0.35);
	context.put("originalOwnerBirthDate", "1958-11-09");
	context.put("originalOwnerDeceasedDate", "2022-11-09");
	context.put("withdrawalEligibilityStartDate", "2022-11-09");
	context.put("withdrawalEligibilityEndDate", "2052-11-09");
	context.put("originalOwnerSpouse", "false");
	context.put("federalTaxWithholding", 0.15);
	context.put("stateTaxWithholding", 0.05);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE_V2));

	// Call Account service
	response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(200)
			.body(acctRoot + "account.accountId.id", notNullValue())
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
			.body(acctRoot + "account.accountId.owner.id", equalTo(ppid))
			.body(acctRoot + "account.displayName", equalTo(displayName))
			.body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(updatedValue)))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
					equalTo(111111.11f))
			.body(acctRoot + "details.retailAccountDetail.isProductSuitable", equalTo(false))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.complementaryAdjustmentOption",
					equalTo("MOVE_TO_MANAGED_ACCOUNT"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.originalOwnerBirthDate",
					equalTo("1958-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.originalOwnerDeceasedDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.withdrawalEligibilityStartDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.withdrawalEligibilityEndDate",
					equalTo("2052-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.originalOwnerSpouse",
					equalTo(false))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(0.15f))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(0.05f))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
					equalTo(111111.11f))
			.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
			.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
			.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
			.body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
			.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
			.body(acctRoot + "contributions" + catchupPath + ".contribBasisTypeCd", equalTo("BASE"))
			.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
			.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
			.body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
			.body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
			.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
			.body(acctRoot + "contributions" + regularPath + ".contribBasisTypeCd", equalTo("BASEBONUS"))
			.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
			.body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
			.body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
			.body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
			.body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
			.body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
			.body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
			.body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
			.body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
			.body(acctRoot + "suitability.investmentTimeHorizon.values[0].value",
					equalTo("Near Term (0-1 year)"))
			.body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
			.body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent",
					equalTo("SELL_LESS_THAN_25"))
			.body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
			.body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
			.body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "withdrawals", notNullValue())
			.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(500.0f))
			.body(acctRoot + "withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }

    // Get composite Account After Update
    private void getCompositeAccountAfterUpdate()
    {
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));
	// Call Account service
	response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
	// Assert on response
	acctRoot = "accounts.find{it.account.accountId.id=='" + accId + "'}.";
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
			.body(acctRoot + "account.accountId.id", notNullValue())
			.body(acctRoot + "account.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
			.body(acctRoot + "account.displayName", equalTo(displayName))
			.body(acctRoot + "account.sourceMarketValue.amount.value", equalTo(Float.valueOf(updatedValue)))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
					equalTo(111111.11f))
			.body(acctRoot + "details.retailAccountDetail.isProductSuitable", equalTo(false))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.complementaryAdjustmentOption",
					equalTo("MOVE_TO_MANAGED_ACCOUNT"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.originalOwnerBirthDate",
					equalTo("1958-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.originalOwnerDeceasedDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.withdrawalEligibilityStartDate",
					equalTo("2022-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.withdrawalEligibilityEndDate",
					equalTo("2052-11-09T00:00:00.000+0000"))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.originalOwnerSpouse",
					equalTo(false))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.federalTaxWithholdingPercent",
					equalTo(0.15f))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.stateTaxWithholdingPercent",
					equalTo(0.05f))
			.body(acctRoot + "details.retailAccountDetail.accountDetail.emergencyFundAmount.value",
					equalTo(111111.11f))
			.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
			.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
			.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
			.body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
			.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
			.body(acctRoot + "contributions" + catchupPath + ".contribBasisTypeCd", equalTo("BASE"))
			.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
			.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
			.body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
			.body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
			.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
			.body(acctRoot + "contributions" + regularPath + ".contribBasisTypeCd", equalTo("BASEBONUS"))
			.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
			.body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
			.body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
			.body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
			.body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
			.body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
			.body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
			.body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
			.body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
			.body(acctRoot + "suitability.investmentTimeHorizon.values[0].value",
					equalTo("Near Term (0-1 year)"))
			.body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
			.body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent",
					equalTo("SELL_LESS_THAN_25"))
			.body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
			.body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
			.body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNumber))
			.body(acctRoot + "withdrawals", notNullValue())
			.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(500.0f))
			.body(acctRoot + "withdrawals[0].amount.frequency", equalTo("HOURLY"));
    }

    //Delete Composite Account
    private void deleteCompositeRetailAccount()
    {
	// Generate request body
	context.put("ppid", ppid);
	context.put("value", String.valueOf(updatedValue));
	context.put("mnemonic", mnemonic);
	context.put("source", source);
	context.put("displayName", displayName);
	context.put("institutionName", displayName);
	context.put("asOfDate", asOfDate1);
	context.put("accountNumber", accNumber);
	context.put("id", accId);

	// Generate request body
	this.request.body(IOUtil.generateJsonRequest(this.context,
			AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE_V2));

	// Call Account service response
	this.request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);
	// Assert on response
	response.then().log().ifValidationFails().statusCode(200);

    }
}
