/*
 * Copyright 2022-2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.get.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.testng.AssertJUnit.assertFalse;

/**
 * @author a601767
 * @author a730306 - updating the test to validate ServiceModelCode
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.COMPOSITE,
		Tags.V2})
/*
TODO: Tests should be rewritten to check if serviceModelCode exists for a managed account.
 */
public class Retail_Composite_Get_v2_serviceModelCode extends PAPBaseServiceTest
{

    protected Retail_Composite_Get_v2_serviceModelCode()
    {
	super(Services.Account);
    }

    //Velocity Context
    private VelocityContext context;

    //Instance to the test data utility class
    private TestDataUtil testDataUtil;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";
    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private static final String LOG_TRACKING_ID = Retail_Composite_Get_v2_serviceModelCode.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private FilterableRequestSpecification frs;

    public static final String ACCOUNT_CATEGORY = "Brokerage";

    private String ssn;

    private String mid;

    private String sid;
    private final String oAuth = AccountUtil.getOauthToken();
    private static final String APP_NAME = "Advice and Planning Platform";
    private final List<String> accountNumberList = new ArrayList<>();
    //list of service model code
    private final List<String> serviceModelCodeList = Arrays.asList("DIGITAL", "1ON1", "TEAM_POD");

    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init() {

        testDataUtil = new TestDataUtil();

        // Data setup
        AccountsCommonTestData accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_positions_get_Retail_100", oAuth);

        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid().replace("-", "");
        ssn = accountsCommonTestData.getSsn();
        frs = (FilterableRequestSpecification) request;
        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, mid, oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", mid, oAuth));
        String ppid = accountsCommonTestData.getPpid();

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("sourceBasedRegistrationFilter", "RETAIL");
        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
    }
    
    /**
     * Test to get the DSS digital account
     */
    @Test
    public void getDSS_V2()
    {
        frs = (FilterableRequestSpecification) request;
        //Set DSS Headers
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();

        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);

        JsonParser parser = new JsonParser();
        JsonObject responseBodyObj = (JsonObject) parser.parse(response.body().asString());
        responseBodyObj.keySet().forEach(objectKey ->
        {
            Object keyValue = responseBodyObj.get(objectKey);
            if(objectKey.equals("acctDetails"))
            {
                JSONArray detailsArray = new JSONArray(keyValue.toString());
                for(Object detailObject: detailsArray)
                {
                    JSONObject detailJsonObj = new JSONObject(detailObject.toString());
                    if(detailJsonObj.has("managedAcctDetail"))
                    {
                        JSONObject managedObj = detailJsonObj.getJSONObject("managedAcctDetail");
                        if(managedObj.has("svcModelCode"))
                        {
                            if (null != managedObj.get("svcModelCode") && serviceModelCodeList.contains(managedObj.get("svcModelCode").toString()))
                            {
                                accountNumberList.add(detailJsonObj.get("acctNum").toString());
                            }
                        }
                    }
                }
            }
        });
        assertFalse(accountNumberList.isEmpty());
    }


    /**
     * Get retail account info from the backend. Assert that serviceModelCode is returned.
     */
    @Test(dependsOnMethods = "getDSS_V2")
    public void getComposite()
    {

        frs.removeHeaders();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        this.request.given()
                        .header(new Header("user-poe", AccountConstants.RETAIL))
                        .header(new Header("user-mid", mid))
                        .header(new Header("user-retail-lid", ssn))
                        .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
                        .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE));
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);
    
        for (String acctNumber : accountNumberList)
        {
            final String basePath = "accounts.find{it.account.accountId.accountNumber=='" + acctNumber + "'}";
            if (null != response.path(basePath))
            {
                response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
                String compositeServiceModelCode =
                                response.path(basePath + ".details.retailAccountDetail.serviceModelCode");
                Assert.assertTrue(serviceModelCodeList.contains(compositeServiceModelCode));
            }
        }
    }

    /**
     * Get retail account info from the backend. Assert that serviceModelCode is returned.
     */
    @Test(dependsOnMethods = "getDSS_V2")
    public void getDetails()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE_V2));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V2);

        JSONArray accountDetailsList = new JSONObject(response.getBody().asString()).getJSONArray("accountDetails");
    
        for (String acctNumber : accountNumberList)
        {
            for (Object accountDetails : accountDetailsList)
            {
                String serviceModelCodeValue = null;
                boolean containsServiceModelCode = false;
                JSONObject accountDetailsObj = new JSONObject(accountDetails.toString());
                if (accountDetailsObj.has("retailAccountDetail"))
                {
                    if (accountDetailsObj.get("retailAccountDetail") != null)
                    {
                        JSONObject retailAccountDetail = accountDetailsObj.getJSONObject("retailAccountDetail");
                        if (retailAccountDetail.has("accountDetail"))
                        {
                            JSONObject accountDetailObj = retailAccountDetail.getJSONObject("accountDetail");
                            if (accountDetailObj.has("accountId"))
                            {
                                JSONObject accountIdObj = accountDetailObj.getJSONObject("accountId");
                                if (accountIdObj.has("accountNumber"))
                                {
                                    if (null != accountIdObj.get("accountNumber") && accountIdObj.get("accountNumber")
                                                    .equals(acctNumber))
                                    {
                                        containsServiceModelCode = true;
                                    }
                                }
                            }
                        }
                    }
                }
                if (containsServiceModelCode)
                {
                    JSONObject retailAccountDetailValue = accountDetailsObj.getJSONObject("retailAccountDetail");
                    if (retailAccountDetailValue.has("serviceModelCode"))
                    {
                        serviceModelCodeValue = retailAccountDetailValue.get("serviceModelCode").toString();
                    }
                    if (null != serviceModelCodeValue)
                    {
                        Assert.assertTrue(serviceModelCodeList.contains(serviceModelCodeValue));
                    }
                }
            }
        }
    }
    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS()
    {
        this.request.given().header(new Header("AppId", "AP106532"))
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppName", APP_NAME))
                .header(new Header("rtazlid", this.ssn))
                .header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
                .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
                .header(new Header("FACMC", "MID=" + this.mid))
                .header(new Header("FACFC", "SESSION_KEY=1"))
                .header(new Header("Content-Type", "application/json"));
    }


    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}
