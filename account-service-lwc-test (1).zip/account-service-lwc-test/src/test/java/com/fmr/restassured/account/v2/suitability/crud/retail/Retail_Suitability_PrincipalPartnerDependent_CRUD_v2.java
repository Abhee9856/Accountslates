/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.suitability.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.MatcherAssert.assertThat;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsSuitabilityPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.SuitabilityDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountSuitabilityTestData;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.constants.TestDataConstants;

import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.http.HttpStatus;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.http.Header;

/**
 * Tests CRUD operations for Account Suitability V2 for multiple Retail accounts owned by the Principal, Partner, and
 * Dependent.
 *
 * @author a560878
 *
 *         Test flow: 
 *         1. Create Principal, Partner, and Dependent 
 *         2. Search for Retail accounts owned by the Principal 
 *         3. Create then get 3 Manual accounts, one for Principal, one for Partner, and one for Dependent 
 *         4. Create then get account suitability for each of the accounts created 
 *         5. Update then get each account suitability created in step 4 
 *         6. Delete the accounts then get accountsuitability to validate Manual accounts and
 *         suitabililty were deleted 7. 
 *         SQLite data includes all data and partial data scenarios
 * 
 */
@Test(groups = {
	Tags.RETAIL,
	Tags.SUITABILITY,
	Tags.V2,
	"PFCP-3080" })
public class Retail_Suitability_PrincipalPartnerDependent_CRUD_v2 extends PAPBaseServiceTest
{
	protected Retail_Suitability_PrincipalPartnerDependent_CRUD_v2()
	{
		super(Services.Account);
	}
	
	// Data setup
	private AccountsCommonTestData accountsCommonTestData;
	
	private String mid;// = "SuitabilityAccountV2TestMid";

	private String ppid;
	
	private String partPid;
	
	private String dependentPid;
	
	private String mnemonic;
	
	private String mnemonic2;

	private String mnemonic3;

	private String accountNumber;
	
	private String accountNumber2;

	private String accountNumber3;
	
	private String accountId;
	
	private String accountId2;

	private String accountId3;
	
	private String sourceSystem;
	
	private String sourceSystem2;

	private String sourceSystem3;
	
	private String displayName;
	
	private String displayName2;
	
	private String displayName3;
	
	private float value;
	
	private float value2;
	
	private float value3;
	
	private String institutionName;

	private String institutionName2;

	private String institutionName3;

	private String asOfDate = "2021-08-01T00:00:00.000+0000";
	
	private String asOfDate2 = "2021-08-02T00:00:00.000+0000";

	private String asOfDate3 = "2021-08-03T00:00:00.000+0000";
	
	private VelocityContext context;
    
    private static final String LOG_TRACKING_ID = Retail_Suitability_PrincipalPartnerDependent_CRUD_v2.class.getSimpleName();
    
    private static final String FSREQID = LOG_TRACKING_ID;
    
	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";
	FilterableRequestSpecification frs = null;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
	 * for the test, and build the request body from Velocity.
	 */
	@BeforeClass
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();
		accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Retail",oAuth);
		this.mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(this.mid);
		DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


		ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);
		
		// Data setup - partner and dependent
		partPid = Identity.createHouseholdIdentity(mid, ppid, TestDataConstants.HH_PARTNER,
		        oAuth);

		dependentPid = Identity.createHouseholdIdentity(mid, ppid,
		        TestDataConstants.HH_DEPENDENT, oAuth);
		
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
		
		this.request.given()
        .header(new Header("user-poe", "RETAIL"))
        .header(new Header("user-mid", accountsCommonTestData.getMid()))
        .header(new Header("user-retail-lid", accountsCommonTestData.getSsn()))
        .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
        .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
        .header(new Header("excludeExternalDataSources", "false"));

		// Populate request context with user IDs
		context = new VelocityContext();
		context.put("ppid", ppid);
		context.put("source", "RETAIL");
		frs = (FilterableRequestSpecification) request;
	}

	/**
	 * Get Retail account info from the backend. Save the account number.
	 */
	@Test
	public void getRetailAccountInfo() 
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);
		
		//account 1
		mnemonic = response.path("accountList[0].regCode.mnemonic");
		accountNumber = response.path("accountList[0].accountId.accountNumber");
		sourceSystem = response.path("accountList[0].accountId.sourceSystem");
		displayName = response.path("accountList[0].displayName");
		value = response.path("accountList[0].sourceMarketValue.amount.value");
		institutionName = response.path("accountList[0].institutionName");

		//account 2
		mnemonic2 = response.path("accountList[1].regCode.mnemonic");
		accountNumber2 = response.path("accountList[1].accountId.accountNumber");
		sourceSystem2 = response.path("accountList[1].accountId.sourceSystem");
		displayName2 = response.path("accountList[1].displayName");
		value2 = response.path("accountList[1].sourceMarketValue.amount.value");
		institutionName2 = response.path("accountList[1].institutionName");

		//account 3
		mnemonic3 = response.path("accountList[2].regCode.mnemonic");
		accountNumber3 = response.path("accountList[2].accountId.accountNumber");
		sourceSystem3 = response.path("accountList[2].accountId.sourceSystem");
		displayName3 = response.path("accountList[2].displayName");
		value3 = response.path("accountList[2].sourceMarketValue.amount.value");
		institutionName3 = response.path("accountList[2].institutionName");

	}

	
	
	/**
	 * The is the test flow. It iterates through the data provider, performing CRUD operations for each use case.
	 *
	 * @param data
	 * 		the test cases
	 */
	@Test(dependsOnMethods = "getRetailAccountInfo", dataProvider = "getRetailSuitabilityData",
			dataProviderClass = SuitabilityDataProviderUtil.class)
	public void performCrudOperations(final AccountSuitabilityTestData data)
	{
		this.createRetailAccount();
		this.getRetailAccountAfterCreate();
		this.createAccountSuitability(data);
		this.getSuitabilityAfterCreate();
		this.updateAccountSuitability(data);
		this.getSuitabilityAfterUpdate();
		this.deleteAccountSuitability(data);
		this.getSuitabilityAfterDelete();
	}
	
	/**
	 * Create the Retail account. Save the account id.
	 * 
	 * Version V1
	 */
	
	private void createRetailAccount()
	{
		frs.removeHeader("excludeExternalDataSources");
		request.given().header(new Header("excludeExternalDataSources", "true"));

		// Populate request context with user IDs
		context = new VelocityContext();
		context.put("ppid", ppid);
		context.put("source", "RETAIL");

		//account 1 for Principal
		context.put("mnemonic", mnemonic);
		context.put("value", value);
		context.put("source", sourceSystem);
		context.put("accountNumber", accountNumber);
		context.put("displayName", displayName);
		context.put("institutionName", institutionName);
		context.put("asOfDate", asOfDate);
		context.put("relationship",  "PRINCIPAL");

		//account 2 for Partner
		context.put("mnemonic2", mnemonic2);
		context.put("value2", value2);
		context.put("source2", sourceSystem2);
		context.put("accountNumber2", accountNumber2);
		context.put("displayName2", displayName2);
		context.put("institutionName2", institutionName2);
		context.put("asOfDate2", asOfDate2);
		context.put("relationShip1",  "PARTNER");
		context.put("partnerPId", partPid);

		//account 3 for Dependent
		context.put("mnemonic3", mnemonic3);
		context.put("value3", value3);
		context.put("source3", sourceSystem3);
		context.put("accountNumber3", accountNumber3);
		context.put("displayName3", displayName3);
		context.put("institutionName3", institutionName3);
		context.put("asOfDate3", asOfDate3);
		context.put("relationShip2",  "DEPENDENT");
		context.put("dependentPId",  dependentPid);
 
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(HttpStatus.SC_OK)
				.body(
					"accountList.find{it.displayName=='" + displayName + "'}.regCode.mnemonic", equalTo(mnemonic),
					"accountList.find{it.displayName=='" + displayName + "'}.accountId.accountNumber", equalTo(accountNumber),
					"accountList.find{it.displayName=='" + displayName2 + "'}.regCode.mnemonic", equalTo(mnemonic2),
					"accountList.find{it.displayName=='" + displayName2 + "'}.accountId.accountNumber", equalTo(accountNumber2),
					"accountList.find{it.displayName=='" + displayName3 + "'}.regCode.mnemonic", equalTo(mnemonic3),
					"accountList.find{it.displayName=='" + displayName3 + "'}.accountId.accountNumber", equalTo(accountNumber3));

		// Gets and saves the CFP account ID
		accountId = response.path("accountList.find{it.displayName=='" + displayName + "'}.accountId.id");
		context.put("accId", accountId);
		accountId2 = response.path("accountList.find{it.displayName=='" + displayName2 + "'}.accountId.id");
		context.put("accId2", accountId2);
		accountId3 = response.path("accountList.find{it.displayName=='" + displayName3 + "'}.accountId.id");
		context.put("accId3", accountId3);

	}
	
	/**
	 * Validate the account was created correctly.
	 */
	
	private void getRetailAccountAfterCreate() 
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);
		
		response.then().log().ifValidationFails()
		.statusCode(HttpStatus.SC_OK)
		.body(
			"accountList.find{it.displayName=='" + displayName + "'}.regCode.mnemonic", equalTo(mnemonic),
			"accountList.find{it.displayName=='" + displayName + "'}.accountId.accountNumber", equalTo(accountNumber),
			"accountList.find{it.displayName=='" + displayName + "'}.accountId.id", equalTo(accountId),
			"accountList.find{it.displayName=='" + displayName2 + "'}.regCode.mnemonic", equalTo(mnemonic2),
			"accountList.find{it.displayName=='" + displayName2 + "'}.accountId.accountNumber", equalTo(accountNumber2),
			"accountList.find{it.displayName=='" + displayName2 + "'}.accountId.id", equalTo(accountId2),
			"accountList.find{it.displayName=='" + displayName3 + "'}.regCode.mnemonic", equalTo(mnemonic3),
			"accountList.find{it.displayName=='" + displayName3 + "'}.accountId.accountNumber", equalTo(accountNumber3));

	}
	

	/**
	 * Create the account suitability.
	 * 
	 */
	private void createAccountSuitability(final AccountSuitabilityTestData data)
	{
		// Generate request body
		//Account 1
		context.put("investObj_Txt", data.getInvestObjTxt());
		context.put("investObj_Id", data.getInvestObjId());
		context.put("tam_TotalEqty", data.getTamTotalEqty());
		context.put("tam_lowEqtyPct", data.getTamLowEqtyPct());
		context.put("tam_upEqtyPct", data.getTamUpEqtyPct());
		context.put("tam_assetAlloc_Id",  data.getTamAssetAllocId());
		context.put("tam_context",  data.getTamContext());
		context.put("investPurp_Txt", data.getInvestPurpTxt());
		context.put("investPurp_Id", data.getInvestPurpId());
		context.put("investKnow_Txt",  data.getInvestKnowTxt());
		context.put("investKnow_Id",  data.getInvestKnowId());
		context.put("annualIncRng_Txt",  data.getAnnualIncRngTxt());
		context.put("annualIncRng_Id",  data.getAnnualIncRngId());
		context.put("liqNWRng_Txt",  data.getLiqNWRngTxt());
		context.put("liqNWRng_Id",  data.getLiqNWRngId());
		context.put("netWorthRng_Txt",  data.getNetWorthRngTxt());
		context.put("netWorthRng_Id",  data.getNetWorthRngId());
		context.put("taxBrktRng_Txt",  data.getTaxBrktRngTxt());
		context.put("taxBrktRng_Id",  data.getTaxBrktRngId());
		context.put("essExpRng_Txt",  data.getEssExpRngTxt());
		context.put("essExpRng_Id",  data.getEssExpRngId());
		context.put("spendLikeRng_Txt",  data.getSpendLikeRngTxt());
		context.put("spendLikeRng_Id",  data.getSpendLikeRngId());
		context.put("invesTimeHrzn_Txt",  data.getInvesTimeHrznTxt());
		context.put("invesTimeHrzn_Id",  data.getInvesTimeHrznId());

		//Account 2
		context.put("source2", sourceSystem2);
		context.put("accountNumber2", accountNumber2);
		context.put("ppid2", partPid);
		context.put("relationship2",  "PARTNER");
		context.put("investObj_Txt2", data.getInvestObjTxt());
		context.put("investObj_Id2", data.getInvestObjId());
		context.put("tam_TotalEqty2", data.getTamTotalEqty());
		context.put("tam_lowEqtyPct2", data.getTamLowEqtyPct());
		context.put("tam_upEqtyPct2", data.getTamUpEqtyPct());
		context.put("tam_assetAlloc_Id2",  data.getTamAssetAllocId());
		context.put("tam_context2",  data.getTamContext());
		context.put("investPurp_Txt2", data.getInvestPurpTxt());
		context.put("investPurp_Id2", data.getInvestPurpId());
		context.put("investKnow_Txt2",  data.getInvestKnowTxt());
		context.put("investKnow_Id2",  data.getInvestKnowId());
		context.put("annualIncRng_Txt2",  data.getAnnualIncRngTxt());
		context.put("annualIncRng_Id2",  data.getAnnualIncRngId());
		context.put("liqNWRng_Txt2",  data.getLiqNWRngTxt());
		context.put("liqNWRng_Id2",  data.getLiqNWRngId());
		context.put("netWorthRng_Txt2",  data.getNetWorthRngTxt());
		context.put("netWorthRng_Id2",  data.getNetWorthRngId());
		context.put("taxBrktRng_Txt2",  data.getTaxBrktRngTxt());
		context.put("taxBrktRng_Id2",  data.getTaxBrktRngId());
		context.put("essExpRng_Txt2",  data.getEssExpRngTxt());
		context.put("essExpRng_Id2",  data.getEssExpRngId());
		context.put("spendLikeRng_Txt2",  data.getSpendLikeRngTxt());
		context.put("spendLikeRng_Id2",  data.getSpendLikeRngId());
		context.put("invesTimeHrzn_Txt2",  data.getInvesTimeHrznTxt());
		context.put("invesTimeHrzn_Id2",  data.getInvesTimeHrznId());

		//Account 3
		context.put("source3", sourceSystem3);
		context.put("accountNumber3", accountNumber3);
		context.put("ppid3", dependentPid);
		context.put("relationship3",  "DEPENDENT");
		context.put("investObj_Txt3", data.getInvestObjTxt());
		context.put("investObj_Id3", data.getInvestObjId());
		context.put("tam_TotalEqty3", data.getTamTotalEqty());
		context.put("tam_lowEqtyPct3", data.getTamLowEqtyPct());
		context.put("tam_upEqtyPct3", data.getTamUpEqtyPct());
		context.put("tam_assetAlloc_Id3",  data.getTamAssetAllocId());
		context.put("tam_context3",  data.getTamContext());
		context.put("investPurp_Txt3", data.getInvestPurpTxt());
		context.put("investPurp_Id3", data.getInvestPurpId());
		context.put("investKnow_Txt3",  data.getInvestKnowTxt());
		context.put("investKnow_Id3",  data.getInvestKnowId());
		context.put("annualIncRng_Txt3",  data.getAnnualIncRngTxt());
		context.put("annualIncRng_Id3",  data.getAnnualIncRngId());
		context.put("liqNWRng_Txt3",  data.getLiqNWRngTxt());
		context.put("liqNWRng_Id3",  data.getLiqNWRngId());
		context.put("netWorthRng_Txt3",  data.getNetWorthRngTxt());
		context.put("netWorthRng_Id3",  data.getNetWorthRngId());
		context.put("taxBrktRng_Txt3",  data.getTaxBrktRngTxt());
		context.put("taxBrktRng_Id3",  data.getTaxBrktRngId());
		context.put("essExpRng_Txt3",  data.getEssExpRngTxt());
		context.put("essExpRng_Id3",  data.getEssExpRngId());
		context.put("spendLikeRng_Txt3",  data.getSpendLikeRngTxt());
		context.put("spendLikeRng_Id3",  data.getSpendLikeRngId());
		context.put("invesTimeHrzn_Txt3",  data.getInvesTimeHrznTxt());
		context.put("invesTimeHrzn_Id3",  data.getInvesTimeHrznId());
		
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_CREATE_TEMPLATE_V2))
			.log().ifValidationFails();

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.CREATE_ACCOUNTS_SUITABILITY_V2);

		// Assert on response
		response.then().log().ifValidationFails()
		.statusCode(HttpStatus.SC_OK)
		.body("accountSuitability", not(empty()));
		
		//Assert on Investment Objective if present
		if (data.getInvestObjTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].investmentObjective.targetAssetMix", not(empty()),
			"accountSuitability[0].investmentObjective.targetAssetMix.name", equalTo(data.getInvestObjTxt()),
			"accountSuitability[0].investmentObjective.targetAssetMix.context", equalTo(data.getTamContext()),
			"accountSuitability[0].investmentObjective.id", equalTo(data.getInvestObjId()),
			"accountSuitability[1].investmentObjective.targetAssetMix", not(empty()),
			"accountSuitability[1].investmentObjective.targetAssetMix.name", equalTo(data.getInvestObjTxt()),
			"accountSuitability[1].investmentObjective.targetAssetMix.context", equalTo(data.getTamContext()),
			"accountSuitability[1].investmentObjective.id", equalTo(data.getInvestObjId()),
			"accountSuitability[2].investmentObjective.targetAssetMix", not(empty()),
			"accountSuitability[2].investmentObjective.targetAssetMix.name", equalTo(data.getInvestObjTxt()),
			"accountSuitability[2].investmentObjective.targetAssetMix.context", equalTo(data.getTamContext()),
			"accountSuitability[2].investmentObjective.id", equalTo(data.getInvestObjId()));

		}
		
		//Assert on Investment Purpose if present
		if (data.getInvestPurpTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].investmentPurpose", not(empty()),
			"accountSuitability[0].investmentPurpose.values[0].value", equalTo(data.getInvestPurpTxt()),
			"accountSuitability[1].investmentPurpose", not(empty()),
			"accountSuitability[1].investmentPurpose.values[0].value", equalTo(data.getInvestPurpTxt()),
			"accountSuitability[2].investmentPurpose", not(empty()),
			"accountSuitability[2].investmentPurpose.values[0].value", equalTo(data.getInvestPurpTxt()));
			Integer investPurpId = response.body().jsonPath()
					.getInt("accountSuitability[0].investmentPurpose.values[0].id");
			assertThat(investPurpId.toString(), equalTo(data.getInvestPurpId()));
			Integer investPurpId2 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentPurpose.values[0].id");
			assertThat(investPurpId2.toString(), equalTo(data.getInvestPurpId()));
			Integer investPurpId3 = response.body().jsonPath()
					.getInt("accountSuitability[2].investmentPurpose.values[0].id");
			assertThat(investPurpId3.toString(), equalTo(data.getInvestPurpId()));
			
		}
		
		//Assert on Investment Knowledge if present
		if (data.getInvestKnowTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].investmentKnowledge", not(empty()),
			"accountSuitability[0].investmentKnowledge.values[0].value", equalTo(data.getInvestKnowTxt()),
			"accountSuitability[1].investmentKnowledge", not(empty()),
			"accountSuitability[1].investmentKnowledge.values[0].value", equalTo(data.getInvestKnowTxt()),
			"accountSuitability[2].investmentKnowledge", not(empty()),
			"accountSuitability[2].investmentKnowledge.values[0].value", equalTo(data.getInvestKnowTxt()));
			Integer investKnowId = response.body().jsonPath()
					.getInt("accountSuitability[0].investmentKnowledge.values[0].id");
			assertThat(investKnowId.toString(), equalTo(data.getInvestKnowId()));
			Integer investKnowId2 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentKnowledge.values[0].id");
			assertThat(investKnowId2.toString(), equalTo(data.getInvestKnowId()));
			Integer investKnowId3 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentKnowledge.values[0].id");
			assertThat(investKnowId3.toString(), equalTo(data.getInvestKnowId()));

		}


		//Assert on Liquid Net Worth Range if present
		if (data.getLiqNWRngTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].liquidNetworthRange", not(empty()),
			"accountSuitability[0].liquidNetworthRange.values[0].value", equalTo(data.getLiqNWRngTxt()),
			"accountSuitability[1].liquidNetworthRange", not(empty()),
			"accountSuitability[1].liquidNetworthRange.values[0].value", equalTo(data.getLiqNWRngTxt()),
			"accountSuitability[2].liquidNetworthRange", not(empty()),
			"accountSuitability[2].liquidNetworthRange.values[0].value", equalTo(data.getLiqNWRngTxt()));
			Integer ligNWRng = response.body().jsonPath()
					.getInt("accountSuitability[0].liquidNetworthRange.values[0].id");
			assertThat(ligNWRng.toString(), equalTo(data.getLiqNWRngId()));
			Integer ligNWRng2 = response.body().jsonPath()
					.getInt("accountSuitability[1].liquidNetworthRange.values[0].id");
			assertThat(ligNWRng2.toString(), equalTo(data.getLiqNWRngId()));
			Integer ligNWRng3 = response.body().jsonPath()
					.getInt("accountSuitability[1].liquidNetworthRange.values[0].id");
			assertThat(ligNWRng3.toString(), equalTo(data.getLiqNWRngId()));

		}

		//Assert on Net Worth Range if present
		if (data.getNetWorthRngTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].networthRange", not(empty()),
			"accountSuitability[0].networthRange.values[0].value", equalTo(data.getNetWorthRngTxt()),
			"accountSuitability[1].networthRange", not(empty()),
			"accountSuitability[1].networthRange.values[0].value", equalTo(data.getNetWorthRngTxt()),
			"accountSuitability[2].networthRange", not(empty()),
			"accountSuitability[2].networthRange.values[0].value", equalTo(data.getNetWorthRngTxt()));
			Integer netWorthRng = response.body().jsonPath()
					.getInt("accountSuitability[0].networthRange.values[0].id");
			assertThat(netWorthRng.toString(), equalTo(data.getNetWorthRngId()));
			Integer netWorthRng2 = response.body().jsonPath()
					.getInt("accountSuitability[1].networthRange.values[0].id");
			assertThat(netWorthRng2.toString(), equalTo(data.getNetWorthRngId()));
			Integer netWorthRng3 = response.body().jsonPath()
					.getInt("accountSuitability[1].networthRange.values[0].id");
			assertThat(netWorthRng3.toString(), equalTo(data.getNetWorthRngId()));

		}

		//Assert on Tax Bracket Range if present
		if (data.getTaxBrktRngTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].taxBracketRange", not(empty()),
			"accountSuitability[0].taxBracketRange.values[0].value", equalTo(data.getTaxBrktRngTxt()),
			"accountSuitability[1].taxBracketRange", not(empty()),
			"accountSuitability[1].taxBracketRange.values[0].value", equalTo(data.getTaxBrktRngTxt()),
			"accountSuitability[2].taxBracketRange", not(empty()),
			"accountSuitability[2].taxBracketRange.values[0].value", equalTo(data.getTaxBrktRngTxt()));
			Integer taxBrktRng = response.body().jsonPath()
					.getInt("accountSuitability[0].taxBracketRange.values[0].id");
			assertThat(taxBrktRng.toString(), equalTo(data.getTaxBrktRngId()));
			Integer taxBrktRng2 = response.body().jsonPath()
					.getInt("accountSuitability[1].taxBracketRange.values[0].id");
			assertThat(taxBrktRng2.toString(), equalTo(data.getTaxBrktRngId()));
			Integer taxBrktRng3 = response.body().jsonPath()
					.getInt("accountSuitability[1].taxBracketRange.values[0].id");
			assertThat(taxBrktRng3.toString(), equalTo(data.getTaxBrktRngId()));

		}

		//Assert on Essential Expense Range if present
		if (data.getEssExpRngTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].essentialExpensesRange", not(empty()),
			"accountSuitability[0].essentialExpensesRange.values[0].value", equalTo(data.getEssExpRngTxt()),
			"accountSuitability[1].essentialExpensesRange", not(empty()),
			"accountSuitability[1].essentialExpensesRange.values[0].value", equalTo(data.getEssExpRngTxt()),
			"accountSuitability[2].essentialExpensesRange", not(empty()),
			"accountSuitability[2].essentialExpensesRange.values[0].value", equalTo(data.getEssExpRngTxt()));
			Integer essExpRng = response.body().jsonPath()
					.getInt("accountSuitability[0].essentialExpensesRange.values[0].id");
			assertThat(essExpRng.toString(), equalTo(data.getEssExpRngId()));
			Integer essExpRng2 = response.body().jsonPath()
					.getInt("accountSuitability[1].essentialExpensesRange.values[0].id");
			assertThat(essExpRng2.toString(), equalTo(data.getEssExpRngId()));
			Integer essExpRng3 = response.body().jsonPath()
					.getInt("accountSuitability[1].essentialExpensesRange.values[0].id");
			assertThat(essExpRng3.toString(), equalTo(data.getEssExpRngId()));

		}

		//Assert on Spending Likelihood Range if present
		if (data.getSpendLikeRngTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].spendingLikelihoodRange", not(empty()),
			"accountSuitability[0].spendingLikelihoodRange.values[0].value", equalTo(data.getSpendLikeRngTxt()),
			"accountSuitability[1].spendingLikelihoodRange", not(empty()),
			"accountSuitability[1].spendingLikelihoodRange.values[0].value", equalTo(data.getSpendLikeRngTxt()),
			"accountSuitability[2].spendingLikelihoodRange", not(empty()),
			"accountSuitability[2].spendingLikelihoodRange.values[0].value", equalTo(data.getSpendLikeRngTxt()));
			Integer spendLikeRng = response.body().jsonPath()
					.getInt("accountSuitability[0].spendingLikelihoodRange.values[0].id");
			assertThat(spendLikeRng.toString(), equalTo(data.getSpendLikeRngId()));
			Integer spendLikeRng2 = response.body().jsonPath()
					.getInt("accountSuitability[1].spendingLikelihoodRange.values[0].id");
			assertThat(spendLikeRng2.toString(), equalTo(data.getSpendLikeRngId()));
			Integer spendLikeRng3 = response.body().jsonPath()
					.getInt("accountSuitability[1].spendingLikelihoodRange.values[0].id");
			assertThat(spendLikeRng3.toString(), equalTo(data.getSpendLikeRngId()));

		}

		//Assert on Investment Time Horizon if present
		if (data.getInvesTimeHrznTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].investmentTimeHorizon", not(empty()),
			"accountSuitability[0].investmentTimeHorizon.values[0].value", equalTo(data.getInvesTimeHrznTxt()),
			"accountSuitability[1].investmentTimeHorizon", not(empty()),
			"accountSuitability[1].investmentTimeHorizon.values[0].value", equalTo(data.getInvesTimeHrznTxt()),
			"accountSuitability[2].investmentTimeHorizon", not(empty()),
			"accountSuitability[2].investmentTimeHorizon.values[0].value", equalTo(data.getInvesTimeHrznTxt()));
			Integer timeHorizon = response.body().jsonPath()
					.getInt("accountSuitability[0].investmentTimeHorizon.values[0].id");
			assertThat(timeHorizon.toString(), equalTo(data.getInvesTimeHrznId()));
			Integer timeHorizon2 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentTimeHorizon.values[0].id");
			assertThat(timeHorizon2.toString(), equalTo(data.getInvesTimeHrznId()));
			Integer timeHorizon3 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentTimeHorizon.values[0].id");
			assertThat(timeHorizon3.toString(), equalTo(data.getInvesTimeHrznId()));

		}
		
	}
	
	/**
	 * Validate the suitability information just created.
	 * 
	 */
	private void getSuitabilityAfterCreate()
	{
		
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));
		
		// Call Account service
		response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);
		
		// Assert on response
		response.then().log().ifValidationFails()
		.statusCode(HttpStatus.SC_OK)
		.body("accountSuitability", not(empty()));

	}
	
	/**
	 * Update the suitability just created.
	 * 
	 */
	private void updateAccountSuitability(final AccountSuitabilityTestData data)
	{
		// Generate request body
		//Account 1
		context.put("investObj_Txt", data.getInvestObjTxtUpdt());
		context.put("investObj_Id", data.getInvestObjIdUpdt());
		context.put("tam_TotalEqty", data.getTamTotalEqtyUpdt());
		context.put("tam_DomEqty", data.getTamDomEqtyUpdt());
		context.put("tam_ForeignEqty",  data.getTamForeignEqtyUpdt());
		context.put("tam_Bond",  data.getTamBondUpdt());
		context.put("tam_Cash", data.getTamCashUpdt());
		context.put("tam_lowEqtyPct", data.getTamLowEqtyPctUpdt());
		context.put("tam_upEqtyPct", data.getTamUpEqtyPctUpdt());
		context.put("tam_assetAlloc_Id",  data.getTamAssetAllocIdUpdt());
		context.put("tam_context",  data.getTamContextUpdt());
		context.put("investPurp_Txt", data.getInvestPurpTxtUpdt());
		context.put("investPurp_Id", data.getInvestPurpIdUpdt());
		context.put("investKnow_Txt",  data.getInvestKnowTxtUpdt());
		context.put("investKnow_Id",  data.getInvestKnowIdUpdt());
		context.put("annualIncRng_Txt",  data.getAnnualIncRngTxtUpdt());
		context.put("annualIncRng_Id",  data.getAnnualIncRngIdUpdt());
		context.put("liqNWRng_Txt",  data.getLiqNWRngTxtUpdt());
		context.put("liqNWRng_Id",  data.getLiqNWRngIdUpdt());
		context.put("netWorthRng_Txt",  data.getNetWorthRngTxtUpdt());
		context.put("netWorthRng_Id",  data.getNetWorthRngIdUpdt());
		context.put("taxBrktRng_Txt",  data.getTaxBrktRngTxtUpdt());
		context.put("taxBrktRng_Id",  data.getTaxBrktRngIdUpdt());
		context.put("essExpRng_Txt",  data.getEssExpRngTxtUpdt());
		context.put("essExpRng_Id",  data.getEssExpRngIdUpdt());
		context.put("spendLikeRng_Txt",  data.getSpendLikeRngTxtUpdt());
		context.put("spendLikeRng_Id",  data.getSpendLikeRngIdUpdt());
		context.put("invesTimeHrzn_Txt",  data.getInvesTimeHrznTxtUpdt());
		context.put("invesTimeHrzn_Id",  data.getInvesTimeHrznIdUpdt());
	
		//Account 2
		context.put("investObj_Txt2", data.getInvestObjTxtUpdt());
		context.put("investObj_Id2", data.getInvestObjIdUpdt());
		context.put("tam_TotalEqty2", data.getTamTotalEqtyUpdt());
		context.put("tam_DomEqty2", data.getTamDomEqtyUpdt());
		context.put("tam_ForeignEqty2",  data.getTamForeignEqtyUpdt());
		context.put("tam_Bond2",  data.getTamBondUpdt());
		context.put("tam_Cash2", data.getTamCashUpdt());
		context.put("tam_lowEqtyPct2", data.getTamLowEqtyPctUpdt());
		context.put("tam_upEqtyPct2", data.getTamUpEqtyPctUpdt());
		context.put("tam_assetAlloc_Id2",  data.getTamAssetAllocIdUpdt());
		context.put("tam_context2",  data.getTamContextUpdt());
		context.put("investPurp_Txt2", data.getInvestPurpTxtUpdt());
		context.put("investPurp_Id2", data.getInvestPurpIdUpdt());
		context.put("investKnow_Txt2",  data.getInvestKnowTxtUpdt());
		context.put("investKnow_Id2",  data.getInvestKnowIdUpdt());
		context.put("annualIncRng_Txt2",  data.getAnnualIncRngTxtUpdt());
		context.put("annualIncRng_Id2",  data.getAnnualIncRngIdUpdt());
		context.put("liqNWRng_Txt2",  data.getLiqNWRngTxtUpdt());
		context.put("liqNWRng_Id2",  data.getLiqNWRngIdUpdt());
		context.put("netWorthRng_Txt2",  data.getNetWorthRngTxtUpdt());
		context.put("netWorthRng_Id2",  data.getNetWorthRngIdUpdt());
		context.put("taxBrktRng_Txt2",  data.getTaxBrktRngTxtUpdt());
		context.put("taxBrktRng_Id2",  data.getTaxBrktRngIdUpdt());
		context.put("essExpRng_Txt2",  data.getEssExpRngTxtUpdt());
		context.put("essExpRng_Id2",  data.getEssExpRngIdUpdt());
		context.put("spendLikeRng_Txt2",  data.getSpendLikeRngTxtUpdt());
		context.put("spendLikeRng_Id2",  data.getSpendLikeRngIdUpdt());
		context.put("invesTimeHrzn_Txt2",  data.getInvesTimeHrznTxtUpdt());
		context.put("invesTimeHrzn_Id2",  data.getInvesTimeHrznIdUpdt());
		
		//Account 3
		context.put("investObj_Txt3", data.getInvestObjTxtUpdt());
		context.put("investObj_Id3", data.getInvestObjIdUpdt());
		context.put("tam_TotalEqty3", data.getTamTotalEqtyUpdt());
		context.put("tam_DomEqty3", data.getTamDomEqtyUpdt());
		context.put("tam_ForeignEqty3",  data.getTamForeignEqtyUpdt());
		context.put("tam_Bond3",  data.getTamBondUpdt());
		context.put("tam_Cash3", data.getTamCashUpdt());
		context.put("tam_lowEqtyPct3", data.getTamLowEqtyPctUpdt());
		context.put("tam_upEqtyPct3", data.getTamUpEqtyPctUpdt());
		context.put("tam_assetAlloc_Id3",  data.getTamAssetAllocIdUpdt());
		context.put("tam_context3",  data.getTamContextUpdt());
		context.put("investPurp_Txt3", data.getInvestPurpTxtUpdt());
		context.put("investPurp_Id3", data.getInvestPurpIdUpdt());
		context.put("investKnow_Txt3",  data.getInvestKnowTxtUpdt());
		context.put("investKnow_Id3",  data.getInvestKnowIdUpdt());
		context.put("annualIncRng_Txt3",  data.getAnnualIncRngTxtUpdt());
		context.put("annualIncRng_Id3",  data.getAnnualIncRngIdUpdt());
		context.put("liqNWRng_Txt3",  data.getLiqNWRngTxtUpdt());
		context.put("liqNWRng_Id3",  data.getLiqNWRngIdUpdt());
		context.put("netWorthRng_Txt3",  data.getNetWorthRngTxtUpdt());
		context.put("netWorthRng_Id3",  data.getNetWorthRngIdUpdt());
		context.put("taxBrktRng_Txt3",  data.getTaxBrktRngTxtUpdt());
		context.put("taxBrktRng_Id3",  data.getTaxBrktRngIdUpdt());
		context.put("essExpRng_Txt3",  data.getEssExpRngTxtUpdt());
		context.put("essExpRng_Id3",  data.getEssExpRngIdUpdt());
		context.put("spendLikeRng_Txt3",  data.getSpendLikeRngTxtUpdt());
		context.put("spendLikeRng_Id3",  data.getSpendLikeRngIdUpdt());
		context.put("invesTimeHrzn_Txt3",  data.getInvesTimeHrznTxtUpdt());
		context.put("invesTimeHrzn_Id3",  data.getInvesTimeHrznIdUpdt());
		
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_UPDATE_TEMPLATE_V2));
		
		// Call Account service
		response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.UPDATE_ACCOUNTS_SUITABILITY_V2);
		
		// Assert on response
		response.then().log().ifValidationFails()
		.statusCode(HttpStatus.SC_OK)
		.body("accountSuitability", not(empty()));
		
		//Assert on Investment Objective if present
		if (data.getInvestObjTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].investmentObjective.targetAssetMix", not(empty()),
			"accountSuitability[0].investmentObjective.targetAssetMix.name", equalTo(data.getInvestObjTxtUpdt()),
			"accountSuitability[0].investmentObjective.targetAssetMix.context", equalTo(data.getTamContextUpdt()),
			"accountSuitability[0].investmentObjective.id", equalTo(data.getInvestObjIdUpdt()),
			"accountSuitability[1].investmentObjective.targetAssetMix", not(empty()),
			"accountSuitability[1].investmentObjective.targetAssetMix.name", equalTo(data.getInvestObjTxtUpdt()),
			"accountSuitability[1].investmentObjective.targetAssetMix.context", equalTo(data.getTamContextUpdt()),
			"accountSuitability[1].investmentObjective.id", equalTo(data.getInvestObjIdUpdt()),
			"accountSuitability[2].investmentObjective.targetAssetMix", not(empty()),
			"accountSuitability[2].investmentObjective.targetAssetMix.name", equalTo(data.getInvestObjTxtUpdt()),
			"accountSuitability[2].investmentObjective.targetAssetMix.context", equalTo(data.getTamContextUpdt()),
			"accountSuitability[2].investmentObjective.id", equalTo(data.getInvestObjIdUpdt()));

		}
		
		//Assert on Investment Purpose if present
		if (data.getInvestPurpTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].investmentPurpose", not(empty()),
			"accountSuitability[0].investmentPurpose.values[0].value", equalTo(data.getInvestPurpTxtUpdt()),
			"accountSuitability[1].investmentPurpose", not(empty()),
			"accountSuitability[1].investmentPurpose.values[0].value", equalTo(data.getInvestPurpTxtUpdt()),
			"accountSuitability[2].investmentPurpose", not(empty()),
			"accountSuitability[2].investmentPurpose.values[0].value", equalTo(data.getInvestPurpTxtUpdt()));
			Integer investPurpId = response.body().jsonPath()
					.getInt("accountSuitability[0].investmentPurpose.values[0].id");
			assertThat(investPurpId.toString(), equalTo(data.getInvestPurpIdUpdt()));
			Integer investPurpId2 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentPurpose.values[0].id");
			assertThat(investPurpId2.toString(), equalTo(data.getInvestPurpIdUpdt()));
			Integer investPurpId3 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentPurpose.values[0].id");
			assertThat(investPurpId3.toString(), equalTo(data.getInvestPurpIdUpdt()));
			
		}
		
		//Assert on Investment Knowledge if present
		if (data.getInvestKnowTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].investmentKnowledge", not(empty()),
			"accountSuitability[0].investmentKnowledge.values[0].value", equalTo(data.getInvestKnowTxtUpdt()),
			"accountSuitability[1].investmentKnowledge", not(empty()),
			"accountSuitability[1].investmentKnowledge.values[0].value", equalTo(data.getInvestKnowTxtUpdt()),
			"accountSuitability[2].investmentKnowledge", not(empty()),
			"accountSuitability[2].investmentKnowledge.values[0].value", equalTo(data.getInvestKnowTxtUpdt()));
			Integer investKnowId = response.body().jsonPath()
					.getInt("accountSuitability[0].investmentKnowledge.values[0].id");
			assertThat(investKnowId.toString(), equalTo(data.getInvestKnowIdUpdt()));
			Integer investKnowId2 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentKnowledge.values[0].id");
			assertThat(investKnowId2.toString(), equalTo(data.getInvestKnowIdUpdt()));
			Integer investKnowId3 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentKnowledge.values[0].id");
			assertThat(investKnowId3.toString(), equalTo(data.getInvestKnowIdUpdt()));

		}

		//Assert on Liquid Net Worth Range if present
		if (data.getLiqNWRngTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].liquidNetworthRange", not(empty()),
			"accountSuitability[0].liquidNetworthRange.values[0].value", equalTo(data.getLiqNWRngTxtUpdt()),
			"accountSuitability[1].liquidNetworthRange", not(empty()),
			"accountSuitability[1].liquidNetworthRange.values[0].value", equalTo(data.getLiqNWRngTxtUpdt()),
			"accountSuitability[2].liquidNetworthRange", not(empty()),
			"accountSuitability[2].liquidNetworthRange.values[0].value", equalTo(data.getLiqNWRngTxtUpdt()));
			Integer ligNWRng = response.body().jsonPath()
					.getInt("accountSuitability[0].liquidNetworthRange.values[0].id");
			assertThat(ligNWRng.toString(), equalTo(data.getLiqNWRngIdUpdt()));
			Integer ligNWRng2 = response.body().jsonPath()
					.getInt("accountSuitability[1].liquidNetworthRange.values[0].id");
			assertThat(ligNWRng2.toString(), equalTo(data.getLiqNWRngIdUpdt()));
			Integer ligNWRng3 = response.body().jsonPath()
					.getInt("accountSuitability[1].liquidNetworthRange.values[0].id");
			assertThat(ligNWRng3.toString(), equalTo(data.getLiqNWRngIdUpdt()));

		}

		//Assert on Net Worth Range if present
		if (data.getNetWorthRngTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].networthRange", not(empty()),
			"accountSuitability[0].networthRange.values[0].value", equalTo(data.getNetWorthRngTxtUpdt()),
			"accountSuitability[1].networthRange", not(empty()),
			"accountSuitability[1].networthRange.values[0].value", equalTo(data.getNetWorthRngTxtUpdt()),
			"accountSuitability[2].networthRange", not(empty()),
			"accountSuitability[2].networthRange.values[0].value", equalTo(data.getNetWorthRngTxtUpdt()));
			Integer netWorthRng = response.body().jsonPath()
					.getInt("accountSuitability[0].networthRange.values[0].id");
			assertThat(netWorthRng.toString(), equalTo(data.getNetWorthRngIdUpdt()));
			Integer netWorthRng2 = response.body().jsonPath()
					.getInt("accountSuitability[1].networthRange.values[0].id");
			assertThat(netWorthRng2.toString(), equalTo(data.getNetWorthRngIdUpdt()));
			Integer netWorthRng3 = response.body().jsonPath()
					.getInt("accountSuitability[1].networthRange.values[0].id");
			assertThat(netWorthRng3.toString(), equalTo(data.getNetWorthRngIdUpdt()));

		}

		//Assert on Tax Bracket Range if present
		if (data.getTaxBrktRngTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].taxBracketRange", not(empty()),
			"accountSuitability[0].taxBracketRange.values[0].value", equalTo(data.getTaxBrktRngTxtUpdt()),
			"accountSuitability[1].taxBracketRange", not(empty()),
			"accountSuitability[1].taxBracketRange.values[0].value", equalTo(data.getTaxBrktRngTxtUpdt()),
			"accountSuitability[2].taxBracketRange", not(empty()),
			"accountSuitability[2].taxBracketRange.values[0].value", equalTo(data.getTaxBrktRngTxtUpdt()));
			Integer taxBrktRng = response.body().jsonPath()
					.getInt("accountSuitability[0].taxBracketRange.values[0].id");
			assertThat(taxBrktRng.toString(), equalTo(data.getTaxBrktRngIdUpdt()));
			Integer taxBrktRng2 = response.body().jsonPath()
					.getInt("accountSuitability[1].taxBracketRange.values[0].id");
			assertThat(taxBrktRng2.toString(), equalTo(data.getTaxBrktRngIdUpdt()));
			Integer taxBrktRng3 = response.body().jsonPath()
					.getInt("accountSuitability[1].taxBracketRange.values[0].id");
			assertThat(taxBrktRng3.toString(), equalTo(data.getTaxBrktRngIdUpdt()));

		}

		//Assert on Essential Expense Range if present
		if (data.getEssExpRngTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].essentialExpensesRange", not(empty()),
			"accountSuitability[0].essentialExpensesRange.values[0].value", equalTo(data.getEssExpRngTxtUpdt()),
			"accountSuitability[1].essentialExpensesRange", not(empty()),
			"accountSuitability[1].essentialExpensesRange.values[0].value", equalTo(data.getEssExpRngTxtUpdt()),
			"accountSuitability[2].essentialExpensesRange", not(empty()),
			"accountSuitability[2].essentialExpensesRange.values[0].value", equalTo(data.getEssExpRngTxtUpdt()));
			Integer essExpRng = response.body().jsonPath()
					.getInt("accountSuitability[0].essentialExpensesRange.values[0].id");
			assertThat(essExpRng.toString(), equalTo(data.getEssExpRngIdUpdt()));
			Integer essExpRng2 = response.body().jsonPath()
					.getInt("accountSuitability[1].essentialExpensesRange.values[0].id");
			assertThat(essExpRng2.toString(), equalTo(data.getEssExpRngIdUpdt()));
			Integer essExpRng3 = response.body().jsonPath()
					.getInt("accountSuitability[1].essentialExpensesRange.values[0].id");
			assertThat(essExpRng3.toString(), equalTo(data.getEssExpRngIdUpdt()));

		}

		//Assert on Spending Likelihood Range if present
		if (data.getSpendLikeRngTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].spendingLikelihoodRange", not(empty()),
			"accountSuitability[0].spendingLikelihoodRange.values[0].value", equalTo(data.getSpendLikeRngTxtUpdt()),
			"accountSuitability[1].spendingLikelihoodRange", not(empty()),
			"accountSuitability[1].spendingLikelihoodRange.values[0].value", equalTo(data.getSpendLikeRngTxtUpdt()),
			"accountSuitability[2].spendingLikelihoodRange", not(empty()),
			"accountSuitability[2].spendingLikelihoodRange.values[0].value", equalTo(data.getSpendLikeRngTxtUpdt()));
			Integer spendLikeRng = response.body().jsonPath()
					.getInt("accountSuitability[0].spendingLikelihoodRange.values[0].id");
			assertThat(spendLikeRng.toString(), equalTo(data.getSpendLikeRngIdUpdt()));
			Integer spendLikeRng2 = response.body().jsonPath()
					.getInt("accountSuitability[1].spendingLikelihoodRange.values[0].id");
			assertThat(spendLikeRng2.toString(), equalTo(data.getSpendLikeRngIdUpdt()));
			Integer spendLikeRng3 = response.body().jsonPath()
					.getInt("accountSuitability[1].spendingLikelihoodRange.values[0].id");
			assertThat(spendLikeRng3.toString(), equalTo(data.getSpendLikeRngIdUpdt()));

		}

		//Assert on Investment Time Horizon if present
		if (data.getInvesTimeHrznTxt() != null) {
			response.then().log().ifValidationFails()
			.statusCode(HttpStatus.SC_OK)
			.body(
			"accountSuitability[0].investmentTimeHorizon", not(empty()),
			"accountSuitability[0].investmentTimeHorizon.values[0].value", equalTo(data.getInvesTimeHrznTxtUpdt()),
			"accountSuitability[1].investmentTimeHorizon", not(empty()),
			"accountSuitability[1].investmentTimeHorizon.values[0].value", equalTo(data.getInvesTimeHrznTxtUpdt()),
			"accountSuitability[2].investmentTimeHorizon", not(empty()),
			"accountSuitability[2].investmentTimeHorizon.values[0].value", equalTo(data.getInvesTimeHrznTxtUpdt()));
			Integer timeHorizon = response.body().jsonPath()
					.getInt("accountSuitability[0].investmentTimeHorizon.values[0].id");
			assertThat(timeHorizon.toString(), equalTo(data.getInvesTimeHrznIdUpdt()));
			Integer timeHorizon2 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentTimeHorizon.values[0].id");
			assertThat(timeHorizon2.toString(), equalTo(data.getInvesTimeHrznIdUpdt()));
			Integer timeHorizon3 = response.body().jsonPath()
					.getInt("accountSuitability[1].investmentTimeHorizon.values[0].id");
			assertThat(timeHorizon3.toString(), equalTo(data.getInvesTimeHrznIdUpdt()));

		}
		
	}
	
	/**
	 * Validate the suitability was updated.
	 * 
	 */
	private void getSuitabilityAfterUpdate()
	{	
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);
		
		// Assert on response
		response.then().log().ifValidationFails()
		.statusCode(HttpStatus.SC_OK)
		.body("accountSuitability", not(empty()));
		
	}
	
	/**
	 * Delete the account.
	 * 
	 * Version V1
	 */
	
	private void deleteAccountSuitability(final AccountSuitabilityTestData data)
	{	

		//account 1
		context.put("mnemonic", mnemonic);
		context.put("value", value);
		context.put("source", sourceSystem);
		context.put("ppid", ppid);
		context.put("displayName", displayName);
		context.put("id", accountId);
		context.put("asOfDate", asOfDate);

		//account 2
		context.put("mnemonic2", mnemonic2);
		context.put("value2", value2);
		context.put("source2", sourceSystem2);
		context.put("ppid2", ppid);
		context.put("displayName2", displayName2);
		context.put("id2", accountId2);
		context.put("asOfDate2", asOfDate2);

//		//account 3
		context.put("mnemonic3", mnemonic3);
		context.put("value3", value3);
		context.put("source3", sourceSystem3);
		context.put("ppid3", ppid);
		context.put("displayName3", displayName3);
		context.put("id3", accountId3);
		context.put("asOfDate3", asOfDate3);
		
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE_V2));

        //Call Account service
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails()
		.statusCode(HttpStatus.SC_OK)
		.body("accountSuitability", equalTo(null));
	}
	
	/**
	 * Validate no suitability is returned.
	 * 
	 * Version V1
	 */
	
	private void getSuitabilityAfterDelete()
	{	
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V2);
		
		// Assert on response
		response.then().log().ifValidationFails()
		.statusCode(HttpStatus.SC_OK);

	}

 
}

	

