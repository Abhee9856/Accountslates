/*
 * Copyright 2023, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.composite.get.fili;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.APP_ID;
import static com.fmr.restassured.account.helpers.testdata.constants.AccountConstants.CALLING_APP_ID;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.is;

/**
 * Contains tests that validate additional data elements for the FILI Account
 * Composite operation
 *
 * @author a631781 Updated by a608077 for Defaulting SDPA/FDRA positions to
 *         bond.(PFCP-16920)
 */
@Test(groups = { Tags.FILI, Tags.ACCOUNT, Tags.V2 })
public class FILI_Composite_AdditionalAnnuityDataPoints_V2 extends PAPBaseServiceTest {

	protected FILI_Composite_AdditionalAnnuityDataPoints_V2() {
		super(Services.Account);
	}

	private String accountNumber;
	private String ssn;
	private String mid;
	public static final String ACCOUNT_CATEGORY = "Annuity";
	private static final String LOG_TRACKING_ID = FILI_Composite_AdditionalAnnuityDataPoints_V2.class.getSimpleName();
	private static final String FSREQID = LOG_TRACKING_ID;
	private static final String APP_NAME = "Advice and Planning Platform";
	private static final String SCENARIO_CATEGORY_CODE = "DEF";
	private static final String SCENARIO_PRODUCT_CODE = "IGE";
	private static final String sourceSystem = "FILI";
	private Response accountResponse;
	private final String oAuth = AccountUtil.getOauthToken();
	private TestDataUtil testDataUtil;
	private VelocityContext context;
	private String deferredAnnuityIndicatorDSS;
	private Boolean isTaxQualifiedDSS;
	private Long maturityDateDSS;
	private Integer surrenderChargeFreeDateDSS;
	private Float guaranteedInterestRateDSS;
	private String guaranteePeriodDSS;
	private Integer guaranteedInterestRateEndDateDSS;
	private String productNameDSS;
	private String insuranceCompanyNameDSS;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on
	 * the default SSN, set up the endpoint for the test, and build the request body
	 * from Velocity.
	 */
	@BeforeClass
	public void init() {
		// Data setup
		AccountsCommonTestData accountsCommonTestData = TestDataUtil
				.populateRegressionTestData("account_get_FILI_Reg_Code_T_85", oAuth);

		mid = accountsCommonTestData.getMid();
		DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


		accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", mid, oAuth));

		ssn = accountsCommonTestData.getSsn();
		testDataUtil = new TestDataUtil();

		// Populate request context with user IDs
		context = new VelocityContext();
		setDefaultRequestHeaders(CALLING_APP_ID, APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

	}

	/**
	 * Test to get the DSS FILI account
	 * <p>
	 * Version V2
	 */
	@Test
	public void getDSS_FILIAccount_V2() {
		// Set DSS Headers
		FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeadersForDSS();
		// Generate request body
		context.put("acctCategory", ACCOUNT_CATEGORY);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

		request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

		response = request.log().ifValidationFails().post(AccountConstants.DSS_ACCOUNT_V2_PATH);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
				.body("acctDetails", not(emptyArray()))
				.body("acctDetails.find{it.annuityProductDetail.productName == 'Principal SPDA Plus'}.annuityProductDetail.productCode",
						equalTo("SPDA"));

		String acctSubTypeDSSAccount = "Fixed Deferred Annuity";
		accountNumber = response.path("acctDetails.find{it.acctSubType=='" + acctSubTypeDSSAccount + "'}.acctNum");

	}

	/**
	 * Test to get the DSS FILI Details
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = { "getDSS_FILIAccount_V2" })
	public void getDSS_FILIDetails_V2() {
		// Generate request body
		context.put("acctCategory", ACCOUNT_CATEGORY);
		context.put("accountNumber", accountNumber);
		String acctSubType = "Fixed Annuity";
		context.put("acctSubType", acctSubType);
		String filiSystem = "OCI";
		context.put("filiSystem", filiSystem);
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_DETAILS_V2));

		request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
		response = request.log().ifValidationFails().post(AccountConstants.DSS_ACCOUNT_DETAILS_V2_PATH);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(200).body("balances", not(emptyArray()));
		accountNumber = response.path("balances[0].acctNum");
		deferredAnnuityIndicatorDSS = response.path("balances[0].annuityContractDetail.fixedVarInd");
		isTaxQualifiedDSS = response.path("balances[0].annuityContractDetail.taxQualifiedInd");
		maturityDateDSS = response.path("balances[0].annuityContractDetail.maturityDate");
		surrenderChargeFreeDateDSS = response
				.path("balances[0].annuityContractDetail.spdaContractDetail.surrenderChargeEndDate");
		guaranteedInterestRateDSS = response
				.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteedInterestRate");
		guaranteePeriodDSS = response.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteePeriod");
		guaranteedInterestRateEndDateDSS = response
				.path("balances[0].annuityContractDetail.spdaContractDetail.guaranteedinterestRateEndDate");
		productNameDSS = response.path("balances[0].annuityContractDetail.productName");
		insuranceCompanyNameDSS = response.path("balances[0].annuityContractDetail.insuranceCompanyName");
	}

	/**
	 * Tests that Additional Annuity details data is brought back for Composite FILI
	 * account.
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = "getDSS_FILIDetails_V2")
	public void getCompositeAccounts_V2() {
		FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();

		request.given().header(new Header("user-poe", AccountConstants.RETAIL)).header(new Header("user-mid", mid))
				.header(new Header("user-fili-lid", ssn)).header(new Header("excludeExternalDataSources", "false"))
				.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
				.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
				.header(new Header("Calling-app-id", CALLING_APP_ID))
				.header(new Header("log-tracking-id", LOG_TRACKING_ID)).header(new Header("fsreqid", FSREQID))
				.header(new Header("Authorization", oAuth)).header(new Header("Content-Type", "application/json"));

		// Generate request body
		context.put("sourceBasedRegistrationFilter", sourceSystem);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		request.baseUri(AccountConstants.PAP_QA_BASE_URI);
		// Call Account service
		accountResponse = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		accountResponse.then().log().ifValidationFails().statusCode(200).body("accounts", not(emptyArray()))
				.body("accounts[0].account.accountId.accountNumber", notNullValue())
				.body("accounts.find{it.details.annuityAccountDetail.productCode == 'SPDA'}.positions.allPositions.financialAssetPosition.financialInstrumentId.symbol.get(0)",
						equalTo("GBOND"))
				.body("accounts.find{it.details.annuityAccountDetail.productCode == 'SPDA'}.positions.allPositions.financialAssetPosition.financialInstrumentId.finstId.get(0)",
						equalTo(999999993));
	}

	/**
	 * Test to validate Account Details Annuity additional elements
	 * <p>
	 * Version V2
	 */
	@Test(dependsOnMethods = { "getDSS_FILIDetails_V2" })
	public void validateResponse() {
		// Account Composite Details elements
		String deferredAnnuityIndicator = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
				+ accountNumber + "'}.details.annuityAccountDetail.deferredAnnuityIndicator");
		Boolean isTaxQualified = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
				+ accountNumber + "'}.details.annuityAccountDetail.isTaxQualified");
		String maturityDate = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + accountNumber
				+ "'}.details.annuityAccountDetail.maturityDate");
		String surrenderChargeFreeDate = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
				+ accountNumber + "'}.details.annuityAccountDetail.surrenderChargeFreeDate");
		Float guaranteedInterestRate = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
				+ accountNumber + "'}.details.annuityAccountDetail.guaranteedInterestRate.value");
		String guaranteePeriod = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
				+ accountNumber + "'}.details.annuityAccountDetail.guaranteePeriod");
		String guaranteedInterestRateEndDate = accountResponse
				.path("accounts.find{it.account.accountId.accountNumber=='" + accountNumber
						+ "'}.details.annuityAccountDetail.guaranteedInterestRateEndDate");
		String productName = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='" + accountNumber
				+ "'}.details.annuityAccountDetail.productName");
		String insuranceCompanyName = accountResponse.path("accounts.find{it.account.accountId.accountNumber=='"
				+ accountNumber + "'}.details.annuityAccountDetail.insuranceCompanyName");

		// Comparing Account Composite Details elements with DSS Details elements
		Assert.assertEquals(productName, productNameDSS);
		Assert.assertEquals(deferredAnnuityIndicator, deferredAnnuityIndicatorDSS);
		Assert.assertEquals(isTaxQualified, isTaxQualifiedDSS);
		Assert.assertEquals(maturityDate, (AccountUtil.parseDSSDate(maturityDateDSS)));
		Assert.assertEquals(insuranceCompanyName, insuranceCompanyNameDSS);
		Assert.assertEquals(guaranteedInterestRate, (guaranteedInterestRateDSS / 100));
		Assert.assertEquals(guaranteePeriod, guaranteePeriodDSS);
		Assert.assertEquals(guaranteedInterestRateEndDate,
				AccountUtil.parseDSSDate(guaranteedInterestRateEndDateDSS.longValue()));
		Assert.assertEquals(surrenderChargeFreeDate,
				(AccountUtil.parseDSSDate(surrenderChargeFreeDateDSS.longValue())));
	}

	/**
	 * Setting default headers for DSS Services
	 */
	private void setDefaultRequestHeadersForDSS() {
		this.request.given().header(new Header("AppId", "AP106532")).header(new Header("fsreqid", FSREQID))
				.header(new Header("Authorization", oAuth)).header(new Header("AppName", APP_NAME))
				.header(new Header("rtazlid", this.ssn)).header(new Header("rtazallrealmslids", "FILI=" + this.ssn))
				.header(new Header("FACSC", "ROLE=FidCust")).header(new Header("Content-Type", "application/json"));
	}

	/**
	 * Clean up method for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void closeDBConnections() {
		this.testDataUtil.closeSQLiteConnection();
	}
}
