/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.contributions.crud.retail;

import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;
import static org.junit.Assert.assertFalse;

import java.util.List;

import org.apache.http.HttpStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fmr.ast.platform.account.domain.Contribution;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsContributionsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;

/**
 * Tests Advisor Info for Contribution V2 CRUD operations for Retail accounts
 *
 * @author a703000
 */
@Test(groups = {Tags.RETAIL, Tags.CONTRIBUTIONS, Tags.V2, "PFCP-18051"})
public class Retail_V2_CRUD_With_AdvisorInfo extends PAPBaseServiceTest
{

	/**
	 * Instantiates a new retail V 2 CRUD with advisor info.
	 */
	protected Retail_V2_CRUD_With_AdvisorInfo()
	{
		super(Services.Account);
	}

	Logger logger = LogManager.getLogger(getClass());

	private VelocityContext context;

	private float value = 120.0F;

	private final String source = "RETAIL";

	private String displayName;

	private String ppid;

	private String mnemonic;

	private String poe = "FRIAG";

	private String advisorLoginId = "7690041287";

	private String advisorRealmType = "FRIAG";

	private String advisorPlanNumber = "500958";

	private String gnumber = "G07492038";

	FilterableRequestSpecification frs = null;

	private static final String LOG_TRACKING_ID = Retail_V2_CRUD_With_AdvisorInfo.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private static final String SCENARIO_CATEGORY_CODE = "DEF";

	private static final String SCENARIO_PRODUCT_CODE = "IGE";

	private String accountNumber;

	private String accountId;

	private String sourceSystem;

	private String institutionName;

	private String asOfDate;

	private static final String MONEY = "MONEY";

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the
	 * endpoint for the test, and build the request body from Velocity.
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{
		final String oAuth = AccountUtil.getOauthToken();

		// Data setup
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
		                FSREQID, oAuth);

		request.given().header(new Header("user-poe", poe))
		                .header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
		                .header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
		                .header(new Header("advisor-login-id", advisorLoginId))
		                .header(new Header("advisor-realm-type", advisorRealmType))
		                .header(new Header("advisor-plan-number", advisorPlanNumber))
		                .header(new Header("gnumber", gnumber))
		                .header(new Header("excludeExternalDataSources", "false"));

		// Populate request variables
		context = new VelocityContext();
		context.put("source", source);

		frs = (FilterableRequestSpecification) request;
	}

	/**
	 * Get Retail account info from the backend. Save the account number.
	 */
	@Test
	public void getRetailAccountInfo()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList", not(emptyArray()));

		mnemonic = response.path("accountList[0].regCode.mnemonic");
		accountNumber = response.path("accountList[0].accountId.accountNumber");
		sourceSystem = response.path("accountList[0].accountId.sourceSystem");
		displayName = response.path("accountList[0].displayName");
		value = response.path("accountList[0].sourceMarketValue.amount.value");
		institutionName = response.path("accountList[0].institutionName");
		asOfDate = response.path("accountList[0].sourceMarketValue.asOfDate");
		ppid = response.path("accountList[0].accountId.owner.id");
		// Gets and saves the CFP account ID
		accountId = response.path("accountList[0].accountId.id");
		context.put("accId", accountId);
	}

	/**
	 * Create the Retail account. Save the account id.
	 * 
	 * Version V2
	 */
	@Test(dependsOnMethods = "getRetailAccountInfo")
	public void createRetailAccount()
	{
		context.put("mnemonic", mnemonic);
		context.put("value", value);
		context.put("source", sourceSystem);
		context.put("accountNumber", accountNumber);
		context.put("displayName", displayName);
		context.put("institutionName", institutionName);
		context.put("asOfDate", asOfDate);
		context.put("ppid", ppid);
		
		if(accountId != null)
		{
			//Data cleanup - delete the retail account before creating Retail account
			this.deleteRetailAccount();
			this.frs.removeHeader("accId");
			context.remove("accId");

		}
		
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList", not(empty()),
		                "accountList[0].regCode.mnemonic", equalTo(mnemonic),
		                "accountList[0].accountId.accountNumber", equalTo(accountNumber));

		// Gets and saves the CFP account ID
		accountId = response.path("accountList[0].accountId.id");
		context.put("accId", accountId);
	}

	/**
	 * Validate the account was created correctly.
	 */
	@Test(dependsOnMethods = "createRetailAccount")
	public void getRetailAccountAfterCreate()
	{
		// Generate request body

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("accountList",
		                not(empty()));

	}

	/**
	 * This is the test flow. performing CRUD operations for Advisor Info use case.
	 *
	 * @param data
	 *                the test cases
	 */
	@Test(dependsOnMethods = "getRetailAccountAfterCreate")
	public void performCrudOperations()
	{
		this.createAccountContributions();
		this.getContributionsAfterCreate();
		this.updateAccountContributions();
		this.getContributionsAfterUpdate();
		this.setAccountContributions();
		this.getContributionsAfterSet();
		this.deleteAccountContributions();
		this.getContributionsAfterDelete();
		this.deleteRetailAccount();
	}

	/**
	 * Create the account contributions.
	 *
	 * Version V2
	 */
	private void createAccountContributions()
	{
		// Generate request body
		context.put("contribValue", 1426.85);
		context.put("contribBasisTypeCd", "BASECMMSN");
		context.put("contributionName", "BEFORE-TAX");
		context.put("electionCd", "12");
		context.put("valueType", "PERCENT");
		context.put("contribType", "SIMPLE");
		context.put("contribTaxType", "PRE_TAX");
		context.put("contribLevelType", "FAMILY");
		context.put("frequency", "MONTHLY");
		context.put("contributor", "INDIVIDUAL");

		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsContributionsPaths.CREATE_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
		                "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
		                "accountContributions[0].accountId.id", equalTo(accountId),
		                "accountContributions[0].accountId.owner.id", equalTo(ppid),
		                "accountContributions[0].contributions[0].contribBasisTypeCd", equalTo("BASECMMSN"),
		                "accountContributions[0].contributions[0].contributionName", equalTo("BEFORE-TAX"),
		                "accountContributions[0].contributions[0].electionCd", equalTo("12"),
		                "accountContributions[0].contributions[0].contributionType", equalTo("SIMPLE"),
		                "accountContributions[0].contributions[0].contributionTaxType", equalTo("PRE_TAX"),
		                "accountContributions[0].contributions[0].contributionLevelType", equalTo("FAMILY"),
		                "accountContributions[0].contributions[0].contribution.value", equalTo(1426.85f),
		                "accountContributions[0].contributions[0].contribution.valueType", equalTo("PERCENT"),
		                "accountContributions[0].contributions[0].frequency", equalTo("MONTHLY"));

	}

	/**
	 * Validate the contributions.
	 * 
	 * Version V2
	 */
	private void getContributionsAfterCreate()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
		                "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
		                "accountContributions[0].accountId.id", equalTo(accountId),
		                "accountContributions[0].accountId.owner.id", equalTo(ppid),
		                "accountContributions[0].contributions[0].contribBasisTypeCd", equalTo("BASECMMSN"),
		                "accountContributions[0].contributions[0].contributionName", equalTo("BEFORE-TAX"),
		                "accountContributions[0].contributions[0].electionCd", equalTo("12"),
		                "accountContributions[0].contributions[0].contributionType", equalTo("SIMPLE"),
		                "accountContributions[0].contributions[0].contributionTaxType", equalTo("PRE_TAX"),
		                "accountContributions[0].contributions[0].contributionLevelType", equalTo("FAMILY"),
		                "accountContributions[0].contributions[0].contribution.value", equalTo(1426.85f),
		                "accountContributions[0].contributions[0].contribution.valueType", equalTo("PERCENT"),
		                "accountContributions[0].contributions[0].frequency", equalTo("MONTHLY"));

	}

	/**
	 * Update the contribution.
	 * 
	 * Version V2
	 */
	private void updateAccountContributions()
	{
		// Generate request body
		context.put("contribValue", 1425.85);
		context.put("contribBasisTypeCd", "BASECMMSN");
		context.put("contributionName", "BEFORE-TAX");
		context.put("electionCd", "12");
		context.put("valueType", "PERCENT");
		context.put("contribType", "SIMPLE");
		context.put("contribTaxType", "PRE_TAX");
		context.put("contribLevelType", "FAMILY");
		context.put("frequency", "MONTHLY");
		context.put("contributor", "INDIVIDUAL");
		context.put("isDetailed", true);

		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_CONTRIBUTIONS_UPDATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsContributionsPaths.UPDATE_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
		                "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
		                "accountContributions[0].accountId.id", equalTo(accountId),
		                "accountContributions[0].accountId.owner.id", equalTo(ppid),
		                "accountContributions[0].contributions[0].contribBasisTypeCd", equalTo("BASECMMSN"),
		                "accountContributions[0].contributions[0].contributionName", equalTo("BEFORE-TAX"),
		                "accountContributions[0].contributions[0].electionCd", equalTo("12"),
		                "accountContributions[0].contributions[0].contributionType", equalTo("SIMPLE"),
		                "accountContributions[0].contributions[0].contributionTaxType", equalTo("PRE_TAX"),
		                "accountContributions[0].contributions[0].contributionLevelType", equalTo("FAMILY"),
		                "accountContributions[0].contributions[0].contribution.value", equalTo(1425.85f),
		                "accountContributions[0].contributions[0].contribution.valueType", equalTo("PERCENT"),
		                "accountContributions[0].contributions[0].frequency", equalTo("MONTHLY"));
	}

	/**
	 * Validate the contribution was updated.
	 * 
	 * Version V2
	 */
	private void getContributionsAfterUpdate()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
		                "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
		                "accountContributions[0].accountId.id", equalTo(accountId),
		                "accountContributions[0].accountId.owner.id", equalTo(ppid),
		                "accountContributions[0].contributions[0].contribBasisTypeCd", equalTo("BASECMMSN"),
		                "accountContributions[0].contributions[0].contributionName", equalTo("BEFORE-TAX"),
		                "accountContributions[0].contributions[0].electionCd", equalTo("12"),
		                "accountContributions[0].contributions[0].contributionType", equalTo("SIMPLE"),
		                "accountContributions[0].contributions[0].contributionTaxType", equalTo("PRE_TAX"),
		                "accountContributions[0].contributions[0].contributionLevelType", equalTo("FAMILY"),
		                "accountContributions[0].contributions[0].contribution.value", equalTo(1425.85f),
		                "accountContributions[0].contributions[0].contribution.valueType", equalTo("PERCENT"),
		                "accountContributions[0].contributions[0].frequency", equalTo("MONTHLY"));

		final List<String> list = response.jsonPath()
		                .getList("accountContributions[0].contributions.contribution.valueType");
		assertFalse(list.contains(MONEY));
	}

	/**
	 * Set the account contributions.
	 *
	 * Version V2
	 */
	private void setAccountContributions()
	{
		// Generate request body
		context.put("contribValue", 1425.85);
		context.put("contribBasisTypeCd", "BASECMMSN");
		context.put("contributionName", "BEFORE-TAX");
		context.put("electionCd", "12");
		context.put("valueType", "PERCENT");
		context.put("contribType", "SIMPLE");
		context.put("contribTaxType", "PRE_TAX");
		context.put("contribLevelType", "FAMILY");
		context.put("frequency", "MONTHLY");
		context.put("contributor", "INDIVIDUAL");
		context.put("isDetailed", true);

		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_CONTRIBUTIONS_CREATE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountConstants.SET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
		                "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
		                "accountContributions[0].accountId.id", equalTo(accountId),
		                "accountContributions[0].accountId.owner.id", equalTo(ppid),
		                "accountContributions[0].contributions[0].contribBasisTypeCd", equalTo("BASECMMSN"),
		                "accountContributions[0].contributions[0].contributionName", equalTo("BEFORE-TAX"),
		                "accountContributions[0].contributions[0].electionCd", equalTo("12"),
		                "accountContributions[0].contributions[0].contributionType", equalTo("SIMPLE"),
		                "accountContributions[0].contributions[0].contributionTaxType", equalTo("PRE_TAX"),
		                "accountContributions[0].contributions[0].contributionLevelType", equalTo("FAMILY"),
		                "accountContributions[0].contributions[0].contribution.value", equalTo(1425.85f),
		                "accountContributions[0].contributions[0].contribution.valueType", equalTo("PERCENT"),
		                "accountContributions[0].contributions[0].frequency", equalTo("MONTHLY"));

	}

	/**
	 * Validate the contributions after set.
	 *
	 * Version V2
	 */
	private void getContributionsAfterSet()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body(
		                "accountContributions[0].accountId.accountNumber", equalTo(accountNumber),
		                "accountContributions[0].accountId.id", equalTo(accountId),
		                "accountContributions[0].accountId.owner.id", equalTo(ppid),
		                "accountContributions[0].contributions[0].contribBasisTypeCd", equalTo("BASECMMSN"),
		                "accountContributions[0].contributions[0].contributionName", equalTo("BEFORE-TAX"),
		                "accountContributions[0].contributions[0].electionCd", equalTo("12"),
		                "accountContributions[0].contributions[0].contributionType", equalTo("SIMPLE"),
		                "accountContributions[0].contributions[0].contributionTaxType", equalTo("PRE_TAX"),
		                "accountContributions[0].contributions[0].contributionLevelType", equalTo("FAMILY"),
		                "accountContributions[0].contributions[0].contribution.value", equalTo(1425.85f),
		                "accountContributions[0].contributions[0].contribution.valueType", equalTo("PERCENT"),
		                "accountContributions[0].contributions[0].frequency", equalTo("MONTHLY"));

	}

	/**
	 * Delete the contribution
	 * 
	 * Version V2
	 */
	private void deleteAccountContributions()
	{
		// Generate request body
		context.put("contribValue", 1425.85);
		context.put("contribBasisTypeCd", "BASECMMSN");
		context.put("contributionName", "BEFORE-TAX");
		context.put("electionCd", "12");
		context.put("valueType", "PERCENT");
		context.put("contribType", "SIMPLE");
		context.put("contribTaxType", "PRE_TAX");
		context.put("contribLevelType", "FAMILY");
		context.put("frequency", "MONTHLY");
		context.put("contributor", "INDIVIDUAL");
		context.put("isDetailed", true);

		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_CONTRIBUTIONS_DELETE_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsContributionsPaths.DELETE_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK);

		try
		{
			final List<Contribution> contributions = response.jsonPath()
			                .getList("accountContributions[0].contributions", Contribution.class);
			contributions.forEach(contribution -> {
				if (contribution.getContributionType().name().equals("SIMPLE")
				                && contribution.getContributionTaxType().name().equals("PRE_TAX"))
				{
					Assert.fail();
				}
			});
		}
		catch (IllegalArgumentException e)
		{
			response.then().body("isEmpty()", Matchers.is(true));
		}

	}

	/**
	 * Validate the contributions were deleted.
	 * 
	 * Version V2
	 */
	private void getContributionsAfterDelete()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context,
		                AccountConstants.ACCOUNT_CONTRIBUTIONS_GET_V2_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails()
		                .post(AccountsContributionsPaths.GET_ACCOUNT_CONTRIBUTIONS_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(HttpStatus.SC_OK).body("isEmpty()",
		                Matchers.is(true));

	}

	// Delete Account
	private void deleteRetailAccount()
	{
		// Generate request body
		context.put("ppid", ppid);
		context.put("value", String.valueOf(value));
		context.put("mnemonic", mnemonic);
		context.put("source", source);
		context.put("displayName", displayName);
		context.put("institutionName", displayName);
		context.put("asOfDate", asOfDate);
		context.put("accountNumber", accountNumber);
		context.put("id", accountId);

		// Generate request body
		this.request.body(
		                IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DELETE_TEMPLATE_V2));

		// Call Account service response =
		this.request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V2);
		// Assert on response
		response.then().log().ifValidationFails().statusCode(200).body("isEmpty()",
                Matchers.is(true));

	}
}