/*
 * Copyright 2019, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.fullview;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests Account Composite operation for a Fullview account. Test will create, update, and delete a composite
 * account and run get requests before and after each of those operations.
 *
 * @author a601767
 * Updated by a608077 on 08/19/2022 to include asset allocation changes(PFCP-9501)
 * Updated by a608077 on 08/26/2022 to include unknown funding amount(PFCP-9908)
 * Updated by a608077 on 05/22/2023 to include backdoor IRA changes(PFCP-12448)
 * Updated by a608077 on 08/30/2023 to include include-suitability-details header(PFCP-12115)
 * Updated by a608077 on 10/10/2023 to include 3 new asset classes: Private Equity, Private Credit,
 *  and Real Assets(PFCP-13826)
 *  
 */
@Test(groups = {Tags.FULLVIEW, Tags.COMPOSITE, Tags.V1, Tags.TARGET_ACCOUNT, Tags.CRITICAL})
public class Fullview_Composite_AllDetails extends PAPBaseServiceTest
{
    
    protected Fullview_Composite_AllDetails()
    {
        super(Services.Account);
    }

    //Context
    private VelocityContext context;

    private final float fundingAccountAmount = 5.55f;

    private static final String TARGET_ACCOUNT_NUMBER_KEY = "targetAccountNumber";
    private static final String TARGET_ACCOUNT_ID_KEY = "targetAccountId";
    
    private static final String TARGET_ACCOUNT_NAME = "NewTargetAccount";

    private AccountsCommonTestData accountsCommonTestData;
    private String accNum;
    private String acctRoot;
	final String catchupPath = ".contributions.find{it.contributionType=='CATCHUP'}";
	final String regularPath = ".contributions.find{it.contributionType=='REGULAR'}";

    private static final String CALLING_APP_ID = "AP136091";
    private static final String APP_ID = "AP136091";
    private static final String LOG_TRACKING_ID = Fullview_Composite_AllDetails.class.getSimpleName();
    private static final String FSREQID = LOG_TRACKING_ID;

    private final float updatedUnknownAmount = 26.0f;
    private final String assetClass_TOTAL_ALTERNATIVE = "TOTAL_ALTERNATIVE";
    private final String assetClass_PRIVATE_EQUITY_ALTERNATIVE = "PRIVATE_EQUITY_ALTERNATIVE";
    private final String assetClass_PRIVATE_CREDIT_ALTERNATIVE = "PRIVATE_CREDIT_ALTERNATIVE";
    private final String assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE = "PRIVATE_REAL_ASSETS_ALTERNATIVE";
    private final float netPercentage_T_ALTERNATIVE = 0.8f;
    private final float netPercentage_Updated_T_ALTERNATIVE = 0.6f;
    private final float netPercentage_PEA = 0.4f;
    private final float netPercentage_Updated_PEA = 0.2f;
    private final float netPercentage_PCA = 0.2f;
    private final float netPercentage_Updated_PCA = 0.3f;
    private final float netPercentage_PRAA = 0.2f;
    private final float netPercentage_Updated_PRAA = 0.1f;

    private static final String TRUSTEE_TYPE = "FPTC";
    private static final String TRUSTEE_TYPE_UPDATE = "ABCD";
    
    /**
     * Initialization method used to:
     * </br>1. Get the default SSN and use it to retrieve the MID.
     * </br>2. Set the Base URI
     * </br>3. Get the account service operation paths.
     * </br>4. Build the request header (with OAuth token).
     */
    @BeforeClass
    public void init()
    {
        String oAuth = AccountUtil.getOauthToken();

        accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_composite_CRUD_allDetails_Fullview",oAuth);
        //Data setup
        accountsCommonTestData.set("updatedAmount", "15000.0");
        accountsCommonTestData.set("contribFreq", "YEARLY");
        accountsCommonTestData.set("updatedContribFreq", "MONTHLY");
        accountsCommonTestData.set("contribAmount", "6000");
        accountsCommonTestData.set("updatedContribAmount", "500");
        accountsCommonTestData.set("withdrawAmount", "3000");
        accountsCommonTestData.set("updatedWithdrawAmount", "3500");
        accountsCommonTestData.set("withdrawFreq", "YEARLY");
        accountsCommonTestData.set("updatedWithdrawFreq", "ONE_TIME");
        accountsCommonTestData.set("detailValue", "42619.85");
        accountsCommonTestData.set("updatedDetailValue", "81819.89");

        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");

        
        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        this.setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
        
        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", AccountConstants.FULLVIEW);
    }
    
    /**
     * Get Fullview account info from the backend. Save the account number.
     */
    @Test
    public void getFullviewAccountInfo()
    {
        context.put("mnemonicFilter", "IRA");
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true));
        
        accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
        accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
        accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
        accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
        accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
        accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
        accountsCommonTestData.setAsOfDate1(response.path("accountList[0].sourceMarketValue.asOfDate"));
    }
    
    /**
     * Get composite accounts for user.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getFullviewAccountInfo")
    public void getCompositeAccount()
    {
        // Exclude external data
        context.put("externalDataSources", "true");
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));
        
        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());
        
    }
    
    /**
     * Create a new composite account. Save the account ID and account number.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getCompositeAccount")
    public void createCompositeAccount()
    {
        // Generate request body
        accNum = accountsCommonTestData.getAccountNumber1();
        context.put("mnemonic", accountsCommonTestData.getMnemonic1());
        context.put("sourceSystem2", accountsCommonTestData.getSourceSystem1());
        context.put("value", accountsCommonTestData.getValue1());
        context.put("accountNumber", accNum);
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("institutionName", accountsCommonTestData.getInstitutionName1());
        context.put("asOfDate", accountsCommonTestData.getAsOfDate1());
        context.put("withdrawAmount", accountsCommonTestData.get("withdrawAmount"));
        context.put("withdrawFreq", accountsCommonTestData.get("withdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("detailValue"));
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.177);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 0);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.0f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_PRAA);
        context.put("_type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS_TYPE);
	context.put("type", AccountConstants.FULLVIEW_ACCOUNT_DETAILS);
	context.put("contribFreq", "YEARLY");
	context.put("contribValue", "500");
	context.put("contributionTaxType", "POST_TAX");
	context.put("contributionType", "CATCHUP");
	context.put("contributor", "EMPLOYER");
	context.put("contribBasisTypeCd", "BASE");
	context.put("contribFreq2", "BIMONTHLY");
	context.put("contribValue2", "900");
	context.put("contributionTaxType2", "AGGREGATE");
	context.put("contributionType2", "REGULAR");
	context.put("contributor2", "INDIVIDUAL");
	context.put("contribBasisTypeCd2", "BASEBONUS");
	context.put("riskTolerance", 2);
        context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
        context.put("withdrawalStartYear", 2055);
        context.put("withdrawalEndYear", 2085);
        context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
        context.put("equityPercent", 0.35);
        context.put("originalOwnerBirthDate", "1958-11-09");
        context.put("originalOwnerDeceasedDate", "2022-11-09");
        context.put("withdrawalEligibilityStartDate", "2022-11-09");
        context.put("withdrawalEligibilityEndDate", "2052-11-09");
        context.put("originalOwnerSpouse", "false");
        context.put("federalTaxWithholding", 0.15);
        context.put("stateTaxWithholding", 0.05);
        context.put("isBackdoorRoth", "true");
        context.put("trusteeType", TRUSTEE_TYPE);
        context.put("TAM_name", "Growth with Income");

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));
        
        // Make post request
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        acctRoot = "accounts.find{it.account.accountId.accountNumber='" + accNum + "'}.";

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.177f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_T_ALTERNATIVE))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PCA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PEA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_PRAA))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.42f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.18f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.35f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.05f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category", equalTo("FINAL"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo("Growth with Income"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(179))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(60))
                .body(acctRoot + "details.equityPercent", equalTo(0.35f))
                .body(acctRoot + "details.originalOwnerBirthDate", equalTo("1958-11-09T00:00:00.000+0000"))
                .body(acctRoot + "details.originalOwnerDeceasedDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body(acctRoot + "details.withdrawalEligibilityStartDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body(acctRoot + "details.withdrawalEligibilityEndDate", equalTo("2052-11-09T00:00:00.000+0000"))
                .body(acctRoot + "details.originalOwnerSpouse", equalTo(false))
                .body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.15f))
                .body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.05f))
                .body(acctRoot + "details.trusteeType", equalTo(TRUSTEE_TYPE))
		.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
		.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
		.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
		.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
		.body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
		.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "contributions" +".isBackdoorRoth", equalTo(true))
		.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
		.body("accounts[0].withdrawals[0].amount.amount.value", equalTo(3000.0f))
		.body("accounts[0].withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("withdrawFreq")));

        //Save account number and ID
        accountsCommonTestData.setAccountId1(response.path(acctRoot + "account.accountId.id"));
        accountsCommonTestData.setAccountNumber1(response.path(acctRoot + "account.accountId.accountNumber"));
    }

    /**
     * Create target account
     */
    @Test(dependsOnMethods = "createCompositeAccount")
    public void createTargetAccount()
    {
	context.remove("displayName");
        context.put("targetAccountSourceSystem", AccountConstants.RETAIL);
        context.put("targetAccountPpid", accountsCommonTestData.getPpid());
        context.put("fundingAccountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
        context.put("fundingAccountValue", String.valueOf(fundingAccountAmount));
        context.put("targetAccountSourceMarketValue", String.valueOf(fundingAccountAmount));
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("category", "INVESTOR_SELECTED_STRATEGY");
        context.put("trusteeType", TRUSTEE_TYPE);
        float unknownAmount = 20.0f;
        context.put("unknownAmount", String.valueOf(unknownAmount));
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount),
                        "targetAccounts[0].displayName", Matchers.equalTo(TARGET_ACCOUNT_NAME),
                        "targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "targetAccounts[0].fundingAccounts[0].unknownAmount", Matchers.equalTo(unknownAmount),
                        "targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"),
                        "targetAccounts[0].targetAssetMixes[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"),
                        "targetAccounts[0].trusteeType", equalTo(TRUSTEE_TYPE));

        accountsCommonTestData
                .set(TARGET_ACCOUNT_NUMBER_KEY, response.path("targetAccounts[0].accountId.accountNumber"));
        accountsCommonTestData.set(TARGET_ACCOUNT_ID_KEY, response.path("targetAccounts[0].accountId.id"));
    }

    /**
     * Gets composite account and verifies there is content in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createTargetAccount")
    public void getCompositeAccountAfterCreate()
    {
        this.request.given()
                .header(new Header("include-suitability-details", "true"));
        // Generate request body
        context.put("source", null);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        acctRoot + "account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        acctRoot + "account.sourceMarketValue.amount.value", equalTo(accountsCommonTestData.getValue1()),
                        acctRoot + "positions.marketValue.amount.value", equalTo(accountsCommonTestData.getValue1()),
                        acctRoot + "details.costBasis.value", equalTo(Float.valueOf(accountsCommonTestData.get("detailValue"))),
                        acctRoot + "details.state", equalTo("AK"),
                        acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                            equalTo(0.177f),
                        acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                            equalTo(0f),
                        acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                            equalTo(0.0f),
                        acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.0f))
                        .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
                                        + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_T_ALTERNATIVE))
                        .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                        + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_PCA))
                        .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                        + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_PEA))
                        .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                        + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_PRAA))
                        .body(acctRoot + "details.trusteeType", equalTo(TRUSTEE_TYPE),
                        acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='TOTAL_EQUITY'}.netPercentage.value",
                            equalTo(0f),
                        acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='BOND'}.netPercentage.value",
                            equalTo(0f),
                        acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it.assetClass='CASH'}.netPercentage.value",
                            equalTo(0f),
                        acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"),

                        acctRoot + "withdrawals[0].amount.amount.value",
                            equalTo(Float.valueOf(accountsCommonTestData.get("withdrawAmount"))),
                        acctRoot + "withdrawals[0].amount.frequency",
                            equalTo(accountsCommonTestData.get("withdrawFreq")),
                        "targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value", equalTo(fundingAccountAmount),
                        "targetAccounts[0].displayName", Matchers.equalTo(TARGET_ACCOUNT_NAME),
                        "targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].fundingAccounts[0].accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        "targetAccounts[0].complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"),
                        "targetAccounts[0].targetAssetMixes[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.42f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.18f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.35f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.05f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category", equalTo("FINAL"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo("Growth with Income"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(179))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(60))
                .body(acctRoot + "details.equityPercent", equalTo(0.35f))
                .body(acctRoot + "details.originalOwnerBirthDate", equalTo("1958-11-09T00:00:00.000+0000"))
                .body(acctRoot + "details.originalOwnerDeceasedDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body(acctRoot + "details.withdrawalEligibilityStartDate", equalTo("2022-11-09T00:00:00.000+0000"))
                .body(acctRoot + "details.withdrawalEligibilityEndDate", equalTo("2052-11-09T00:00:00.000+0000"))
                .body(acctRoot + "details.originalOwnerSpouse", equalTo(false))
                .body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.15f))
                .body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.05f))
		.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(500.0f))
		.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
		.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(900.0f))
		.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
		.body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
		.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "contributions" +".isBackdoorRoth", equalTo(true))
		.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(2))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_LESS_THAN_25"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2055))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2085))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
				.body("accounts[0].withdrawals[0].amount.amount.value", equalTo(3000.0f))
				.body("accounts[0].withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("withdrawFreq")));
    }

    /**
     * Runs an update on the new account and verifies content in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateTargetAccount")
    public void updateCompositeAccount()
    {
	context.remove("displayName");
        // Populate variables for tests into context
        context.put("value", accountsCommonTestData.get("updatedAmount"));
        context.put("withdrawAmount", accountsCommonTestData.get("updatedWithdrawAmount"));
        context.put("withdrawFreq", accountsCommonTestData.get("updatedWithdrawFreq"));
        context.put("detailValue", accountsCommonTestData.get("updatedDetailValue"));
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("assetClass1", "UNKNOWN");
        context.put("netPercentage1", 0.4f);
        context.put("assetClass_T_Equity", "TOTAL_EQUITY");
        context.put("netPercentage_T_Equity", 1.0f);
        context.put("assetClass_DOMESTIC_EQUITY", "DOMESTIC_EQUITY");
        context.put("netPercentage_DE", 0.70f);
        context.put("assetClass_FOREIGN_EQUITY", "FOREIGN_EQUITY");
        context.put("netPercentage_FE", 0.30f);
        context.put("assetClass_TOTAL_ALTERNATIVE", assetClass_TOTAL_ALTERNATIVE);
        context.put("netPercentage_T_ALTERNATIVE", netPercentage_Updated_T_ALTERNATIVE);
        context.put("assetClass_PRIVATE_EQUITY_ALTERNATIVE", assetClass_PRIVATE_EQUITY_ALTERNATIVE);
        context.put("netPercentage_PEA", netPercentage_Updated_PEA);
        context.put("assetClass_PRIVATE_CREDIT_ALTERNATIVE", assetClass_PRIVATE_CREDIT_ALTERNATIVE);
        context.put("netPercentage_PCA", netPercentage_Updated_PCA);
        context.put("assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE", assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE);
        context.put("netPercentage_PRAA", netPercentage_Updated_PRAA);
        context.put("riskTolerance", 3);
        context.put("displayName", accountsCommonTestData.getDisplayName1());
        context.put("stockMarketDeclinePercent", "SELL_BETWEEN_25_AND_50");
        context.put("withdrawalStartYear", 2056);
        context.put("withdrawalEndYear", 2086);
        context.put("complementaryAdjustmentOption", "MANAGED_LOCK_CURRENT_ALLOCATION");
        context.put("equityPercent", 0.25);
	context.put("originalOwnerBirthDate", "1958-12-09");
	context.put("originalOwnerDeceasedDate", "2022-12-09");
	context.put("contribValue", "600");
	context.put("contribFreq", "YEARLY");
	context.put("contribValue2", "700");
	context.put("contribFreq2", "BIMONTHLY");
	context.put("withdrawalEligibilityStartDate", "2022-12-09");
	context.put("withdrawalEligibilityEndDate", "2052-12-09");
        context.put("originalOwnerSpouse", true);
        context.put("federalTaxWithholding", 0.16);
        context.put("stateTaxWithholding", 0.06);
        context.put("TAM_total_equity", 0.5);
        context.put("TAM_domestic_equity", 0.4);
        context.put("TAM_foreign_equity", 0.1);
        context.put("TAM_bond", 0.5);
        context.put("TAM_cash", 0.0);
        context.put("TAM_category", "INVESTOR_SELECTED_STRATEGY");
        context.put("TAM_name", "Aggressive Growth");
        context.put("TAM_repositoryTamId", 181);
        context.put("TAM_assetAllocationId", 85);
        context.put("isBackdoorRoth","false");
        context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

        // Generate request body
        context.put("source", AccountConstants.FULLVIEW);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f))
                .body(acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
                                + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_T_ALTERNATIVE))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PCA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PEA))
                .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                        equalTo(netPercentage_Updated_PRAA))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.85f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.25f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.15f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo("Aggressive Growth"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(181))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(85))
                .body(acctRoot + "details.complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body(acctRoot + "details.equityPercent", equalTo(0.25f))
                .body(acctRoot + "details.originalOwnerBirthDate", equalTo("1958-12-09T00:00:00.000+0000"))
                .body(acctRoot + "details.originalOwnerDeceasedDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body(acctRoot + "details.withdrawalEligibilityStartDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body(acctRoot + "details.withdrawalEligibilityEndDate", equalTo("2052-12-09T00:00:00.000+0000"))
                .body(acctRoot + "details.originalOwnerSpouse", equalTo(true))
                .body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.16f))
                .body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.06f))
                .body(acctRoot + "details.trusteeType", equalTo(TRUSTEE_TYPE_UPDATE))
		.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
		.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
		.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(700.0f))
		.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
		.body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
		.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "contributions" +".isBackdoorRoth", equalTo(false))
		.body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(3))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
		.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(3500.0f))
		.body(acctRoot + "withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("updatedWithdrawFreq")));

    }

    /**
     * Update target account
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterCreate")
    public void updateTargetAccount()
    {
        float updatedFundingAccountAmount = 6.78f;
        context.put("fundingAccountValue", String.valueOf(updatedFundingAccountAmount));
        context.put("targetDisplayName", TARGET_ACCOUNT_NAME);
        context.put("targetAccountSourceMarketValue", String.valueOf(updatedFundingAccountAmount));
        context.put(TARGET_ACCOUNT_NUMBER_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_NUMBER_KEY));
        context.put(TARGET_ACCOUNT_ID_KEY, accountsCommonTestData.get(TARGET_ACCOUNT_ID_KEY));
        context.put("complementaryAdjustmentOption", "MOVE_TO_MANAGED_ACCOUNT");
        context.put("category", "FINAL");
        context.put("unknownAmount",String.valueOf(updatedUnknownAmount));
        context.put("trusteeType", TRUSTEE_TYPE_UPDATE);

        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TARGET_ACCOUNT_CREATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value", equalTo(updatedFundingAccountAmount),
                        "targetAccounts[0].displayName", Matchers.equalTo(TARGET_ACCOUNT_NAME),
                        "targetAccounts[0].accountId.sourceSystem", equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].fundingAccounts[0].accountNumber", equalTo(accountsCommonTestData.getAccountNumber1()),
                        "targetAccounts[0].fundingAccounts[0].unknownAmount", Matchers.equalTo(updatedUnknownAmount),
                        "targetAccounts[0].complementaryAdjustmentOption", equalTo("MOVE_TO_MANAGED_ACCOUNT"),
                        "targetAccounts[0].targetAssetMixes[0].category", equalTo("FINAL"),
                        "targetAccounts[0].trusteeType", Matchers.equalTo(TRUSTEE_TYPE_UPDATE));

    }

    /**
     * Gets the composite accounts and verifies that content is still coming back.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateCompositeAccount")
    public void getCompositeAccountAfterUpdate()
    {
        // Generate request body
        context.put("source", null);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Assert on response
        float updatedFundingAccountAmount = 6.78f;
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        acctRoot + "account.accountId.id", equalTo(accountsCommonTestData.getAccountId1()),
                        acctRoot + "account.accountId.accountNumber",
                        equalTo(accountsCommonTestData.getAccountNumber1()),
                        acctRoot + "account.accountId.owner.id", equalTo(accountsCommonTestData.getPpid()),
                        acctRoot + "account.displayName", equalTo(accountsCommonTestData.getDisplayName1()),
                        acctRoot + "account.regCode.mnemonic", equalTo(accountsCommonTestData.getMnemonic1()),
                        acctRoot + "account.regCode.sourceSystem", equalTo(accountsCommonTestData.getSourceSystem1()),
                        acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
                        acctRoot + "positions.marketValue.amount.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedAmount"))),
                        acctRoot + "details.costBasis.value",
                        equalTo(Float.valueOf(accountsCommonTestData.get("updatedDetailValue"))),
                        acctRoot + "details.state", equalTo("AK"),
                        acctRoot + "details.trusteeType", equalTo(TRUSTEE_TYPE_UPDATE),
                        acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='UNKNOWN'}.netPercentage.value",
                        equalTo(0.4f),
                        acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(1.0f),
                        acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.70f),
                        acctRoot + "details.assetAllocation.allocation[1].allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.30f))
                        .body(acctRoot + "details.assetAllocation.allocation.find{it.assetClass=='"
                                        + assetClass_TOTAL_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_Updated_T_ALTERNATIVE))
                        .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                        + assetClass_PRIVATE_CREDIT_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PCA))
                        .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                        + assetClass_PRIVATE_EQUITY_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PEA))
                        .body(acctRoot + "details.assetAllocation.allocation[2].allocation.find{it.assetClass=='"
                                        + assetClass_PRIVATE_REAL_ASSETS_ALTERNATIVE + "'}.netPercentage.value",
                                equalTo(netPercentage_Updated_PRAA),
                        acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
                                + ".assetClass='TOTAL_EQUITY'}.netPercentage.value", equalTo(0f),
                        acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
                                + ".assetClass='BOND'}.netPercentage.value", equalTo(0f),
                        acctRoot + "suitability.investmentObjective.targetAssetMix.allocation.find{it"
                                + ".assetClass='CASH'}.netPercentage.value", equalTo(0f),
                        acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"),
                        acctRoot + "withdrawals[0].amount.amount.value", equalTo(Float.valueOf(accountsCommonTestData.get("updatedWithdrawAmount"))),
                        acctRoot + "withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("updatedWithdrawFreq")),
                        "targetAccounts", not(empty()),
                        "targetAccounts[0].sourceMarketValue.amount.value", Matchers.equalTo(updatedFundingAccountAmount),
                        "targetAccounts[0].displayName", Matchers.equalTo("NewTargetAccount"),
                        "targetAccounts[0].accountId.sourceSystem", Matchers.equalTo(AccountConstants.RETAIL),
                        "targetAccounts[0].fundingAccounts[0].accountNumber", Matchers.equalTo(accountsCommonTestData.getAccountNumber1()),
                        "targetAccounts[0].fundingAccounts[0].unknownAmount", Matchers.equalTo(updatedUnknownAmount),
                        "targetAccounts[0].complementaryAdjustmentOption", Matchers.equalTo("MOVE_TO_MANAGED_ACCOUNT"),
                        "targetAccounts[0].targetAssetMixes[0].category", Matchers.equalTo("FINAL"),
                        "targetAccounts[0].trusteeType", Matchers.equalTo(TRUSTEE_TYPE_UPDATE))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.netPercentage.value",
                        equalTo(0.85f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='DOMESTIC_EQUITY'}.netPercentage.value",
                        equalTo(0.6f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='TOTAL_EQUITY'}.allocation.find{it.assetClass=='FOREIGN_EQUITY'}.netPercentage.value",
                        equalTo(0.25f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='BOND'}.netPercentage.value",
                        equalTo(0.15f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].allocation.find{it.assetClass=='CASH'}.netPercentage.value",
                        equalTo(0.0f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].category", equalTo("INVESTOR_SELECTED_STRATEGY"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].name", equalTo("Aggressive Growth"))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].repositoryTamId", equalTo(181))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(85))
                .body(acctRoot + "details.complementaryAdjustmentOption", equalTo("MANAGED_LOCK_CURRENT_ALLOCATION"))
                .body(acctRoot + "details.equityPercent", equalTo(0.25f))
                .body(acctRoot + "details.originalOwnerBirthDate", equalTo("1958-12-09T00:00:00.000+0000"))
                .body(acctRoot + "details.originalOwnerDeceasedDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body(acctRoot + "details.withdrawalEligibilityStartDate", equalTo("2022-12-09T00:00:00.000+0000"))
                .body(acctRoot + "details.withdrawalEligibilityEndDate", equalTo("2052-12-09T00:00:00.000+0000"))
                .body(acctRoot + "details.originalOwnerSpouse", equalTo(true))
                .body(acctRoot + "details.federalTaxWithholding.value", equalTo(0.16f))
                .body(acctRoot + "details.stateTaxWithholding.value", equalTo(0.06f))
		.body(acctRoot + "contributions" + catchupPath + ".contribution.value", equalTo(600.0f))
		.body(acctRoot + "contributions" + catchupPath + ".frequency", equalTo("YEARLY"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionTaxType", equalTo("POST_TAX"))
		.body(acctRoot + "contributions" + catchupPath + ".contributionType", equalTo("CATCHUP"))
		.body(acctRoot + "contributions" + catchupPath + ".contributor", equalTo("EMPLOYER"))
		.body(acctRoot + "contributions" + regularPath + ".contribution.value", equalTo(700.0f))
		.body(acctRoot + "contributions" + regularPath + ".frequency", equalTo("BIMONTHLY"))
		.body(acctRoot + "contributions" + regularPath + ".contributionTaxType", equalTo("AGGREGATE"))
		.body(acctRoot + "contributions" + regularPath + ".contributionType", equalTo("REGULAR"))
		.body(acctRoot + "contributions" + regularPath + ".contributor", equalTo("INDIVIDUAL"))
                .body(acctRoot + "contributions" +".isBackdoorRoth", equalTo(false))
                .body(acctRoot + "suitability.investmentObjective.targetAssetMix.name", equalTo("Short Term"))
                .body(acctRoot + "suitability.investmentPurpose.values[0].value", equalTo("Save for education"))
                .body(acctRoot + "suitability.investmentKnowledge.values[0].value", equalTo("Limited"))
                .body(acctRoot + "suitability.annualIncomeRange.values[0].value", equalTo("$0 to $25K"))
                .body(acctRoot + "suitability.liquidNetworthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.networthRange.values[0].value", equalTo("$0 to $50K"))
                .body(acctRoot + "suitability.taxBracketRange.values[0].value", equalTo("Under 15%"))
                .body(acctRoot + "suitability.essentialExpensesRange.values[0].value", equalTo("Under 25%"))
                .body(acctRoot + "suitability.spendingLikelihoodRange.values[0].value", equalTo("Not Likely"))
                .body(acctRoot + "suitability.investmentTimeHorizon.values[0].value", equalTo("Near Term (0-1 year)"))
                .body(acctRoot + "suitability.accountPreferencesIA.riskTolerance", equalTo(3))
                .body(acctRoot + "suitability.accountPreferencesIA.stockMarketDeclinePercent", equalTo("SELL_BETWEEN_25_AND_50"))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalStartYear", equalTo(2056))
                .body(acctRoot + "suitability.accountPreferencesIA.withdrawalEndYear", equalTo(2086))
                .body(acctRoot + "suitability.accountId.accountNumber", equalTo(accNum))
		.body(acctRoot + "withdrawals[0].amount.amount.value", equalTo(3500.0f))
		.body(acctRoot + "withdrawals[0].amount.frequency", equalTo(accountsCommonTestData.get("updatedWithdrawFreq")));
    }
    
    /**
     * Delete the composite account that we created. Verify the account list is empty.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getCompositeAccountAfterUpdate")
    public void deleteCompositeAccount()
    {
        context.put("accId", accountsCommonTestData.getAccountId1());
        context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
        context.put("source", accountsCommonTestData.getSourceSystem1());
        
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));
        
        // Make post request
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true))
                .body("accountList", empty());
    }
    
    /**
     * Call delete and confirm that no accounts come back in the response.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteCompositeAccount")
    public void getCompositeAccountAfterDelete()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));
        
        // Make post request
        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        
        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(AccountConstants.HTTP_200)
                .body("resultCode", equalTo(true),
                        "accounts", empty());
    }
    
}
