/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.get.workplace;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.Matchers.equalTo;

/**
 * Tests Account composite/get operation for a Workplace account for PRDC account numbers, with allPlans=true.
 * PFCP-18182
 *
 * @author a608077
 */
@Test(groups = {
		Tags.REGRESSION,
		Tags.WORKPLACE,
		Tags.COMPOSITE,
		Tags.V1,
		Tags.PRDC_DATA})
public class WP_Get_Composite_v1_with_AllPlans_PRDC extends PAPBaseServiceTest
{

	protected WP_Get_Composite_v1_with_AllPlans_PRDC()
	{
		super(Services.Account);
	}

	private AccountsCommonTestData accountsCommonTestData;

	private static final String LOG_TRACKING_ID = WP_Get_Composite_v1_with_AllPlans_PRDC.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	private TestDataUtil testDataUtil;

	private VelocityContext context;

	/**
	 * Initialization method used to:
	 * 1. Get the default SSN and use it to retrieve the MID.
	 * 2. Set the Base URI
	 * 3. Get the account service operation paths.
	 * 4. Build the request header (with OAuth token).
	 */
	@BeforeClass
	public void init()
	{
		String oAuth = AccountUtil.getOauthToken();
		testDataUtil = new TestDataUtil();
		accountsCommonTestData = TestDataUtil
				.populateRegressionTestData("account_composite_CRUD_allDetails_Workplace 2", oAuth);
		String mid = accountsCommonTestData.getMid();
		accountsCommonTestData.setMid(mid);

		DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


		accountsCommonTestData.setPpid(
				Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID,
				FSREQID, oAuth);

		// Populate common variables for tests into context
		context = new VelocityContext();
		context.put("fescoLid", accountsCommonTestData.getSsn());
		context.put("mid", accountsCommonTestData.getMid());
		context.put("ppid", accountsCommonTestData.getPpid());
		context.put("source", "WORKPLACE");

		this.request.given().
				header(new Header("return-prdc-accounts", "true"))
				.header(new Header("allPlans", "true"));
	}

	/**
	 * Get retail account info from the backend. Save the account number.
	 */
	@Test
	public void getWorkplaceAccountInfo()
	{
		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

		// Call Account service
		response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true))
				.body("accountList[0].accountId.accountNumber", containsString("DCA"));
	}

	/**
	 * Get composite accounts for user.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = "getWorkplaceAccountInfo")
	public void getCompositeAccount()
	{

		// Generate request body
		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

		// Make post request
		response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

		// Assert on response
		response.then().log().ifValidationFails()
				.statusCode(AccountConstants.HTTP_200)
				.body("resultCode", equalTo(true))
				.body("accounts[0].account.accountId.accountNumber", containsString("DCA"));

	}

	@AfterClass(alwaysRun = true)
	public void closeDBConnections()
	{
		testDataUtil.closeSQLiteConnection();
	}
}
