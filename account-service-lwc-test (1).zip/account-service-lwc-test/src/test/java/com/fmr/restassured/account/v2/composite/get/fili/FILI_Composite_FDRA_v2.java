/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */

package com.fmr.restassured.account.v2.composite.get.fili;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.is;

/**
 * Contains tests for Defaulting FDRA positions to bond.(PFCP-16920)
 *
 * @author a608077
 *
 */
@Test(groups = { Tags.FILI, Tags.ACCOUNT, Tags.V2 })
public class FILI_Composite_FDRA_v2 extends PAPBaseServiceTest {
	protected FILI_Composite_FDRA_v2() {
		super(Services.Account);
	}

	private String ssn;
	public static final String ACCOUNT_CATEGORY = "Annuity";
	private static final String LOG_TRACKING_ID = FILI_Composite_FDRA_v2.class.getSimpleName();
	private static final String FSREQID = LOG_TRACKING_ID;
	private static final String APP_NAME = "Advice and Planning Platform";
	private final String oAuth = AccountUtil.getOauthToken();
	private TestDataUtil testDataUtil;
	private VelocityContext context;
	private static final String SCENARIO_CATEGORY_CODE = "DEF";
	private static final String SCENARIO_PRODUCT_CODE = "IGE";
	private static String mid;
	private static final String sourceSystem = "FILI";

	/**
	 * Initialization method used to populate the UserIdentifiers object based on
	 * the default SSN, set up the endpoint for the test, and build the request body
	 * from Velocity.
	 */
	@BeforeClass
	public void init() {
		// Data setup
		AccountsCommonTestData accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_fili",
				oAuth);

		mid = accountsCommonTestData.getMid();
		DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


		ssn = accountsCommonTestData.getSsn();
		testDataUtil = new TestDataUtil();

		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID,
				this.oAuth);

		// Populate request context with user IDs
		context = new VelocityContext();
		context.put("source", AccountConstants.FILI);
		context.put("mid", mid);

	}

	/**
	 * Test to get the DSS FILI account
	 * <p>
	 * Version V1
	 */
	@Test
	public void getDSS_FILIAccount_V2() {

		FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();
		setDefaultRequestHeadersForDSS();

		context.put("acctCategory", ACCOUNT_CATEGORY);

		request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));

		response = request.log().ifValidationFails().post(AccountConstants.DSS_ACCOUNT_V2_PATH);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)))
				.body("acctDetails", not(emptyArray()))
				.body("acctDetails.find{it.annuityProductDetail.productName == 'Fixed Deferred Retirement'}.annuityProductDetail.productCode",
						equalTo("FDRA"));

	}

	/**
	 * Tests that Additional Annuity details data is brought back for Composite Fili
	 * account.
	 * <p>
	 * Version V1
	 */
	@Test(dependsOnMethods = { "getDSS_FILIAccount_V2" })
	public void getCompositeAccounts_V2() {
		FilterableRequestSpecification frs = (FilterableRequestSpecification) request;
		frs.removeHeaders();

		request.given().header(new Header("user-poe", AccountConstants.RETAIL)).header(new Header("user-mid", mid))
				.header(new Header("user-fili-lid", ssn)).header(new Header("excludeExternalDataSources", "false"))
				.header(new Header("scenario-product-code", SCENARIO_PRODUCT_CODE))
				.header(new Header("scenario-category-code", SCENARIO_CATEGORY_CODE))
				.header(new Header("Calling-app-id", AccountConstants.CALLING_APP_ID))
				.header(new Header("log-tracking-id", LOG_TRACKING_ID)).header(new Header("fsreqid", FSREQID))
				.header(new Header("Authorization", oAuth)).header(new Header("Content-Type", "application/json"));

		// Generate request body
		context.put("sourceBasedRegistrationFilter", sourceSystem);

		request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE_V2));

		request.baseUri(AccountConstants.PAP_QA_BASE_URI);
		// Call Account service
		response = request.log().ifValidationFails().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V2);

		// Assert on response
		response.then().log().ifValidationFails().statusCode(200).body("accounts", not(emptyArray()))
				.body("accounts[0].account.accountId.accountNumber", notNullValue())
				.body("accounts.find{it.details.annuityAccountDetail.productCode == 'SPDA'}.positions.allPositions.financialAssetPosition.financialInstrumentId.symbol.get(0)",
						equalTo("GBOND"))
				.body("accounts.find{it.details.annuityAccountDetail.productCode == 'SPDA'}.positions.allPositions.financialAssetPosition.financialInstrumentId.finstId.get(0)",
						equalTo(999999993));

	}

	/**
	 * Setting default headers for DSS Services
	 */
	private void setDefaultRequestHeadersForDSS() {
		this.request.given().header(new Header("AppId", "AP106532")).header(new Header("fsreqid", FSREQID))
				.header(new Header("Authorization", oAuth)).header(new Header("AppName", APP_NAME))
				.header(new Header("rtazlid", this.ssn)).header(new Header("rtazallrealmslids", "FILI=" + this.ssn))
				.header(new Header("FACSC", "ROLE=FidCust")).header(new Header("Content-Type", "application/json"));
	}

	/**
	 * Clean up method for SQLite DB connection
	 */
	@AfterClass(alwaysRun = true)
	public void closeDBConnections() {
		this.testDataUtil.closeSQLiteConnection();
	}
}
