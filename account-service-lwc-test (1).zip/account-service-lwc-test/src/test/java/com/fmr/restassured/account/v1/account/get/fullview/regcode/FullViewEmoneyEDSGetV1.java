/*
 * Copyright 2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.get.fullview.regcode;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.is;

/**
 * Tests for v1/account/get operation for FullView accounts from EDS Emoney
 * (for handling multiiple regCodes).
 *
 * @author a783909
 */
@Test(groups = {Tags.PIPELINE, Tags.ASYNCHRONOUS, Tags.FULLVIEW, Tags.ACCOUNT, Tags.V2, Tags.GET})
public class FullViewEmoneyEDSGetV1 extends PAPBaseServiceTest {
    protected FullViewEmoneyEDSGetV1() {
        super(Services.Account);
    }

    private VelocityContext context;

    private static final String sourceSystem = "FULLVIEW";

    private Response accountResponse;

    /**
     * Instance to the test data utility class
     */

    private String accNumber;

    private String displayName;

    private static final String SCENARIO_CATEGORY_CODE = "DEF";

    private static final String SCENARIO_PRODUCT_CODE = "IGE";

    private final String oAuth = AccountUtil.getOauthToken();

    private static final String APP_NAME = "Advice and Planning Platform";

    private FilterableRequestSpecification frs;

    private String ssn;

    private String fcpsid="dd5ef4c38f0a8a1ccd2001cf880000aa33";

    private String mid;

    private String sid;

    private static final String LOG_TRACKING_ID = FullViewEmoneyEDSGetV1.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */

    @BeforeClass
    public void init() {
        // Data setup
        AccountsCommonTestData accountsCommonTestData = TestDataUtil
                .populateRegressionTestData("Emoney_PFCP-536_3", oAuth);

        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid();
        DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");


        ssn = accountsCommonTestData.getSsn();

        // Common headers setup
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

    }

    /**
     * Test for getting Fullview Accounts using EDS.
     * <p>
     * Version V1
     */

    @Test
    public void getEDS() {
        //Set DSS Headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeadersForEDS();

        request.baseUri(AccountConstants.PAP_QA_BASE_URI);
        response = request.get(AccountConstants.EDS_EMONEY_ACCOUNT_GET);

        // Assert on response
        response.then().log().ifValidationFails().statusCode(anyOf(is(200), is(206)));

        accNumber = response.path("accountInfo[0].accountId");
        displayName = response.path("accountInfo[0].name");
    }

    /**
     * Verify EDS data with account.
     * <p>
     * Version V1
     */

    @Test(dependsOnMethods = {"getEDS"})
    public void getAccountInfo_v1() {
        context = new VelocityContext();
        // Set request headers
        frs = (FilterableRequestSpecification) request;
        frs.removeHeaders();
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        // Generate request body
        this.context.put("retailLid", ssn);
        this.context.put("mid", mid);
        this.context.put("source", sourceSystem);
        context.put("fcpsId", fcpsid);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        // Call Account service v1
        accountResponse = request.post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        accountResponse.then().log().ifValidationFails().statusCode(200);

		Assert.assertEquals(accountResponse.path("accountList.find{it.accountId.accountNumber == '" + accNumber + "'}.displayName"), displayName);

    }

    private void setDefaultRequestHeadersForEDS() {
        this.request.given()
                .header(new Header("fsreqid", FSREQID))
                .header(new Header("Authorization", oAuth))
                .header(new Header("AppId", AccountConstants.APP_ID))
                .header(new Header("fcps-id", fcpsid))
                .header(new Header("Content-Type", "application/json"));
    }

}
