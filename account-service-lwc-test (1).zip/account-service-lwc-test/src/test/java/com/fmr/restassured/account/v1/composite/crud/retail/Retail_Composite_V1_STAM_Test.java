/*
 * Copyright 2024, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.crud.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.common.module.Scenario;
import com.fmr.pap.restassured.common.module.constants.HTTPStatusCodes;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.pap.restassured.utilities.OAuthUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Header;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.hasSize;

/**
 * Class to test TAM is created&Updated successfully via UPDATE method.
 *
 * @author a647281 | Arunkumar Mathivanan
 */
@Test(groups = {Tags.RETAIL, Tags.ACCOUNT, Tags.V1})
public class Retail_Composite_V1_STAM_Test extends PAPBaseServiceTest {

    /**
     * Logger to print appropriate error, warning, or info messages
     **/
    private static final Logger LOGGER = LogManager.getLogger(Retail_Composite_V1_STAM_Test.class);

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String acctRoot;
    private String acct2Root;

    /**
     * Global variable holding the oAuth token generated in the initClass method
     */
    private String oAuth;

    /**
     * Global variable holding retailAccount information
     */
    private HashMap<String, Map<String, String>> retailAccountMap;

    /**
     * Global variable holding account test data from sqlite
     */
    private AccountsCommonTestData accountTestData;

    private static final String CALLING_APP_ID = "AP136091";

    private static final String APP_ID = "AP136091";

    private static final String LOG_TRACKING_ID = Retail_Composite_V1_STAM_Test.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    private static final String source = "RETAIL";

    private String scenarioId;

    private VelocityContext context;
    private static final String tamName = "Growth with Income";
    private static final float tamTotalEquity = 0.60F;
    private static final float tamDomesticEquity = 0.42F;
    private static final float tamForeignEquity = 0.18F;
    private static final float tamBond = 0.35F;
    private static final float tamCash = 0.05F;

    private static final String tamCategory = "INVESTOR_SELECTED_STRATEGY";
    private static final Integer tamRepositoryTamId = 179;
    private static final Integer tamAssetAllocationId = 60;
    private static final Integer tamAssetAllocationIdUpdate = 40;

    private String accountNo1 = "";
    private String accountNo2 = "";

    /**
     * Constructor
     */
    protected Retail_Composite_V1_STAM_Test() {
        super(Services.Account);
    }

    /**
     * Instantiates TestDataUtil & retrieves oAuth token
     */
    @BeforeClass(alwaysRun = true)
    public void initClass() {

        oAuth = AccountUtil.getOauthToken();
        testDataUtil = new TestDataUtil();
        retailAccountMap = new HashMap<>();

        accountTestData = TestDataUtil.populateRegressionTestData("accountCRUD_Retail", oAuth);
        accountTestData.setMid("RetailCompositeV1TestMid");
        DataCleanup.deleteCustomerDataFromCP("mid", accountTestData.getMid(), oAuth, "true");

        retailAccountMap = getRetailAccountInformation(accountTestData, oAuth);

        //populate initial acc nos
        accountNo1 = retailAccountMap.keySet().toArray()[0].toString();
        accountNo2 = retailAccountMap.keySet().toArray()[1].toString();

        final String ppid = Identity.createHouseholdIdentity(accountTestData.getMid(), oAuth);
        accountTestData.setPpid(ppid);
        // Get/Create ScenarioId
        Response allScenarioIDs = Scenario.getAllScenarios(accountTestData.getMid(), oAuth);
        scenarioId = allScenarioIDs.path("scenario[0].id").toString();
        if (scenarioId == null) {
            scenarioId = Scenario.createScenarioWithProductCode(accountTestData.getMid(), "IGE", "DEF",
                    oAuth);
        }
    }

    /**
     * Test setup method.
     */
    @BeforeMethod(alwaysRun = true)
    public void init() {
        
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
    }

    // Get Composite account before create
    @Test
    public void getCompositeAccountRetailBeforeCreate() {
        if (retailAccountMap.isEmpty()) {
            throw new SkipException(
                    "'getCompositeAccountRetailBeforeCreate' test scenario cannot run due to failure to retrieve "
                            + "retail account information!");
        }
        context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", true);
        context.put("source", source);
        context.put("scenarioId", scenarioId);

        request.body(IOUtil.generateJsonRequest(context,
                AccountConstants.ACCOUNT_GET_WITH_SCENARIO_ID_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Populate account id and number.
     * This method is created to overcome the Rest assured look-up feature's failure. Below did not fetch correct information as of NYE 2024
     * acctRoot = "accounts.find{it.account.accountId.accountNumber='" + retailAccountMap.get("accountNumber") + "'}.";
     * acct2Root = "accounts.find{it.account.accountId.accountNumber='" + retailAccountMap.get("accountNumber2") + "'}.";
     * It basically looks for matching account number from response and swap the index.
     * ** Warning - Modifying this method will break the assertions **
     */
    private void populateAccountIdAndNumber()
    {
        acctRoot = "accounts[0].";
        acct2Root = "accounts[1].";
        //order swap
        if(accountNo1.equals(response.jsonPath().getString(append( acct2Root, "account.accountId.accountNumber"))))
        {
            acctRoot = "accounts[1].";
            acct2Root = "accounts[0].";
        }
        accountNo1 = response.jsonPath().getString(append( acctRoot, "account.accountId.accountNumber"));
        accountNo2 = response.jsonPath().getString(append( acct2Root, "account.accountId.accountNumber"));

        accountTestData.setAccountId1(response.jsonPath().getString(append( acctRoot, "account.accountId.id")));
        accountTestData.setAccountNumber1(response.jsonPath().getString(append( acctRoot, "account.accountId.accountNumber")));
        accountTestData.setAccountId2(response.jsonPath().getString(append( acct2Root, "account.accountId.id")));
        accountTestData.setAccountNumber2(response.jsonPath().getString(append( acct2Root, "account.accountId.accountNumber")));

    }

    //Create composite account
    @Test(dependsOnMethods = "getCompositeAccountRetailBeforeCreate")
    public void createCompositeAccountRetail() {
        context.put("externalDataSources", true);
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("scenarioId", scenarioId);
        context.put("source", source);
        context.put("ppid", accountTestData.getPpid());
        context.put("sourceSystem2", source);
        context.put("detailValue", "111111.11");
        context.put("emergencyFundAmount", "111111.11");
        context.put("isProductSuitable", "false");
        context.put("suitabilityStatus", "SUITABLE");
        context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
        context.put("type", "RetailAccountDetails");
        context.put("TAM_name1", tamName);
        context.put("TAM_repositoryTamId", tamRepositoryTamId);
        context.put("TAM_assetAllocationId", tamAssetAllocationId);

        populateContextWithAccData("", accountNo1);
        populateContextWithAccData("2", accountNo2);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_2_ACCOUNT_TEMPLATE));
        response = request.post(AccountsCompositePaths.CREATE_COMPOSITE_ACCOUNT_V1);

        // Save account number and ID
        populateAccountIdAndNumber();

        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.accountNumber", equalTo(accountTestData.getAccountNumber1()))
                .body(acct2Root + "account.accountId.id", notNullValue())
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get(accountNo1).get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get(accountNo1).get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get(accountNo1).get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get(accountNo1).get("sourceMarketAmountValue"))))
                .body(acctRoot + "details.emergencyFundAmount.value", equalTo(111111.11f))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(tamAssetAllocationId));
    }

    /**
     * Populate context with acc data.
     *
     * @param postfix
     * 		the postfix
     * @param accNo
     * 		the acc no
     */
    private void populateContextWithAccData(final String postfix, final String accNo)
    {
        context.put(append("accountNumber", postfix), retailAccountMap.get(accNo).get("accountNumber"));
        context.put(append("institutionName", postfix), retailAccountMap.get(accNo).get("institutionName"));
        context.put(append("value", postfix), retailAccountMap.get(accNo).get("sourceMarketAmountValue"));
        context.put(append("asOfDate", postfix), retailAccountMap.get(accNo).get("sourceMarketAsOfDate"));
        context.put(append("displayName", postfix), retailAccountMap.get(accNo).get("displayName"));
        context.put(append("mnemonic", postfix), retailAccountMap.get(accNo).get("mnemonic"));
    }

    /**
     * Gets composite account retail after create.
     */
    //Get composite account after create
    @Test(dependsOnMethods = "createCompositeAccountRetail")
    public void getCompositeAccountRetailAfterCreate() {
        this.request.given().header(new Header("include-suitability-details", "true"));
        VelocityContext context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", true);
        context.put("source", source);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);

        // Save account number and ID
        populateAccountIdAndNumber();

        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(retailAccountMap.get(accountNo1).get("accountNumber")))
                .body(acct2Root + "account.accountId.accountNumber",
                         equalTo(retailAccountMap.get(accountNo2).get("accountNumber")))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(tamAssetAllocationId))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get(accountNo1).get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get(accountNo1).get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get(accountNo1).get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get(accountNo1).get("sourceMarketAmountValue"))));

    }

    /**
     * Update composite account retail.
     */
    //Create TAM via update call
    @Test(dependsOnMethods = "getCompositeAccountRetailAfterCreate")
    public void updateCompositeAccountRetail() {
        context.put("externalDataSources", true);
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("accId", accountTestData.getAccountId1());
        context.put("accountNumber", retailAccountMap.get(accountNo1).get("accountNumber"));
        context.put("accId2", accountTestData.getAccountId2());
        context.put("source", source);
        context.put("ppid", accountTestData.getPpid());
        context.put("displayName", retailAccountMap.get(accountNo1).get("displayName"));
        context.put("mnemonic", retailAccountMap.get(accountNo1).get("mnemonic"));
        context.put("sourceSystem2", source);
        context.put("institutionName", retailAccountMap.get(accountNo1).get("institutionName"));
        context.put("value", retailAccountMap.get(accountNo1).get("sourceMarketAmountValue"));
        context.put("asOfDate", retailAccountMap.get(accountNo1).get("sourceMarketAsOfDate"));
        context.put("detailValue", "211111.11");
        context.put("emergencyFundAmount", "211111.11");
        context.put("_type", "com.fmr.ast.platform.account.domain.RetailAccountDetails");
        context.put("type", "RetailAccountDetails");
        context.put("isProductSuitable", "false");
        context.put("suitabilityStatus", "SUITABLE");
        context.put("TAM_name2", tamName);
        context.put("TAM_total_equity", tamTotalEquity);
        context.put("TAM_domestic_equity", tamDomesticEquity);
        context.put("TAM_foreign_equity", tamForeignEquity);
        context.put("TAM_bond", tamBond);
        context.put("TAM_cash", tamCash);
        context.put("TAM_category", tamCategory);
        context.put("TAM_assetAllocationId2", tamAssetAllocationIdUpdate);
        context.put("TAM_assetAllocationId", tamAssetAllocationIdUpdate);


        request.body    (IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_CREATE_2_ACCOUNT_TEMPLATE));

        response = request.post(AccountsCompositePaths.UPDATE_COMPOSITE_ACCOUNT_V1);
        // Save account number and ID
        populateAccountIdAndNumber();

        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(retailAccountMap.get(accountNo1).get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get(accountNo1).get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get(accountNo1).get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get(accountNo1).get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get(accountNo1).get("sourceMarketAmountValue"))))
                .body(acctRoot + "details.emergencyFundAmount.value", equalTo(211111.11f));

    }

    /**
     * Gets composite account retail after update.
     */
    //Get composite account after update
    @Test(dependsOnMethods = "updateCompositeAccountRetail")
    public void getCompositeAccountRetailAfterUpdate() {
        this.request.given().header(new Header("include-suitability-details", "true"));
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", true);
        context.put("source", source);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        // Save account number and ID
        populateAccountIdAndNumber();

        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200)
                .body("resultCode", equalTo(true))
                .body(acctRoot + "account.accountId.id", equalTo(accountTestData.getAccountId1()))
                .body(acctRoot + "account.accountId.accountNumber",
                        equalTo(retailAccountMap.get(accountNo1).get("accountNumber")))
                .body(acctRoot + "account.accountId.sourceSystem", equalTo(source))
                .body(acctRoot + "account.accountId.owner.id", equalTo(accountTestData.getPpid()))
                .body(acctRoot + "account.displayName", equalTo(retailAccountMap.get(accountNo1).get("displayName")))
                .body(acctRoot + "account.regCode.mnemonic", equalTo(retailAccountMap.get(accountNo1).get("mnemonic")))
                .body(acctRoot + "account.institutionName",
                        equalTo(retailAccountMap.get(accountNo1).get("institutionName")))
                .body(acctRoot + "account.sourceMarketValue.amount.value",
                        equalTo(Float.valueOf(retailAccountMap.get(accountNo1).get("sourceMarketAmountValue"))))
                .body(acctRoot + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(tamAssetAllocationIdUpdate))
                .body(acct2Root + "details.targetAssetMixes.targetAssetMix[0].assetAllocationId", equalTo(tamAssetAllocationIdUpdate));

    }

    /**
     * Delete composite account retail.
     */
    //Delete Composite Account
    @Test(dependsOnMethods = "getCompositeAccountRetailAfterUpdate")
    public void deleteCompositeAccountRetail() {
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_DELETE_TEMPLATE));
        response = request.post(AccountsPaths.DELETE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accountList",
                hasSize(0));
    }

    //Get composite after Delete
    @Test(dependsOnMethods = "deleteCompositeAccountRetail")
    public void getCompositeAccountRetailAfterDelete() {
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountTestData.getMid());
        context.put("retailLid", accountTestData.getSsn());
        context.put("poe", source);
        context.put("externalDataSources", true);
        context.put("source", source);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        response = request.post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
        response.then().log().ifValidationFails().statusCode(HTTPStatusCodes.STATUS_200).body("accounts",
                hasSize(0));
    }

    /**
     * Returns the response of retrieving a retail account
     *
     * @param accountsCommonTestData the test data
     * @return retailAccountMap
     */
    private static HashMap<String, Map<String, String>> getRetailAccountInformation(
            final AccountsCommonTestData accountsCommonTestData, final String oAuth) {
        final HashMap<String, Map<String, String>> retailMap = new HashMap<>();
        final VelocityContext context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("source", "RETAIL");
        RestAssured.reset();
        RestAssured.baseURI = currentHost;
        RestAssured.useRelaxedHTTPSValidation();
        final RequestSpecification request =
                OAuthUtil.setDefaultHeaders("AP136091", "AP136091", "PAPQA", "PAPQA", oAuth);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

        request.given().log().all();
        final Response response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        response.then().log().all();
        if (response.statusCode() != HTTPStatusCodes.STATUS_200) {
            LOGGER.error(String.format("Accounts cannot be retrieved for the following ssn: %s",
                    accountsCommonTestData.getSsn()));

            return null;
        }

        //Account 1
        final JsonPath retailAccountJP = response.jsonPath();
        populateRetailAccountmap(retailAccountJP, "accountList[0].", retailMap);
        //Account 2
        if(null != retailAccountJP.getString("accountList[1].accountId.accountNumber"))
        {
            populateRetailAccountmap(retailAccountJP, "accountList[1].", retailMap);
        }

        return retailMap;
    }

    /**
     * Populate retail accountmap.
     *
     * @param retailAccountJP
     * 		the retail account jp
     * @param accountRoot
     * 		the account root
     * @param retailMap
     * 		the retail map
     */
    private static void populateRetailAccountmap(final JsonPath retailAccountJP, final String accountRoot, final HashMap<String, Map<String, String>> retailMap)
    {
        final HashMap<String, String> retailAccountMap = new HashMap<>();
        //Account 1 -- expecting at least one account, otherwise the test input is invalid.
        retailAccountMap.put("accountNumber",
                        retailAccountJP.getString(append(accountRoot, "accountId.accountNumber")));
        retailAccountMap.put("sourceSystem",
                        retailAccountJP.getString(append(accountRoot, "accountId.sourceSystem")));
        retailAccountMap.put("displayName", retailAccountJP.getString(append(accountRoot,"displayName")));
        retailAccountMap.put("mnemonic", retailAccountJP.getString(append(accountRoot, "regCode.mnemonic")));
        retailAccountMap.put("institutionName", retailAccountJP.getString(append(accountRoot, "institutionName")));
        retailAccountMap.put("sourceMarketAmountType",
                        retailAccountJP.getString(append(accountRoot, "sourceMarketValue.amount._type")));
        retailAccountMap.put("sourceMarketAmountValue",
                        retailAccountJP.getString(append(accountRoot, "sourceMarketValue.amount.value")));
        retailAccountMap.put("sourceMarketAmountValueType",
                        retailAccountJP.getString(append(accountRoot, "sourceMarketValue.amount.valueType")));
        retailAccountMap.put("sourceMarketAmountCurrency",
                        retailAccountJP.getString(append(accountRoot, "sourceMarketValue.amount.currency")));
        retailAccountMap.put("sourceMarketAsOfDate",
                        retailAccountJP.getString(append(accountRoot, "sourceMarketValue.asOfDate")));
        retailMap.put(retailAccountJP.getString(append(accountRoot, "accountId.accountNumber")), retailAccountMap);
    }

    /**
     * Append string.
     *
     * @param stringA
     * 		the string a
     * @param stringB
     * 		the string b
     * @return the string
     */
    private static String append(final String stringA, final String stringB)
    {
        return stringA + stringB;
    }

    /**
     * Tear down method
     */
    @AfterClass(alwaysRun = true)
    public void tearDown() {
        testDataUtil.closeSQLiteConnection();
    }
}