/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v2.account.get.workplace.regcode;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import org.apache.commons.collections.CollectionUtils;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.http.Header;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.notNullValue;

/**
 * Tests for v2/account/get operation for workplace accounts using DataProvider (for handling multiple regCodes).
 *
 * @author a560878
 *
 */
@Test(groups = {
		Tags.PIPELINE, 
		Tags.ASYNCHRONOUS,
		Tags.WORKPLACE, 
		Tags.ACCOUNT, 
		Tags.V2, 
		Tags.GET})

public class WorkplaceRegCodeGetV2 extends PAPBaseServiceTest
{

	protected WorkplaceRegCodeGetV2()
	{
		super(Services.Account);
	}

	// Data setup
	private AccountsCommonTestData accountsCommonTestData;

	private VelocityContext context;

    /** Instance to the test data utility class */
	private TestDataUtil testDataUtil;

    private static final String CALLING_APP_ID = "AP136091";

	private static final String APP_ID = "AP136091";

	private static final String LOG_TRACKING_ID = WorkplaceRegCodeGetV2.class.getSimpleName();

	private static final String FSREQID = LOG_TRACKING_ID;

	/**
	 * Initialization method used to populate the UserIdentifiers object based (when needed) on the default SSN, and
	 * build the request header.
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{

        String oAuth = AccountUtil.getOauthToken();
		testDataUtil = new TestDataUtil();
		setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

		accountsCommonTestData = TestDataUtil.populateRegressionTestData("default_ssn_workplace", oAuth);
		this.request.given().header(new Header("user-poe", AccountConstants.RETAIL))
		        .header(new Header("user-fesco-lid", accountsCommonTestData.getSsn()))
		        .header(new Header("scenario-product-code", "IGE")).header(new Header("scenario-category-code", "DEF"))
		        .header(new Header("log-tracking-id", "AP136091RA"))
		        .header(new Header("excludeExternalDataSources", "false"));

	}

	/**
	 * Test for getting Workplace Accounts using data provider.
	 *
	 * Version V2
	 */
	@Test(dataProvider = "getWorkplaceAccountRegCode", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
	public void getWorkplaceAccountsForRegCodes(final AccountRegCodeTestData data)
	{

		this.context = new VelocityContext();
		this.context.put("mnemonicFilter", data.getRegCode1());
		this.context.put("mnemonicFilter2", data.getRegCode2());
		this.context.put("mnemonicFilter3", data.getRegCode3());
		this.context.put("source", data.getSrcFilter());
		this.context.put("filterType", data.getFilterType());

		this.request =
		        this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE_V2));
		this.request.log().uri();
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V2);

		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
		if (CollectionUtils.isNotEmpty(response.path("accountList"))
		        && (response.jsonPath().getList("accountList").size() > 0))
		{
			response.then().body("accountList[0].accountId", notNullValue())
			        .body("accountList[0].accountId.owner.id", notNullValue())
			        .body("accountList[0].accountId.accountNumber", notNullValue()).body("accountList", notNullValue());
		}
	}

	/**
	 *
	 * Cleanup operation for SQLite DB connection
	 *
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections()
	{
		this.testDataUtil.closeSQLiteConnection();
	}

}