/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.details.crud.manual;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.Matchers.equalTo;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.constants.TestDataConstants;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

import java.util.Map;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests CRUD operations of account details V1 for Workplace Accounts owned by Principal, Partner, and Dependent.
 *
 * @author a560878
 *
 */
@Test(groups = {
		Tags.MANUAL,
		Tags.DETAILS, 
		Tags.V1})

public class Manual_Details_V1_CrudPrincipalPartnerDependent extends PAPBaseServiceTest
{

	Logger logger = LogManager.getLogger(getClass());

	protected Manual_Details_V1_CrudPrincipalPartnerDependent()
	{
		super(Services.Account);
	}

	/**
	 * Instance to the p2 test data utility class
	 */
	private TestDataUtil p2TestDataUtil;

	private AccountsCommonTestData accountsCommonTestData;

	private String ppid;

	private String partPid;

	private String dependentPid;

	private VelocityContext context;

	private static final String callingAppId = "AP136091";

	private static final String appId = "AP136091";

	private static final String logTrackingId = Manual_Details_V1_CrudPrincipalPartnerDependent.class.getSimpleName();

	private static final String fsreqid = logTrackingId;

	// Test data
	private String mid;//= "ManualDetailsV1TestMid";

	private String accId;

	private String accIdPartner; // Partner account ID

	private String accIdDependent; // Dependent account ID

	private String sourceSystem = "MANUAL";

	private String nickName = "RA";

	private String displayName = "Rest Assured Dependent Manual Account";

	private String asOfDate;

	private float value = 818.89f;

	private final float updatedValue = 426.85f;

	private final Map<String, String> accNumberAccIdMap = new TreeMap<>();

	private String accNum;

	private String accNumPartner; // Partner account number

	private String accNumDependent; // Dependent account number

	/**
	 * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
	 * for the test, and build the request body from Velocity.
	 */
	@BeforeClass(alwaysRun = true)
	public void init()
	{
		this.p2TestDataUtil = new TestDataUtil();

		final String oAuth = AccountUtil.getOauthToken();
		this.accountsCommonTestData = TestDataUtil.populateRegressionTestData(AccountConstants.DEFAULT_SSN_FILI, oAuth);
		this.mid = this.accountsCommonTestData.getMid();
        this.accountsCommonTestData.setMid(this.mid);
		DataCleanup.deleteCustomerDataFromCP("mid", this.accountsCommonTestData.getMid(), oAuth, "true");


		this.ppid = Identity.createHouseholdIdentity(this.accountsCommonTestData.getMid(), oAuth);
		// Data setup - partner and dependent
		this.partPid = Identity.createHouseholdIdentity(this.accountsCommonTestData.getMid(), this.ppid, TestDataConstants.HH_PARTNER,
		        oAuth);
		this.accountsCommonTestData.setPartPid(this.partPid);

		this.dependentPid = Identity.createHouseholdIdentity(this.accountsCommonTestData.getMid(), this.ppid,
		        TestDataConstants.HH_DEPENDENT, oAuth);
		this.accountsCommonTestData.setDependentPid(this.dependentPid);

		// Endpoint setup
		setDefaultRequestHeaders(callingAppId, appId, logTrackingId, fsreqid, oAuth);

		// Populate request variables
		context = new VelocityContext();
		context.put("mid", accountsCommonTestData.getMid());
		context.put("source", sourceSystem);
		context.put("poe", "RETAIL");
	}

	/**
	 * Creates three new Manual accounts, one for Principal, one for Partner, one for Dependent
	 * <p>
	 * Version V1
	 */
	@Test
	public void createManualAccount()
	{

		// create account for Principal
		this.context.put("ppid", ppid);
		this.context.put("mnemonic", "401K");
		this.context.put("value", this.value);
		this.context.put("nickName", this.nickName);
		this.context.put("displayName", this.displayName);
		this.context.put("asOfDate", this.asOfDate);
		this.context.put("relationship", TestDataConstants.HH_PRINCIPAL);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));


		// Call Account service
		this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
		        .body("accountList[0].accountId.owner.id", equalTo(ppid))
		        .body("accountList[0].accountId.owner.relationship", equalTo(TestDataConstants.HH_PRINCIPAL))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

		this.accId = this.response.path("accountList[0].accountId.id");
		this.accNum = this.response.path("accountList[0].accountId.accountNumber");

		if (null != this.accId)
		{
			this.accNumberAccIdMap.put(this.accNum, this.accId);
		}

		// create account for Partner
		this.context.put("ppid", this.accountsCommonTestData.getPartPid());
		this.context.put("mnemonic", "401K");
		this.context.put("value", this.value);
		this.context.put("nickName", this.nickName);
		this.context.put("displayName", this.displayName);
		this.context.put("asOfDate", this.asOfDate);
		this.context.put("relationship", TestDataConstants.HH_PARTNER);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
		        .body("accountList[0].accountId.owner.id", equalTo(this.accountsCommonTestData.getPartPid()))
		        .body("accountList[0].accountId.owner.relationship", equalTo(TestDataConstants.HH_PARTNER))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

		this.accIdPartner = this.response.path("accountList[0].accountId.id");
		this.accNumPartner = this.response.path("accountList[0].accountId.accountNumber");

		if (null != this.accId)
		{
			this.accNumberAccIdMap.put(this.accNum, this.accId);
		}

		// create account for Dependent
		this.context.put("ppid", this.accountsCommonTestData.getDependentPid());
		this.context.put("mnemonic", "401K");
		this.context.put("value", this.value);
		this.context.put("nickName", this.nickName);
		this.context.put("displayName", this.displayName);
		this.context.put("asOfDate", this.asOfDate);
		this.context.put("relationship", TestDataConstants.HH_DEPENDENT);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.post(AccountsPaths.CREATE_ACCOUNT_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
		        .body("accountList[0].accountId.owner.id", equalTo(this.accountsCommonTestData.getDependentPid()))
		        .body("accountList[0].accountId.owner.relationship", equalTo(TestDataConstants.HH_DEPENDENT))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

		this.accIdDependent = this.response.path("accountList[0].accountId.id");
		this.accNumDependent = this.response.path("accountList[0].accountId.accountNumber");

		if (null != this.accId)
		{
			this.accNumberAccIdMap.put(this.accNum, this.accId);
		}

	}

	/**
	 * Create Manual account Details Request.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "createManualAccount")
	public void createAccountDetails()
	{

		// create account details for Principal
		this.context.put("ppid", ppid);
		this.context.put("relationship", TestDataConstants.HH_PRINCIPAL);
		this.context.put("value", this.value);
		this.context.put("accountNumber", this.accNum);
		this.context.put("accId", this.accId);
		this.context.put("isInherited", false);
		this.context.put("isPreviousEmployersAccount", false);
		this.context.put("state", "NC");
		this.context.put("type", "ManualAccountDetails");
		this.context.put("_type", "ManualAccountDetails");

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
		        .body("accountDetails[0].accountId.id", equalTo(this.accId))
		        .body("accountDetails[0].accountId.accountNumber", equalTo(this.accNum))
		        .body("accountDetails[0].accountId.owner.id", equalTo(ppid))
		        .body("accountDetails[0].accountId.owner.relationship", equalTo(TestDataConstants.HH_PRINCIPAL))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

		// create account details for Partner
		this.context.put("ppid", this.accountsCommonTestData.getPartPid());
		this.context.put("relationship", TestDataConstants.HH_PARTNER);
		this.context.put("value", this.value);
		this.context.put("accountNumber", this.accNumPartner);
		this.context.put("accId", this.accIdPartner);
		this.context.put("isInherited", false);
		this.context.put("isPreviousEmployersAccount", false);
		this.context.put("state", "NC");
		this.context.put("type", "ManualAccountDetails");
		this.context.put("_type", "ManualAccountDetails");

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
		        .body("accountDetails[0].accountId.id", equalTo(this.accIdPartner))
		        .body("accountDetails[0].accountId.accountNumber", equalTo(this.accNumPartner))
		        .body("accountDetails[0].accountId.owner.id", equalTo(this.accountsCommonTestData.getPartPid()))
		        .body("accountDetails[0].accountId.owner.relationship", equalTo(TestDataConstants.HH_PARTNER))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

		// create account details for Dependent
		this.context.put("ppid", this.accountsCommonTestData.getDependentPid());
		this.context.put("relationship", TestDataConstants.HH_DEPENDENT);
		this.context.put("value", this.value);
		this.context.put("accountNumber", this.accNumDependent);
		this.context.put("accId", this.accIdDependent);
		this.context.put("isInherited", false);
		this.context.put("isPreviousEmployersAccount", false);
		this.context.put("state", "NC");
		this.context.put("type", "ManualAccountDetails");
		this.context.put("_type", "ManualAccountDetails");

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.CREATE_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
		        .body("accountDetails[0].accountId.id", equalTo(this.accIdDependent))
		        .body("accountDetails[0].accountId.accountNumber", equalTo(this.accNumDependent))
		        .body("accountDetails[0].accountId.owner.id", equalTo(this.accountsCommonTestData.getDependentPid()))
		        .body("accountDetails[0].accountId.owner.relationship", equalTo(TestDataConstants.HH_DEPENDENT))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

	}

	/**
	 * Validate the Manual account details after create.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "createAccountDetails")
	public void getDetailsAfterCreate()
	{

		// get account details for Principal
		this.context.put("ppid", ppid);
		this.context.put("source", sourceSystem);
		this.context.put("accountNumber", this.accNum);
		this.context.put("accId", this.accId);
		this.context.put("relationship", TestDataConstants.HH_PRINCIPAL);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
		        "accountDetails[0].accountId.accountNumber", equalTo(accNum), "accountDetails[0].accountId.id",
		        equalTo(accId), "accountDetails[0].accountId.sourceSystem", equalTo("MANUAL"));

		// get account details for Partner
		this.context.put("ppid", this.accountsCommonTestData.getPartPid());
		this.context.put("accountNumber", this.accNumPartner);
		this.context.put("accId", this.accIdPartner);
		this.context.put("relationship", TestDataConstants.HH_PARTNER);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
		        "accountDetails[0].accountId.accountNumber", equalTo(accNumPartner), "accountDetails[0].accountId.id",
		        equalTo(accIdPartner), "accountDetails[0].accountId.sourceSystem", equalTo("MANUAL"));

		// get account details for Dependent
		this.context.put("ppid", this.accountsCommonTestData.getDependentPid());
		this.context.put("accountNumber", this.accNumDependent);
		this.context.put("accId", this.accIdDependent);
		this.context.put("relationship", TestDataConstants.HH_DEPENDENT);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
		        "accountDetails[0].accountId.accountNumber", equalTo(accNumDependent), "accountDetails[0].accountId.id",
		        equalTo(accIdDependent), "accountDetails[0].accountId.sourceSystem", equalTo("MANUAL"));

	}

	/**
	 * Update the account details for Manual account.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "getDetailsAfterCreate")
	public void updateAccountDetails()
	{

		// update account details for Principal
		this.context.put("ppid", ppid);
		this.context.put("relationship", TestDataConstants.HH_PRINCIPAL);
		this.context.put("value", this.updatedValue);
		this.context.put("accountNumber", this.accNum);
		this.context.put("accId", this.accId);
		this.context.put("isInherited", true);
		this.context.put("isPreviousEmployersAccount", true);
		this.context.put("state", "NC");
		this.context.put("type", "ManualAccountDetails");
		this.context.put("_type", "ManualAccountDetails");

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
		        .body("accountDetails[0].accountId.id", equalTo(this.accId))
		        .body("accountDetails[0].accountId.accountNumber", equalTo(this.accNum))
		        .body("accountDetails[0].accountId.owner.id", equalTo(ppid))
		        .body("accountDetails[0].accountId.owner.relationship", equalTo(TestDataConstants.HH_PRINCIPAL))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

		// update account details for Partner
		this.context.put("ppid", this.accountsCommonTestData.getPartPid());
		this.context.put("relationship", TestDataConstants.HH_PARTNER);
		this.context.put("value", this.updatedValue);
		this.context.put("accountNumber", this.accNumPartner);
		this.context.put("accId", this.accIdPartner);
		this.context.put("isInherited", true);
		this.context.put("isPreviousEmployersAccount", true);
		this.context.put("state", "NC");
		this.context.put("type", "ManualAccountDetails");
		this.context.put("_type", "ManualAccountDetails");

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
		        .body("accountDetails[0].accountId.id", equalTo(this.accIdPartner))
		        .body("accountDetails[0].accountId.accountNumber", equalTo(this.accNumPartner))
		        .body("accountDetails[0].accountId.owner.id", equalTo(this.accountsCommonTestData.getPartPid()))
		        .body("accountDetails[0].accountId.owner.relationship", equalTo(TestDataConstants.HH_PARTNER))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

		// update account details for Dependent
		this.context.put("ppid", this.accountsCommonTestData.getDependentPid());
		this.context.put("relationship", TestDataConstants.HH_DEPENDENT);
		this.context.put("value", this.updatedValue);
		this.context.put("accountNumber", this.accNumDependent);
		this.context.put("accId", this.accIdDependent);
		this.context.put("isInherited", true);
		this.context.put("isPreviousEmployersAccount", true);
		this.context.put("state", "NC");
		this.context.put("type", "ManualAccountDetails");
		this.context.put("_type", "ManualAccountDetails");

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.UPDATE_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(200).body("resultCode", equalTo(true))
		        .body("accountDetails[0].accountId.id", equalTo(this.accIdDependent))
		        .body("accountDetails[0].accountId.accountNumber", equalTo(this.accNumDependent))
		        .body("accountDetails[0].accountId.owner.id", equalTo(this.accountsCommonTestData.getDependentPid()))
		        .body("accountDetails[0].accountId.owner.relationship", equalTo(TestDataConstants.HH_DEPENDENT))
		        .body("userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()));

	}

	/**
	 * Validate the updated Manual account details.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "updateAccountDetails")
	public void getDetailsAfterUpdate()
	{
		// get account details for Principal
		this.context.put("ppid", ppid);
		this.context.put("accountNumber", this.accNum);
		this.context.put("accId", this.accId);
		this.context.put("relationship", TestDataConstants.HH_PRINCIPAL);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
		        "accountDetails[0].accountId.accountNumber", equalTo(accNum), "accountDetails[0].accountId.id",
		        equalTo(accId), "accountDetails[0].accountId.sourceSystem", equalTo("MANUAL"));

		// get account details for Partner
		this.context.put("ppid", this.accountsCommonTestData.getPartPid());
		this.context.put("accountNumber", this.accNumPartner);
		this.context.put("accId", this.accIdPartner);
		this.context.put("relationship", TestDataConstants.HH_PARTNER);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
		        "accountDetails[0].accountId.accountNumber", equalTo(accNumPartner), "accountDetails[0].accountId.id",
		        equalTo(accIdPartner), "accountDetails[0].accountId.sourceSystem", equalTo("MANUAL"));

		// get account details for Dependent
		this.context.put("ppid", this.accountsCommonTestData.getDependentPid());
		this.context.put("accountNumber", this.accNumDependent);
		this.context.put("accId", this.accIdDependent);
		this.context.put("relationship", TestDataConstants.HH_DEPENDENT);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
		        "accountDetails[0].accountId.accountNumber", equalTo(accNumDependent), "accountDetails[0].accountId.id",
		        equalTo(accIdDependent), "accountDetails[0].accountId.sourceSystem", equalTo("MANUAL"));

	}

	/**
	 * Delete the Manual account details.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "getDetailsAfterUpdate")
	public void deleteAccountDetails()
	{

		// delete account details for Principal
		this.context.put("ppid", ppid);
		this.context.put("accountNumber", this.accNum);
		this.context.put("accId", this.accId);
		this.context.put("relationship", TestDataConstants.HH_PRINCIPAL);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("userIdentifier.mid",
		        equalTo(this.accountsCommonTestData.getMid()));

		// delete account details for Partner
		this.context.put("ppid", this.accountsCommonTestData.getPartPid());
		this.context.put("accountNumber", this.accNumPartner);
		this.context.put("accId", this.accIdPartner);
		this.context.put("relationship", TestDataConstants.HH_PARTNER);
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("userIdentifier.mid",
		        equalTo(this.accountsCommonTestData.getMid()));

		// delete account details for Dependent
		this.context.put("ppid", this.accountsCommonTestData.getDependentPid());
		this.context.put("accountNumber", this.accNumDependent);
		this.context.put("accId", this.accIdDependent);
		this.context.put("relationship", TestDataConstants.HH_DEPENDENT);
		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_CREATE_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.DELETE_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("userIdentifier.mid",
		        equalTo(this.accountsCommonTestData.getMid()));

	}

	/**
	 * Validate the Manual account was deleted.
	 *
	 * Version V1
	 */
	@Test(dependsOnMethods = "deleteAccountDetails")
	public void getDetailsAfterDelete()
	{
		// get account details for Principal
		this.context.put("ppid", ppid);
		this.context.put("accountNumber", this.accNum);
		this.context.put("accId", this.accId);
		this.context.put("relationship", TestDataConstants.HH_PRINCIPAL);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
		        "accountDetails[0].accountId.accountNumber", equalTo(accNum), "accountDetails[0].accountId.id",
		        equalTo(accId), "accountDetails[0].accountId.sourceSystem", equalTo("MANUAL"));

		// get account details for Partner
		this.context.put("ppid", this.accountsCommonTestData.getPartPid());
		this.context.put("accountNumber", this.accNumPartner);
		this.context.put("accId", this.accIdPartner);
		this.context.put("relationship", TestDataConstants.HH_PARTNER);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
		        "accountDetails[0].accountId.accountNumber", equalTo(accNumPartner), "accountDetails[0].accountId.id",
		        equalTo(accIdPartner), "accountDetails[0].accountId.sourceSystem", equalTo("MANUAL"));

		// get account details for Dependent
		this.context.put("ppid", this.accountsCommonTestData.getDependentPid());
		this.context.put("accountNumber", this.accNumDependent);
		this.context.put("accId", this.accIdDependent);
		this.context.put("relationship", TestDataConstants.HH_DEPENDENT);

		// Generate request body
		this.request.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_DETAILS_GET_TEMPLATE));

		// Call Account service
		this.response = this.request.log().ifValidationFails().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);

		// Assert on response
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200).body("resultCode",
		        equalTo(true), "userIdentifier.mid", equalTo(this.accountsCommonTestData.getMid()),
		        "accountDetails[0].accountId.accountNumber", equalTo(accNumDependent), "accountDetails[0].accountId.id",
		        equalTo(accIdDependent), "accountDetails[0].accountId.sourceSystem", equalTo("MANUAL"));

	}

	@AfterClass(alwaysRun = true)
	public void closeDBConnections()
	{
		this.p2TestDataUtil.closeSQLiteConnection();
	}

}
