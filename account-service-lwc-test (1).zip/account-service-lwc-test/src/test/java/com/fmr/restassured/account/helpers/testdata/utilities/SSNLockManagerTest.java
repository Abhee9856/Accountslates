package com.fmr.restassured.account.helpers.testdata.utilities;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.restassured.account.database.DatabaseConfigUtil;
import com.zaxxer.hikari.HikariDataSource;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

public abstract class SSNLockManagerTest extends PAPBaseServiceTest
{

	protected String ssn;

	protected boolean enableDbIsolation = false;

	protected HikariDataSource dataSource;

	private String tempDbPath;

	protected SSNLockManagerTest(Services service)
	{
		super(service);
	}

	@BeforeClass(alwaysRun = true)
	public void lockSSN()
	{
		if (ssn != null)
		{
			SSNLockManager.lock(ssn);
		}
	}

	@AfterClass(alwaysRun = true)
	public void unlockSSN()
	{
		if (ssn != null)
		{
			SSNLockManager.unlock(ssn);
		}
	}

	@BeforeClass(alwaysRun = true)
	public void setupIsolatedDb()
	{
		try
		{
			Path originalPath =
					Paths.get(getClass().getClassLoader().getResource("data/account_test_data.db")
							.toURI());
			tempDbPath = System.getProperty("java.io.tmpdir") + "/test_" + UUID.randomUUID() + ".db";
			Files.copy(originalPath, Paths.get(tempDbPath));
			dataSource = DatabaseConfigUtil.getIsolatedDataSource(tempDbPath);
		}
		catch (IOException | URISyntaxException e)
		{
			throw new RuntimeException("Failed to set up isolated DB", e);
		}
	}

	@AfterClass(alwaysRun = true)
	public void cleanupIsolatedDb()
	{
		try
		{
			if (dataSource != null)
			{
				dataSource.close();
			}
			if (tempDbPath != null)
			{
				Files.deleteIfExists(Paths.get(tempDbPath));
			}
		}
		catch (IOException e)
		{
			System.err.println("Failed to clean up test DB file: " + e.getMessage());
		}
	}

	protected void setSsn(String ssn)
	{
		this.ssn = ssn;
	}
}