/*
 * Copyright 2018, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.suitability.crud.retail;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.*;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;

import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsSuitabilityPaths;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;

import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.fmr.pap.restassured.utilities.IOUtil;

import org.apache.velocity.VelocityContext;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.ZonedDateTime;

/**
 * Tests CRUD operation for suitability against V1 for Retail accounts with single set of data.
 *
 * @author a601767
 * <p>
 * Updated by a608077 on 12/06/2021 to include: Changes for account level preferences(PFCP-6920)
 */
@Test(groups = {Tags.RETAIL, Tags.SUITABILITY, Tags.V1, Tags.CRITICAL})
public class Retail_Suitability_CRUD extends PAPBaseServiceTest
{

    // Data setup
    private AccountsCommonTestData accountsCommonTestData;

    private static final String LOG_TRACKING_ID = Retail_Suitability_CRUD.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;

    /**
     * Start and End years for accountPreferencesIA - both should be greater than the current year.
     */
    int startYear = ZonedDateTime.now().plusYears(1).getYear();

    int endYear = ZonedDateTime.now().plusYears(2).getYear();

    private VelocityContext context;

    private TestDataUtil testDataUtil;

    protected Retail_Suitability_CRUD()
    {
	super(Services.Account);
    }

    /**
     * Initialization method used to populate the TestData object based on the  SSN, set up the endpoint
     * for the test, and initialize the request context for Velocity with global data.
     */
    @BeforeClass
    public void init()
    {
	final String oAuth = AccountUtil.getOauthToken();
	accountsCommonTestData = TestDataUtil.populateRegressionTestData("account_suitability_CRUD_Retail", oAuth);

	this.testDataUtil = new TestDataUtil();

	String mid = accountsCommonTestData.getMid();
	DataCleanup.deleteCustomerDataFromCP("mid", mid, oAuth, "true");



	// create identity
	String ppid = Identity.createHouseholdIdentity("mid", mid, oAuth);

	accountsCommonTestData.setPpid(ppid);
	setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);
	accountsCommonTestData.setSourceSystem1("RETAIL");

	accountsCommonTestData.set("investmentPurpose", "Save for education");
	accountsCommonTestData.set("investmentPurposeId", "31");
	accountsCommonTestData.set("investmentKnowledge", "Limited");
	accountsCommonTestData.set("investmentKnowledgeId", "46");
	accountsCommonTestData.set("totalEstIncome", "$0 to $25K");
	accountsCommonTestData.set("totalEstIncomeId", "39");
	accountsCommonTestData.set("liquidNetWorth", "$0 to $50K");
	accountsCommonTestData.set("liquidNetWorthId", "49");
	accountsCommonTestData.set("netWorthRange", "$0 to $50K");
	accountsCommonTestData.set("netWorthRangeId", "53");
	accountsCommonTestData.set("taxBracket", "Under 15%");
	accountsCommonTestData.set("taxBracketId", "43");
	accountsCommonTestData.set("essentialExpenses", "Under 25%");
	accountsCommonTestData.set("essentialExpensesId", "57");
	accountsCommonTestData.set("spendingLikelihood", "Not Likely");
	accountsCommonTestData.set("spendingLikelihoodId", "62");
	accountsCommonTestData.set("investmentTimeHorizon", "Near Term (0-1 year)");
	accountsCommonTestData.set("investmentTimeHorizonId", "73");

	// Populate request variables
	context = new VelocityContext();
	context.put("mid", accountsCommonTestData.getMid());
	context.put("retailLid", accountsCommonTestData.getSsn());
	context.put("source", accountsCommonTestData.getSourceSystem1());
	context.put("ppid", accountsCommonTestData.getPpid());

    }

    /**
     * Get retail account info from the backend. Save the account number.
     */
    @Test
    public void getAccountInfo()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
	Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
		        response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
	    Assert.assertEquals(dssResultCode, false);
        }

	accountsCommonTestData.setMnemonic1(response.path("accountList[0].regCode.mnemonic"));
	accountsCommonTestData.setAccountNumber1(response.path("accountList[0].accountId.accountNumber"));
	accountsCommonTestData.setSourceSystem1(response.path("accountList[0].accountId.sourceSystem"));
	accountsCommonTestData.setDisplayName1(response.path("accountList[0].displayName"));
	accountsCommonTestData.setValue1(response.path("accountList[0].sourceMarketValue.amount.value"));
	accountsCommonTestData.setInstitutionName1(response.path("accountList[0].institutionName"));
    }

    /**
     * Create the retail account in CFP. Save the account ID.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getAccountInfo")
    public void createRetailAccount()
    {
	context.put("mnemonic", accountsCommonTestData.getMnemonic1());
	context.put("value", accountsCommonTestData.getValue1());
	context.put("source", accountsCommonTestData.getSourceSystem1());
	context.put("accountNumber", accountsCommonTestData.getAccountNumber1());
	context.put("displayName", accountsCommonTestData.getDisplayName1());
	context.put("institutionName", accountsCommonTestData.getInstitutionName1());

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()),
					"accountList[0].regCode.mnemonic",
					equalTo(accountsCommonTestData.getMnemonic1()),
					"accountList[0].accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()));

	// Gets and saves the CFP account ID
	accountsCommonTestData.setAccountId1(response.path("accountList[0].accountId.id"));
	context.put("accId", accountsCommonTestData.getAccountId1());
    }

    /**
     * Create the account suitability.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createRetailAccount")
    public void createAccountSuitability()
    {
	// Generate request body
	context.put("investPurp_Txt", accountsCommonTestData.get("investmentPurpose"));
	context.put("investPurp_Id", accountsCommonTestData.get("investmentPurposeId"));
	context.put("investKnow_Txt", accountsCommonTestData.get("investmentKnowledge"));
	context.put("investKnow_Id", accountsCommonTestData.get("investmentKnowledgeId"));
	context.put("annualIncRng_Txt", accountsCommonTestData.get("totalEstIncome"));
	context.put("annualIncRng_Id", accountsCommonTestData.get("totalEstIncomeId"));
	context.put("liqNWRng_Txt", accountsCommonTestData.get("liquidNetWorth"));
	context.put("liqNWRng_Id", accountsCommonTestData.get("liquidNetWorthId"));
	context.put("netWorthRng_Txt", accountsCommonTestData.get("netWorthRange"));
	context.put("netWorthRng_Id", accountsCommonTestData.get("netWorthRangeId"));
	context.put("taxBrktRng_Txt", accountsCommonTestData.get("taxBracket"));
	context.put("taxBrktRng_Id", accountsCommonTestData.get("taxBracketId"));
	context.put("essExpRng_Txt", accountsCommonTestData.get("essentialExpenses"));
	context.put("essExpRng_Id", accountsCommonTestData.get("essentialExpensesId"));
	context.put("spendLikeRng_Txt", accountsCommonTestData.get("spendingLikelihood"));
	context.put("spendLikeRng_Id", accountsCommonTestData.get("spendingLikelihoodId"));
	context.put("invesTimeHrzn_Txt", accountsCommonTestData.get("investmentTimeHorizon"));
	context.put("invesTimeHrzn_Id", accountsCommonTestData.get("investmentTimeHorizonId"));
	context.put("riskTolerance", 1);
	context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
	context.put("withdrawalStartYear", startYear);
	context.put("withdrawalEndYear", endYear);

	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_CREATE_TEMPLATE_V1));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.CREATE_ACCOUNTS_SUITABILITY_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200);
	Boolean resultCode = response.path("resultCode");
	Boolean dssResultCode =
			response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2'}.result");
	if (dssResultCode != null)
	{
	    org.testng.Assert.assertEquals(resultCode, false);
	}
	else
	{
	    org.testng.Assert.assertEquals(resultCode, true);
	}
	response.then().log().ifValidationFails().body("userIdentifier.mid", equalTo(accountsCommonTestData.getMid()))
			.body("userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()))
			.body("accountSuitability", not(empty()));
    }

    /**
     * Validate the suitability.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "createAccountSuitability")
    public void getSuitabilityAfterCreate()
    {
	// Generate request body
	context.put("externalDataSources", true);
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentPurpose.values[0].value",
					equalTo(accountsCommonTestData.get("investmentPurpose")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentKnowledge.values[0].value",
					equalTo(accountsCommonTestData.get("investmentKnowledge")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.annualIncomeRange.values[0].value",
					equalTo(accountsCommonTestData.get("totalEstIncome")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.liquidNetworthRange.values[0].value",
					equalTo(accountsCommonTestData.get("liquidNetWorth")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.networthRange.values[0].value",
					equalTo(accountsCommonTestData.get("netWorthRange")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.taxBracketRange.values[0].value",
					equalTo(accountsCommonTestData.get("taxBracket")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.essentialExpensesRange.values[0].value",
					equalTo(accountsCommonTestData.get("essentialExpenses")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.spendingLikelihoodRange.values[0].value",
					equalTo(accountsCommonTestData.get("spendingLikelihood")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentTimeHorizon.values[0].value",
					equalTo(accountsCommonTestData.get("investmentTimeHorizon")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentPurpose.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("investmentPurposeId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentKnowledge.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("investmentKnowledgeId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.annualIncomeRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("totalEstIncomeId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.liquidNetworthRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("liquidNetWorthId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.networthRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("netWorthRangeId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.taxBracketRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("taxBracketId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.essentialExpensesRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("essentialExpensesId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.spendingLikelihoodRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("spendingLikelihoodId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentTimeHorizon.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("investmentTimeHorizonId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountPreferencesIA", not(empty()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountPreferencesIA.riskTolerance",
					equalTo(1),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1()
							+ "'}.accountPreferencesIA.stockMarketDeclinePercent",
					equalTo("SELL_LESS_THAN_25"),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1()
							+ "'}.accountPreferencesIA.withdrawalStartYear",
					equalTo(startYear),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountPreferencesIA.withdrawalEndYear",
					equalTo(endYear));

    }

    /**
     * Update the suitability.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getSuitabilityAfterCreate")
    public void updateAccountSuitability()
    {
	// Update variables
	accountsCommonTestData.set("investmentPurpose", "Not Asked");
	accountsCommonTestData.set("investmentPurposeId", "92");
	accountsCommonTestData.set("investmentKnowledge", "Not Asked");
	accountsCommonTestData.set("investmentKnowledgeId", "90");
	accountsCommonTestData.set("totalEstIncome", "More than $100k");
	accountsCommonTestData.set("totalEstIncomeId", "42");
	accountsCommonTestData.set("liquidNetWorth", "More than $500K");
	accountsCommonTestData.set("liquidNetWorthId", "52");
	accountsCommonTestData.set("netWorthRange", "More than $500K");
	accountsCommonTestData.set("netWorthRangeId", "56");
	accountsCommonTestData.set("taxBracket", "Not Asked");
	accountsCommonTestData.set("taxBracketId", "88");
	accountsCommonTestData.set("essentialExpenses", "51% - 75%");
	accountsCommonTestData.set("essentialExpensesId", "59");
	accountsCommonTestData.set("spendingLikelihood", "Not Asked");
	accountsCommonTestData.set("spendingLikelihoodId", "96");
	accountsCommonTestData.set("investmentTimeHorizon", "Very Short (1-2 years)");
	accountsCommonTestData.set("investmentTimeHorizonId", "74");
	context.put("investPurp_Txt", accountsCommonTestData.get("investmentPurpose"));
	context.put("investPurp_Id", accountsCommonTestData.get("investmentPurposeId"));
	context.put("investKnow_Txt", accountsCommonTestData.get("investmentKnowledge"));
	context.put("investKnow_Id", accountsCommonTestData.get("investmentKnowledgeId"));
	context.put("annualIncRng_Txt", accountsCommonTestData.get("totalEstIncome"));
	context.put("annualIncRng_Id", accountsCommonTestData.get("totalEstIncomeId"));
	context.put("liqNWRng_Txt", accountsCommonTestData.get("liquidNetWorth"));
	context.put("liqNWRng_Id", accountsCommonTestData.get("liquidNetWorthId"));
	context.put("netWorthRng_Txt", accountsCommonTestData.get("netWorthRange"));
	context.put("netWorthRng_Id", accountsCommonTestData.get("netWorthRangeId"));
	context.put("taxBrktRng_Txt", accountsCommonTestData.get("taxBracket"));
	context.put("taxBrktRng_Id", accountsCommonTestData.get("taxBracketId"));
	context.put("essExpRng_Txt", accountsCommonTestData.get("essentialExpenses"));
	context.put("essExpRng_Id", accountsCommonTestData.get("essentialExpensesId"));
	context.put("spendLikeRng_Txt", accountsCommonTestData.get("spendingLikelihood"));
	context.put("spendLikeRng_Id", accountsCommonTestData.get("spendingLikelihoodId"));
	context.put("invesTimeHrzn_Txt", accountsCommonTestData.get("investmentTimeHorizon"));
	context.put("invesTimeHrzn_Id", accountsCommonTestData.get("investmentTimeHorizonId"));
	context.put("riskTolerance", 2);
	context.put("stockMarketDeclinePercent", "SELL_LESS_THAN_25");
	context.put("withdrawalStartYear", startYear);
	context.put("withdrawalEndYear", endYear);

	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_UPDATE_TEMPLATE_V1));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.UPDATE_ACCOUNTS_SUITABILITY_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountId.sourceSystem",
					equalTo(accountsCommonTestData.getSourceSystem1()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()));

    }

    /**
     * Validate the updated suitability.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "updateAccountSuitability")
    public void getSuitabilityAfterUpdate()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()),
					"userIdentifier.retailLid", equalTo(accountsCommonTestData.getSsn()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountId.accountNumber",
					equalTo(accountsCommonTestData.getAccountNumber1()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountId.id",
					equalTo(accountsCommonTestData.getAccountId1()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountId.owner.id",
					equalTo(accountsCommonTestData.getPpid()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentPurpose.values[0].value",
					equalTo(accountsCommonTestData.get("investmentPurpose")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentKnowledge.values[0].value",
					equalTo(accountsCommonTestData.get("investmentKnowledge")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.annualIncomeRange.values[0].value",
					equalTo(accountsCommonTestData.get("totalEstIncome")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.liquidNetworthRange.values[0].value",
					equalTo(accountsCommonTestData.get("liquidNetWorth")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.networthRange.values[0].value",
					equalTo(accountsCommonTestData.get("netWorthRange")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.taxBracketRange.values[0].value",
					equalTo(accountsCommonTestData.get("taxBracket")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.essentialExpensesRange.values[0].value",
					equalTo(accountsCommonTestData.get("essentialExpenses")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.spendingLikelihoodRange.values[0].value",
					equalTo(accountsCommonTestData.get("spendingLikelihood")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentTimeHorizon.values[0].value",
					equalTo(accountsCommonTestData.get("investmentTimeHorizon")),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentPurpose.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("investmentPurposeId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentKnowledge.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("investmentKnowledgeId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.annualIncomeRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("totalEstIncomeId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.liquidNetworthRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("liquidNetWorthId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.networthRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("netWorthRangeId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.taxBracketRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("taxBracketId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.essentialExpensesRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("essentialExpensesId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.spendingLikelihoodRange.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("spendingLikelihoodId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.investmentTimeHorizon.values[0].id",
					equalTo(Integer.valueOf(accountsCommonTestData.get("investmentTimeHorizonId"))),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountPreferencesIA", not(empty()),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountPreferencesIA.riskTolerance",
					equalTo(2),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1()
							+ "'}.accountPreferencesIA.stockMarketDeclinePercent",
					equalTo("SELL_LESS_THAN_25"),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1()
							+ "'}.accountPreferencesIA.withdrawalStartYear",
					equalTo(startYear),
					"accountSuitability.find{it.accountId.id == '" + accountsCommonTestData
							.getAccountId1() + "'}.accountPreferencesIA.withdrawalEndYear",
					equalTo(endYear));

    }

    /**
     * Delete the account.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "getSuitabilityAfterUpdate")
    public void deleteAccountSuitability()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"userIdentifier.mid", equalTo(accountsCommonTestData.getMid()));

    }

    /**
     * Validate no suitability is returned.
     * <p>
     * Version V1
     */
    @Test(dependsOnMethods = "deleteAccountSuitability")
    public void getSuitabilityAfterDelete()
    {
	// Generate request body
	request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_SUITABILITY_GET_TEMPLATE));

	// Call Account service
	response = request.log().ifValidationFails().post(AccountsSuitabilityPaths.GET_ACCOUNTS_SUITABILITY_V1);

	// Assert on response
	response.then().log().ifValidationFails()
			.statusCode(AccountConstants.HTTP_200)
			.body("resultCode", equalTo(true),
					"accountSuitability", empty());

    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections()
    {
	this.testDataUtil.closeSQLiteConnection();
    }
}
