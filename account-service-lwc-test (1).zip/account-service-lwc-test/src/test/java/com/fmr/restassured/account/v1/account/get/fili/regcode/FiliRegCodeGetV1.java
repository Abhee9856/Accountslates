/*
 * Copyright 2021, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.account.get.fili.regcode;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.Matchers.equalTo;

import org.apache.commons.collections.CollectionUtils;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountRegCodeTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.AccountsRegCodesDataProviderUtil;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;

/**
 * Tests for v1/account/get operation for FILI accounts using DataProvider (for handling multiiple regCodes)..
 *
 * @author a653510
 *
 */
@Test(groups = { "pipeline", "fili", "get", "v1" })
public class FiliRegCodeGetV1 extends PAPBaseServiceTest {
	
	protected FiliRegCodeGetV1() {
		super(Services.Account);
	}

	// Data setup
	private VelocityContext context;

	/** Instance to the test data utility class */
	private TestDataUtil testDataUtil;

	private String token;

	private String accNumber;

	private String maskedAccountNumber;

	private String displayName;

	/**
	 * Initialization method used to populate the UserIdentifiers object based on
	 * the default SSN, set up the endpoint for the test, and build the request body
	 * from Velocity.
	 */
	@BeforeClass(alwaysRun = true)
	public void init() {
		this.token = AccountUtil.getOauthToken();
		this.testDataUtil = new TestDataUtil();
		this.setDefaultRequestHeaders(this.token);

	}

	/**
	 * Test for getting Retail Accounts using data provider.
	 *
	 * Version V1
	 */
	@Test(dataProvider = "getFiliRegCodeData", dataProviderClass = AccountsRegCodesDataProviderUtil.class)
	public void getFiliRegCodeData(final AccountRegCodeTestData data) {
		this.context = new VelocityContext();
		this.context.put("filiLid", data.getSsn());
		this.context.put("mnemonicFilter", data.getRegCode1());
		this.context.put("mnemonicFilter2", data.getRegCode2());
		this.context.put("mnemonicFilter3", data.getRegCode3());
		this.context.put("source", data.getSrcFilter());

		this.request = this.request
				.body(IOUtil.generateJsonRequest(this.context, AccountConstants.ACCOUNT_GET_TEMPLATE));
		this.request.log().uri();
		this.response = this.request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
		this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
		.body("userIdentifier.filiLid", equalTo(data.getSsn()));

		if (CollectionUtils.isNotEmpty(this.response.path("accountList"))
				&& (this.response.jsonPath().getList("accountList").size() > 0)) {

			accNumber = response.path("accountList[0].accountId.accountNumber");
			maskedAccountNumber = TestDataUtil.getMaskedAccountNumber(accNumber);

			displayName = response.path("accountList[0].nickName") !=null ?
					response.path("accountList[0].nickName") + maskedAccountNumber : maskedAccountNumber;

			this.response.then().body("accountList[0].accountId", notNullValue())
					.body("accountList[0].accountId.owner.id", notNullValue())
					.body("accountList[0].accountId.accountNumber", notNullValue())
					.body("accountList[0].regCode.mnemonic", Matchers
							.isOneOf(new String[] { data.getRegCode1(), data.getRegCode2(), data.getRegCode3() }))
					.body("accountList[0].displayName", equalTo(displayName));
		}

	}

	/**
	 *
	 * Cleanup operation for SQLite DB connection
	 *
	 */
	@AfterClass(alwaysRun = true)
	public void cleanUpDBConnections() {
		this.testDataUtil.closeSQLiteConnection();
	}

}
