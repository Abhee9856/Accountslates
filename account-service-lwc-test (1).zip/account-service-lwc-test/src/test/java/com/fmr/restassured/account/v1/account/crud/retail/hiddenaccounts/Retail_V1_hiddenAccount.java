package com.fmr.restassured.account.v1.account.crud.retail.hiddenaccounts;

import com.fmr.ast.platform.account.domain.Account;
import com.fmr.ast.platform.account.domain.AccountId;
import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.apache.velocity.VelocityContext;
import org.hamcrest.Matchers;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.emptyArray;
import static org.hamcrest.Matchers.not;

public class Retail_V1_hiddenAccount extends PAPBaseServiceTest {

    protected Retail_V1_hiddenAccount() { super(Services.Account); }

    // Data setup
    private AccountsCommonTestData accountsCommonTestData = null;

    private VelocityContext context;

    private final float value = 120.0F;

    private final float updatedValue = 426.85f;

    private final String source = "RETAIL";

    private final String asOfDate1 = "2014-10-31";

    private static final String sourceSystem = "RETAIL";

    private String mid;// = "RetailAccountV1TestMid";

    /**
     * Instance to the test data utility class
     */
    private TestDataUtil testDataUtil;

    private String accId;

    private String accNumber;

    private String mnemonic;



    /**
     * Initialization method used to populate the UserIdentifiers object based on
     * the default SSN, set up the endpoint for the test, and build the request body
     * from Velocity.
     */
    @BeforeClass(alwaysRun = true)
    public void init() {
        RestAssured.filters(new RequestLoggingFilter(),new ResponseLoggingFilter());

        final String oAuth = AccountUtil.getOauthToken();
        accountsCommonTestData = TestDataUtil.populateRegressionTestData("retail_is_hidden_account", oAuth);
        testDataUtil = new TestDataUtil();
        this.mid = accountsCommonTestData.getMid();
        accountsCommonTestData.setMid(this.mid);
        accountsCommonTestData.setAsOfDate1(asOfDate1);
        accountsCommonTestData.setValue1(value);
        DataCleanup.deleteCustomerDataFromCP("mid", accountsCommonTestData.getMid(), oAuth, "true");


        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        setDefaultRequestHeaders(oAuth);

        // Populate request variables
        context = new VelocityContext();
        context.put("mid", accountsCommonTestData.getMid());
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("value", String.valueOf(value));

    }

    /**
     * Create Retail account with different combination of Regcodes from DataProvider.
     * <p>
     * Version V1
     */

    //Get account info from the backend.
    @Test
    public void getRetailAccountWithHidden() {
        // Generate request body
        this.context.put("source", this.source);
        this.context.put("externalDataSources", false);
        request.header("return-hidden-accounts", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200);
        Boolean resultCode = response.path("resultCode");
        Boolean dssResultCode =
                response.path("responseDiagnostic.externalSystemDiagnostic.find{it.source=='DSS_ACCOUNT_V2' && it.code == '5000'}.result");
        if (!resultCode)
        {
            Assert.assertEquals(dssResultCode, false);
        }
        response.then().log().ifValidationFails()
                .body("accountList", not(emptyArray()));

        accNumber = response.path("accountList.find{it.isHidden == true}.accountId.accountNumber");
        mnemonic = response.path("accountList.find{it.isHidden == true}.regCode.mnemonic");
    }

    //Create Retail Account
    @Test(dependsOnMethods = {"getRetailAccountWithHidden"})
    public void createRetailAccountWithHidden() {
        // Generate request body
        this.context.put("ppid", this.accountsCommonTestData.getPpid());
        this.context.put("value", String.valueOf(this.value));
        this.context.put("mnemonic", mnemonic);
        this.context.put("source", sourceSystem);
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("id", null);
        this.context.put("excludeExternalDataSources", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_CREATE_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.CREATE_ACCOUNT_V1);

        //Asset on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList[0].accountId.accountNumber", Matchers.notNullValue());

        accId = response.path("accountList[0].accountId.id");

    }

    // Validate the created account.
    @Test(dependsOnMethods = {"createRetailAccountWithHidden"})
    public void getRetailAccountAfterCreateWithHidden() {
        // Exclude external data sources
        this.context.put("source", this.source);
        this.context.put("externalDataSources", true);

        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        response.then().log().ifValidationFails()
                .statusCode(200)
                .body("resultCode",  equalTo(true))
                .body("accountList", not(emptyArray()))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(this.value));

    }

    // Update account
    @Test(dependsOnMethods = {"getRetailAccountAfterCreateWithHidden"})
    public void updateRetailAccountWithHidden() {
        // Generate request body
        this.context.put("source", sourceSystem);
        this.context.put("accId", accId);
        this.context.put("value", this.updatedValue);
        this.context.put("mnemonic", mnemonic);
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("excludeExternalDataSources", false);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_UPDATE_TEMPLATE));

        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.UPDATE_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(emptyArray()))
                .body("resultCode",  equalTo(true))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(updatedValue));

    }

    // Validate Updated account
    @Test(dependsOnMethods = {"updateRetailAccountWithHidden"})
    public void getRetailAccountAfterUpdateWithHidden() {
        // Exclude external data sources
        this.context.put("source", this.source);
        this.context.put("externalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);

        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200)
                .body("accountList", not(emptyArray()))
                .body("resultCode",  equalTo(true))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.accountNumber", equalTo(accNumber))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.accountId.sourceSystem", equalTo(source))
                .body("accountList.find{it.accountId.id=='" + accId + "'}.sourceMarketValue.amount.value", equalTo(updatedValue));
    }


    // Delete Account
    @Test(dependsOnMethods = {"getRetailAccountAfterUpdateWithHidden"})
    public void deleteRetailAccountWithHidden() {
        // Generate request body
        this.context.put("source", sourceSystem);
        this.context.put("value", this.updatedValue);
        this.context.put("mnemonic", mnemonic);
        this.context.put("displayName", this.accountsCommonTestData.getDisplayName1());
        this.context.put("institutionName", this.accountsCommonTestData.getInstitutionName1());
        this.context.put("asOfDate", this.accountsCommonTestData.getAsOfDate1());
        this.context.put("accountNumber", accNumber);
        this.context.put("id", accId);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_DELETE_TEMPLATE));

        // Call Account service response
        request.log().ifValidationFails().post(AccountsPaths.DELETE_ACCOUNT_V1);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);

    }

    //Validate Account after delete
    @Test(dependsOnMethods = {"deleteRetailAccountWithHidden"})
    public void getRetailAccountAfterDeleteWithHidden() {
        // Exclude external data sources
        this.context.put("source", this.source);
        this.context.put("externalDataSources", true);
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_GET_TEMPLATE));
        // Call Account service
        response = request.log().ifValidationFails().post(AccountsPaths.GET_ACCOUNT_V1);
        // Assert on response
        this.response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
    }

    /**
     * Cleanup operation for SQLite DB connection
     */
    @AfterClass(alwaysRun = true)
    public void cleanUpDBConnections() {
        testDataUtil.closeSQLiteConnection();
    }

}
