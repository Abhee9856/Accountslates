/*
 * Copyright 2022-2025, FMR LLC.
 * All Rights Reserved.
 * Fidelity Confidential Information
 */
package com.fmr.restassured.account.v1.composite.get.retail;

import com.fmr.pap.restassured.common.module.DataCleanup;
import com.fmr.pap.restassured.common.module.Identity;
import com.fmr.pap.restassured.core.PAPBaseServiceTest;
import com.fmr.pap.restassured.core.Services;
import com.fmr.pap.restassured.endpoints.accounts.AccountsCompositePaths;
import com.fmr.pap.restassured.endpoints.accounts.AccountsDetailsPaths;
import com.fmr.pap.restassured.utilities.IOUtil;
import com.fmr.restassured.account.helpers.AccountUtil;
import com.fmr.restassured.account.helpers.Tags;
import com.fmr.restassured.account.helpers.testdata.constants.AccountConstants;
import com.fmr.restassured.account.helpers.testdata.dto.AccountsCommonTestData;
import com.fmr.restassured.account.helpers.testdata.utilities.TestDataUtil;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.restassured.http.Header;
import io.restassured.specification.FilterableRequestSpecification;
import org.apache.velocity.VelocityContext;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.testng.AssertJUnit.assertFalse;

/**
 * @author a601767
 * @author a730306 - to get account numbers dynamically for testing serviceModelCode
 */
@Test(groups = {
		Tags.RETAIL,
		Tags.COMPOSITE,
		Tags.V1})
/*
TODO: Tests should be rewritten to check if serviceModelCode exists for a managed account.
 */
public class Retail_Composite_Get_serviceModelCode extends PAPBaseServiceTest
{

    protected Retail_Composite_Get_serviceModelCode()
    {
	super(Services.Account);
    }

    //Velocity Context
    private VelocityContext context;

    //Instance to the test data utility class
    private TestDataUtil testDataUtil;
    
    private FilterableRequestSpecification frs;

    //Logging Details
    private static final String LOG_TRACKING_ID = Retail_Composite_Get_serviceModelCode.class.getSimpleName();

    private static final String FSREQID = LOG_TRACKING_ID;
    
    private final String oAuth = AccountUtil.getOauthToken();
    private static final String APP_NAME = "Advice and Planning Platform";
    
    public static final String ACCOUNT_CATEGORY = "Brokerage";
    
    private String ssn;
    
    private String mid;
    
    private String sid;
    
    private final List<String> accountNumberList = new ArrayList<>();
    //list of service model code
    private final List<String> serviceModelCodeList = Arrays.asList("DIGITAL", "1ON1", "TEAM_POD");
    
    /**
     * Initialization method used to populate the UserIdentifiers object based on the default SSN, set up the endpoint
     * for the test, and build the request body from Velocity.
     */
    @BeforeClass
    public void init()
    {
        testDataUtil = new TestDataUtil();

        // Data setup
        final AccountsCommonTestData accountsCommonTestData =
                TestDataUtil.populateRegressionTestData("account_positions_get_Retail_100", oAuth);
        
        mid = accountsCommonTestData.getMid();
        sid = accountsCommonTestData.getSid().replace("-", "");
        ssn = accountsCommonTestData.getSsn();
        frs = (FilterableRequestSpecification) request;
        
        accountsCommonTestData.setMid(accountsCommonTestData.getMid());
        //Set default REST header with authorization token
        setDefaultRequestHeaders(AccountConstants.CALLING_APP_ID, AccountConstants.APP_ID, LOG_TRACKING_ID, FSREQID, oAuth);

        //Data cleanup
        DataCleanup.deleteCustomerDataFromCP(AccountConstants.MID, accountsCommonTestData.getMid(), oAuth, "true");

        accountsCommonTestData.setPpid(Identity.createHouseholdIdentity("mid", accountsCommonTestData.getMid(), oAuth));

        // Populate common variables for tests into context
        context = new VelocityContext();
        context.put("retailLid", accountsCommonTestData.getSsn());
        context.put("mid", accountsCommonTestData.getMid());
        context.put("ppid", accountsCommonTestData.getPpid());
        context.put("source", "RETAIL");
    }

    /**
     * Test to get the DSS digital account
     */
    @Test
    public void getDSS_V2()
    {
        frs = (FilterableRequestSpecification) request;
        //Set DSS Headers
        frs.removeHeaders();
        setDefaultRequestHeadersForDSS();
    
        // Generate request body
        context.put("acctCategory", ACCOUNT_CATEGORY);
    
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.TEMPLATE_DSS_ACCOUNT_V2));
    
        request.baseUri(AccountConstants.DSS_ACCOUNT_BASE_URI);
        response = request.post(AccountConstants.DSS_ACCOUNT_V2_PATH);
    
        JsonParser parser = new JsonParser();
        JsonObject responseBodyObj = (JsonObject) parser.parse(response.body().asString());
        responseBodyObj.keySet().forEach(objectKey -> {
            Object keyValue = responseBodyObj.get(objectKey);
            if (objectKey.equals("acctDetails"))
            {
                JSONArray detailsArray = new JSONArray(keyValue.toString());
                for (Object detailObject : detailsArray)
                {
                    JSONObject detailJsonObj = new JSONObject(detailObject.toString());
                    if (detailJsonObj.has("managedAcctDetail"))
                    {
                        JSONObject managedObj = detailJsonObj.getJSONObject("managedAcctDetail");
                        if (managedObj.has("svcModelCode"))
                        {
                            if (null != managedObj.get("svcModelCode") && serviceModelCodeList
                                            .contains(managedObj.get("svcModelCode").toString()))
                            {
                                accountNumberList.add(detailJsonObj.get("acctNum").toString());
                            }
                        }
                    }
                }
            }
        });
        assertFalse(accountNumberList.isEmpty());
    }

    /**
     * Get retail account info from the backend. Assert that serviceModelCode is returned.
     */
    @Test(dependsOnMethods = "getDSS_V2")
    public void getComposite()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Call Account service
        response = request.log().all().post(AccountsCompositePaths.GET_COMPOSITE_ACCOUNT_V1);
    
        for (String acctNumber : accountNumberList)
        {
            final String basePath = "accounts.find{it.account.accountId.accountNumber=='" + acctNumber + "'}";
            if (null != response.path(basePath))
            {
                // Assert on response
                response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
                String compositeServiceModelCode = response.path(basePath + ".details.serviceModelCode");
                Assert.assertTrue(serviceModelCodeList.contains(compositeServiceModelCode));
            }
        }
    }

    /**
     * Get retail account info from the backend. Assert that serviceModelCode is returned.
     */
    @Test(dependsOnMethods = "getDSS_V2")
    public void getDetails()
    {
        // Generate request body
        request.body(IOUtil.generateJsonRequest(context, AccountConstants.ACCOUNT_COMPOSITE_GET_TEMPLATE));

        // Call Account service
        response = request.log().all().post(AccountsDetailsPaths.GET_ACCOUNT_DETAILS_V1);
    
        for (String acctNumber : accountNumberList)
        {
            final String basePath = "accountDetails.find{it.accountId.accountNumber=='" + acctNumber + "'}";
            if (null != response.path(basePath))
            {
                // Assert on response
                response.then().log().ifValidationFails().statusCode(AccountConstants.HTTP_200);
                String detailsServiceModelCode = response.path(basePath + ".serviceModelCode");
                Assert.assertTrue(serviceModelCodeList.contains(detailsServiceModelCode));
            }
        }
    }
    
    /**
     * Setting default headers for DSS Services
     */
    private void setDefaultRequestHeadersForDSS()
    {
        this.request.given().header(new Header("AppId", "AP106532"))
                        .header(new Header("fsreqid", FSREQID))
                        .header(new Header("Authorization", oAuth))
                        .header(new Header("AppName", APP_NAME))
                        .header(new Header("rtazlid", this.ssn))
                        .header(new Header("rtazallrealmslids", "Retail=" + this.ssn))
                        .header(new Header("FACSC", "ROLE=FidCust" + "," + "SID=" + this.sid))
                        .header(new Header("FACMC", "MID=" + this.mid))
                        .header(new Header("FACFC", "SESSION_KEY=1"))
                        .header(new Header("Content-Type", "application/json"));
    }

    @AfterClass(alwaysRun = true)
    public void closeDBConnections()
    {
	testDataUtil.closeSQLiteConnection();
    }
}
